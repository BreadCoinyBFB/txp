This Kernel is only in Termux.

Note on the `cX/` directory above: it's an earlier, general-purpose
(hosted, transpiles to C) implementation of the cX language, kept for
reference — it is *not* what actually builds this kernel. The real
compiler is `../compiler/x86_64-elf-cxc`, a from-scratch freestanding
backend that compiles cX straight to x86_64 ELF64 with no C and no
libc anywhere in the chain (see its own README). This file's Build
section below was wrong about this for a while; fixed as of Stage 3.

Kernel24/
├── boot/
│   └── entry.asm       # _start — first code that actually runs
├── arch/x86_64/
│   ├── lowlevel.asm       # port I/O, control-register access, cpuid/rdmsr,
│   │                       # idt_load, kernel_image_end — every single-
│   │                       # instruction primitive cX has no syntax for
│   ├── idt/
│   │   └── idt.cx          # Interrupt Descriptor Table
│   └── interrupts/
│       ├── isr_stubs.asm    # ISR trampolines
│       └── isr.cx           # dispatch / exception reporting
├── kernel/
│   ├── main.cx           # kernel_main() — orchestrates everything below
│   ├── panic.cx
│   ├── bootinfo.cx
│   └── version.cx
├── memory/
│   ├── physical.cx       # bitmap physical memory manager
│   ├── align.cx          # alignment & bitmap math
│   ├── virtual.cx        # page tables, PTE_USER, per-process address spaces
│   └── heap.cx           # kmalloc/kfree
├── process/                # Stage 3: tasks, scheduler, syscalls
├── fs/                      # Stage 3: filesystem foundation
├── drivers/
│   ├── screen/screen.cx     # VGA text output
│   ├── pic/, timer/, keyboard/, serial/, storage/   # Stage 3
├── cX/                     # NOT the compiler this kernel is built with —
│                           # see the note below

├── tools/
│   └── patch_checksum.py   # same tool XLoader uses, same contract
├── docs/
│   ├── design.md            # memory map, hand-off contract, what's deferred
│   ├── cx-integration.md     # how cX grew pointers/extern/long for this
│   └── roadmap.md
├── linker.ld
├── Makefile
├── README.md
└── LICENSE

There is no hand-written C anywhere in this tree — every kernel-logic
file is `.cx`; only single-instruction primitives and the two stack-
frame-sensitive entry points stay in NASM. See `docs/cx-integration.md`.

## Build

Needs `nasm`, `ld`, `objcopy`, `g++` (to build
`../compiler/x86_64-elf-cxc` itself — a normal host program, not a
cross-compiler, despite living next to a bootloader), and `python3`.
No `x86_64-elf-gcc` or any other real cross-compiler: every `.cx` file
here (kernel logic *and*, as of Stage 3, `../../shell`/`../../init`)
compiles straight to x86_64 ELF64 objects through `x86_64-elf-cxc`
itself — see that compiler's own README and `docs/cx-integration.md`.
(This section used to say otherwise, from before that compiler existed
— corrected as of Stage 3.) From this directory:

```
make          # -> build/kernel24.bin
make cx-check # fast compile-only check of every .cx file, no nasm/ld needed
make clean
```

`cX/build/cxc` is built automatically the first time (`make -C cX`) if it
isn't already present — that step uses your regular host `g++`, not the
cross-compiler, since `cxc` is a normal program that runs on your machine
to *generate* the C that the cross-compiler then builds for the kernel.

Building from XLoader's own `Makefile` (one directory up) picks this up
automatically — `make` there detects `Kernel24/Makefile`, builds this
project, and uses its output in place of the placeholder stub. See
XLoader's `docs/memory-map.md` for the image contract both sides honor.

## Status

Early stage: done — see `docs/roadmap.md`. Screen output, a physical
memory manager, and interrupt handling are all in place, transpiled
from cX and boot-tested (built + disassembled-and-verified against
XLoader's real hand-off, the same way XLoader itself was).
