// terminal.cpp — the Terminal application: hosts the existing mX shell (cX) in a window.
// The shell keeps calling screen_print()/screen_putchar() and input's character reader exactly as
// in text mode; glue.cpp routes those calls here while a Terminal window exists.
#include "mx/apps.hpp"
#include "mx/wm.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
namespace mx {

constexpr int TCOLS = 80, TROWS = 120;
static char g_ch[TROWS][TCOLS]; static u8 g_at[TROWS][TCOLS];
static int g_row = 0, g_col = 0; static u8 g_color = 0x07;
static volatile bool g_active = false;
static long g_shellPid = -1; static volatile bool g_shellAlive = false;
static volatile int g_inq[64]; static volatile u32 g_ih = 0, g_it = 0;

static const Color VGA[16] = {
    rgb(0,0,0), rgb(0,0,170), rgb(0,170,0), rgb(0,170,170), rgb(170,0,0), rgb(170,0,170), rgb(170,85,0), rgb(170,170,170),
    rgb(85,85,85), rgb(85,85,255), rgb(85,255,85), rgb(85,255,255), rgb(255,85,85), rgb(255,85,255), rgb(255,255,85), rgb(255,255,255) };

bool term_active() { return g_active; }
static void clear_row(int r) { for (int c = 0; c < TCOLS; c++) { g_ch[r][c] = ' '; g_at[r][c] = g_color; } }
void term_clear() { for (int r = 0; r < TROWS; r++) clear_row(r); g_row = g_col = 0; ui_invalidate(); }
static void newline() {
    g_col = 0;
    if (g_row < TROWS - 1) { g_row++; return; }
    for (int r = 1; r < TROWS; r++) { mem_cpy(g_ch[r - 1], g_ch[r], TCOLS); mem_cpy(g_at[r - 1], g_at[r], TCOLS); }
    clear_row(TROWS - 1);
}
void term_color(int fg, int bg) { g_color = (u8)(((bg & 15) << 4) | (fg & 15)); }
void term_putc(char ch) {
    if (ch == '\n') newline();
    else if (ch == '\r') g_col = 0;
    else if (ch == '\t') { int n = 4 - (g_col % 4); while (n--) term_putc(' '); return; }
    else if (ch == '\b') term_backspace();
    else { if (g_col >= TCOLS) newline(); g_ch[g_row][g_col] = ch; g_at[g_row][g_col] = g_color; g_col++; }
    ui_invalidate();
}
void term_backspace() {
    if (g_col == 0) { if (g_row == 0) return; g_row--; g_col = TCOLS; }
    g_col--; g_ch[g_row][g_col] = ' '; g_at[g_row][g_col] = g_color; ui_invalidate();
}
void term_puts(const char* s) { while (*s) term_putc(*s++); }

long term_read_char() {
    for (;;) {
        if (g_ih != g_it) { int v = g_inq[g_it]; asm volatile("" ::: "memory"); g_it = (g_it + 1) % 64; return v; }
        hal_yield();
    }
}
static void inq_push(int v) { u32 n = (g_ih + 1) % 64; if (n == g_it) return; g_inq[g_ih] = v; asm volatile("" ::: "memory"); g_ih = n; }
void term_shell_died() { g_shellAlive = false; term_puts("\n[shell exited - press Enter to start it again]\n"); }

static void shell_task_entry() {
    shell_main();                 // returns only if the user typed `exit`
    term_shell_died();
    sys_exit(0);
    for (;;) sys_yield();
}
static void start_shell() {
    if (g_shellAlive) return;
    g_ih = g_it = 0;
    g_shellPid = task_create((long)&shell_task_entry, "shell");
    g_shellAlive = g_shellPid >= 0;
    if (!g_shellAlive) notify(N_ERROR, "Terminal", "Cannot start shell", "Out of tasks or memory.");
}

struct TermApp : App {
    int scrollBack = 0;
    void windowSpec(WindowSpec& s) override { s.title = "Terminal"; s.frame = Rect{ 70, 40, 8 * 80 + 2 * BORDER, 16 * 26 + TITLE_H + BORDER }; s.flags = WF_RESIZABLE; s.minW = 240; s.minH = 140; }
    void onCreate() override { g_active = true; term_color(7, 0); term_clear(); start_shell(); }
    bool onClose() override {
        g_active = false;
        if (g_shellAlive) { task_kill(g_shellPid); g_shellAlive = false; }
        return true;
    }
    void onPaint(Canvas& c) override {
        c.fill(c.bounds(), VGA[0]);
        int rows = c.h / FONT_H, cols = min(TCOLS, c.w / FONT_W);
        int first = g_row - rows + 1 - scrollBack; if (first < 0) first = 0;
        for (int r = 0; r < rows && first + r < TROWS; r++) {
            int sr = first + r;
            for (int col = 0; col < cols; col++) {
                u8 a = g_at[sr][col]; char ch = g_ch[sr][col];
                if ((a >> 4) & 15) c.fill(Rect{ col * FONT_W, r * FONT_H, FONT_W, FONT_H }, VGA[(a >> 4) & 15]);
                if (ch != ' ' && ch) c.glyph(col * FONT_W, r * FONT_H, (u8)ch, VGA[a & 15]);
            }
        }
        if (win && wm().focused() == win && scrollBack == 0 && ((ui_ticks() / 50) & 1) == 0) {
            int r = g_row - first; if (r >= 0 && r < rows && g_col < cols) c.fill(Rect{ g_col * FONT_W, r * FONT_H + FONT_H - 3, FONT_W, 2 }, VGA[7]);
        }
        if (scrollBack > 0) c.text(c.w - 100, 2, "[scrollback]", VGA[14]);
    }
    void onMouse(const UiMouse& m) override { if (m.kind == UiMouse::Wheel) { scrollBack = clamp(scrollBack - m.wheel * 3, 0, TROWS); invalidate(); } }
    void onKey(const KeyEvent& e) override {
        if (!e.down) return;
        if (e.key == K_PGUP) { scrollBack = clamp(scrollBack + 10, 0, TROWS); invalidate(); return; }
        if (e.key == K_PGDN) { scrollBack = clamp(scrollBack - 10, 0, TROWS); invalidate(); return; }
        scrollBack = 0;
        if (!g_shellAlive) { if (e.key == K_ENTER) { term_clear(); start_shell(); } return; }
        int v = 0;
        switch (e.key) {
        case K_ENTER: v = 10; break; case K_BACKSPACE: v = 8; break; case K_TAB: v = 9; break;
        case K_UP: v = 17; break; case K_DOWN: v = 18; break;
        case K_SPACE: v = ' '; break;
        case K_CHAR: if (!(e.mods & (MOD_CTRL | MOD_ALT))) v = e.ch; break;
        default: break;
        }
        if (v) inq_push(v);
        invalidate();
    }
    void onTick(long) override { static int n = 0; if (++n % 5 == 0) invalidate(); }    // cursor blink
};
App* make_terminal() { return new TermApp(); }

} // namespace mx
