#include "mx/display.hpp"
#include "mx/pci.hpp"
#include "mx/kapi.hpp"
#include "mx/gfx.hpp"
#include "mx/font.hpp"
namespace mx {

static DisplayInfo g_di = { false, 0, 0, 0, nullptr, 0, "none", 0, 0, 1, false };
static u64 g_bi_addr = 0; static int g_bi_w = 0, g_bi_h = 0, g_bi_pitch = 0, g_bi_bpp = 0;
static bool g_bga = false;

enum { BGA_IDX = 0x01CE, BGA_DATA = 0x01CF };
enum { BGA_ID = 0, BGA_XRES, BGA_YRES, BGA_BPP, BGA_ENABLE, BGA_BANK, BGA_VW, BGA_VH, BGA_XOFF, BGA_YOFF };
static void bga_w(u16 i, u16 v) { outw(BGA_IDX, i); outw(BGA_DATA, v); }
static u16  bga_r(u16 i) { outw(BGA_IDX, i); return inw(BGA_DATA); }

void display_set_bootinfo(u64 a, int w, int h, int pitch, int bpp) { g_bi_addr = a; g_bi_w = w; g_bi_h = h; g_bi_pitch = pitch; g_bi_bpp = bpp; }
const DisplayInfo& display_info() { return g_di; }

// Identity-map [phys, phys+bytes) uncached. The kernel's page tables only cover the first 8 MiB,
// and a PCI framebuffer lives far above that (QEMU: 0xFD000000).
static u64 g_mappedBytes = 0;
static bool map_fb(u64 phys, u64 bytes) {
    for (u64 off = g_mappedBytes; off < bytes; off += 4096)
        if (!vmm_map((long)(phys + off), (long)(phys + off), 0x2 | 0x8 | 0x10)) return false;  // RW | PWT | PCD
    if (bytes > g_mappedBytes) g_mappedBytes = bytes;
    return true;
}

bool display_init(int w, int h) {
    if (g_bi_addr && g_bi_bpp == 32 && g_bi_w > 0) {               // XLoader-provided framebuffer
        if (!map_fb(g_bi_addr, (u64)g_bi_pitch * (u64)g_bi_h)) return false;
        g_di.ok = true; g_di.w = g_bi_w; g_di.h = g_bi_h; g_di.pitchPixels = g_bi_pitch / 4; g_di.pw = g_bi_w; g_di.ph = g_bi_h; g_di.scale = 1; g_di.canSwitch = false;
        g_di.lfb = (u32*)(uintptr_t)g_bi_addr; g_di.phys = g_bi_addr; scopy(g_di.driver, "BootInfo framebuffer", 32);
        return true;
    }
    pci_scan();
    const PciDev* v = pci_find(0x1234, 0x1111);                     // Bochs/QEMU std VGA
    if (!v) v = pci_find(0x80EE, 0xBEEF);                           // VirtualBox VGA speaks BGA too
    if (!v) return false;
    u16 id = bga_r(BGA_ID);
    if (id < 0xB0C0 || id > 0xB0CF) return false;
    u32 bar0 = v->bar[0];
    if (bar0 & 1) return false;                                     // I/O BAR: not a framebuffer
    u64 phys = bar0 & ~0xFu;
    if (!phys) return false;
    pci_enable(*v, false);
    bga_w(BGA_ENABLE, 0);
    bga_w(BGA_XRES, (u16)w); bga_w(BGA_YRES, (u16)h); bga_w(BGA_BPP, 32);
    bga_w(BGA_VW, (u16)w); bga_w(BGA_VH, (u16)h); bga_w(BGA_XOFF, 0); bga_w(BGA_YOFF, 0);
    bga_w(BGA_ENABLE, 0x01 | 0x40);                                 // enabled + linear framebuffer
    if (bga_r(BGA_XRES) != w || bga_r(BGA_YRES) != h || bga_r(BGA_BPP) != 32) { bga_w(BGA_ENABLE, 0); return false; }
    if (!map_fb(phys, (u64)w * (u64)h * 4)) { bga_w(BGA_ENABLE, 0); return false; }
    g_bga = true;
    g_di.ok = true; g_di.w = w; g_di.h = h; g_di.pitchPixels = w; g_di.lfb = (u32*)(uintptr_t)phys; g_di.phys = phys; g_di.pw = w; g_di.ph = h; g_di.scale = 1; g_di.canSwitch = true;
    scopy(g_di.driver, "Bochs VBE (BGA)", 32);
    return true;
}

bool display_set_mode(int w, int h, int scale) {
    if (!g_di.ok || !g_bga || (scale != 1 && scale != 2)) return false;
    int pw = w * scale, ph = h * scale;
    if (pw < 320 || ph < 200 || pw > 2560 || ph > 1600) return false;
    u64 oldPw = (u64)g_di.pw, oldPh = (u64)g_di.ph;
    if (!map_fb(g_di.phys, (u64)pw * (u64)ph * 4)) return false;
    bga_w(BGA_ENABLE, 0);
    bga_w(BGA_XRES, (u16)pw); bga_w(BGA_YRES, (u16)ph); bga_w(BGA_BPP, 32); bga_w(BGA_VW, (u16)pw); bga_w(BGA_VH, (u16)ph); bga_w(BGA_XOFF, 0); bga_w(BGA_YOFF, 0);
    bga_w(BGA_ENABLE, 0x01 | 0x40);
    if (bga_r(BGA_XRES) != pw || bga_r(BGA_YRES) != ph) {                         // the adapter refused (not enough video memory?): go back
        bga_w(BGA_ENABLE, 0); bga_w(BGA_XRES, (u16)oldPw); bga_w(BGA_YRES, (u16)oldPh); bga_w(BGA_BPP, 32); bga_w(BGA_VW, (u16)oldPw); bga_w(BGA_VH, (u16)oldPh); bga_w(BGA_ENABLE, 0x01 | 0x40);
        return false;
    }
    g_di.w = w; g_di.h = h; g_di.pw = pw; g_di.ph = ph; g_di.scale = scale; g_di.pitchPixels = pw;
    return true;
}

static u32 g_row[2560 * 2];                                                     // one scaled output row
void display_present_block(const u32* src, int sp, int dx, int dy, int w, int h) {
    if (!g_di.ok) return;
    if (g_di.scale == 1) { for (int y = 0; y < h; y++) mx_copy32(g_di.lfb + (dy + y) * g_di.pitchPixels + dx, src + y * sp, (size_t)w); return; }
    for (int y = 0; y < h; y++) {                                               // 2x: duplicate every pixel horizontally and every row vertically
        const u32* s = src + y * sp; for (int x = 0; x < w; x++) { g_row[2 * x] = s[x]; g_row[2 * x + 1] = s[x]; }
        u32* d0 = g_di.lfb + (2 * (dy + y)) * g_di.pitchPixels + 2 * dx;
        mx_copy32(d0, g_row, (size_t)(2 * w)); mx_copy32(d0 + g_di.pitchPixels, g_row, (size_t)(2 * w));
    }
}
void display_present(const u32* scene, int sp, const Rect& r0) {
    Rect r = r0.intersect(Rect{ 0, 0, g_di.w, g_di.h });
    if (r.empty()) return;
    display_present_block(scene + r.y * sp + r.x, sp, r.x, r.y, r.w, r.h);
}

// ---- QEMU fw_cfg (ports 0x510/0x511): read the file "opt/mx/display" if the host supplied one ----
static bool fwcfg_read_file(const char* name, char* out, int cap) {
    outw(0x510, 0x0000); char sig[4]; for (int i = 0; i < 4; i++) sig[i] = (char)inb(0x511);
    if (sig[0] != 'Q' || sig[1] != 'E' || sig[2] != 'M' || sig[3] != 'U') return false;
    outw(0x510, 0x0019);                                                        // FW_CFG_FILE_DIR
    u32 count = 0; for (int i = 0; i < 4; i++) count = (count << 8) | inb(0x511);   // big-endian
    for (u32 f = 0; f < count && f < 64; f++) {
        u32 size = 0; for (int i = 0; i < 4; i++) size = (size << 8) | inb(0x511);
        u16 sel = 0; for (int i = 0; i < 2; i++) sel = (u16)((sel << 8) | inb(0x511));
        inb(0x511); inb(0x511);
        char nm[56]; for (int i = 0; i < 56; i++) nm[i] = (char)inb(0x511);
        if (seq(nm, name)) {
            outw(0x510, sel); int n = (int)min<u32>(size, (u32)cap - 1); for (int i = 0; i < n; i++) out[i] = (char)inb(0x511); out[n] = 0; return true;
        }
    }
    return false;
}
bool fwcfg_display_request(int* w, int* h, int* scale) {
    char b[32]; if (!fwcfg_read_file("opt/mx/display", b, sizeof b)) return false;
    int v[3] = { 0, 0, 1 }, k = 0; for (const char* p = b; *p && k < 3; p++) { if (*p >= '0' && *p <= '9') v[k] = v[k] * 10 + (*p - '0'); else if (*p == 'x' || *p == 'X') { k++; if (k < 3) v[k] = 0; } }
    if (v[0] < 320 || v[1] < 200 || v[0] > 1024 || v[1] > 768) return false;
    *w = v[0]; *h = v[1]; *scale = v[2] == 2 ? 2 : 1; return true;
}

static void vga_reg(u16 port, u8 idx, u8 val) { outb(port, idx); outb((u16)(port + 1), val); }
// Writing 32 bpp pixels clobbers VGA plane 2 (the text font). Reload our 8x16 glyphs (ASCII range) so the text
// console, the panic screen and the safe-mode shell are readable again after a trip through graphics.
static void vga_restore_font() {
    vga_reg(0x3C4, 0x02, 0x04);      // sequencer map mask: plane 2 only
    vga_reg(0x3C4, 0x04, 0x07);      // sequential (non odd/even) memory access
    vga_reg(0x3CE, 0x04, 0x02);      // read plane 2
    vga_reg(0x3CE, 0x05, 0x00);      // write mode 0, no odd/even
    vga_reg(0x3CE, 0x06, 0x00);      // map the 64 KiB window at 0xA0000
    volatile u8* f = (volatile u8*)0xA0000;
    for (int c = 0; c < 256; c++) for (int r = 0; r < 32; r++) f[c * 32 + r] = 0;
    for (int c = 0x20; c < 0x7F; c++) for (int r = 0; r < 16; r++) f[c * 32 + r] = font8x16[c - 0x20][r];
    vga_reg(0x3C4, 0x02, 0x03);      // back to text mode: planes 0+1
    vga_reg(0x3C4, 0x04, 0x03);
    vga_reg(0x3CE, 0x04, 0x00);
    vga_reg(0x3CE, 0x05, 0x10);
    vga_reg(0x3CE, 0x06, 0x0E);      // text window at 0xB8000
}
void display_text_mode() {
    if (g_bga) { bga_w(BGA_ENABLE, 0); g_bga = false; }             // back to the VGA text console
    g_di.ok = false;
    vga_restore_font();
    volatile u16* t = (volatile u16*)0xB8000; for (int i = 0; i < 80 * 25; i++) t[i] = 0x0720;
}
} // namespace mx
