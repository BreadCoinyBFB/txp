// appreg.cpp — "a proper way for mX to recognize installed applications".
//
// Every application is described by a small manifest file in /system/apps/<id>.mxapp:
//     name=Terminal / version=1.0 / icon=terminal / exec=builtin:terminal /
//     perms=terminal,process / resources=/system/resources/terminal / singleton=1 / desktop=1
// At boot the registry scans that folder and builds its table from the files, so a manifest can
// be edited (e.g. to tighten permissions) or removed (to "uninstall") without touching code.
// `exec=builtin:<id>` binds to a factory compiled into the kernel image; there is no on-disk
// executable loader yet, which is the seam where TSX -> mX app development plugs in later
// (exec=file:/apps/foo.mxe).
#include "mx/sys.hpp"
#include "mx/ui.hpp"
#include "mx/wm.hpp"
#include "mx/kapi.hpp"
namespace mx {

static struct Builtin { char id[16]; AppFactory f; } g_builtin[APPS_MAX]; static int g_nb = 0;
static AppManifest g_apps[APPS_MAX]; static int g_na = 0;
// running instance per app id (keyed by id, because the manifest table is re-sorted on every rescan)
static struct Inst { char id[16]; App* app; } g_inst[APPS_MAX];
static App*& inst_slot(const char* id) {
    for (auto& i : g_inst) if (i.app && seq(i.id, id)) return i.app;
    for (auto& i : g_inst) if (!i.app) { scopy(i.id, id, 16); return i.app; }
    return g_inst[0].app;
}
static App* inst_get(const char* id) { App* a = inst_slot(id); return (a && wm().find(a)) ? a : nullptr; }

void apps_register_builtin(const char* id, AppFactory f) {
    if (g_nb < APPS_MAX) { scopy(g_builtin[g_nb].id, id, 16); g_builtin[g_nb].f = f; g_nb++; }
}
static AppFactory builtin_factory(const char* id) { for (int i = 0; i < g_nb; i++) if (seq(g_builtin[i].id, id)) return g_builtin[i].f; return nullptr; }

// Default manifests for the built-in apps.
static const struct Def { const char* id; const char* name; const char* icon; const char* perms; const char* hidden; int single; int desktop; int core; } DEFS[] = {
    { "terminal", "Terminal",        "terminal", "terminal,process",       "0", 1, 1, 1 },
    { "files",    "mX Files",        "files",    "notify",                  "0", 0, 1, 1 },
    { "settings", "mX Settings",     "settings", "settings-read",           "0", 1, 1, 1 },
    { "appcenter","App Center",      "store",    "notify",                  "0", 1, 1, 1 },
    { "monitor",  "System Monitor",  "monitor",  "sysmon",                  "0", 1, 1, 1 },
    { "notepad",  "Notepad",         "notepad",  "notify",                  "0", 0, 0, 0 },
    { "calc",     "Calculator",      "calc",     "notify",                  "0", 0, 0, 0 },
    { "about",    "About mX",        "about",    "notify",                  "0", 1, 0, 0 },
    { "diag",     "Diagnostics",     "diagnostics", "sysmon",               "0", 1, 0, 0 },
    { "recovery", "Recovery Tools",  "recovery", "recovery,admin",          "0", 1, 0, 1 },
};

static void def_text(const Def& d, char* body, int cap) {
    sfmt(body, cap, "name=%s\nversion=4.1\nicon=%s\nexec=builtin:%s\nperms=%s\nresources=/system/resources/%s\nsingleton=%d\ndesktop=%d\ncore=%d\n",
         d.name, d.icon, d.id, d.perms, d.id, d.single, d.desktop, d.core);
}
static int g_installed = 0, g_installFail = 0, g_fromVfs = 0, g_fallback = 0;
bool apps_install_manifests() {
    FsSys sys;
    bool dirsOk = fs_mkdir_p("/system/apps") && fs_mkdir_p("/system/resources");
    g_installed = g_installFail = 0;
    for (auto& d : DEFS) {
        char path[64], body[300];
        sfmt(path, sizeof path, "/system/apps/%s.mxapp", d.id);
        char tomb[64]; sfmt(tomb, sizeof tomb, "/system/apps/%s.removed", d.id);
        if (fs_exists(tomb)) continue;                       // uninstalled by the user: leave it gone
        if (fs_exists(path)) { g_installed++; continue; }    // never overwrite an edited manifest
        def_text(d, body, sizeof body);
        if (fs_write(path, body, slen(body))) g_installed++; else g_installFail++;
    }
    return dirsOk && g_installFail == 0;
}
void apps_stats(int* installed, int* installFail, int* fromVfs, int* fallback) { *installed = g_installed; *installFail = g_installFail; *fromVfs = g_fromVfs; *fallback = g_fallback; }

static IconId icon_by_name(const char* n) { for (int i = 0; i < IC_COUNT; i++) if (seq(icon_name((IconId)i), n)) return (IconId)i; return IC_FILE; }

static bool parse_manifest(const char* id, const char* text, int n, AppManifest& m) {
    mem_set(&m, 0, sizeof m);
    scopy(m.id, id, sizeof m.id); scopy(m.version, "?", sizeof m.version); m.icon = IC_FILE;
    int i = 0; bool haveName = false, haveExec = false;
    while (i < n) {
        char key[12], val[48]; int k = 0, v = 0;
        while (i < n && text[i] != '=' && text[i] != '\n' && k < 11) key[k++] = text[i++]; key[k] = 0;
        if (i < n && text[i] == '=') i++;
        while (i < n && text[i] != '\n' && v < 47) val[v++] = text[i++]; val[v] = 0;
        while (i < n && text[i] != '\n') i++; i++;
        if (seq(key, "name")) { scopy(m.name, val, sizeof m.name); haveName = true; }
        else if (seq(key, "version")) scopy(m.version, val, sizeof m.version);
        else if (seq(key, "icon")) m.icon = icon_by_name(val);
        else if (seq(key, "exec")) { scopy(m.exec, val, sizeof m.exec); haveExec = true; }
        else if (seq(key, "resources")) scopy(m.resources, val, sizeof m.resources);
        else if (seq(key, "singleton")) m.singleton = satoi(val) != 0;
        else if (seq(key, "desktop")) m.desktop = satoi(val) != 0;
        else if (seq(key, "hidden")) m.hidden = satoi(val) != 0;
        else if (seq(key, "core")) m.core = satoi(val) != 0;
        else if (seq(key, "perms")) {
            int s = 0;
            for (int j = 0;; j++) {
                if (val[j] == ',' || val[j] == 0) { char t[16]; int l = min(j - s, 15); for (int q = 0; q < l; q++) t[q] = val[s + q]; t[l] = 0; m.perms |= perm_from_name(t); s = j + 1; if (val[j] == 0) break; }
            }
        }
    }
    if (!haveName || !haveExec) return false;
    if (sstarts(m.exec, "builtin:")) m.factory = builtin_factory(m.exec + 8);
    return m.factory != nullptr;                              // file: executables aren't loadable yet
}

int apps_scan() {
    g_na = 0;
    FsEntry list[FS_MAX_LIST]; int n = fs_list("/system/apps", list, FS_MAX_LIST);
    for (int i = 0; i < n && g_na < APPS_MAX; i++) {
        int l = slen(list[i].name);
        if (list[i].dir || l < 7 || !seq(list[i].name + l - 6, ".mxapp")) continue;
        char id[16]; int il = min(l - 6, 15); for (int q = 0; q < il; q++) id[q] = list[i].name[q]; id[il] = 0;
        char path[64], text[VFS_BLOCK_SIZE + 1]; int tn = 0;
        sfmt(path, sizeof path, "/system/apps/%s", list[i].name);
        if (fs_read(path, text, sizeof text, &tn) && parse_manifest(id, text, tn, g_apps[g_na])) g_na++;
    }
    g_fromVfs = g_na; g_fallback = 0;
    // A built-in app must never be unlaunchable just because its manifest file is missing/unreadable (disk full,
    // filesystem trouble, a deleted file): synthesise the default manifest for any built-in not found above.
    for (auto& d : DEFS) {
        char tomb[64]; sfmt(tomb, sizeof tomb, "/system/apps/%s.removed", d.id);
        if (apps_find(d.id) || g_na >= APPS_MAX || !builtin_factory(d.id) || fs_exists(tomb)) continue;
        char body[300]; def_text(d, body, sizeof body);
        if (parse_manifest(d.id, body, slen(body), g_apps[g_na])) { g_na++; g_fallback++; }
    }
    // stable, human-friendly order: the built-ins in DEFS order, then anything else by name
    auto rank = [](const char* id) { for (unsigned i = 0; i < sizeof DEFS / sizeof DEFS[0]; i++) if (seq(DEFS[i].id, id)) return (int)i; return 100; };
    for (int i = 1; i < g_na; i++) { AppManifest v = g_apps[i]; int j = i - 1;
        while (j >= 0 && (rank(g_apps[j].id) > rank(v.id) || (rank(g_apps[j].id) == rank(v.id) && scmp(g_apps[j].name, v.name) > 0))) { g_apps[j + 1] = g_apps[j]; j--; }
        g_apps[j + 1] = v; }
    return g_na;
}
int apps_count() { return g_na; }
const AppManifest* apps_at(int i) { return (i >= 0 && i < g_na) ? &g_apps[i] : nullptr; }
const AppManifest* apps_find(const char* id) { for (int i = 0; i < g_na; i++) if (seq(g_apps[i].id, id)) return &g_apps[i]; return nullptr; }

const char* apps_perm_text(u32 p, char* out, int cap) {
    static const struct { u32 v; const char* n; } t[] = { {P_FILES_ALL,"files"},{P_FILES_SYSTEM,"system-files"},{P_SETTINGS_READ,"settings-read"},{P_SETTINGS_WRITE,"settings"},
        {P_NETWORK,"network"},{P_NOTIFY,"notify"},{P_ADMIN,"admin"},{P_PROCESS,"process"},{P_TERMINAL,"terminal"},{P_USERS,"users"},{P_SYSMON,"sysmon"},{P_RECOVERY,"recovery"} };
    out[0] = 0;
    for (auto& e : t) if (p & e.v) { if (out[0]) scat(out, ", ", cap); scat(out, e.n, cap); }
    if (!out[0]) scopy(out, "none", cap);
    return out;
}

Window* app_open(App* a, IconId icon) {
    WindowSpec s; a->windowSpec(s);
    Window* w = wm().create(a, s.title, s.frame, s.flags, icon, s.minW, s.minH);
    if (!w) delete a;
    return w;
}

// ---- management API ----
static bool manifest_path(const char* id, char* out, int cap) { for (const char* c = id; *c; c++) if (*c == '/' || *c == '.') return false; sfmt(out, cap, "/system/apps/%s.mxapp", id); return true; }
bool apps_set_desktop(const char* id, bool on) {
    FsSys sys; char path[64], text[VFS_BLOCK_SIZE + 1], out[VFS_BLOCK_SIZE + 1]; int n = 0;
    if (!manifest_path(id, path, sizeof path) || !fs_read(path, text, sizeof text, &n)) return false;
    out[0] = 0; bool done = false; int i = 0;
    while (i < n) {
        char line[96]; int k = 0; while (i < n && text[i] != '\n' && k < 95) line[k++] = text[i++]; line[k] = 0; if (i < n && text[i] == '\n') i++;
        if (sstarts(line, "desktop=")) { scat(out, on ? "desktop=1" : "desktop=0", sizeof out); done = true; } else scat(out, line, sizeof out);
        scat(out, "\n", sizeof out);
    }
    if (!done) { scat(out, on ? "desktop=1\n" : "desktop=0\n", sizeof out); }
    bool ok = fs_write(path, out, slen(out)); apps_scan(); return ok;
}
bool apps_uninstall(const char* id) {
    const AppManifest* m = apps_find(id); if (!m || m->core) return false;
    if (!(user_perms() & P_ADMIN)) return false;
    FsSys sys; char path[64], tomb[64]; if (!manifest_path(id, path, sizeof path)) return false;
    app_close_all(id);
    sfmt(tomb, sizeof tomb, "/system/apps/%s.removed", id); fs_write(tomb, "", 0);
    bool ok = fs_delete(path); apps_scan(); audit(users_current() ? users_current()->name : "system", "app uninstalled"); return ok;
}
bool apps_install(const char* id) {
    if (!(user_perms() & P_ADMIN)) return false;
    FsSys sys; char tomb[64]; sfmt(tomb, sizeof tomb, "/system/apps/%s.removed", id); fs_delete(tomb);
    apps_install_manifests(); apps_scan(); return apps_find(id) != nullptr;
}
int apps_removed(const char** ids, const char** names, int max) {
    int n = 0;
    for (auto& d : DEFS) { char tomb[64]; sfmt(tomb, sizeof tomb, "/system/apps/%s.removed", d.id); if (fs_exists(tomb) && builtin_factory(d.id) && n < max) { ids[n] = d.id; names[n] = d.name; n++; } }
    return n;
}
bool app_running(const char* id) { return inst_get(id) != nullptr; }
int app_close_all(const char* id) { App* a = inst_get(id); if (!a) return 0; wm().requestClose(wm().find(a)); return 1; }

bool app_launch(const char* id) {
    const AppManifest* m = apps_find(id);
    if (!m) { notifyf(N_ERROR, "mX", "Application not found", "No manifest for '%s' in /system/apps.", id); return false; }
    u32 have = user_perms();
    if ((have & m->perms) != m->perms) {
        char need[80]; apps_perm_text(m->perms & ~have, need, sizeof need);
        notifyf(N_ERROR, m->name, "Permission denied", "%s needs: %s", m->name, need);
        return false;
    }
    if (m->singleton) { App* run = inst_get(id); if (run) { wm().setFocus(wm().find(run)); return true; } }
    App* a = m->factory();
    if (!a) return false;
    Window* w = app_open(a, m->icon);
    inst_slot(id) = w ? a : nullptr;
    return w != nullptr;
}
}
