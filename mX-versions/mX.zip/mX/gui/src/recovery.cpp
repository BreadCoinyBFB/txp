#include "mx/recovery.hpp"
#include "mx/apps.hpp"
#include "mx/desktop.hpp"
#include "mx/display.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
namespace mx {

// 22-byte record at CMOS offset 0 (kernel HAL adds 0x40, see hal_kernel.cpp)
struct Rec { u8 m0, m1, attempts, flags, vec; u32 rip, err; char msg[8]; u8 sum; } __attribute__((packed));
enum { RF_CRASH = 1, RF_RECOVERY_NEXT = 2 };
static Rec g_rec; static bool g_loaded = false, g_forced = false;

static u8 checksum(const Rec& r) { const u8* p = (const u8*)&r; u8 s = 0x5A; for (unsigned i = 0; i < sizeof r - 1; i++) s = (u8)(s + p[i] * 3 + 1); return s; }
static void load() {
    if (g_loaded) return; g_loaded = true;
    hal_cmos_read(0, (u8*)&g_rec, sizeof g_rec);
    if (g_rec.m0 != 'm' || g_rec.m1 != 'X' || g_rec.sum != checksum(g_rec)) { mem_set(&g_rec, 0, sizeof g_rec); g_rec.m0 = 'm'; g_rec.m1 = 'X'; }
}
static void store() { g_rec.sum = checksum(g_rec); hal_cmos_write(0, (const u8*)&g_rec, sizeof g_rec); }

void recovery_boot_begin() {
    load();
    if (g_rec.attempts < 250) g_rec.attempts++;
    g_forced = g_rec.attempts >= 4 || (g_rec.flags & RF_RECOVERY_NEXT);
    g_rec.flags &= (u8)~RF_RECOVERY_NEXT;
    store();
}
void recovery_mark_stable() { load(); if (g_rec.attempts) { g_rec.attempts = 0; store(); } }
bool recovery_forced() { return g_forced; }
int recovery_attempts() { load(); return g_rec.attempts; }
bool recovery_get_crash(CrashInfo& o) {
    load(); o.valid = (g_rec.flags & RF_CRASH) != 0; o.vector = g_rec.vec; o.rip = g_rec.rip; o.err = g_rec.err;
    for (int i = 0; i < 8; i++) o.msg[i] = g_rec.msg[i]; o.msg[8] = 0; return o.valid;
}
void recovery_clear_crash() { load(); g_rec.flags &= (u8)~RF_CRASH; store(); }
void recovery_note_crash(u8 v, u32 e, u32 rip, const char* msg) {
    load(); g_rec.flags |= RF_CRASH; g_rec.vec = v; g_rec.err = e; g_rec.rip = rip;
    for (int i = 0; i < 8; i++) g_rec.msg[i] = (msg && msg[i]) ? msg[i] : 0;
    if (msg) { int i = 0; for (; i < 8 && msg[i]; i++) g_rec.msg[i] = msg[i]; for (; i < 8; i++) g_rec.msg[i] = 0; }
    store();
}
void recovery_request_recovery_next(bool on) { load(); if (on) g_rec.flags |= RF_RECOVERY_NEXT; else g_rec.flags &= (u8)~RF_RECOVERY_NEXT; store(); }
bool recovery_next_requested() { load(); return (g_rec.flags & RF_RECOVERY_NEXT) != 0; }
void recovery_announce_crash() {
    CrashInfo ci; if (!recovery_get_crash(ci)) return;
    notifyf(N_ERROR, "Recovery", "The last session crashed", "Vector %d at %x (%s). Open Recovery Tools for details.", ci.vector, ci.rip, ci.msg);
}
void recovery_reset_settings() { FsSys sys; fs_delete("/system/config/settings.cfg"); config_defaults(); config_apply(); config_save(); }
void recovery_reset_users() { FsSys sys; fs_delete("/system/users"); users_init(); audit("recovery", "accounts reset to defaults"); }
void recovery_enter_safe_shell() {
    wm().closeAll(); display_text_mode();
    shell_main();
    for (;;) hal_yield();
}

// ============================================================ Recovery UI (full-screen at boot, window on the desktop)
struct RecoveryApp : App {
    bool full; char log[18][72]; Color logc[18]; int nlog = 0; int confirmTag = 0;
    explicit RecoveryApp(bool f) : full(f) {}
    enum { B_CONT = 1, B_DIAG, B_CRASH, B_SETTINGS, B_USERS, B_SAFE, B_REBOOT, B_CLEARCNT };
    void windowSpec(WindowSpec& s) override { s.title = "Recovery Tools"; s.frame = Rect{ 90, 50, 640, 420 }; s.flags = WF_RESIZABLE; s.minW = 560; s.minH = 360; }
    void say(const char* t, Color c) { if (nlog == 18) { for (int i = 1; i < 18; i++) { scopy(log[i - 1], log[i], 72); logc[i - 1] = logc[i]; } nlog = 17; } scopy(log[nlog], t, 72); logc[nlog++] = c; invalidate(); }
    void onCreate() override {
        Theme& t = theme(); say("Recovery environment ready.", t.ok);
        char b[72]; sfmt(b, sizeof b, "Boot attempts since last good boot: %d", recovery_attempts()); say(b, t.text);
        if (recovery_forced()) say("Entered automatically: the last boots did not finish.", t.warn);
        CrashInfo ci; if (recovery_get_crash(ci)) say("A crash report is stored. Choose 'Last crash report'.", t.warn);
    }
    void runDiag() {
        Theme& t = theme(); nlog = 0; say("Running diagnostics...", t.text);
        DiagResult r[24]; int n = diag_run(r, 24); int fail = 0, warn = 0;
        for (int i = 0; i < n && nlog < 17; i++) { char b[72]; sfmt(b, sizeof b, "[%s] %s: %s", diag_status_name(r[i].status), r[i].name, r[i].detail); say(b, r[i].status == 0 ? t.ok : (r[i].status == 1 ? t.warn : t.danger)); if (r[i].status == 1) warn++; if (r[i].status == 2) fail++; }
        char b[72]; sfmt(b, sizeof b, "%d checks, %d warnings, %d failures.", n, warn, fail); say(b, fail ? t.danger : t.text);
    }
    void showCrash() {
        Theme& t = theme(); nlog = 0; CrashInfo ci;
        if (!recovery_get_crash(ci)) { say("No crash is recorded.", t.ok); return; }
        char b[72]; say("Last crash report", t.text);
        sfmt(b, sizeof b, "CPU vector : %d (%s)", ci.vector, ci.vector == 14 ? "page fault" : ci.vector == 13 ? "general protection" : ci.vector == 6 ? "invalid opcode" : ci.vector == 0 ? "divide error" : ci.vector == 255 ? "kernel panic" : "exception"); say(b, t.text);
        sfmt(b, sizeof b, "Address    : 0x%x", ci.rip); say(b, t.text);
        sfmt(b, sizeof b, "Error code : 0x%x", ci.err); say(b, t.text);
        sfmt(b, sizeof b, "Message    : %s", ci.msg); say(b, t.text);
        say("Press 'Clear counter/crash' once you've noted it.", t.textDim);
    }
    void onAction(int id, int) override {
        Theme& t = theme();
        switch (id) {
        case B_CONT: if (full) { recovery_mark_stable(); desktop_set_screen(SCR_LOGIN); } else close(); break;
        case B_DIAG: runDiag(); break;
        case B_CRASH: showCrash(); break;
        case B_SETTINGS: dialog_confirm(this, B_SETTINGS, "Reset settings", "Reset wallpaper, accent colour, mouse and network\nsettings to their defaults?"); break;
        case B_USERS: dialog_confirm(this, B_USERS, "Reset accounts", "Recreate the default accounts (admin/member/guest)\nwith their factory passwords? Added users are removed."); break;
        case B_SAFE: if (full) recovery_enter_safe_shell(); else { recovery_request_recovery_next(true); say("Recovery will open at the next boot.", t.ok); } break;
        case B_REBOOT: desktop_power(1); break;
        case B_CLEARCNT: recovery_mark_stable(); recovery_clear_crash(); say("Boot counter and crash record cleared.", t.ok); break;
        }
    }
    void onDialog(int tag, bool ok, const char*) override {
        if (!ok) return; Theme& t = theme();
        if (tag == B_SETTINGS) { recovery_reset_settings(); say("Settings reset to defaults.", t.ok); }
        if (tag == B_USERS) { bool wasIn = users_current() != nullptr; recovery_reset_users(); say("Default accounts recreated.", t.ok); if (wasIn) say("You were signed out; sign in again.", t.warn); }
    }
    void onPaint(Canvas& c) override {
        Theme& t = theme();
        if (full) { c.gradV(Rect{ 0, 0, c.w, c.h }, rgb(14, 40, 34), rgb(10, 20, 30)); c.icon(IC_RECOVERY, 24, 20, 40); c.text(76, 18, "mX Recovery", rgb(255, 255, 255), 2); c.text(78, 62, "Safe environment - nothing here depends on your accounts or settings.", rgb(170, 210, 190)); }
        int top = full ? 92 : 8; int lw = 220;
        Rect menu = { 12, top, lw, c.h - top - 12 }; c.fillRound(menu, 4, t.panel); c.roundRect(menu, 4, t.panelDark);
        struct M { const char* l; int id; bool en; } ms[] = { {full ? "Continue to sign-in" : "Close", B_CONT, true}, {"Run diagnostics", B_DIAG, true}, {"Last crash report", B_CRASH, true},
            {"Reset settings", B_SETTINGS, true}, {"Reset user accounts", B_USERS, true}, {full ? "Safe shell (text mode)" : "Open recovery at next boot", B_SAFE, true}, {"Clear counter/crash", B_CLEARCNT, true}, {"Restart", B_REBOOT, true} };
        int y = menu.y + 10; for (auto& m : ms) { button(c, Rect{ menu.x + 10, y, lw - 20, 32 }, m.l, m.id, m.id == B_CONT, m.en); y += 40; }
        Rect out = { lw + 24, top, c.w - lw - 36, c.h - top - 12 }; c.fillRound(out, 4, rgb(18, 22, 30)); c.roundRect(out, 4, t.panelDark);
        Canvas oc = c.sub(out); for (int i = 0; i < nlog; i++) oc.textMax(10, 10 + i * 18, log[i], logc[i] == t.text ? rgb(220, 224, 236) : logc[i], out.w - 20);
    }
    void onKey(const KeyEvent& e) override { if (e.down && e.key == K_ESC && !full) close(); if (e.down && e.key == K_ENTER && full) onAction(B_CONT, 1); }
};
static RecoveryApp* g_boot = nullptr;
App* make_recovery_tools() { return new RecoveryApp(false); }
bool recovery_requested() { return recovery_forced(); }
static RecoveryApp& boot_ui() { if (!g_boot) { g_boot = new RecoveryApp(true); g_boot->onCreate(); } return *g_boot; }
void recovery_paint(Canvas& c) { boot_ui().beginPaint(c); boot_ui().onPaint(c); }
void recovery_key(const KeyEvent& e) { boot_ui().onKey(e); }
void recovery_mouse(const UiMouse& m) { boot_ui().dispatchMouse(m); }

} // namespace mx
