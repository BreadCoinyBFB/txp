#include "mx/sys.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
namespace mx {

// ---------------- SHA-256 (public-domain algorithm, FIPS 180-4) ----------------
namespace {
const u32 K[64] = {
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2 };
inline u32 ror(u32 x, int n) { return (x >> n) | (x << (32 - n)); }
void sha_block(u32 h[8], const u8* p) {
    u32 w[64];
    for (int i = 0; i < 16; i++) w[i] = ((u32)p[4*i] << 24) | ((u32)p[4*i+1] << 16) | ((u32)p[4*i+2] << 8) | p[4*i+3];
    for (int i = 16; i < 64; i++) {
        u32 s0 = ror(w[i-15], 7) ^ ror(w[i-15], 18) ^ (w[i-15] >> 3);
        u32 s1 = ror(w[i-2], 17) ^ ror(w[i-2], 19) ^ (w[i-2] >> 10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }
    u32 a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
    for (int i = 0; i < 64; i++) {
        u32 S1 = ror(e,6) ^ ror(e,11) ^ ror(e,25), ch = (e & f) ^ (~e & g);
        u32 t1 = hh + S1 + ch + K[i] + w[i];
        u32 S0 = ror(a,2) ^ ror(a,13) ^ ror(a,22), mj = (a & b) ^ (a & c) ^ (b & c);
        u32 t2 = S0 + mj;
        hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hh;
}
}
// out = SHA-256(msg[0..len)); exposed for the self-test in diagnostics
void sha256(const u8* msg, int len, u32 out[8]) {
    u32 h[8] = { 0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19 };
    int i = 0;
    for (; i + 64 <= len; i += 64) sha_block(h, msg + i);
    u8 tail[128]; int rem = len - i;
    for (int k = 0; k < rem; k++) tail[k] = msg[i + k];
    tail[rem] = 0x80;
    int total = (rem + 9 <= 64) ? 64 : 128;
    for (int k = rem + 1; k < total; k++) tail[k] = 0;
    u64 bits = (u64)len * 8;
    for (int k = 0; k < 8; k++) tail[total - 1 - k] = (u8)(bits >> (8 * k));
    for (int k = 0; k < total; k += 64) sha_block(h, tail + k);
    for (int k = 0; k < 8; k++) out[k] = h[k];
}

// ---------------- accounts ----------------
// Passwords are never stored: each account keeps salt + an iterated SHA-256 (key stretching, 3000 rounds) and is
// persisted as a small file /system/users/<name>.acct on the data disk. Failed sign-ins back off exponentially and
// every sign-in / sign-out / lock event lands in an audit log (/system/log/auth.log, newest 12 entries).
static User g_users[USERS_MAX];
static const User* g_current = nullptr;
static bool g_defaultAdminPw = false;
static long g_sessionStart = 0; static char g_sessionClock[24] = "";
constexpr int HASH_ITERS = 3000;

const char* role_name(Role r) { return r == ROLE_ADMIN ? "Administrator" : (r == ROLE_MEMBER ? "Member" : "Guest"); }
u32 role_perms(Role r) {
    switch (r) {
    case ROLE_ADMIN: return 0xFFFFFFFFu;
    case ROLE_MEMBER: return P_FILES_ALL | P_SETTINGS_READ | P_SETTINGS_WRITE | P_NETWORK | P_NOTIFY | P_PROCESS | P_TERMINAL | P_SYSMON;
    default: return P_SETTINGS_READ | P_NOTIFY;
    }
}
u32 perm_from_name(const char* n) {
    static const struct { const char* n; u32 v; } t[] = {
        {"files", P_FILES_ALL}, {"system-files", P_FILES_SYSTEM}, {"settings-read", P_SETTINGS_READ}, {"settings", P_SETTINGS_WRITE},
        {"network", P_NETWORK}, {"notify", P_NOTIFY}, {"admin", P_ADMIN}, {"process", P_PROCESS}, {"terminal", P_TERMINAL},
        {"users", P_USERS}, {"sysmon", P_SYSMON}, {"recovery", P_RECOVERY} };
    for (auto& e : t) if (seq(e.n, n)) return e.v;
    return 0;
}

static void hash_pw(u32 salt, int iters, const char* pw, u32 out[8]) {
    u8 buf[96]; int n = 0;
    for (int i = 0; i < 4; i++) buf[n++] = (u8)(salt >> (8 * i));
    for (const char* p = pw; *p && n < 90; p++) buf[n++] = (u8)*p;
    sha256(buf, n, out);
    for (int r = 1; r < iters; r++) {                          // stretch: H = SHA256(H || salt)
        u8 b2[36]; for (int k = 0; k < 8; k++) { b2[k * 4] = (u8)(out[k] >> 24); b2[k * 4 + 1] = (u8)(out[k] >> 16); b2[k * 4 + 2] = (u8)(out[k] >> 8); b2[k * 4 + 3] = (u8)out[k]; }
        for (int i = 0; i < 4; i++) b2[32 + i] = (u8)(salt >> (8 * i));
        sha256(b2, 36, out);
    }
}
static u32 g_rng = 0x9E3779B9u;
static u32 next_salt() {                       // not cryptographic: mixes the PIT tick count and RTC into an LCG
    RtcTime t; hal_rtc_read(t);
    g_rng = g_rng * 1664525u + 1013904223u + (u32)hal_ticks() * 2654435761u + (u32)(t.second * 977 + t.minute * 31 + t.day * 7);
    return g_rng;
}
static void set_pw(User& u, const char* pw) {
    u.noPassword = (pw == nullptr || pw[0] == 0);
    u.salt = next_salt(); u.iters = HASH_ITERS;
    hash_pw(u.salt, u.iters, pw ? pw : "", u.hash);
}
static User* find_mut(const char* name) { for (int i = 0; i < USERS_MAX; i++) if (g_users[i].used && streq_nocase(g_users[i].name, name)) return &g_users[i]; return nullptr; }

// ---- audit log ----
static char g_audit[16][48]; static int g_naudit = 0;
void audit(const char* user, const char* event) {
    RtcTime t; hal_rtc_read(t);
    for (int i = 15; i > 0; i--) mem_cpy(g_audit[i], g_audit[i - 1], 48);
    sfmt(g_audit[0], 48, "%04d-%02d-%02d %02d:%02d  %s: %s", t.year, t.month, t.day, t.hour, t.minute, user, event);
    if (g_naudit < 16) g_naudit++;
    FsSys sys; char b[520]; b[0] = 0;
    for (int i = 0; i < min(g_naudit, 12); i++) { scat(b, g_audit[i], sizeof b); scat(b, "\n", sizeof b); }
    fs_mkdir_p("/system/log"); fs_write("/system/log/auth.log", b, slen(b));
}
int audit_count() { return g_naudit; }
const char* audit_line(int i) { return (i >= 0 && i < g_naudit) ? g_audit[i] : ""; }
static void audit_load() {
    FsSys sys; char b[520]; int n = 0; g_naudit = 0;
    if (!fs_read("/system/log/auth.log", b, sizeof b, &n)) return;
    int i = 0; while (i < n && g_naudit < 12) { int k = 0; char line[48]; while (i < n && b[i] != '\n' && k < 47) line[k++] = b[i++]; line[k] = 0; if (i < n && b[i] == '\n') i++; if (k) scopy(g_audit[g_naudit++], line, 48); }
}

// ---- persistence of accounts ----
static void hex(const u32* w, int n, char* out) { static const char* d = "0123456789abcdef"; for (int i = 0; i < n; i++) for (int k = 7; k >= 0; k--) *out++ = d[(w[i] >> (k * 4)) & 15]; *out = 0; }
static u32 unhex(const char* s, int digits) { u32 v = 0; for (int i = 0; i < digits; i++) { char c = s[i]; v = v * 16 + (u32)((c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : 0); } return v; }
static void make_home(User& u) {
    FsSys sys; sfmt(u.home, sizeof u.home, "/home/%s", u.name);
    fs_mkdir_p(u.home); char p[64]; sfmt(p, sizeof p, "%s/Documents", u.home); fs_mkdir_p(p);
}
static void save_user(const User& u) {
    FsSys sys; char path[64], body[300], h[65], sl[9];
    hex(u.hash, 8, h); hex(&u.salt, 1, sl);
    sfmt(path, sizeof path, "/system/users/%s.acct", u.name);
    sfmt(body, sizeof body, "display=%s\nrole=%d\nnopw=%d\nsalt=%s\niters=%d\nhash=%s\n", u.display, (int)u.role, (int)u.noPassword, sl, u.iters, h);
    fs_mkdir_p("/system/users"); fs_write(path, body, slen(body));
}
static bool load_user(const char* name, const char* text, int n) {
    User u; mem_set(&u, 0, sizeof u); u.used = true; scopy(u.name, name, 16); bool haveHash = false, haveSalt = false; u.iters = HASH_ITERS; u.role = ROLE_GUEST;
    int i = 0;
    while (i < n) {
        char key[10], val[72]; int k = 0, v = 0;
        while (i < n && text[i] != '=' && text[i] != '\n' && k < 9) key[k++] = text[i++]; key[k] = 0;
        if (i < n && text[i] == '=') i++;
        while (i < n && text[i] != '\n' && v < 71) val[v++] = text[i++]; val[v] = 0;
        while (i < n && text[i] != '\n') i++; i++;
        if (seq(key, "display")) scopy(u.display, val, 24); else if (seq(key, "role")) u.role = (Role)clamp(satoi(val), 0, 2);
        else if (seq(key, "nopw")) u.noPassword = satoi(val) != 0; else if (seq(key, "iters")) u.iters = clamp(satoi(val), 1, 100000);
        else if (seq(key, "salt") && v == 8) { u.salt = unhex(val, 8); haveSalt = true; }
        else if (seq(key, "hash") && v == 64) { for (int w = 0; w < 8; w++) u.hash[w] = unhex(val + w * 8, 8); haveHash = true; }
    }
    if (!haveHash || !haveSalt) return false;
    for (int s = 0; s < USERS_MAX; s++) if (!g_users[s].used) { g_users[s] = u; make_home(g_users[s]); return true; }
    return false;
}

bool users_password_acceptable(Role role, const char* pw, const char** why) {
    int l = slen(pw);
    if (role == ROLE_GUEST) return true;                       // guests may stay passwordless
    if (l < 4) { if (why) *why = "Use at least 4 characters."; return false; }
    if (role == ROLE_ADMIN && l < 6) { if (why) *why = "Administrator passwords need at least 6 characters."; return false; }
    if (seq(pw, "admin") || seq(pw, "password") || seq(pw, "123456") || seq(pw, "member")) { if (why) *why = "That password is too easy to guess."; return false; }
    return true;
}
bool users_add(const char* name, const char* display, Role role, const char* pw) {
    if (!name || !name[0] || slen(name) > 15 || find_mut(name)) return false;
    for (const char* c = name; *c; c++) if (!((*c >= 'a' && *c <= 'z') || (*c >= '0' && *c <= '9') || (*c >= 'A' && *c <= 'Z') || *c == '_')) return false;
    for (int i = 0; i < USERS_MAX; i++) if (!g_users[i].used) {
        User& u = g_users[i]; mem_set(&u, 0, sizeof u);
        u.used = true; scopy(u.name, name, 16); scopy(u.display, display && display[0] ? display : name, 24); u.role = role;
        set_pw(u, pw); make_home(u); save_user(u); return true;
    }
    return false;
}
bool users_remove(const char* name) {
    User* u = find_mut(name);
    if (!u || u == g_current) return false;
    if (u->role == ROLE_ADMIN) { int admins = 0; for (int i = 0; i < USERS_MAX; i++) if (g_users[i].used && g_users[i].role == ROLE_ADMIN) admins++; if (admins <= 1) return false; }
    { FsSys sys; char p[64]; sfmt(p, sizeof p, "/system/users/%s.acct", u->name); fs_delete(p); }
    audit(u->name, "account removed");
    u->used = false; return true;
}
bool users_set_password(const char* name, const char* pw) {
    User* u = find_mut(name); if (!u) return false;
    set_pw(*u, pw); u->fails = 0; u->lockUntil = 0; save_user(*u);
    if (u->role == ROLE_ADMIN && seq(u->name, "admin") && !seq(pw, "admin")) g_defaultAdminPw = false;
    audit(u->name, "password changed");
    return true;
}
bool users_set_role(const char* name, Role r) {
    User* u = find_mut(name); if (!u || u == g_current) return false;
    if (u->role == ROLE_ADMIN && r != ROLE_ADMIN) { int admins = 0; for (int i = 0; i < USERS_MAX; i++) if (g_users[i].used && g_users[i].role == ROLE_ADMIN) admins++; if (admins <= 1) return false; }
    u->role = r; save_user(*u); audit(u->name, "role changed"); return true;
}
static bool pw_matches(const User& u, const char* pw) {
    if (u.noPassword) return true;
    u32 h[8]; hash_pw(u.salt, u.iters, pw ? pw : "", h);
    u32 diff = 0; for (int i = 0; i < 8; i++) diff |= h[i] ^ u.hash[i];   // constant-time compare
    return diff == 0;
}
bool users_check_password(const char* name, const char* pw) { User* u = find_mut(name); return u && pw_matches(*u, pw); }

void users_init() {
    mem_set(g_users, 0, sizeof g_users); g_current = nullptr; g_defaultAdminPw = false;
    { FsSys sys; fs_mkdir_p("/home"); fs_mkdir_p("/shared"); fs_mkdir_p("/system"); fs_mkdir_p("/system/users"); }
    audit_load();
    int loaded = 0;
    {
        FsSys sys; FsEntry list[FS_MAX_LIST]; int n = fs_list("/system/users", list, FS_MAX_LIST);
        for (int i = 0; i < n; i++) {
            int l = slen(list[i].name); if (list[i].dir || l < 6 || !seq(list[i].name + l - 5, ".acct")) continue;
            char nm[16]; int il = min(l - 5, 15); for (int q = 0; q < il; q++) nm[q] = list[i].name[q]; nm[il] = 0;
            char path[64], text[VFS_BLOCK_SIZE + 1]; int tn = 0; sfmt(path, sizeof path, "/system/users/%s", list[i].name);
            if (fs_read(path, text, sizeof text, &tn) && load_user(nm, text, tn)) loaded++;
        }
    }
    if (loaded == 0) {                                          // first boot (or wiped disk): factory accounts
        users_add("admin", "Admin", ROLE_ADMIN, "admin");
        users_add("member", "Member", ROLE_MEMBER, "member");
        users_add("guest", "Guest", ROLE_GUEST, "");
        audit("system", "default accounts created");
    }
    const User* a = find_mut("admin"); g_defaultAdminPw = a && pw_matches(*a, "admin");   // still the factory password?
}
int users_count() { int n = 0; for (int i = 0; i < USERS_MAX; i++) if (g_users[i].used) n++; return n; }
const User* users_at(int idx) { int n = 0; for (int i = 0; i < USERS_MAX; i++) if (g_users[i].used) { if (n == idx) return &g_users[i]; n++; } return nullptr; }
const User* users_find(const char* name) { return find_mut(name); }
const User* users_current() { return g_current; }
u32 user_perms() { return g_current ? role_perms(g_current->role) : 0; }
bool users_default_password_active() { return g_defaultAdminPw; }
long users_lock_remaining(const char* name) { User* u = find_mut(name); if (!u) return 0; long left = (u->lockUntil - hal_ticks() + 99) / 100; return left > 0 ? left : 0; }
LoginResult users_login(const char* name, const char* pw) {
    User* u = find_mut(name);
    if (!u) return LOGIN_BAD;
    if (users_lock_remaining(name) > 0) return LOGIN_LOCKED;
    if (!pw_matches(*u, pw)) {
        u->fails++;
        if (u->fails >= 3) { int shift = min(u->fails - 3, 6); u->lockUntil = hal_ticks() + 100L * (5L << shift); audit(u->name, u->fails == 3 ? "locked (3 failed sign-ins)" : "failed sign-in, locked again"); }
        else audit(u->name, "failed sign-in");
        return LOGIN_BAD;
    }
    u->fails = 0; u->lockUntil = 0; g_current = u; g_sessionStart = hal_ticks();
    RtcTime t; hal_rtc_read(t); sfmt(g_sessionClock, sizeof g_sessionClock, "%02d:%02d", t.hour, t.minute);
    audit(u->name, "signed in"); return LOGIN_OK;
}
LoginResult users_unlock(const char* name, const char* pw) {
    User* u = find_mut(name); if (!u || u != g_current) return LOGIN_BAD;
    if (users_lock_remaining(name) > 0) return LOGIN_LOCKED;
    if (!pw_matches(*u, pw)) {
        u->fails++;
        if (u->fails >= 3) { int shift = min(u->fails - 3, 6); u->lockUntil = hal_ticks() + 100L * (5L << shift); audit(u->name, "locked (failed unlocks)"); } else audit(u->name, "failed unlock");
        return LOGIN_BAD;
    }
    u->fails = 0; u->lockUntil = 0; audit(u->name, "screen unlocked"); return LOGIN_OK;
}
void users_logout() { if (g_current) audit(g_current->name, "signed out"); g_current = nullptr; }
long users_session_seconds() { return g_current ? (hal_ticks() - g_sessionStart) / 100 : 0; }
const char* users_session_clock() { return g_sessionClock; }

} // namespace mx
