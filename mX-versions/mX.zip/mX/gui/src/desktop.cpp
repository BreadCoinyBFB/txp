#include "mx/desktop.hpp"
#include "mx/sys.hpp"
#include "mx/hal.hpp"
#include "mx/display.hpp"
#include "mx/net.hpp"
#include "mx/kapi.hpp"
#include "mx/recovery.hpp"
#include "mx/apps.hpp"
#include "mx/persist.hpp"
namespace mx {

constexpr int MAX_W = 1024, MAX_H = 768;            // the scene buffer is sized for the largest logical desktop
static int SW = 800, SH = 600;                      // current logical desktop size (Settings > Display)
static u32 g_scene[MAX_W * MAX_H];
static int TBH() { int s = cfg().taskbarSize; return s == 0 ? 30 : (s == 2 ? 44 : 36); }
static bool tbTop() { return cfg().taskbarTop; }
static int tbY() { return tbTop() ? 0 : SH - TBH(); }
static Rect workRect() { return tbTop() ? Rect{ 0, TBH(), SW, SH - TBH() } : Rect{ 0, 0, SW, SH - TBH() }; }
static bool inTaskbar(int y) { return tbTop() ? y < TBH() : y >= SH - TBH(); }
static Canvas g_canvas;
static Screen g_screen = SCR_SPLASH;
static long g_splashUntil = 0, g_desktopSince = 0;
static bool g_bootStable = false;
static int g_powerState = -1; static long g_lastInput = 0;

Canvas& desktop_scene() { return g_canvas; }
Screen desktop_screen() { return g_screen; }
bool desktop_boot_stable() { return g_bootStable; }

// ================================================================= popup menus
struct MenuItem { const char* label; IconId icon; int id; bool sep; };
struct PopupMenu {
    bool open = false; Rect r = {0, 0, 0, 0}; MenuItem items[24]; int n = 0; int hover = -1; int headerH = 0;
    char title[32], sub[32]; IconId hicon = IC_NONE; int itemH = 28;
    void clear() { n = 0; hover = -1; headerH = 0; }
    void add(const char* l, IconId i, int id) { if (n < 24) { items[n].label = l; items[n].icon = i; items[n].id = id; items[n].sep = false; n++; } }
    void sep() { if (n < 24) { items[n].label = ""; items[n].icon = IC_NONE; items[n].id = -1; items[n].sep = true; n++; } }
    int height() const { int h = headerH + 8; for (int i = 0; i < n; i++) h += items[i].sep ? 9 : itemH; return h; }
    int itemAt(int x, int y) const {
        if (!r.contains(x, y)) return -1;
        int cy = r.y + headerH + 4;
        for (int i = 0; i < n; i++) { int h = items[i].sep ? 9 : itemH; if (!items[i].sep && y >= cy && y < cy + h) return i; cy += h; }
        return -1;
    }
    void paint(Canvas& c) {
        Theme& t = theme();
        c.shadow(r, 8, 100);
        c.fillRound(r, 4, t.panel); c.roundRect(r, 4, t.border);
        if (headerH) {
            Rect hr = { r.x + 1, r.y + 1, r.w - 2, headerH - 1 };
            c.gradV(hr, t.titleActiveA, t.titleActiveB);
            c.icon(hicon, r.x + 10, r.y + 10, headerH - 20);
            c.text(r.x + headerH, r.y + 10, title, t.textOnAccent); c.text(r.x + headerH, r.y + 30, sub, blend(t.textOnAccent, t.accent, 200));
        }
        int cy = r.y + headerH + 4;
        for (int i = 0; i < n; i++) {
            if (items[i].sep) { c.hline(r.x + 8, cy + 4, r.w - 16, t.panelDark); cy += 9; continue; }
            Rect ir = { r.x + 3, cy, r.w - 6, itemH };
            if (i == hover) { c.fillRound(ir, 3, t.accent); }
            if (items[i].icon != IC_NONE) c.icon(items[i].icon, ir.x + 6, ir.y + 5, 18);
            c.text(ir.x + 32, ir.y + (itemH - FONT_H) / 2, items[i].label, i == hover ? t.textOnAccent : t.text);
            cy += itemH;
        }
    }
};
static PopupMenu g_menu;        // start menu / context menu share one slot
enum MenuKind { MK_NONE, MK_START, MK_CONTEXT } g_menuKind = MK_NONE;
// menu ids: 1000+i = launch app i ; 2000.. actions
enum { A_LOCK = 2000, A_LOGOUT, A_RESTART, A_SHUTDOWN, A_WALLPAPER, A_REFRESH, A_RECOVERY };

static void close_menu() { if (g_menu.open) { g_menu.open = false; g_menuKind = MK_NONE; ui_invalidate(); } }
static bool g_ncOpen = false;
void desktop_toggle_notification_center() { g_ncOpen = !g_ncOpen; if (g_ncOpen) { notes_mark_all_read(); notes_dismiss_toasts(); close_menu(); } ui_invalidate(); }

void desktop_open_start() {
    g_menu.clear(); g_ncOpen = false;
    const User* u = users_current();
    scopy(g_menu.title, u ? u->display : "mX", sizeof g_menu.title);
    scopy(g_menu.sub, u ? role_name(u->role) : "", sizeof g_menu.sub);
    g_menu.headerH = 52; g_menu.hicon = IC_USER;
    for (int i = 0; i < apps_count(); i++) { const AppManifest* m = apps_at(i); if (!m->hidden) g_menu.add(m->name, m->icon, 1000 + i); }
    g_menu.sep();
    g_menu.add("Lock", IC_LOCK, A_LOCK); g_menu.add("Log out", IC_USER, A_LOGOUT);
    g_menu.add("Restart", IC_RECOVERY, A_RESTART); g_menu.add("Shut down", IC_POWER, A_SHUTDOWN);
    int h = g_menu.height();
    g_menu.r = Rect{ 4, tbTop() ? TBH() + 2 : SH - TBH() - h - 2, 250, h };
    g_menu.open = true; g_menuKind = MK_START; ui_invalidate();
}
static void open_context(int x, int y) {
    g_menu.clear(); g_ncOpen = false; g_menu.headerH = 0;
    g_menu.add("Open Terminal", IC_TERMINAL, 1000 + 0);   // resolved by id below
    g_menu.items[0].id = -2; g_menu.items[0].label = "Open Terminal";
    g_menu.add("Open Files", IC_FILES, -3);
    g_menu.add("Settings", IC_SETTINGS, -4);
    g_menu.sep();
    g_menu.add("Change wallpaper", IC_DISPLAY, A_WALLPAPER);
    g_menu.add("Refresh", IC_RECOVERY, A_REFRESH);
    int h = g_menu.height();
    g_menu.r = Rect{ min(x, SW - 190), min(y, workRect().bottom() - h), 190, h };
    g_menu.open = true; g_menuKind = MK_CONTEXT; ui_invalidate();
}

// ================================================================= wallpaper
static void paint_wallpaper(Canvas& c) {
    Theme& t = theme(); Rect full = { 0, 0, SW, SH };
    switch (cfg().wallpaper) {
    case 4: { Rect top = { 0, 0, SW, SH / 2 }, bot = { 0, SH / 2, SW, SH - SH / 2 }; c.gradV(top, rgb(34, 22, 78), rgb(176, 72, 120)); c.gradV(bot, rgb(176, 72, 120), rgb(246, 156, 90)); break; }
    case 5: c.gradV(full, rgb(6, 38, 74), rgb(22, 146, 176)); for (int i = 0; i < 6; i++) c.tint(Rect{ 0, SH * 55 / 100 + i * 22, SW, 3 }, rgb(255, 255, 255), 14); break;
    case 6: c.gradV(full, rgb(52, 54, 64), rgb(16, 18, 24)); break;
    case 7: c.fill(full, cfg().wallColor); break;
    case 1: c.gradV(full, rgb(8, 10, 24), rgb(28, 30, 56)); break;
    case 2: c.gradV(full, rgb(10, 44, 38), rgb(40, 92, 60)); break;
    case 3: c.gradV(full, rgb(12, 18, 40), rgb(20, 40, 80));
            for (int x = 0; x < SW; x += 40) c.vline(x, 0, SH, rgb(30, 52, 100));
            for (int y = 0; y < SH; y += 40) c.hline(0, y, SW, rgb(30, 52, 100)); break;
    default:
        c.gradV(full, t.desktopTop, t.desktopBottom);
        for (int i = 0; i < 24; i++) { c.tint(Rect{ 0, SH * 55 / 100 + i * 6, SW, 6 }, rgb(40, 200, 190), i < 12 ? 3 + i * 2 : 3 + (23 - i) * 2); }
        for (int i = 0; i < 16; i++) { c.tint(Rect{ 0, SH * 15 / 100 + i * 5, SW, 5 }, rgb(230, 80, 170), i < 8 ? 2 + i * 2 : 2 + (15 - i) * 2); }
    }
    // faint mX mark
    c.text(SW - 100, workRect().bottom() - 28, "mX 2026.10", blend(rgb(255, 255, 255), rgb(0, 0, 0), 70), 1);
}

// ================================================================= desktop icons
static int g_selIcon = -1; static long g_iconClickT = -1000; static int g_iconClickIdx = -1;
static int icon_count(int idxs[APPS_MAX]) { int n = 0; for (int i = 0; i < apps_count(); i++) if (apps_at(i)->desktop && !apps_at(i)->hidden) idxs[n++] = i; return n; }
static int iconCell() { int z = cfg().iconSize; return z == 0 ? 64 : (z == 2 ? 104 : 84); }
static int iconPx() { int z = cfg().iconSize; return z == 0 ? 28 : (z == 2 ? 56 : 40); }
static Rect icon_rect(int slot) {                       // fills columns top-to-bottom, then moves right
    int cell = iconCell(); Rect wr = workRect(); int rows = max(1, (wr.h - 16) / (cell + 6)); int col = slot / rows, row = slot % rows;
    Rect r = { 16 + col * (cell + 6), wr.y + 12 + row * (cell + 6), cell, cell }; return r;
}
static void paint_icons(Canvas& c) {
    if (!cfg().desktopIcons) return;
    Theme& t = theme(); int idx[APPS_MAX]; int n = icon_count(idx); int px = iconPx();
    for (int s = 0; s < n; s++) {
        const AppManifest* m = apps_at(idx[s]); Rect r = icon_rect(s);
        if (g_selIcon == s) { c.tint(r, t.accent, 110); c.roundRect(r, 3, t.accentLight); }
        c.icon(m->icon, r.x + (r.w - px) / 2, r.y + 6, px);
        int tw = min(c.textWidth(m->name), r.w - 4);
        Rect lr = { r.x + (r.w - tw) / 2 - 2, r.y + 6 + px + 3, tw + 4, 18 };
        c.tint(lr, rgb(0, 0, 0), 90);
        c.textMax(r.x + (r.w - tw) / 2, lr.y + 1, m->name, rgb(255, 255, 255), r.w - 4);
    }
}
static int icon_at(int x, int y) {
    if (!cfg().desktopIcons) return -1;
    int idx[APPS_MAX]; int n = icon_count(idx);
    for (int s = 0; s < n; s++) if (icon_rect(s).contains(x, y)) return s;
    return -1;
}

// ================================================================= clock
static char g_clock[16]; static RtcTime g_rtc; static long g_rtcTick = -1000;
static void update_clock() {
    long now = hal_ticks();
    if (now - g_rtcTick < 50) return;
    g_rtcTick = now;
    RtcTime t; hal_rtc_read(t);
    char b[16];
    if (cfg().clock24) { if (cfg().showSeconds) sfmt(b, 16, "%02d:%02d:%02d", t.hour, t.minute, t.second); else sfmt(b, 16, "%02d:%02d", t.hour, t.minute); }
    else { int h = t.hour % 12; if (h == 0) h = 12; if (cfg().showSeconds) sfmt(b, 16, "%d:%02d:%02d %s", h, t.minute, t.second, t.hour >= 12 ? "PM" : "AM"); else sfmt(b, 16, "%d:%02d %s", h, t.minute, t.hour >= 12 ? "PM" : "AM"); }
    if (!seq(b, g_clock)) { scopy(g_clock, b, 16); ui_invalidate(); }
    g_rtc = t;
}

// ================================================================= taskbar
static Rect tb_start() { return Rect{ 4, tbY() + 3, 78, TBH() - 6 }; }
static Rect tb_bell(Canvas& c) { (void)c; return Rect{ SW - 196, tbY() + 3, 30, TBH() - 6 }; }
static Rect tb_net() { return Rect{ SW - 164, tbY() + 3, 30, TBH() - 6 }; }
static struct TbBtn { Rect r; Window* w; } g_tb[WM_MAX]; static int g_ntb = 0;

static void paint_taskbar(Canvas& c) {
    Theme& t = theme();
    Rect bar = { 0, tbY(), SW, TBH() };
    c.gradV(bar, rgb(44, 48, 66), rgb(26, 28, 42));
    c.hline(0, tbTop() ? bar.bottom() - 1 : bar.y, SW, t.accent);
    int mx_, my_; mouse_position(mx_, my_);
    Rect sb = tb_start();
    bool startOpen = g_menuKind == MK_START;
    if (startOpen || sb.contains(mx_, my_)) c.fillRound(sb, 4, startOpen ? t.accentDark : rgb(70, 76, 100));
    { int ip = TBH() - 10; c.icon(IC_START, sb.x + 5, sb.y + (sb.h - ip) / 2, ip); c.textB(sb.x + 12 + ip, sb.y + (sb.h - 16) / 2, "Start", rgb(255, 255, 255)); }
    // window buttons
    g_ntb = 0;
    int avail = SW - 210 - 90; int count = 0;
    for (int i = 0; i < wm().count(); i++) if (!(wm().at(i)->flags & WF_NOTASKBAR)) count++;
    if (count) {
        int bw = cfg().taskbarLabels ? min(160, avail / count) : min(48, avail / count); int x = 90;
        // stable order: by window id
        Window* order[WM_MAX]; int k = 0;
        for (int i = 0; i < wm().count(); i++) if (!(wm().at(i)->flags & WF_NOTASKBAR)) order[k++] = wm().at(i);
        for (int i = 1; i < k; i++) { Window* v = order[i]; int j = i - 1; while (j >= 0 && order[j]->id > v->id) { order[j + 1] = order[j]; j--; } order[j + 1] = v; }
        for (int i = 0; i < k; i++) {
            Window* w = order[i]; Rect r = { x, tbY() + 3, bw - 4, TBH() - 6 };
            bool act = (w == wm().focused() && !w->minimized);
            bool hov = r.contains(mx_, my_);
            c.fillRound(r, 4, act ? rgb(78, 86, 120) : (hov ? rgb(62, 68, 92) : rgb(44, 48, 66)));
            if (act) c.hline(r.x + 4, r.bottom() - 2, r.w - 8, t.accentLight);
            { int ip = TBH() - 14; c.icon(w->icon, r.x + (cfg().taskbarLabels ? 6 : (r.w - ip) / 2), r.y + (r.h - ip) / 2, ip); }
            if (cfg().taskbarLabels) c.textMax(r.x + TBH() - 4, r.y + (r.h - 16) / 2, w->title, w->minimized ? rgb(150, 156, 172) : rgb(240, 242, 248), r.w - TBH());
            if (g_ntb < WM_MAX) { g_tb[g_ntb].r = r; g_tb[g_ntb].w = w; g_ntb++; }
            x += bw;
        }
    }
    // tray
    Rect nb = tb_net(); const NetInfo& ni = net_info();
    if (nb.contains(mx_, my_)) c.fillRound(nb, 4, rgb(62, 68, 92));
    c.icon(IC_NET, nb.x + (nb.w - 20) / 2, nb.y + (nb.h - 20) / 2, 20);
    if (!(ni.present && ni.linkUp)) { c.line(nb.x + 6, nb.y + 22, nb.x + 24, nb.y + 4, rgb(255, 120, 120)); c.line(nb.x + 7, nb.y + 22, nb.x + 25, nb.y + 4, rgb(255, 120, 120)); }
    Rect bb = tb_bell(c);
    if (bb.contains(mx_, my_) || g_ncOpen) c.fillRound(bb, 4, rgb(62, 68, 92));
    c.icon(IC_BELL, bb.x + (bb.w - 20) / 2, bb.y + (bb.h - 20) / 2, 20);
    int un = notes_unread();
    if (un > 0) { Rect bd = { bb.x + 17, bb.y, 14, 14 }; c.fillRound(bd, 6, t.danger); char nb2[4]; sfmt(nb2, 4, "%d", un > 9 ? 9 : un); c.text(bd.x + 3, bd.y - 1, nb2, rgb(255, 255, 255)); }
    int cw = c.textWidth(g_clock);
    c.text(SW - 12 - cw, tbY() + (TBH() - 16) / 2, g_clock, rgb(240, 242, 248));
}

// ================================================================= notifications (toasts + center)
static void paint_toasts(Canvas& c) {
    if (!cfg().notifyToasts || g_ncOpen) return;
    Theme& t = theme(); const Note* list[4]; int n = notes_active_toasts(list, 4, hal_ticks());
    int y = workRect().y + 12;
    for (int i = 0; i < n; i++) {
        Rect r = { SW - 316, y, 304, 58 };
        c.shadow(r, 6, 90); c.fillRound(r, 4, t.panel); c.roundRect(r, 4, t.border);
        c.fill(Rect{ r.x + 1, r.y + 4, 4, r.h - 8 }, list[i]->sev == N_ERROR ? t.danger : list[i]->sev == N_WARN ? t.warn : list[i]->sev == N_OK ? t.ok : t.accent);
        c.icon(note_icon(list[i]->sev), r.x + 12, r.y + 10, 24);
        c.textMax(r.x + 46, r.y + 8, list[i]->title, t.text, r.w - 54);
        c.textMax(r.x + 46, r.y + 30, list[i]->body, t.textDim, r.w - 54);
        y += 64;
    }
}
static Rect nc_rect() { Rect w = workRect(); return Rect{ SW - 320, w.y, 320, w.h }; }
static Rect nc_clear_rect() { Rect r = nc_rect(); return Rect{ r.right() - 90, r.y + 8, 80, 24 }; }
static void paint_nc(Canvas& c) {
    if (!g_ncOpen) return;
    Theme& t = theme(); Rect r = nc_rect();
    c.shadow(r, 8, 120); c.fill(r, t.panel); c.vline(r.x, r.y, r.h, t.border);
    char hdr[48]; sfmt(hdr, sizeof hdr, "Notifications");
    c.text(r.x + 14, r.y + 12, hdr, t.text); c.text(r.x + 15, r.y + 12, hdr, t.text);
    Rect cl = nc_clear_rect(); c.fillRound(cl, 3, t.panelLight); c.roundRect(cl, 3, t.panelDark); c.textCentered(cl, "Clear all", t.text);
    char d[40]; sfmt(d, sizeof d, "%04d-%02d-%02d", g_rtc.year, g_rtc.month, g_rtc.day);
    c.text(r.x + 14, r.y + 36, d, t.textDim);
    int y = r.y + 62;
    if (notes_count() == 0) c.text(r.x + 14, y + 10, "No notifications.", t.textDim);
    for (int i = 0; i < notes_count() && y + 66 < r.bottom(); i++) {
        const Note& n = notes_at(i); Rect nr = { r.x + 8, y, r.w - 16, 62 };
        c.fillRound(nr, 4, t.panelLight); c.roundRect(nr, 4, t.panelDark);
        c.icon(note_icon(n.sev), nr.x + 8, nr.y + 8, 24);
        c.textMax(nr.x + 42, nr.y + 6, n.title, t.text, nr.w - 50);
        c.textMax(nr.x + 42, nr.y + 24, n.body, t.textDim, nr.w - 50);
        char meta[40]; long secs = (hal_ticks() - n.tick) / 100; sfmt(meta, sizeof meta, "%s - %ds ago", n.app, (int)secs);
        c.textMax(nr.x + 42, nr.y + 42, meta, t.textDim, nr.w - 50);
        y += 68;
    }
}

// ================================================================= login screen
struct LoginApp : App {
    int sel = 0; TextField pw; char msg[64] = ""; long failUntil = 0; bool lock = false;
    void onCreate() override { pw.password = true; pw.focused = true; }
    void tryLogin() {
        const User* u = users_at(sel); if (!u) return;
        if (hal_ticks() < failUntil) return;
        LoginResult r = lock ? users_unlock(u->name, pw.buf) : users_login(u->name, pw.buf);
        if (r == LOGIN_OK) { pw.clear(); msg[0] = 0; lock = false; desktop_set_screen(SCR_DESKTOP); }
        else if (r == LOGIN_LOCKED) { sfmt(msg, sizeof msg, "Too many attempts. Try again in %d s.", (int)users_lock_remaining(u->name)); pw.clear(); ui_invalidate(); }
        else { long lk = users_lock_remaining(u->name); if (lk > 0) sfmt(msg, sizeof msg, "Incorrect password. Locked for %d s.", (int)lk); else scopy(msg, "Incorrect password.", sizeof msg); failUntil = hal_ticks() + 100; pw.clear(); ui_invalidate(); }
    }
    void onPaint(Canvas& c) override {
        Theme& t = theme(); beginPaint(c);
        paint_wallpaper(c); c.tint(Rect{ 0, 0, SW, SH }, rgb(0, 0, 0), 90);
        c.fillRound(Rect{ SW / 2 - 62, 46, 124, 108 }, 14, rgb(250, 250, 252)); c.logo(SW / 2 - 50, 62, 100, rgb(14, 14, 18));
        c.textCentered(Rect{ 0, 168, SW, 24 }, lock ? "Screen locked" : "Sign in to continue", rgb(220, 224, 240));
        int n = lock ? 1 : users_count(); int cw = 140, gap = 16; int total = n * cw + (n - 1) * gap; int x0 = (SW - total) / 2;
        for (int i = 0; i < n; i++) {
            const User* u = users_at(lock ? sel : i); Rect r = { x0 + i * (cw + gap), 214, cw, 128 };
            bool s = lock || i == sel;
            c.tint(r, rgb(255, 255, 255), s ? 70 : 28); if (s) c.roundRect(r, 4, t.accentLight);
            c.icon(IC_USER, r.x + (cw - 48) / 2, r.y + 12, 48);
            c.textCentered(Rect{ r.x, r.y + 68, cw, 18 }, u->display, rgb(255, 255, 255));
            c.textCentered(Rect{ r.x, r.y + 88, cw, 18 }, role_name(u->role), rgb(190, 198, 224));
            c.textCentered(Rect{ r.x, r.y + 106, cw, 18 }, u->noPassword ? "no password" : "password", rgb(150, 160, 190));
            addHit(r, 100 + (lock ? sel : i));
        }
        const User* su = users_at(sel);
        if (su && !su->noPassword) {
            Rect f = { SW / 2 - 130, 366, 260, 28 }; pw.paint(c, *this, f, 10);
            button(c, Rect{ SW / 2 - 130, 402, 260, 30 }, lock ? "Unlock" : "Sign in", 11, true);
        } else button(c, Rect{ SW / 2 - 130, 366, 260, 30 }, su ? "Continue" : "", 11, true);
        if (msg[0]) c.textCentered(Rect{ 0, 442, SW, 18 }, msg, rgb(255, 150, 150));
        if (!lock && users_default_password_active())
            c.textCentered(Rect{ 0, 480, SW, 18 }, "First boot: the Administrator password is \"admin\". Change it in Settings > Users.", rgb(240, 220, 150));
        c.textCentered(Rect{ 0, 500, SW, 18 }, "Tip: Ctrl+Alt+Arrows moves the pointer, Ctrl+Alt+Space clicks.", rgb(170, 178, 205));
        button(c, Rect{ SW - 130, SH - 44, 54, 28 }, "Off", 20); button(c, Rect{ SW - 70, SH - 44, 58, 28 }, "Restart", 21);
        if (lock) button(c, Rect{ 12, SH - 44, 150, 28 }, "Switch user", 23); else button(c, Rect{ 12, SH - 44, 250, 28 }, "Recovery tools (or hold R at boot)", 22);
    }
    void onAction(int id, int) override {
        if (id >= 100 && id < 100 + USERS_MAX) { if (lock) return; sel = id - 100; pw.clear(); msg[0] = 0; const User* u = users_at(sel); if (u && u->noPassword) tryLogin(); }
        else if (id == 11) tryLogin();
        else if (id == 10) { pw.focused = true; }
        else if (id == 20) desktop_power(0); else if (id == 21) desktop_power(1); else if (id == 22) desktop_set_screen(SCR_RECOVERY);
        else if (id == 23) { lock = false; desktop_logout(false); }
    }
    void onKey(const KeyEvent& e) override {
        if (!e.down) return;
        if (lock && (e.key == K_UP || e.key == K_DOWN || e.key == K_TAB)) return;
        if (e.key == K_UP || (e.key == K_LEFT && pw.len == 0)) { sel = (sel + users_count() - 1) % users_count(); pw.clear(); msg[0] = 0; ui_invalidate(); return; }
        if (e.key == K_DOWN || (e.key == K_RIGHT && pw.len == 0)) { sel = (sel + 1) % users_count(); pw.clear(); msg[0] = 0; ui_invalidate(); return; }
        if (e.key == K_TAB) { sel = (sel + 1) % users_count(); pw.clear(); ui_invalidate(); return; }
        if (pw.key(e)) tryLogin();
    }
};
static LoginApp* g_login = nullptr;

// ================================================================= splash
static void paint_splash(Canvas& c) {
    Theme& t = theme();
    c.gradV(Rect{ 0, 0, SW, SH }, rgb(10, 14, 32), rgb(34, 22, 64));
    c.fillRound(Rect{ SW / 2 - 110, 150, 220, 190 }, 18, rgb(250, 250, 252)); c.logo(SW / 2 - 90, 172, 180, rgb(14, 14, 18));
    c.textCentered(Rect{ 0, 350, SW, 20 }, "Powered by Kernel24", rgb(170, 178, 205));
    long now = hal_ticks(); int pct = clamp((int)(100 - (g_splashUntil - now) * 100 / 120), 0, 100);
    Rect pb = { SW / 2 - 100, 392, 200, 8 }; c.fillRound(pb, 3, rgb(50, 56, 84)); c.fillRound(Rect{ pb.x, pb.y, max(6, pb.w * pct / 100), pb.h }, 3, t.accent);
    c.textCentered(Rect{ 0, SH - 40, SW, 20 }, "Press R for Recovery", rgb(130, 138, 170));
}

// ================================================================= compositor
static int g_cx = -100, g_cy = -100;           // where the cursor is currently drawn on the real screen
static bool g_cursorDrawn = false;

void desktop_present_all() { display_present(g_scene, SW, Rect{ 0, 0, SW, SH }); g_cursorDrawn = false; }

static void draw_cursor(int x, int y) {
    u32 tmp[CURSOR_W * CURSOR_H];
    for (int j = 0; j < CURSOR_H; j++)
        for (int i = 0; i < CURSOR_W; i++) {
            int sx = x + i, sy = y + j; bool op; Color cc = cursor_pixel(i, j, op);
            tmp[j * CURSOR_W + i] = op ? cc : ((sx >= 0 && sy >= 0 && sx < SW && sy < SH) ? g_scene[sy * SW + sx] : 0);
        }
    Rect r = Rect{ x, y, CURSOR_W, CURSOR_H }.intersect(Rect{ 0, 0, SW, SH });
    if (r.empty()) return;
    display_present_block(tmp + (r.y - y) * CURSOR_W + (r.x - x), CURSOR_W, r.x, r.y, r.w, r.h);
}
static void update_cursor() {
    int x, y; mouse_position(x, y);
    if (g_cursorDrawn && x == g_cx && y == g_cy) return;
    if (g_cursorDrawn) display_present(g_scene, SW, Rect{ g_cx, g_cy, CURSOR_W, CURSOR_H });   // erase old
    draw_cursor(x, y); g_cx = x; g_cy = y; g_cursorDrawn = true;
}

static void paint_trial(Canvas& c);
static void paint_scene() {
    Canvas& c = g_canvas; c.clip = Rect{ 0, 0, SW, SH }; c.ox = 0; c.oy = 0;
    switch (g_screen) {
    case SCR_SPLASH: paint_splash(c); break;
    case SCR_RECOVERY: recovery_paint(c); break;
    case SCR_LOGIN: case SCR_LOCK: if (g_login) g_login->onPaint(c); break;
    case SCR_DESKTOP:
        paint_wallpaper(c); paint_icons(c);
        wm().paint(c);
        paint_taskbar(c);
        if (g_menu.open) g_menu.paint(c);
        paint_toasts(c); paint_nc(c); paint_trial(c);
        break;
    }
}

void desktop_set_screen(Screen s) {
    if (s == SCR_LOGIN && !g_login) { g_login = new LoginApp(); g_login->onCreate(); }
    if (s == SCR_DESKTOP && g_screen == SCR_LOCK) { g_screen = s; g_lastInput = hal_ticks(); ui_invalidate(); return; }
    if (s == SCR_DESKTOP) { g_lastInput = hal_ticks(); g_desktopSince = hal_ticks(); close_menu(); g_ncOpen = false; wm().init(workRect());
        const User* u = users_current(); if (u) notifyf(N_INFO, "mX", "Welcome", "Signed in as %s (%s).", u->display, role_name(u->role));
        if (u && u->role == ROLE_ADMIN && users_default_password_active()) notify(N_WARN, "Security", "Default password in use", "Change the Administrator password in Settings > Users.");
        if (u) { recovery_announce_crash(); notes_rearm_toasts(); }
        if (u && u->role == ROLE_ADMIN && users_default_password_active()) open_set_password_dialog(u->name, true); }
    g_screen = s; ui_invalidate();
}
void desktop_logout(bool lock) {
    (void)lock; wm().closeAll(); close_menu(); persist_flush(); users_logout();
    if (g_login) { g_login->pw.clear(); g_login->msg[0] = 0; }
    desktop_set_screen(SCR_LOGIN);
}
void desktop_power(int a) { g_powerState = a; }
void desktop_note_activity() { g_lastInput = hal_ticks(); }
int desktop_width() { return SW; } int desktop_height() { return SH; }
void desktop_lock() {
    const User* u = users_current(); if (!u || g_screen != SCR_DESKTOP) return;
    close_menu(); g_ncOpen = false; audit(u->name, "screen locked"); persist_flush();
    if (!g_login) { g_login = new LoginApp(); g_login->onCreate(); }
    g_login->lock = true; g_login->pw.clear(); g_login->msg[0] = 0; g_login->pw.focused = true;
    for (int i = 0; i < users_count(); i++) if (seq(users_at(i)->name, u->name)) g_login->sel = i;
    g_screen = SCR_LOCK; ui_invalidate();
}
void desktop_layout_changed() { wm().setWorkArea(workRect()); close_menu(); ui_invalidate(); }

// ---- changing resolution/scaling safely: a "keep these settings?" banner reverts by itself after 10 s ----
static struct { bool on; long until; int w, h, s; } g_trial;
bool desktop_set_display(int w, int h, int scale, bool trial) {
    if (w < 320 || h < 200 || w > MAX_W || h > MAX_H) return false;
    int ow = SW, oh = SH, os = display_info().scale;
    if (!display_set_mode(w, h, scale)) return false;
    SW = w; SH = h; g_canvas = Canvas(g_scene, SW, SH, SW); input_set_bounds(SW, SH);
    wm().setWorkArea(workRect()); g_cursorDrawn = false; close_menu();
    if (trial) { g_trial.on = true; g_trial.until = hal_ticks() + 1000; g_trial.w = ow; g_trial.h = oh; g_trial.s = os; }
    else { cfg().resW = w; cfg().resH = h; cfg().scale = scale; }
    ui_invalidate(); return true;
}
static Rect trial_rect() { return Rect{ SW / 2 - 220, workRect().y + 10, 440, 64 }; }
static Rect trial_keep() { Rect r = trial_rect(); return Rect{ r.right() - 190, r.y + 30, 84, 26 }; }
static Rect trial_revert() { Rect r = trial_rect(); return Rect{ r.right() - 98, r.y + 30, 84, 26 }; }
static void trial_finish(bool keep) {
    if (!g_trial.on) return; g_trial.on = false;
    if (keep) { cfg().resW = SW; cfg().resH = SH; cfg().scale = display_info().scale; config_save(); notifyf(N_OK, "Display", "Display setting kept", "%dx%d at %dx scale.", SW, SH, display_info().scale); }
    else { desktop_set_display(g_trial.w, g_trial.h, g_trial.s, false); notify(N_INFO, "Display", "Reverted", "The previous display setting was restored."); }
}
static void paint_trial(Canvas& c) {
    if (!g_trial.on) return;
    Theme& t = theme(); Rect r = trial_rect(); int left = (int)((g_trial.until - hal_ticks() + 99) / 100); if (left < 0) left = 0;
    c.shadow(r, 8, 120); c.fillRound(r, 6, t.panel); c.roundRect(r, 6, t.accent);
    char b[80]; sfmt(b, sizeof b, "Keep this display setting? Reverting in %d s", left); c.textB(r.x + 14, r.y + 8, b, t.text);
    Rect k = trial_keep(), v = trial_revert();
    c.fillRound(k, 4, t.accent); c.textCenteredB(k, "Keep", t.textOnAccent); c.fillRound(v, 4, t.panelLight); c.roundRect(v, 4, t.panelDark); c.textCenteredB(v, "Revert", t.text);
    c.text(r.x + 14, r.y + 34, "Enter = keep, Esc = revert", t.textDim);
}

void desktop_init(int, int) {
    g_canvas = Canvas(g_scene, SW, SH, SW);
    input_init(SW, SH); wm().init(workRect());
    g_screen = SCR_SPLASH; g_splashUntil = hal_ticks() + 120; update_clock();
    g_menu.open = false; g_menuKind = MK_NONE; g_ncOpen = false;
}

// ---------------------------------------------------------------- input routing
static u8 g_prevButtons = 0;

static void run_menu_action(int id) {
    if (id >= 1000 && id < 1000 + APPS_MAX) { app_launch(apps_at(id - 1000)->id); return; }
    switch (id) {
    case -2: app_launch("terminal"); break; case -3: app_launch("files"); break; case -4: app_launch("settings"); break;
    case A_LOCK: desktop_lock(); break; case A_LOGOUT: desktop_logout(false); break;
    case A_RESTART: desktop_power(1); break; case A_SHUTDOWN: desktop_power(0); break;
    case A_WALLPAPER: cfg().wallpaper = (cfg().wallpaper + 1) % 4; config_save(); break;
    case A_REFRESH: break;
    }
    ui_invalidate();
}

static bool desktop_mouse(const MouseEvent& e) {
    if (g_trial.on && (e.buttons & 1) && !(g_prevButtons & 1)) { if (trial_keep().contains(e.x, e.y)) { trial_finish(true); return true; } if (trial_revert().contains(e.x, e.y)) { trial_finish(false); return true; } }
    bool leftDown = (e.buttons & 1) && !(g_prevButtons & 1);
    bool rightDown = (e.buttons & 2) && !(g_prevButtons & 2);
    // hover tracking for menu
    if (g_menu.open) { int h = g_menu.itemAt(e.x, e.y); if (h != g_menu.hover) { g_menu.hover = h; ui_invalidate(); } }
    if (leftDown || rightDown) {
        // popup menus
        if (g_menu.open) {
            if (g_menu.r.contains(e.x, e.y)) { int i = g_menu.itemAt(e.x, e.y); if (i >= 0 && leftDown) { int id = g_menu.items[i].id; close_menu(); run_menu_action(id); } return true; }
            bool onStart = tb_start().contains(e.x, e.y); close_menu(); if (onStart && g_menuKind == MK_NONE) return true;
        }
        if (g_ncOpen) {
            if (nc_rect().contains(e.x, e.y)) { if (leftDown && nc_clear_rect().contains(e.x, e.y)) notes_clear(); return true; }
            if (!tb_bell(g_canvas).contains(e.x, e.y)) { g_ncOpen = false; ui_invalidate(); }
        }
        // toasts: click dismisses
        if (cfg().notifyToasts) { const Note* l[4]; int n = notes_active_toasts(l, 4, hal_ticks()); for (int i = 0; i < n; i++) if (Rect{ SW - 316, workRect().y + 12 + i * 64, 304, 58 }.contains(e.x, e.y)) { notes_dismiss_toasts(); return true; } }
        // taskbar
        if (inTaskbar(e.y)) {
            if (leftDown) {
                if (tb_start().contains(e.x, e.y)) { desktop_open_start(); return true; }
                if (tb_bell(g_canvas).contains(e.x, e.y)) { desktop_toggle_notification_center(); return true; }
                if (tb_net().contains(e.x, e.y)) { app_launch("settings"); return true; }
                for (int i = 0; i < g_ntb; i++) if (g_tb[i].r.contains(e.x, e.y)) { wm().taskbarClick(g_tb[i].w); return true; }
            }
            return true;
        }
    }
    if (wm().mouse(e, g_prevButtons)) return true;
    // nothing consumed it: desktop surface
    if (leftDown) {
        int s = icon_at(e.x, e.y);
        if (s >= 0) {
            long now = hal_ticks();
            if (s == g_iconClickIdx && now - g_iconClickT < 40) { int idx[APPS_MAX]; icon_count(idx); app_launch(apps_at(idx[s])->id); g_iconClickIdx = -1; }
            else { g_iconClickIdx = s; g_iconClickT = now; }
        } else g_iconClickIdx = -1;
        if (g_selIcon != s) { g_selIcon = s; ui_invalidate(); }
    }
    if (rightDown) open_context(e.x, e.y);
    return true;
}

static void desktop_key(const KeyEvent& e) {
    if (g_trial.on && e.down) { if (e.key == K_ENTER) { trial_finish(true); return; } if (e.key == K_ESC) { trial_finish(false); return; } }
    if (e.down && e.key == K_SUPER) { if (g_menuKind == MK_START) close_menu(); else desktop_open_start(); return; }
    if (e.down && (e.mods & MOD_CTRL) && (e.mods & MOD_ALT) && e.key == K_DELETE) { app_launch("monitor"); return; }
    if (e.down && (e.mods & MOD_CTRL) && e.key == K_CHAR && (e.ch == 'l' || e.ch == 'L')) { desktop_lock(); return; }
    if (g_menu.open && e.down) {
        if (e.key == K_ESC) { close_menu(); return; }
        if (e.key == K_UP || e.key == K_DOWN) {
            int d = e.key == K_UP ? -1 : 1; int i = g_menu.hover;
            for (int k = 0; k < g_menu.n; k++) { i = (i + d + g_menu.n) % g_menu.n; if (!g_menu.items[i].sep) break; }
            g_menu.hover = i; ui_invalidate(); return;
        }
        if (e.key == K_ENTER && g_menu.hover >= 0) { int id = g_menu.items[g_menu.hover].id; close_menu(); run_menu_action(id); return; }
        return;
    }
    if (g_ncOpen && e.down && e.key == K_ESC) { g_ncOpen = false; ui_invalidate(); return; }
    wm().key(e);
}

// periodic system health checks that raise real notifications
static void health_checks(long now) {
    { char dp[64]; bool dw; if (fs_take_denied(dp, sizeof dp, &dw)) notifyf(N_WARN, "Files", "Permission denied", "You may not %s %s", dw ? "change" : "open", dp); }
    static long last = 0; static bool warnedStorage = false, warnedMem = false, warnedNet = false, announcedNet = false;
    if (now - last < 300) return; last = now;
    int iu, it, bu, bt; fs_usage(&iu, &it, &bu, &bt);
    int pct = (iu * 100 / it) > (bu * 100 / bt) ? (iu * 100 / it) : (bu * 100 / bt);
    if (pct >= 85 && !warnedStorage) { warnedStorage = true; notifyf(N_WARN, "Storage", "Storage almost full", "RAM disk is %d%% full (%d/%d files, %d/%d blocks).", pct, iu, it, bu, bt); }
    if (pct < 70) warnedStorage = false;
    u64 freeKb = hal_free_mem_kb();
    if (freeKb < 512 && !warnedMem) { warnedMem = true; notifyf(N_WARN, "System", "Low memory", "Only %d KiB of physical memory is free.", (int)freeKb); }
    const NetInfo& ni = net_info();
    if (ni.present && ni.linkUp && !announcedNet) { announcedNet = true; notifyf(N_OK, "Network", "Network connected", "%s - %s", ni.name, ni.ip); }
    if (ni.present && !ni.linkUp && !warnedNet) { warnedNet = true; notify(N_WARN, "Network", "Network cable unplugged", "No link on the network adapter."); }
}

void desktop_step() {
    long now = hal_ticks();
    // 1. input
    KeyEvent k;
    while (input_next_key(k)) {
        g_lastInput = now;
        if (g_screen == SCR_SPLASH) { if (k.down && k.key == K_CHAR && (k.ch == 'r' || k.ch == 'R')) desktop_set_screen(SCR_RECOVERY); continue; }
        if (g_screen == SCR_RECOVERY) recovery_key(k);
        else if (g_screen == SCR_LOGIN || g_screen == SCR_LOCK) { if (g_login) g_login->onKey(k); }
        else desktop_key(k);
        ui_invalidate();
    }
    MouseEvent m;
    while (input_next_mouse(m)) {
        g_lastInput = now;
        if (g_screen == SCR_DESKTOP) desktop_mouse(m);
        else if ((g_screen == SCR_LOGIN || g_screen == SCR_LOCK) && g_login) {
            UiMouse u = { UiMouse::Move, m.x, m.y, 0, m.wheel, m.buttons };
            bool ld = (m.buttons & 1) && !(g_prevButtons & 1), lu = !(m.buttons & 1) && (g_prevButtons & 1);
            if (ld) { u.kind = UiMouse::Down; u.button = 1; } else if (lu) { u.kind = UiMouse::Up; u.button = 1; }
            g_login->dispatchMouse(u);
        } else if (g_screen == SCR_RECOVERY) {
            UiMouse u = { UiMouse::Move, m.x, m.y, 0, m.wheel, m.buttons };
            bool ld = (m.buttons & 1) && !(g_prevButtons & 1), lu = !(m.buttons & 1) && (g_prevButtons & 1);
            if (ld) { u.kind = UiMouse::Down; u.button = 1; } else if (lu) { u.kind = UiMouse::Up; u.button = 1; }
            recovery_mouse(u);
        }
        g_prevButtons = m.buttons;
    }
    // 2. timers
    static long lastTick = 0;
    if (now - lastTick >= 10) { lastTick = now; if (g_screen == SCR_DESKTOP) wm().tick(now); update_clock(); net_poll(); persist_tick(now); }
    if (g_screen == SCR_SPLASH && now >= g_splashUntil) desktop_set_screen(recovery_requested() ? SCR_RECOVERY : SCR_LOGIN);
    if (g_screen == SCR_SPLASH && now < g_splashUntil && (now & 7) == 0) ui_invalidate();
    if (g_screen == SCR_DESKTOP) {
        wm().reapClosed(); health_checks(now);
        if (g_trial.on && now >= g_trial.until) trial_finish(false);
        if (cfg().idleLockMin > 0 && now - g_lastInput > (long)cfg().idleLockMin * 6000 && users_current()) desktop_lock();
        if (!g_bootStable && now - g_desktopSince > 300) { g_bootStable = true; recovery_mark_stable(); }     // 3 s on the desktop = this boot is good
        static long lastToastCheck = 0; if (now - lastToastCheck > 20) { lastToastCheck = now; const Note* l[4]; if (notes_active_toasts(l, 4, now) > 0 || g_ncOpen) ui_invalidate(); }
    }
    if ((g_screen == SCR_LOGIN || g_screen == SCR_LOCK) && g_login && (now % 25) == 0) ui_invalidate();       // caret blink
    // 3. paint
    if (ui_take_dirty()) { paint_scene(); desktop_present_all(); }
    update_cursor();
}

void desktop_run_forever() {
    for (;;) {
        desktop_step();
        if (g_powerState >= 0) {
            int a = g_powerState; g_powerState = -1;
            persist_flush(); wm().closeAll(); Canvas& c = g_canvas; c.gradV(Rect{ 0, 0, SW, SH }, rgb(0, 0, 0), rgb(0, 0, 0));
            c.textCentered(Rect{ 0, 270, SW, 20 }, a == 0 ? "Shutting down..." : "Restarting...", rgb(220, 224, 240));
            desktop_present_all();
            long until = hal_ticks() + 80; while (hal_ticks() < until) hal_yield();
            if (a == 0) hal_poweroff(); else hal_reboot();
            c.textCentered(Rect{ 0, 300, SW, 20 }, "It is now safe to turn off your computer.", rgb(150, 156, 180)); desktop_present_all();
            for (;;) hal_yield();
        }
        hal_yield();
    }
}

} // namespace mx
