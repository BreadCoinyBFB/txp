// rtl8139.cpp — polled driver for the Realtek RTL8139 (QEMU: -nic user,model=rtl8139).
// NOTE: written against the RTL8139 programming guide; exercised by the host stack tests only up to
// the NicOps boundary — first contact with real (emulated) hardware happens on your QEMU run.
#include "mx/nic.hpp"
#include "mx/pci.hpp"
#include "mx/kapi.hpp"
namespace mx {

static u16 g_io = 0; static u32 g_rxoff = 0; static int g_tx = 0;
alignas(4) static u8 g_rxbuf[8192 + 16 + 1536];
alignas(4) static u8 g_txbuf[4][1792];

static bool rtl_send(const u8* f, int len) {
    if (len > 1792) return false;
    int d = g_tx; g_tx = (g_tx + 1) & 3;
    for (int w = 0; w < 100000; w++) { u32 tsd = inl((u16)(g_io + 0x10 + 4 * d)); if ((tsd & (1u << 13)) || (tsd & 0x1FFF) == 0) break; cpu_relax(); }
    mem_cpy(g_txbuf[d], f, (size_t)len);
    outl((u16)(g_io + 0x20 + 4 * d), (u32)(uintptr_t)g_txbuf[d]);
    outl((u16)(g_io + 0x10 + 4 * d), (u32)len);             // writing the length clears OWN and starts the DMA
    return true;
}
static int rtl_recv(u8* buf, int max) {
    if (inb((u16)(g_io + 0x37)) & 1) return 0;               // BUFE: buffer empty
    u8* h = g_rxbuf + g_rxoff; u16 st = (u16)(h[0] | (h[1] << 8)); int len = h[2] | (h[3] << 8);
    int n = 0;
    if ((st & 1) && len >= 18 && len <= 1600) { n = len - 4; if (n > max) n = max; mem_cpy(buf, h + 4, (size_t)n); }
    else { // bad frame: reset the receiver to resynchronise
        outb((u16)(g_io + 0x37), 0x04); outb((u16)(g_io + 0x37), 0x0C); g_rxoff = 0; outw((u16)(g_io + 0x38), (u16)(0 - 16)); outl((u16)(g_io + 0x44), 0xF | (1 << 7)); return 0; }
    g_rxoff = (g_rxoff + (u32)len + 4 + 3) & ~3u; g_rxoff %= 8192;
    outw((u16)(g_io + 0x38), (u16)(g_rxoff - 16));
    return n;
}
static bool rtl_link() { return !(inb((u16)(g_io + 0x58)) & 0x04); }   // MSR bit 2 = LINKB (0 = link ok)

bool nic_probe(NicOps& o, bool& other) {
    pci_scan(); other = false;
    const PciDev* d = pci_find(0x10EC, 0x8139);
    if (!d) { for (int i = 0; i < pci_count(); i++) if (pci_get(i).cls == 0x02) other = true; return false; }
    if (!(d->bar[0] & 1)) return false;
    g_io = (u16)(d->bar[0] & ~3u);
    pci_enable(*d, true);
    outb((u16)(g_io + 0x52), 0);                              // power on
    outb((u16)(g_io + 0x37), 0x10); for (int i = 0; i < 100000 && (inb((u16)(g_io + 0x37)) & 0x10); i++) cpu_relax();   // soft reset
    mem_set(g_rxbuf, 0, sizeof g_rxbuf); g_rxoff = 0; g_tx = 0;
    outl((u16)(g_io + 0x30), (u32)(uintptr_t)g_rxbuf);
    outw((u16)(g_io + 0x3C), 0);                              // no interrupts: we poll
    outl((u16)(g_io + 0x44), 0xF | (1 << 7));                 // accept broadcast/multicast/unicast, WRAP
    outl((u16)(g_io + 0x40), 0x03000700);                     // TX: IFG normal, max DMA burst
    outb((u16)(g_io + 0x37), 0x0C);                           // RX + TX enable
    for (int i = 0; i < 6; i++) o.mac[i] = inb((u16)(g_io + i));
    o.send = rtl_send; o.recv = rtl_recv; o.link = rtl_link; scopy(o.name, "Realtek RTL8139 Fast Ethernet", sizeof o.name);
    return true;
}
} // namespace mx
