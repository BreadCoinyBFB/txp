#include "mx/ui.hpp"
#include "mx/wm.hpp"
#include "mx/hal.hpp"
namespace mx {

static volatile bool g_dirty = true;
void ui_invalidate() { g_dirty = true; }
bool ui_take_dirty() { bool d = g_dirty; g_dirty = false; return d; }
long ui_ticks() { return hal_ticks(); }

void App::close() { if (win) wm().requestClose(win); }
void App::beginPaint(Canvas& c) { nhits = 0; cw = c.w; ch = c.h; baseOx = c.ox; baseOy = c.oy; }
void App::addHit(const Rect& r, int id) { if (nhits < MAX_HITS) { hits[nhits].r = r; hits[nhits].id = id; nhits++; } }
void App::addHitC(const Canvas& c, const Rect& r, int id) {
    Rect a = { r.x + c.ox - baseOx, r.y + c.oy - baseOy, r.w, r.h };
    Rect vis = { c.clip.x - baseOx, c.clip.y - baseOy, c.clip.w, c.clip.h };
    a = a.intersect(vis); if (!a.empty()) addHit(a, id);
}
int  App::hitAt(int x, int y) const {
    for (int i = nhits - 1; i >= 0; i--) if (hits[i].r.contains(x, y)) return hits[i].id;
    return -1;
}
void App::dispatchMouse(const UiMouse& m) {
    mouseX = m.x; mouseY = m.y; mouseBtn = m.buttons;
    int h = hitAt(m.x, m.y);
    if (h != hoverId) { hoverId = h; invalidate(); }
    if (m.kind == UiMouse::Down) { pressId = h; invalidate(); }
    if (m.kind == UiMouse::Up) {
        int p = pressId; pressId = -1; invalidate();
        if (p != -1 && p == h) onAction(h, m.button);
    }
    onMouse(m);
}

// ---------------- widgets ----------------
void App::button(Canvas& c, const Rect& r, const char* label, int id, bool primary, bool enabled) {
    Theme& t = theme();
    bool hov = enabled && hoverId == id, prs = enabled && pressId == id && hov;
    Color bg = primary ? (prs ? t.accentDark : (hov ? t.accentLight : t.accent)) : (prs ? t.panelDark : (hov ? t.panelLight : t.panel));
    c.fillRound(r, 3, bg);
    c.roundRect(r, 3, primary ? t.accentDark : t.panelDark);
    Color fg = !enabled ? t.textDim : (primary ? t.textOnAccent : t.text);
    c.textCentered(r.moved(0, prs ? 1 : 0), label, fg);
    if (enabled) addHitC(c, r, id);
}
void App::iconButton(Canvas& c, const Rect& r, IconId ic, const char*, int id, bool enabled) {
    Theme& t = theme();
    bool hov = enabled && hoverId == id, prs = enabled && pressId == id && hov;
    if (hov) { c.fillRound(r, 3, prs ? t.panelDark : t.panelLight); c.roundRect(r, 3, t.panelDark); }
    int s = min(r.w, r.h) - 8;
    if (!enabled) c.tint(r, t.window, 0);
    c.icon(ic, r.x + (r.w - s) / 2, r.y + (r.h - s) / 2 + (prs ? 1 : 0), s);
    if (!enabled) c.tint(r.inset(2), t.window, 150);
    if (enabled) addHitC(c, r, id);
}
void App::checkbox(Canvas& c, int x, int y, const char* label, bool on, int id) {
    Theme& t = theme();
    Rect b = { x, y + 1, 14, 14 };
    c.fillRound(b, 2, t.field); c.roundRect(b, 2, hoverId == id ? t.accent : t.panelDark);
    if (on) { c.line(x + 3, y + 8, x + 6, y + 11, t.accent); c.line(x + 6, y + 11, x + 11, y + 4, t.accent); c.line(x + 3, y + 7, x + 6, y + 10, t.accent); c.line(x + 6, y + 10, x + 11, y + 3, t.accent); }
    int w = c.text(x + 20, y, label, t.text);
    Rect hit = { x, y, 24 + w, 16 }; addHitC(c, hit, id);
}
void App::radio(Canvas& c, int x, int y, const char* label, bool on, int id) {
    Theme& t = theme();
    Rect b = { x, y + 1, 14, 14 };
    c.fillRound(b, 6, t.field); c.roundRect(b, 6, hoverId == id ? t.accent : t.panelDark);
    if (on) c.fillRound(Rect{ x + 4, y + 5, 6, 6 }, 3, t.accent);
    int w = c.text(x + 20, y, label, t.text);
    Rect hit = { x, y, 24 + w, 16 }; addHitC(c, hit, id);
}
// slider: hit id gets onAction; the value is recomputed by the app from mouseX via sliderValue()
void App::slider(Canvas& c, const Rect& r, int value, int lo, int hi, int id) {
    Theme& t = theme();
    int ty = r.y + r.h / 2;
    c.fillRound(Rect{ r.x, ty - 2, r.w, 4 }, 2, t.panelDark);
    int knob = r.x + (hi > lo ? (value - lo) * (r.w - 10) / (hi - lo) : 0);
    c.fillRound(Rect{ r.x, ty - 2, knob - r.x + 5, 4 }, 2, t.accent);
    c.fillRound(Rect{ knob, ty - 7, 10, 14 }, 3, hoverId == id || pressId == id ? t.accentLight : t.panelLight);
    c.roundRect(Rect{ knob, ty - 7, 10, 14 }, 3, t.panelDark);
    addHitC(c, r, id);
}
void App::progress(Canvas& c, const Rect& r, int pct, Color col) {
    Theme& t = theme();
    c.fillRound(r, 3, t.panelDark);
    int w = (r.w - 2) * clamp(pct, 0, 100) / 100;
    if (w > 0) c.fillRound(Rect{ r.x + 1, r.y + 1, w, r.h - 2 }, 2, col);
}
void App::panel(Canvas& c, const Rect& r) {
    Theme& t = theme();
    c.fillRound(r, 4, t.panelLight); c.roundRect(r, 4, t.panelDark);
}
void App::heading(Canvas& c, int x, int y, const char* s) {
    Theme& t = theme();
    c.textB(x, y, s, t.text);
}

// ---------------- TextField ----------------
bool TextField::key(const KeyEvent& e) {
    if (!e.down) return false;
    if (e.key == K_ENTER) return true;
    if (e.key == K_BACKSPACE) { if (cur > 0) { for (int i = cur - 1; i < len; i++) buf[i] = buf[i + 1]; cur--; len--; } }
    else if (e.key == K_DELETE) { if (cur < len) { for (int i = cur; i < len; i++) buf[i] = buf[i + 1]; len--; } }
    else if (e.key == K_LEFT) { if (cur > 0) cur--; }
    else if (e.key == K_RIGHT) { if (cur < len) cur++; }
    else if (e.key == K_HOME) cur = 0;
    else if (e.key == K_END) cur = len;
    else if ((e.key == K_CHAR || e.key == K_SPACE) && e.ch >= 32 && len < maxLen && !(e.mods & (MOD_CTRL | MOD_ALT))) {
        if (numeric && !(e.ch >= '0' && e.ch <= '9') && e.ch != '.') return false;
        for (int i = len; i >= cur; i--) buf[i + 1] = buf[i];
        buf[cur++] = (char)e.ch; len++;
    }
    ui_invalidate();
    return false;
}
void TextField::paint(Canvas& c, App& a, const Rect& r, int id) {
    Theme& t = theme();
    c.fillRound(r, 3, t.field);
    c.roundRect(r, 3, focused ? t.accent : t.panelDark);
    if (focused) c.roundRect(r.inset(1), 2, blend(t.accent, t.field, 60));
    char shown[72]; int n = 0;
    for (; n < len && n < 70; n++) shown[n] = password ? '*' : buf[n];
    shown[n] = 0;
    int start = 0;                                                  // scroll so the caret stays inside the box
    while (start < cur && c.textWidthN(shown + start, cur - start) > r.w - 14) start++;
    Rect inner = r.inset(1); Canvas cc = c.sub(inner);
    cc.text(5, (inner.h - FONT_H) / 2, shown + start, t.text);
    if (focused && ((ui_ticks() / 50) & 1) == 0) cc.fill(Rect{ 5 + c.textWidthN(shown + start, cur - start), 3, 1, inner.h - 6 }, t.text);
    a.addHitC(c, r, id);
}

} // namespace mx
