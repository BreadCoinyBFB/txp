// diag.cpp — basic system diagnostics, shared by the Diagnostics app and Recovery.
#include "mx/apps.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
#include "mx/display.hpp"
#include "mx/net.hpp"
#include "mx/pci.hpp"
#include "mx/recovery.hpp"
namespace mx {
void sha256(const u8* msg, int len, u32 out[8]);
const char* diag_status_name(int s) { return s == 0 ? "PASS" : (s == 1 ? "WARN" : "FAIL"); }

static void add(DiagResult* o, int& n, int max, const char* name, int st, const char* fmt, ...) {
    if (n >= max) return; DiagResult& r = o[n++]; scopy(r.name, name, sizeof r.name); r.status = st;
    va_list ap; va_start(ap, fmt); svfmt(r.detail, sizeof r.detail, fmt, ap); va_end(ap);
}
// walk the directory tree from the root and verify the VFS invariants
static int vfs_check(int& reach, int& orphans) {
    static bool seen[VFS_MAX_INODES]; mem_set(seen, 0, sizeof seen); reach = 0; int bad = 0;
    int stack[VFS_MAX_INODES], sp = 0; stack[sp++] = 0; seen[0] = true; reach = 1;
    while (sp) {
        int d = stack[--sp];
        int guard = 0;
        for (int c = inode_table[d].first_child; c != -1; c = inode_table[c].next_sibling) {
            if (++guard > VFS_MAX_INODES || c < 0 || c >= VFS_MAX_INODES) { bad++; break; }
            if (seen[c]) { bad++; break; }
            if (inode_table[c].inode_type == INODE_FREE || inode_table[c].parent != d) bad++;
            seen[c] = true; reach++;
            if (inode_table[c].inode_type == INODE_DIR && sp < VFS_MAX_INODES) stack[sp++] = c;
        }
    }
    orphans = 0; for (int i = 0; i < VFS_MAX_INODES; i++) if (inode_table[i].inode_type != INODE_FREE && !seen[i]) orphans++;
    return bad;
}

int diag_run(DiagResult* o, int max) {
    int n = 0;
    // heap
    { void* p[8]; bool ok = true; int sizes[8] = { 16, 64, 100, 256, 512, 1024, 2000, 4000 };
      for (int i = 0; i < 8; i++) { p[i] = (void*)kmalloc(sizes[i]); if (!p[i]) { ok = false; continue; } mem_set(p[i], 0xA0 + i, (size_t)sizes[i]); }
      for (int i = 0; i < 8; i++) if (p[i]) { u8* b = (u8*)p[i]; if (b[0] != 0xA0 + i || b[sizes[i] - 1] != 0xA0 + i) ok = false; }
      for (int i = 0; i < 8; i++) if (p[i]) kfree((long)p[i]);
      add(o, n, max, "Heap allocator", ok ? 0 : 2, ok ? "8 allocations written, verified, freed" : "allocation or pattern check failed"); }
    // memory
    { u64 fk = hal_free_mem_kb(), tk = hal_total_mem_kb(); add(o, n, max, "Physical memory", fk < 256 ? 2 : (fk < 1024 ? 1 : 0), "%d KiB free of %d MiB RAM", (int)fk, (int)(tk / 1024)); }
    // timer
    { long a = hal_ticks(); for (int i = 0; i < 4; i++) hal_yield(); long b = hal_ticks(); add(o, n, max, "System timer", 0, "100 Hz PIT running (tick %d)", (int)b); (void)a; }
    // vfs
    { int reach, orph; int bad = vfs_check(reach, orph); add(o, n, max, "Filesystem integrity", bad ? 2 : (orph ? 1 : 0), "%d nodes reachable, %d orphaned, %d inconsistent", reach, orph, bad); }
    { // end-to-end filesystem self-test: create, write, read back, list, delete
      const char* tp = "/system/.difftest"; char rb[40]; int rn = 0; FsEntry le[FS_MAX_LIST];
      bool dir = fs_is_dir("/system"), w = fs_write(tp, "mX-selftest", 11), r = fs_read(tp, rb, sizeof rb, &rn) && rn == 11 && rb[0] == 'm';
      int ln = fs_list("/system", le, FS_MAX_LIST); bool d = fs_delete(tp);
      add(o, n, max, "Filesystem write test", (dir && w && r && d && ln > 0) ? 0 : 2, "dir=%d write=%d read=%d list=%d delete=%d", (int)dir, (int)w, (int)r, ln, (int)d); }
    { int ins, insFail, fromVfs, fb; apps_stats(&ins, &insFail, &fromVfs, &fb); add(o, n, max, "App registry", (fb == 0 && insFail == 0) ? 0 : 1, "%d apps: %d from manifests, %d built-in defaults, %d write failures", apps_count(), fromVfs, fb, insFail); }
    { int iu, it, bu, bt; fs_usage(&iu, &it, &bu, &bt); int pct = mx::max(iu * 100 / it, bu * 100 / bt); add(o, n, max, "Storage capacity", pct >= 95 ? 2 : (pct >= 85 ? 1 : 0), "%d%% used (%d/%d inodes, %d/%d blocks)", pct, iu, it, bu, bt); }
    // crypto self-test
    { u32 h[8]; const u8 abc[3] = { 'a', 'b', 'c' }; sha256(abc, 3, h); bool ok = h[0] == 0xba7816bfu && h[7] == 0xf20015adu; add(o, n, max, "Password hashing (SHA-256)", ok ? 0 : 2, ok ? "known-answer test passed" : "wrong digest for \"abc\""); }
    // display
    { const DisplayInfo& d = display_info(); add(o, n, max, "Display", d.ok ? 0 : 1, d.ok ? "%dx%d via %s" : "no graphics adapter driver active", d.w, d.h, d.driver); }
    // input
    { add(o, n, max, "Keyboard", 0, "scancode set 1, modifiers %d", (int)input_mods()); add(o, n, max, "Mouse", mouse_present() ? 0 : 1, mouse_present() ? (mouse_has_wheel() ? "PS/2, wheel detected" : "PS/2 mouse detected") : "no PS/2 mouse - MouseKeys available"); }
    // rtc
    { RtcTime t; hal_rtc_read(t); bool ok = t.month >= 1 && t.month <= 12 && t.day >= 1 && t.day <= 31 && t.hour < 24 && t.minute < 60 && t.second < 60; add(o, n, max, "Real-time clock", ok ? 0 : 1, "%04d-%02d-%02d %02d:%02d:%02d", t.year, t.month, t.day, t.hour, t.minute, t.second); }
    // network
    { const NetInfo& ni = net_info(); add(o, n, max, "Network", ni.present ? (ni.linkUp ? 0 : 1) : 1, "%s", ni.status); }
    // pci
    { add(o, n, max, "PCI bus", pci_count() > 0 ? 0 : 1, "%d devices found", pci_count()); }
    // accounts
    { bool admin = false; for (int i = 0; i < users_count(); i++) if (users_at(i)->role == ROLE_ADMIN) admin = true; add(o, n, max, "User accounts", admin ? 0 : 2, "%d accounts, administrator %s", users_count(), admin ? "present" : "MISSING"); }
    // recovery state
    { add(o, n, max, "Boot state", recovery_attempts() > 1 ? 1 : 0, "boot attempts since last good boot: %d", recovery_attempts()); }
    return n;
}
}
