// netstack.cpp — a small polled TCP/IP stack: Ethernet, ARP, IPv4, ICMP echo, UDP and a DNS A resolver.
// (TCP is deliberately not here yet.) Hardware-independent, so the host tests exercise exactly this code.
#include "mx/net.hpp"
#include "mx/nic.hpp"
#include "mx/sys.hpp"
#include "mx/hal.hpp"
namespace mx {

static NetInfo g_ni; static NicOps g_nic; static bool g_have = false;
static u8 g_ip[4], g_mask[4], g_gw[4], g_dns[4];
static struct { u8 ip[4]; u8 mac[6]; bool ok; } g_arp[4]; static int g_arpNext = 0;
static u16 g_ipid = 1, g_pingSeq = 1, g_dnsId = 0x4d58;
static struct { bool wait, got; u8 ip[4]; u16 id, seq; long sentTick; int rtt; } g_ping;
static struct { bool wait, got; u16 id; u8 ip[4]; } g_dnsq;
static struct { bool wait, got; u8 ip[4]; u8 mac[6]; } g_arpq;
static u8 g_rx[1600];

static void tcp_handle(const u8* ip, const u8* t, int tn);


const NetInfo& net_info() { return g_ni; }

// ---------------------------------------------------------------- helpers
bool ip_parse(const char* s, u8 out[4]) {
    for (int i = 0; i < 4; i++) {
        if (*s < '0' || *s > '9') return false;
        int v = 0, d = 0; while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; if (++d > 3) return false; }
        if (v > 255) return false; out[i] = (u8)v;
        if (i < 3) { if (*s != '.') return false; s++; }
    }
    return *s == 0;
}
void ip_format(const u8 ip[4], char* out) { sfmt(out, 16, "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]); }
u16 ip_checksum(const void* data, int len) {
    const u8* p = (const u8*)data; u32 sum = 0;
    for (; len > 1; len -= 2, p += 2) sum += (u32)((p[0] << 8) | p[1]);
    if (len) sum += (u32)(p[0] << 8);
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (u16)~sum;
}
static bool ip_eq(const u8* a, const u8* b) { return a[0] == b[0] && a[1] == b[1] && a[2] == b[2] && a[3] == b[3]; }
static void put16(u8* p, u16 v) { p[0] = (u8)(v >> 8); p[1] = (u8)v; }
static u16 get16(const u8* p) { return (u16)((p[0] << 8) | p[1]); }
static bool same_subnet(const u8* a, const u8* b) { for (int i = 0; i < 4; i++) if ((a[i] & g_mask[i]) != (b[i] & g_mask[i])) return false; return true; }

static void status() {
    if (!g_have) { scopy(g_ni.status, g_ni.detectedOther ? "Network card found, no driver for it yet" : "No network adapter detected", sizeof g_ni.status); return; }
    sfmt(g_ni.status, sizeof g_ni.status, "%s - %s", g_ni.linkUp ? "Connected" : "Cable unplugged", g_ni.ip);
}
void net_apply_config() {
    Config& c = cfg();
    if (c.netMode == 1) { ip_parse(c.ip, g_ip); ip_parse(c.mask, g_mask); ip_parse(c.gw, g_gw); ip_parse(c.dns, g_dns); }
    else { ip_parse("10.0.2.15", g_ip); ip_parse("255.255.255.0", g_mask); ip_parse("10.0.2.2", g_gw); ip_parse("10.0.2.3", g_dns); }   // QEMU user-mode defaults
    ip_format(g_ip, g_ni.ip); ip_format(g_mask, g_ni.mask); ip_format(g_gw, g_ni.gw); ip_format(g_dns, g_ni.dns);
    for (auto& e : g_arp) e.ok = false;
    status();
}

// ---------------------------------------------------------------- send paths
static bool eth_send(const u8* dst, u16 type, const u8* payload, int len) {
    if (!g_have || len > 1500) return false;
    static u8 f[1536]; mem_cpy(f, dst, 6); mem_cpy(f + 6, g_nic.mac, 6); put16(f + 12, type); mem_cpy(f + 14, payload, (size_t)len);
    int total = 14 + len; if (total < 60) { mem_set(f + total, 0, (size_t)(60 - total)); total = 60; }
    bool ok = g_nic.send(f, total); if (ok) g_ni.txPackets++; return ok;
}
static void arp_send(u16 op, const u8* targetMac, const u8* targetIp) {
    u8 a[28]; put16(a, 1); put16(a + 2, 0x0800); a[4] = 6; a[5] = 4; put16(a + 6, op);
    mem_cpy(a + 8, g_nic.mac, 6); mem_cpy(a + 14, g_ip, 4); mem_cpy(a + 18, targetMac, 6); mem_cpy(a + 24, targetIp, 4);
    static const u8 bc[6] = { 255, 255, 255, 255, 255, 255 };
    eth_send(op == 1 ? bc : targetMac, 0x0806, a, 28);
}
static bool wait_flag(volatile bool* f, int ms) { long end = hal_ticks() + ms / 10 + 1; while (!*f && hal_ticks() < end) { net_poll(); if (*f) break; hal_yield(); } return *f; }
static bool arp_resolve(const u8* ip, u8* mac) {
    for (auto& e : g_arp) if (e.ok && ip_eq(e.ip, ip)) { mem_cpy(mac, e.mac, 6); return true; }
    static const u8 zero[6] = { 0, 0, 0, 0, 0, 0 };
    for (int attempt = 0; attempt < 3; attempt++) {
        g_arpq.wait = true; g_arpq.got = false; mem_cpy(g_arpq.ip, ip, 4);
        arp_send(1, zero, ip);
        if (wait_flag(&g_arpq.got, 300)) { g_arpq.wait = false; mem_cpy(mac, g_arpq.mac, 6); return true; }
    }
    g_arpq.wait = false; return false;
}
static bool ip_send(u8 proto, const u8* dst, const u8* payload, int len) {
    if (len > 1480) return false;
    const u8* hop = same_subnet(g_ip, dst) ? dst : g_gw; u8 mac[6];
    if (!arp_resolve(hop, mac)) return false;
    u8 p[1500]; p[0] = 0x45; p[1] = 0; put16(p + 2, (u16)(20 + len)); put16(p + 4, g_ipid++); put16(p + 6, 0x4000); p[8] = 64; p[9] = proto; put16(p + 10, 0);
    mem_cpy(p + 12, g_ip, 4); mem_cpy(p + 16, dst, 4); put16(p + 10, ip_checksum(p, 20)); mem_cpy(p + 20, payload, (size_t)len);
    return eth_send(mac, 0x0800, p, 20 + len);
}

// ---------------------------------------------------------------- receive
static bool dns_parse(const u8* d, int len, u8 out[4]) {
    if (len < 12 || (get16(d + 2) & 0x8000) == 0 || (get16(d + 2) & 0xF) != 0) return false;
    int qd = get16(d + 4), an = get16(d + 6), p = 12;
    auto skip = [&](int q) { while (q < len) { u8 l = d[q]; if (l == 0) return q + 1; if ((l & 0xC0) == 0xC0) return q + 2; q += l + 1; } return len; };
    for (int i = 0; i < qd; i++) p = skip(p) + 4;
    for (int i = 0; i < an && p < len; i++) {
        p = skip(p); if (p + 10 > len) return false;
        u16 type = get16(d + p), cls = get16(d + p + 2), rd = get16(d + p + 8); p += 10;
        if (type == 1 && cls == 1 && rd == 4 && p + 4 <= len) { mem_cpy(out, d + p, 4); return true; }
        p += rd;
    }
    return false;
}
static void handle_ip(const u8* p, int len) {
    if (len < 20 || (p[0] >> 4) != 4) return; int ihl = (p[0] & 15) * 4; int tl = get16(p + 2); if (tl > len || ihl < 20 || tl < ihl) return;
    static const u8 bc[4] = { 255, 255, 255, 255 }; if (!ip_eq(p + 16, g_ip) && !ip_eq(p + 16, bc)) return;
    const u8* pl = p + ihl; int pn = tl - ihl;
    if (p[9] == 1 && pn >= 8) {                         // ICMP
        if (pl[0] == 8) {                               // echo request -> reply
            u8 r[1480]; if (pn > 1480) return; mem_cpy(r, pl, (size_t)pn); r[0] = 0; put16(r + 2, 0); put16(r + 2, ip_checksum(r, pn)); ip_send(1, p + 12, r, pn);
        } else if (pl[0] == 0 && g_ping.wait && get16(pl + 4) == g_ping.id && get16(pl + 6) == g_ping.seq && ip_eq(p + 12, g_ping.ip)) {
            g_ping.rtt = (int)((hal_ticks() - g_ping.sentTick) * 10); g_ping.got = true;
        }
    } else if (p[9] == 6) { tcp_handle(p, pl, pn);
    } else if (p[9] == 17 && pn >= 8) {                 // UDP
        if (g_dnsq.wait && get16(pl) == 53) { const u8* d = pl + 8; if (pn >= 20 && get16(d) == g_dnsq.id && dns_parse(d, pn - 8, g_dnsq.ip)) g_dnsq.got = true; }
    }
}
void net_poll() {
    if (!g_have) return;
    g_ni.linkUp = g_nic.link();
    for (int n = 0; n < 32; n++) {
        int len = g_nic.recv(g_rx, sizeof g_rx); if (len <= 0) break; g_ni.rxPackets++;
        if (len < 14) continue; u16 type = get16(g_rx + 12); const u8* p = g_rx + 14; int pl = len - 14;
        if (type == 0x0806 && pl >= 28 && get16(p) == 1 && get16(p + 2) == 0x0800) {
            u16 op = get16(p + 6);
            if (op == 2 || op == 1) {                                  // learn from any ARP we see addressed to us
                int slot = -1; for (int i = 0; i < 4; i++) if (g_arp[i].ok && ip_eq(g_arp[i].ip, p + 14)) slot = i;
                if (slot < 0) { slot = g_arpNext; g_arpNext = (g_arpNext + 1) % 4; }
                mem_cpy(g_arp[slot].ip, p + 14, 4); mem_cpy(g_arp[slot].mac, p + 8, 6); g_arp[slot].ok = true;
                if (g_arpq.wait && ip_eq(g_arpq.ip, p + 14)) { mem_cpy(g_arpq.mac, p + 8, 6); g_arpq.got = true; }
            }
            if (op == 1 && ip_eq(p + 24, g_ip)) arp_send(2, p + 8, p + 14);
        } else if (type == 0x0800) handle_ip(p, pl);
    }
    status();
}

// ---------------------------------------------------------------- public blocking API
bool net_ping(const char* ipstr, int* rtt, int timeoutMs) {
    u8 ip[4]; if (!g_have || !g_ni.linkUp || !ip_parse(ipstr, ip)) return false;
    u8 m[40]; mem_set(m, 0, sizeof m); m[0] = 8; g_ping.id = 0x6d58; g_ping.seq = g_pingSeq++; put16(m + 4, g_ping.id); put16(m + 6, g_ping.seq);
    for (int i = 8; i < 40; i++) m[i] = (u8)('a' + (i % 23)); put16(m + 2, ip_checksum(m, 40));
    mem_cpy(g_ping.ip, ip, 4); g_ping.got = false; g_ping.wait = true; g_ping.sentTick = hal_ticks();
    if (!ip_send(1, ip, m, 40)) { g_ping.wait = false; return false; }
    bool ok = wait_flag(&g_ping.got, timeoutMs); g_ping.wait = false;
    if (ok && rtt) *rtt = g_ping.rtt; return ok;
}
bool net_resolve(const char* host, char* out16, int timeoutMs) {
    u8 ip[4]; if (ip_parse(host, ip)) { ip_format(ip, out16); return true; }
    if (!g_have || !g_ni.linkUp || !host[0]) return false;
    u8 q[300]; int n = 12; mem_set(q, 0, 12); g_dnsq.id = g_dnsId++; put16(q, g_dnsq.id); put16(q + 2, 0x0100); put16(q + 4, 1);
    const char* p = host;
    while (*p) { int l = 0; const char* s = p; while (*p && *p != '.') { p++; l++; } if (l == 0 || l > 63 || n + l + 6 > 280) return false; q[n++] = (u8)l; for (int i = 0; i < l; i++) q[n++] = (u8)s[i]; if (*p == '.') p++; }
    q[n++] = 0; put16(q + n, 1); put16(q + n + 2, 1); n += 4;
    u8 u[320]; put16(u, 40053); put16(u + 2, 53); put16(u + 4, (u16)(8 + n)); put16(u + 6, 0); mem_cpy(u + 8, q, (size_t)n);
    g_dnsq.got = false; g_dnsq.wait = true;
    for (int attempt = 0; attempt < 2 && !g_dnsq.got; attempt++) { if (!ip_send(17, g_dns, u, 8 + n)) continue; wait_flag(&g_dnsq.got, timeoutMs / 2); }
    g_dnsq.wait = false; if (!g_dnsq.got) return false;
    ip_format(g_dnsq.ip, out16); return true;
}


// ---------------------------------------------------------------- TCP (client side, one socket)
enum TcpState { T_CLOSED, T_SYN_SENT, T_ESTABLISHED, T_FIN_WAIT, T_CLOSE_WAIT };
static struct Tcp {
    TcpState st; u8 rip[4]; u16 lport, rport; u32 snd_nxt, snd_una, rcv_nxt; bool peerFin, reset, gotAck;
    u8 rx[4096]; int rxLen; u16 nextPort;
} g_tcp = { T_CLOSED, {0}, 0, 0, 0, 0, 0, false, false, false, {0}, 0, 40000 };
static void put32(u8* p, u32 v) { p[0] = (u8)(v >> 24); p[1] = (u8)(v >> 16); p[2] = (u8)(v >> 8); p[3] = (u8)v; }
static u32 get32(const u8* p) { return ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3]; }
enum { F_FIN = 1, F_SYN = 2, F_RST = 4, F_PSH = 8, F_ACK = 16 };
static bool tcp_send_seg(u8 flags, const u8* data, int len, bool withMss) {
    u8 seg[1100]; int hl = withMss ? 24 : 20; if (len > 1000) return false;
    put16(seg, g_tcp.lport); put16(seg + 2, g_tcp.rport); put32(seg + 4, g_tcp.snd_nxt); put32(seg + 8, (flags & F_ACK) ? g_tcp.rcv_nxt : 0);
    seg[12] = (u8)((hl / 4) << 4); seg[13] = flags; put16(seg + 14, 4096); put16(seg + 16, 0); put16(seg + 18, 0);
    if (withMss) { seg[20] = 2; seg[21] = 4; put16(seg + 22, 1360); }
    if (len) mem_cpy(seg + hl, data, (size_t)len);
    u8 ps[12 + 1100]; mem_cpy(ps, g_ip, 4); mem_cpy(ps + 4, g_tcp.rip, 4); ps[8] = 0; ps[9] = 6; put16(ps + 10, (u16)(hl + len)); mem_cpy(ps + 12, seg, (size_t)(hl + len));
    put16(seg + 16, ip_checksum(ps, 12 + hl + len));
    return ip_send(6, g_tcp.rip, seg, hl + len);
}
static void tcp_handle(const u8* ip, const u8* t, int tn) {
    if (g_tcp.st == T_CLOSED || tn < 20 || !ip_eq(ip + 12, g_tcp.rip)) return;
    if (get16(t) != g_tcp.rport || get16(t + 2) != g_tcp.lport) return;
    int hl = (t[12] >> 4) * 4; if (hl < 20 || hl > tn) return;
    u8 fl = t[13]; u32 seq = get32(t + 4), ack = get32(t + 8); const u8* d = t + hl; int dn = tn - hl;
    if (fl & F_RST) { g_tcp.reset = true; g_tcp.st = T_CLOSED; return; }
    if (g_tcp.st == T_SYN_SENT) {
        if ((fl & (F_SYN | F_ACK)) == (F_SYN | F_ACK) && ack == g_tcp.snd_nxt + 1) { g_tcp.snd_nxt++; g_tcp.snd_una = g_tcp.snd_nxt; g_tcp.rcv_nxt = seq + 1; g_tcp.st = T_ESTABLISHED; tcp_send_seg(F_ACK, nullptr, 0, false); g_tcp.gotAck = true; }
        return;
    }
    if (fl & F_ACK) { int diff = (int)(ack - g_tcp.snd_una); if (diff > 0 && (int)(g_tcp.snd_nxt - ack) >= 0) { g_tcp.snd_una = ack; g_tcp.gotAck = true; } }
    bool needAck = false;
    if (dn > 0 && seq == g_tcp.rcv_nxt) {
        int room = (int)sizeof g_tcp.rx - g_tcp.rxLen; int take = dn < room ? dn : room;
        mem_cpy(g_tcp.rx + g_tcp.rxLen, d, (size_t)take); g_tcp.rxLen += take; g_tcp.rcv_nxt += (u32)take; needAck = true;
    } else if (dn > 0) needAck = true;                                  // out of order / duplicate: re-ACK what we have
    if ((fl & F_FIN) && seq + (u32)dn == g_tcp.rcv_nxt) { g_tcp.rcv_nxt++; g_tcp.peerFin = true; if (g_tcp.st == T_ESTABLISHED) g_tcp.st = T_CLOSE_WAIT; needAck = true; }
    if (needAck) tcp_send_seg(F_ACK, nullptr, 0, false);
}
bool net_tcp_open() { return g_tcp.st == T_ESTABLISHED || g_tcp.st == T_CLOSE_WAIT; }
bool net_tcp_connect(const char* ipstr, u16 port, int timeoutMs, int* connectMs) {
    u8 ip[4]; if (!g_have || !g_ni.linkUp || !ip_parse(ipstr, ip)) return false;
    if (g_tcp.st != T_CLOSED) net_tcp_close();
    mem_cpy(g_tcp.rip, ip, 4); g_tcp.rport = port; g_tcp.lport = g_tcp.nextPort++; if (g_tcp.nextPort > 60000) g_tcp.nextPort = 40000;
    g_tcp.snd_nxt = (u32)hal_ticks() * 7919u + 1000u; g_tcp.snd_una = g_tcp.snd_nxt; g_tcp.rcv_nxt = 0; g_tcp.rxLen = 0; g_tcp.peerFin = false; g_tcp.reset = false; g_tcp.gotAck = false;
    g_tcp.st = T_SYN_SENT; long t0 = hal_ticks(); long end = t0 + timeoutMs / 10 + 1;
    for (int attempt = 0; attempt < 3 && g_tcp.st == T_SYN_SENT; attempt++) {
        if (!tcp_send_seg(F_SYN, nullptr, 0, true)) { g_tcp.st = T_CLOSED; return false; }
        long wait = min(end, hal_ticks() + timeoutMs / 30 + 1);
        while (g_tcp.st == T_SYN_SENT && hal_ticks() < wait) { net_poll(); if (g_tcp.st != T_SYN_SENT) break; hal_yield(); }
    }
    if (g_tcp.st != T_ESTABLISHED) { g_tcp.st = T_CLOSED; return false; }
    if (connectMs) *connectMs = (int)((hal_ticks() - t0) * 10); return true;
}
int net_tcp_send(const u8* data, int len) {
    if (!net_tcp_open()) return -1;
    int sent = 0;
    while (sent < len) {
        int n = len - sent < 900 ? len - sent : 900; u32 start = g_tcp.snd_nxt; bool acked = false;
        for (int attempt = 0; attempt < 4 && !acked; attempt++) {
            g_tcp.snd_nxt = start; g_tcp.gotAck = false;
            if (!tcp_send_seg(F_PSH | F_ACK, data + sent, n, false)) return -1;
            g_tcp.snd_nxt = start + (u32)n;
            long end = hal_ticks() + 60;
            while (hal_ticks() < end && !acked) { net_poll(); if ((int)(g_tcp.snd_una - (start + (u32)n)) >= 0) acked = true; else if (g_tcp.st == T_CLOSED) return -1; else hal_yield(); }
        }
        if (!acked) return sent > 0 ? sent : -1;
        sent += n;
    }
    return sent;
}
int net_tcp_recv(u8* buf, int max, int timeoutMs) {
    long end = hal_ticks() + timeoutMs / 10 + 1;
    for (;;) {
        net_poll();
        if (g_tcp.rxLen > 0) { int n = g_tcp.rxLen < max ? g_tcp.rxLen : max; mem_cpy(buf, g_tcp.rx, (size_t)n); mem_cpy(g_tcp.rx, g_tcp.rx + n, (size_t)(g_tcp.rxLen - n)); g_tcp.rxLen -= n; return n; }
        if (g_tcp.reset || g_tcp.st == T_CLOSED || g_tcp.peerFin) return -1;
        if (hal_ticks() >= end) return 0;
        hal_yield();
    }
}
void net_tcp_close() {
    if (g_tcp.st == T_ESTABLISHED || g_tcp.st == T_CLOSE_WAIT) {
        tcp_send_seg(F_FIN | F_ACK, nullptr, 0, false); g_tcp.snd_nxt++; g_tcp.st = T_FIN_WAIT;
        long end = hal_ticks() + 30; while (hal_ticks() < end && g_tcp.st == T_FIN_WAIT) { net_poll(); hal_yield(); }
    }
    g_tcp.st = T_CLOSED; g_tcp.rxLen = 0;
}

// ---------------------------------------------------------------- diagnostics
bool net_dns_query(const char* host, char* ip16, int* ms) { long t0 = hal_ticks(); bool ok = net_resolve(host, ip16, 2000); if (ms) *ms = (int)((hal_ticks() - t0) * 10); return ok; }
bool net_http_head(const char* ip, u16 port, const char* host, char* line, int cap, int* ms) {
    long t0 = hal_ticks(); line[0] = 0; int cm = 0;
    if (!net_tcp_connect(ip, port, 3000, &cm)) return false;
    char req[160]; sfmt(req, sizeof req, "HEAD / HTTP/1.0\r\nHost: %s\r\nUser-Agent: mX\r\nConnection: close\r\n\r\n", host);
    bool ok = net_tcp_send((const u8*)req, slen(req)) > 0; u8 b[200]; int n = ok ? net_tcp_recv(b, sizeof b - 1, 3000) : -1;
    if (n > 0) { b[n] = 0; int i = 0; while (i < n && b[i] != '\r' && b[i] != '\n' && i < cap - 1) { line[i] = (char)b[i]; i++; } line[i] = 0; }
    net_tcp_close(); if (ms) *ms = (int)((hal_ticks() - t0) * 10); return n > 0 && line[0];
}
int net_diagnose(NetTest* o, int max) {
    int n = 0;
    auto add = [&](const char* name, int st, const char* fmt, ...) { if (n >= max) return; scopy(o[n].name, name, sizeof o[n].name); o[n].status = st; va_list ap; va_start(ap, fmt); svfmt(o[n].detail, sizeof o[n].detail, fmt, ap); va_end(ap); n++; };
    if (!g_have) { add("Network adapter", 2, "%s", g_ni.status); return n; }
    net_poll(); add("Network adapter", 0, "%s", g_ni.name); add("Link", g_ni.linkUp ? 0 : 2, g_ni.linkUp ? "cable connected" : "no link - check the cable / QEMU -nic");
    if (!g_ni.linkUp) return n;
    add("IP configuration", 0, "%s  mask %s  gw %s  dns %s", g_ni.ip, g_ni.mask, g_ni.gw, g_ni.dns);
    int rtt = 0; bool gw = net_ping(g_ni.gw, &rtt, 1000); add("Gateway reachable", gw ? 0 : 2, gw ? "%s replied in %d ms" : "no reply from %s", g_ni.gw, rtt);
    char ip[16]; int ms = 0; bool dn = net_dns_query("example.com", ip, &ms); add("DNS lookup", dn ? 0 : 2, dn ? "example.com -> %s (%d ms, server %s)" : "no answer from %s", dn ? ip : g_ni.dns, ms, g_ni.dns);
    if (dn) {
        int cm = 0; bool tc = net_tcp_connect(ip, 80, 3000, &cm); add("TCP connection", tc ? 0 : 1, tc ? "connected to %s:80 in %d ms" : "could not connect to %s:80 (offline?)", ip, cm); if (tc) net_tcp_close();
        char st[80]; int hm = 0; bool hh = tc && net_http_head(ip, 80, "example.com", st, sizeof st, &hm); if (tc) add("HTTP request", hh ? 0 : 1, hh ? "%s (%d ms)" : "no HTTP answer", st, hm);
    }
    return n;
}

void net_init() {
    mem_set(&g_ni, 0, sizeof g_ni); g_have = false;
    bool other = false;
    if (nic_probe(g_nic, other)) { g_have = true; g_ni.present = true; scopy(g_ni.name, g_nic.name, sizeof g_ni.name); mem_cpy(g_ni.mac, g_nic.mac, 6); g_ni.linkUp = g_nic.link(); }
    g_ni.detectedOther = other;
    net_apply_config();
}
} // namespace mx
