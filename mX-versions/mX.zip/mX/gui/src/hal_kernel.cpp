// hal_kernel.cpp — the real hardware behind mx/hal.hpp: PIT ticks via Kernel24, RTC/CMOS, CPUID, serial log.
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
#include "mx/sysstat.hpp"
namespace mx {

static constexpr u16 CMOS_BASE = 0x40;          // first CMOS byte used for mX recovery state (see recovery.cpp)

long hal_ticks() { return timer_ticks(); }
void hal_yield() {
    sys_yield();
    u64 fl; asm volatile("pushfq; popq %0" : "=r"(fl));
    if (fl & 0x200) { sysstat_idle(true); asm volatile("hlt"); sysstat_idle(false); }   // sleep until the next interrupt; counted as idle
}
void hal_log(const char* s) { for (; *s; s++) { for (int i = 0; i < 20000 && !(inb(0x3FD) & 0x20); i++) {} outb(0x3F8, (u8)*s); } }

static u8 cmos_in(u8 reg) { outb(0x70, reg); return inb(0x71); }
static void cmos_out(u8 reg, u8 v) { outb(0x70, reg); outb(0x71, v); }
void hal_cmos_read(int off, u8* out, int n) { u64 f = irq_save(); for (int i = 0; i < n; i++) out[i] = cmos_in((u8)(CMOS_BASE + off + i)); irq_restore(f); }
void hal_cmos_write(int off, const u8* in, int n) { u64 f = irq_save(); for (int i = 0; i < n; i++) cmos_out((u8)(CMOS_BASE + off + i), in[i]); irq_restore(f); }

static int bcd(int v) { return (v & 0x0F) + ((v >> 4) * 10); }
static u8 tobcd(int v) { return (u8)(((v / 10) << 4) | (v % 10)); }
void hal_rtc_read(RtcTime& t) {
    u64 f = irq_save();
    for (int i = 0; i < 100000 && (cmos_in(0x0A) & 0x80); i++) cpu_relax();     // wait out an update in progress
    int s = cmos_in(0), mi = cmos_in(2), h = cmos_in(4), wd = cmos_in(6), d = cmos_in(7), mo = cmos_in(8), y = cmos_in(9), cent = cmos_in(0x32), b = cmos_in(0x0B);
    irq_restore(f);
    if (!(b & 4)) { s = bcd(s); mi = bcd(mi); h = ((h & 0x80) ? (bcd(h & 0x7F) | 0x80) : bcd(h)); wd = bcd(wd); d = bcd(d); mo = bcd(mo); y = bcd(y); cent = bcd(cent); }
    if (!(b & 2) && (h & 0x80)) h = ((h & 0x7F) % 12) + 12;
    t.second = s; t.minute = mi; t.hour = h & 0x7F; t.weekday = wd; t.day = d; t.month = mo; t.year = (cent >= 19 && cent <= 21 ? cent : 20) * 100 + y;
}
bool hal_rtc_write(const RtcTime& t) {
    u64 f = irq_save(); u8 b = cmos_in(0x0B); cmos_out(0x0B, (u8)(b | 0x80));        // SET: freeze updates
    bool binary = (b & 4) != 0;
    cmos_out(0, binary ? (u8)t.second : tobcd(t.second)); cmos_out(2, binary ? (u8)t.minute : tobcd(t.minute)); cmos_out(4, binary ? (u8)t.hour : tobcd(t.hour));
    cmos_out(0x0B, b); irq_restore(f); return true;
}

static void cpuid(u32 leaf, u32& a, u32& b, u32& c, u32& d) { asm volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(leaf), "c"(0)); }
void hal_cpu_vendor(char* out) { u32 a, b, c, d; cpuid(0, a, b, c, d); mem_cpy(out, &b, 4); mem_cpy(out + 4, &d, 4); mem_cpy(out + 8, &c, 4); out[12] = 0; }
void hal_cpu_brand(char* out) {
    u32 a, b, c, d; cpuid(0x80000000u, a, b, c, d);
    if (a < 0x80000004u) { scopy(out, "Unknown x86-64 CPU", 49); return; }
    for (u32 i = 0; i < 3; i++) { cpuid(0x80000002u + i, a, b, c, d); mem_cpy(out + i * 16, &a, 4); mem_cpy(out + i * 16 + 4, &b, 4); mem_cpy(out + i * 16 + 8, &c, 4); mem_cpy(out + i * 16 + 12, &d, 4); }
    out[48] = 0; char* p = out; while (*p == ' ') p++; if (p != out) { int i = 0; while ((out[i] = p[i])) i++; }
}
u64 hal_free_mem_kb() { return (u64)pmm_free_pages() * 4; }
u64 hal_total_mem_kb() { return system_memory_kb > 0 ? (u64)system_memory_kb : (u64)pmm_total_pages() * 4; }
u64 hal_heap_free() { return (u64)heap_free_bytes(); }

void hal_reboot() {
    for (int i = 0; i < 100000 && (inb(0x64) & 2); i++) {}
    outb(0x64, 0xFE);                            // pulse the CPU reset line via the keyboard controller
    for (;;) asm volatile("cli; hlt");
}
void hal_poweroff() {
    outw(0x604, 0x2000); outw(0xB004, 0x2000); outw(0x4004, 0x3400);     // QEMU(ACPI), Bochs/old QEMU, VirtualBox
    for (;;) asm volatile("cli; hlt");
}
} // namespace mx
