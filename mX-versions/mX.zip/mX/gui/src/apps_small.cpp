// dialogs, Notepad, Calculator, About mX
#include "mx/apps.hpp"
#include "mx/wm.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
namespace mx {

// ================================================================= dialogs
struct DialogApp : App {
    App* owner; int tag; FStr<48> title; FStr<200> msg; FStr<24> label; TextField field; bool prompt, confirm, password; IconId icon; int lines = 1;
    void windowSpec(WindowSpec& s) override {
        int nl = 1; for (const char* p = msg; *p; p++) if (*p == '\n') nl++;
        int h = (prompt ? 130 : 100) + nl * 18;
        s.title = title; s.frame = Rect{ 0, 0, 380, h }; s.flags = WF_MODAL | WF_CENTER | WF_NOMIN | WF_NOTASKBAR; s.minW = 380; s.minH = h;
    }
    void onCreate() override { field.focused = true; field.password = password; }
    void finish(bool ok) {
        App* o = owner; int t = tag; bool wasPrompt = prompt; char text[64]; scopy(text, field.buf, sizeof text);
        if (o && wm().find(o)) o->onDialog(t, ok, wasPrompt ? text : "");
        close();
    }
    void onPaint(Canvas& c) override {
        Theme& th = theme();
        c.icon(icon, 14, 14, 32);
        int y = 14; const char* p = msg; char line[100];
        while (*p) { int n = 0; while (*p && *p != '\n' && n < 99) line[n++] = *p++; line[n] = 0; if (*p == '\n') p++; c.textMax(58, y, line, th.text, c.w - 70); y += 18; }
        int by = c.h - 40;
        if (prompt) { c.text(14, y + 8, label, th.textDim); Rect f = { 14, y + 26, c.w - 28, 26 }; field.paint(c, *this, f, 1); }
        if (confirm || prompt) { button(c, Rect{ c.w - 182, by, 80, 28 }, confirm ? "Yes" : "OK", 2, true); button(c, Rect{ c.w - 94, by, 80, 28 }, confirm ? "No" : "Cancel", 3); }
        else button(c, Rect{ c.w - 94, by, 80, 28 }, "OK", 2, true);
    }
    void onAction(int id, int) override { if (id == 2) finish(true); else if (id == 3) finish(false); }
    void onKey(const KeyEvent& e) override {
        if (!e.down) return;
        if (e.key == K_ESC) { finish(false); return; }
        if (prompt) { if (field.key(e)) finish(true); }
        else if (e.key == K_ENTER || e.key == K_SPACE) finish(true);
    }
    bool onClose() override { return true; }
};
static Window* make_dialog(App* owner, int tag, const char* title, const char* msg, const char* label, const char* init, bool prompt, bool confirm, bool pw, IconId ic) {
    DialogApp* d = new DialogApp(); d->owner = owner; d->tag = tag; d->title.set(title); d->msg.set(msg); d->label.set(label ? label : "");
    d->prompt = prompt; d->confirm = confirm; d->password = pw; d->icon = ic; if (init) d->field.set(init);
    return app_open(d, ic);
}
Window* dialog_prompt(App* o, int tag, const char* t, const char* label, const char* init, bool pw) { return make_dialog(o, tag, t, "", label, init, true, false, pw, IC_INFO); }
Window* dialog_confirm(App* o, int tag, const char* t, const char* m) { return make_dialog(o, tag, t, m, nullptr, nullptr, false, true, false, IC_WARN); }
Window* dialog_message(const char* t, const char* m, IconId ic) { return make_dialog(nullptr, 0, t, m, nullptr, nullptr, false, false, false, ic); }

// ================================================================= "Choose a new password" (first-boot admin + Settings)
struct SetPasswordApp : App {
    char user[16]; bool forced; TextField a, b; int focus = 0; char err[80] = "";
    void windowSpec(WindowSpec& s) override { s.title = forced ? "Secure your administrator account" : "Change password"; s.frame = Rect{ 0, 0, 420, 250 }; s.flags = WF_MODAL | WF_CENTER | WF_NOMIN | WF_NOTASKBAR | (forced ? WF_NOCLOSE : 0); s.minW = 420; s.minH = 250; }
    void onCreate() override { a.password = b.password = true; a.focused = true; a.maxLen = b.maxLen = 30; }
    void submit() {
        const User* u = users_find(user); if (!u) { close(); return; }
        if (!seq(a.buf, b.buf)) { scopy(err, "The two passwords don't match.", sizeof err); invalidate(); return; }
        const char* why = nullptr; if (!users_password_acceptable(u->role, a.buf, &why)) { scopy(err, why ? why : "Password rejected.", sizeof err); invalidate(); return; }
        if (users_set_password(user, a.buf)) { notify(N_OK, "Security", "Password changed", "Your new password is active."); close(); } else { scopy(err, "Couldn't save the password.", sizeof err); invalidate(); }
    }
    void onPaint(Canvas& c) override {
        Theme& t = theme(); beginPaint(c);
        c.icon(IC_LOCK, 16, 14, 32);
        c.textMax(60, 12, forced ? "This account still uses the factory password." : "Choose a new password.", t.text, c.w - 76, true);
        c.textMax(60, 32, forced ? "Pick a new one (6+ characters for administrators)." : "Use at least 4 characters (6 for administrators).", t.textDim, c.w - 76);
        c.text(16, 66, "New password", t.textDim); a.focused = focus == 0; a.paint(c, *this, Rect{ 16, 84, c.w - 32, 28 }, 1);
        c.text(16, 120, "Repeat it", t.textDim); b.focused = focus == 1; b.paint(c, *this, Rect{ 16, 138, c.w - 32, 28 }, 2);
        if (err[0]) c.text(16, 174, err, t.danger);
        button(c, Rect{ c.w - 190, c.h - 40, 84, 28 }, "Save", 3, true); button(c, Rect{ c.w - 98, c.h - 40, 84, 28 }, forced ? "Later" : "Cancel", 4);
    }
    void onAction(int id, int) override { if (id == 1) { focus = 0; invalidate(); } else if (id == 2) { focus = 1; invalidate(); } else if (id == 3) submit(); else if (id == 4) close(); }
    void onKey(const KeyEvent& e) override {
        if (!e.down) return;
        if (e.key == K_TAB) { focus = 1 - focus; invalidate(); return; }
        if (e.key == K_ESC) { close(); return; }
        TextField& f = focus == 0 ? a : b;
        if (f.key(e)) { if (focus == 0) { focus = 1; invalidate(); } else submit(); }
    }
};
Window* open_set_password_dialog(const char* user, bool forced) { SetPasswordApp* a = new SetPasswordApp(); scopy(a->user, user, 16); a->forced = forced; return app_open(a, IC_LOCK); }

// ================================================================= Notepad
struct NotepadApp : App {
    char text[VFS_BLOCK_SIZE + 2]; int len = 0, cur = 0; FStr<96> path; bool dirty = false; int scrollLine = 0;
    NotepadApp() { text[0] = 0; }
    void windowSpec(WindowSpec& s) override { s.title = "Notepad"; s.frame = Rect{ 120, 60, 520, 380 }; s.flags = WF_RESIZABLE; s.minW = 300; s.minH = 180; }
    void updateTitle() { char t[64]; sfmt(t, sizeof t, "%s%s - Notepad", path.len() ? fs_basename(path) : "Untitled", dirty ? "*" : ""); if (win) win->title.set(t); }
    void load(const char* p) {
        path.set(p); int n = 0;
        if (fs_read(p, text, sizeof text, &n)) { len = n; cur = 0; dirty = false; } updateTitle();
    }
    void save() {
        if (!path.len()) { dialog_prompt(this, 1, "Save as", "File path (e.g. /home/<you>/note.txt)", "", false); return; }
        if (!fs_can_write(path)) { notifyf(N_ERROR, "Notepad", "Permission denied", "You can't write to %s", path.c()); return; }
        if (fs_write(path, text, len)) { dirty = false; updateTitle(); notifyf(N_OK, "Notepad", "Saved", "%s (%d bytes)", fs_basename(path), len); }
        else notify(N_ERROR, "Notepad", "Save failed", "Files are limited to 512 bytes on the RAM disk.");
    }
    void onDialog(int tag, bool ok, const char* t) override { if (tag == 1 && ok && t[0]) { path.set(t); save(); } }
    void onCreate() override { updateTitle(); }
    void onPaint(Canvas& c) override {
        Theme& th = theme();
        c.fill(Rect{ 0, 0, c.w, 34 }, th.panel); c.hline(0, 33, c.w, th.panelDark);
        button(c, Rect{ 6, 5, 64, 24 }, "Save", 1, true); button(c, Rect{ 76, 5, 64, 24 }, "Clear", 2);
        char st[48]; sfmt(st, sizeof st, "%d/%d bytes", len, VFS_BLOCK_SIZE); c.text(c.w - 8 - c.textWidth(st), 9, st, len > 480 ? th.warn : th.textDim);
        Rect area = { 0, 34, c.w, c.h - 34 }; c.fill(area, th.field);
        Canvas ac = c.sub(area); int cols = max(1, (area.w - 12) / FONT_W);
        int x = 6, y = 4, col = 0, line = 0; int curx = 6, cury = 4;
        for (int i = 0; i <= len; i++) {
            if (i == cur) { curx = x; cury = y; }
            if (i == len) break;
            char ch = text[i];
            if (ch == '\n' || col >= cols) { x = 6; y += FONT_H; col = 0; line++; if (ch == '\n') continue; }
            if (y - scrollLine * FONT_H >= -FONT_H && y - scrollLine * FONT_H < area.h) ac.glyph(x, y - scrollLine * FONT_H, (u8)ch, th.text);
            x += FONT_W; col++;
        }
        if (cury - scrollLine * FONT_H >= area.h - FONT_H) scrollLine++;
        else if (cury - scrollLine * FONT_H < 0 && scrollLine > 0) scrollLine--;
        if (((ui_ticks() / 50) & 1) == 0) ac.fill(Rect{ curx, cury - scrollLine * FONT_H, 2, FONT_H }, th.accent);
    }
    void onAction(int id, int) override { if (id == 1) save(); else if (id == 2) { len = cur = 0; text[0] = 0; dirty = true; updateTitle(); invalidate(); } }
    void onKey(const KeyEvent& e) override {
        if (!e.down) return;
        if ((e.mods & MOD_CTRL) && e.key == K_CHAR && (e.ch == 's' || e.ch == 'S')) { save(); return; }
        bool ch = false;
        if (e.key == K_BACKSPACE && cur > 0) { for (int i = cur - 1; i < len; i++) text[i] = text[i + 1]; cur--; len--; ch = true; }
        else if (e.key == K_DELETE && cur < len) { for (int i = cur; i < len; i++) text[i] = text[i + 1]; len--; ch = true; }
        else if (e.key == K_LEFT && cur > 0) cur--; else if (e.key == K_RIGHT && cur < len) cur++;
        else if (e.key == K_HOME) { while (cur > 0 && text[cur - 1] != '\n') cur--; }
        else if (e.key == K_END) { while (cur < len && text[cur] != '\n') cur++; }
        else if (e.key == K_UP) { int col = 0; int p = cur; while (p > 0 && text[p - 1] != '\n') { p--; col++; } if (p > 0) { int q = p - 1; int ls = q; while (ls > 0 && text[ls - 1] != '\n') ls--; cur = min(ls + col, q); } }
        else if (e.key == K_DOWN) { int col = 0; int p = cur; while (p > 0 && text[p - 1] != '\n') { p--; col++; } int q = cur; while (q < len && text[q] != '\n') q++; if (q < len) { int ns = q + 1; int ne = ns; while (ne < len && text[ne] != '\n') ne++; cur = min(ns + col, ne); } }
        else if ((e.key == K_ENTER || e.key == K_CHAR || e.key == K_SPACE || e.key == K_TAB) && len < VFS_BLOCK_SIZE && !(e.mods & (MOD_CTRL | MOD_ALT))) {
            char v = e.key == K_ENTER ? '\n' : (e.key == K_TAB ? ' ' : (char)e.ch);
            if (v >= 32 || v == '\n') { for (int i = len; i >= cur; i--) text[i + 1] = text[i]; text[cur++] = v; len++; ch = true; }
        }
        if (ch) { dirty = true; updateTitle(); }
        invalidate();
    }
    bool onClose() override { if (dirty) { notify(N_INFO, "Notepad", "Discarded changes", "Unsaved text was discarded. Use Save (Ctrl+S) next time."); } return true; }
};
App* make_notepad() { return new NotepadApp(); }
Window* notepad_open_file(const char* p) { NotepadApp* n = new NotepadApp(); Window* w = app_open(n, IC_NOTEPAD); if (w) n->load(p); return w; }

// ================================================================= Calculator
struct CalcApp : App {
    i64 acc = 0, cur = 0; char op = 0; bool fresh = true, err = false;
    void windowSpec(WindowSpec& s) override { s.title = "Calculator"; s.frame = Rect{ 200, 80, 232, 300 }; s.flags = 0; s.minW = 232; s.minH = 300; }
    void onPaint(Canvas& c) override {
        Theme& t = theme();
        Rect d = { 8, 8, c.w - 16, 44 }; c.fillRound(d, 4, rgb(30, 34, 46));
        char b[32]; if (err) scopy(b, "Error", 32); else sfmt(b, 32, "%lld", (long long)cur);
        int tw = c.textWidth(b, 2); c.text(d.right() - 8 - tw, d.y + 6, b, rgb(170, 240, 190), 2);
        static const char* keys[5][4] = { {"C","+/-","%","/"}, {"7","8","9","*"}, {"4","5","6","-"}, {"1","2","3","+"}, {"0","0",".","="} };
        for (int r = 0; r < 5; r++) for (int col = 0; col < 4; col++) {
            if (r == 4 && col == 1) continue;
            Rect k = { 8 + col * 54, 62 + r * 46, (r == 4 && col == 0) ? 100 : 50, 42 };
            bool opk = col == 3 || (r == 4 && col == 3);
            button(c, k, keys[r][col], r * 10 + col + 100, opk);
        }
        (void)t;
    }
    void apply() {
        if (op == '+') acc += cur; else if (op == '-') acc -= cur; else if (op == '*') acc *= cur;
        else if (op == '/') { if (cur == 0) err = true; else acc /= cur; } else acc = cur;
        cur = acc;
    }
    void press(const char* k) {
        if (err && k[0] != 'C') return;
        if (k[0] >= '0' && k[0] <= '9') { cur = fresh ? (k[0] - '0') : cur * 10 + (k[0] - '0'); fresh = false; }
        else if (k[0] == 'C') { acc = cur = 0; op = 0; fresh = true; err = false; }
        else if (k[0] == '+' && k[1] == '/') cur = -cur;
        else if (k[0] == '%') cur /= 100;
        else if (k[0] == '=') { apply(); op = 0; fresh = true; }
        else if (k[0] == '+' || k[0] == '-' || k[0] == '*' || k[0] == '/') { if (op && !fresh) apply(); else acc = cur; op = k[0]; fresh = true; }
        invalidate();
    }
    void onAction(int id, int) override {
        static const char* keys[5][4] = { {"C","+/-","%","/"}, {"7","8","9","*"}, {"4","5","6","-"}, {"1","2","3","+"}, {"0","0",".","="} };
        int r = (id - 100) / 10, col = (id - 100) % 10; if (r >= 0 && r < 5 && col < 4) press(keys[r][col]);
    }
    void onKey(const KeyEvent& e) override {
        if (!e.down) return;
        char s[2] = { 0, 0 };
        if (e.key == K_ENTER) s[0] = '='; else if (e.key == K_ESC || e.key == K_BACKSPACE) s[0] = 'C'; else if (e.key == K_CHAR) s[0] = (char)e.ch; else return;
        if ((s[0] >= '0' && s[0] <= '9') || s[0] == '+' || s[0] == '-' || s[0] == '*' || s[0] == '/' || s[0] == '=' || s[0] == 'C' || s[0] == '%') press(s);
    }
};
App* make_calc() { return new CalcApp(); }

// ================================================================= About
struct AboutApp : App {
    void windowSpec(WindowSpec& s) override { s.title = "About mX"; s.frame = Rect{ 180, 90, 380, 300 }; s.flags = WF_NOMIN; s.minW = 380; s.minH = 300; }
    void onPaint(Canvas& c) override {
        Theme& t = theme();
        c.gradV(Rect{ 0, 0, c.w, 96 }, t.titleActiveA, t.titleActiveB);
        c.fillRound(Rect{ 16, 14, 84, 68 }, 8, rgb(250, 250, 252)); c.logo(24, 22, 68, rgb(14, 14, 18)); c.text(116, 24, "mX", rgb(255, 255, 255), 2); c.text(118, 64, "Powered by Kernel24", rgb(210, 224, 250));
        char b[80]; int y = 112;
        auto row = [&](const char* k, const char* v) { c.text(20, y, k, t.textDim); c.text(150, y, v, t.text); y += 22; };
        row("Version", "mX 2026.10 (Stage 4)"); row("Kernel", "Kernel24 1.x, x86-64");
        char v[16]; hal_cpu_vendor(v); row("CPU vendor", v);
        sfmt(b, sizeof b, "%d MiB", (int)(hal_total_mem_kb() / 1024)); row("Memory", b);
        const User* u = users_current(); sfmt(b, sizeof b, "%s (%s)", u ? u->display : "-", u ? role_name(u->role) : "-"); row("User", b);
        sfmt(b, sizeof b, "%d x %d, 32-bit", c.w > 0 ? 800 : 0, 600); row("Display", b);
        c.textMax(20, c.h - 28, "Font: GNU Unifont (OFL 1.1).  Shell, kernel and GUI by you.", t.textDim, c.w - 30);
    }
};
App* make_about() { return new AboutApp(); }

} // namespace mx
