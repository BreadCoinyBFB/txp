#include "mx/sysstat.hpp"
#include "mx/kapi.hpp"
namespace mx {
// mirrors `struct Task` in process/task.cx (natural alignment: 48 bytes)
struct TaskRaw { i32 id; i32 state; i64 rsp; i64 kstack; i64 pml4; u8 isUser; u8 pad[3]; i32 exitCode; const char* name; };
static_assert(sizeof(TaskRaw) == 48, "Task layout must match process/task.cx");
}
extern "C" mx::TaskRaw task_table[];
extern "C" mx::i32 current_task;
namespace mx {

static volatile u32 g_ticksTotal = 0, g_ticksIdle = 0, g_perTask[PROC_MAX]; static volatile bool g_idle = false;
static u32 g_snapTotal = 0, g_snapIdle = 0, g_snapTask[PROC_MAX]; static int g_cpuPct = 0, g_taskTenths[PROC_MAX]; static long g_guiPid = -1;

void sysstat_idle(bool on) { g_idle = on; }
void sysstat_sample(long idx) {
    g_ticksTotal = g_ticksTotal + 1;
    if (g_idle) { g_ticksIdle = g_ticksIdle + 1; return; }
    if (idx >= 0 && idx < PROC_MAX) g_perTask[idx] = g_perTask[idx] + 1;
}
void sysstat_update() {
    u32 tot = g_ticksTotal - g_snapTotal, idle = g_ticksIdle - g_snapIdle;
    if (tot >= 50) {                                       // window of at least half a second
        g_cpuPct = tot ? (int)(100 - (idle * 100 + tot / 2) / tot) : 0; if (g_cpuPct < 0) g_cpuPct = 0;
        for (int i = 0; i < PROC_MAX; i++) { g_taskTenths[i] = (int)(((g_perTask[i] - g_snapTask[i]) * 1000u + tot / 2) / tot); g_snapTask[i] = g_perTask[i]; }
        g_snapTotal = g_ticksTotal; g_snapIdle = g_ticksIdle;
    }
}
int sysstat_cpu_percent() { return g_cpuPct; }
const char* sysstat_state_name(int s) { return s == 1 ? "Ready" : (s == 2 ? "Running" : (s == 3 ? "Ended" : "-")); }
int sysstat_processes(ProcInfo* out, int max) {
    int n = 0; if (g_guiPid < 0) g_guiPid = task_current_pid();
    for (int i = 0; i < PROC_MAX && n < max; i++) {
        const TaskRaw& t = task_table[i]; if (t.state == 0) continue;
        ProcInfo& p = out[n++]; p.pid = t.id; scopy(p.name, t.name ? t.name : "?", sizeof p.name); p.state = t.state; p.cpuTenths = g_taskTenths[i];
        p.stackUsed = (i == current_task) ? 0 : (t.kstack > t.rsp ? (int)(t.kstack - t.rsp) : 0); p.isGui = (t.id == g_guiPid);
    }
    return n;
}
} // namespace mx
extern "C" void gui_sched_sample(long idx) { mx::sysstat_sample(idx); }
