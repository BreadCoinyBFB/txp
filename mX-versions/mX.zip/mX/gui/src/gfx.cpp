#include "mx/gfx.hpp"
namespace mx {

extern const int logoW, logoH; extern const uint8_t logoMask[];
static Theme g_theme;
static bool g_theme_init = false;

void theme_set_accent(Color a) {
    Theme& t = g_theme;
    t.accent = a;
    t.accentDark = blend(rgb(0, 0, 0), a, 70);
    t.accentLight = blend(rgb(255, 255, 255), a, 70);
    t.titleActiveA = blend(rgb(255, 255, 255), a, 40);
    t.titleActiveB = blend(rgb(0, 0, 0), a, 55);
    t.selection = blend(a, rgb(255, 255, 255), 90);
}
Theme& theme() {
    if (!g_theme_init) {
        g_theme_init = true;
        Theme& t = g_theme;
        t.desktopTop = rgb(18, 28, 64);  t.desktopBottom = rgb(66, 40, 110);
        t.panel = rgb(236, 238, 242);    t.panelDark = rgb(196, 200, 210); t.panelLight = rgb(250, 251, 253);
        t.window = rgb(246, 247, 250);   t.text = rgb(24, 26, 32);        t.textDim = rgb(106, 112, 126);
        t.textOnAccent = rgb(255, 255, 255);
        t.titleInactive = rgb(150, 156, 172); t.border = rgb(70, 76, 96);
        t.ok = rgb(46, 160, 90); t.warn = rgb(224, 150, 20); t.danger = rgb(206, 62, 62);
        t.field = rgb(255, 255, 255);
        theme_set_accent(rgb(58, 120, 230));
    }
    return g_theme;
}

Canvas Canvas::sub(const Rect& r) const {
    Canvas c = *this;
    Rect abs_r = { r.x + ox, r.y + oy, r.w, r.h };
    c.clip = clip.intersect(abs_r);
    c.ox = abs_r.x; c.oy = abs_r.y; c.w = r.w; c.h = r.h;
    return c;
}

void Canvas::put(int x, int y, Color c) {
    x += ox; y += oy;
    if (x < clip.x || y < clip.y || x >= clip.x + clip.w || y >= clip.y + clip.h) return;
    px[y * pitch + x] = c;
}
Color Canvas::get(int x, int y) const {
    x += ox; y += oy;
    if (x < 0 || y < 0 || x >= bw || y >= bh) return 0;
    return px[y * pitch + x];
}
void Canvas::fill(const Rect& r, Color c) {
    Rect a = { r.x + ox, r.y + oy, r.w, r.h };
    a = a.intersect(clip);
    for (int y = a.y; y < a.y + a.h; y++) mx_fill32(px + y * pitch + a.x, c, (size_t)a.w);
}
void Canvas::hline(int x, int y, int len, Color c) { Rect r = { x, y, len, 1 }; fill(r, c); }
void Canvas::vline(int x, int y, int len, Color c) { Rect r = { x, y, 1, len }; fill(r, c); }
void Canvas::rect(const Rect& r, Color c) {
    if (r.empty()) return;
    hline(r.x, r.y, r.w, c); hline(r.x, r.bottom() - 1, r.w, c);
    vline(r.x, r.y, r.h, c); vline(r.right() - 1, r.y, r.h, c);
}
void Canvas::line(int x0, int y0, int x1, int y1, Color c) {
    int dx = abs_(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs_(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    for (;;) {
        put(x0, y0, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
// corner inset per row for a small radius (no sqrt needed: precomputed for r<=6)
static int corner_inset(int radius, int row) {
    static const u8 t[7][6] = {
        {0,0,0,0,0,0}, {1,0,0,0,0,0}, {2,1,0,0,0,0}, {3,1,1,0,0,0}, {4,2,1,1,0,0}, {5,3,2,1,1,0}, {6,4,3,2,1,1}};
    if (radius > 6) radius = 6;
    if (row >= radius) return 0;
    return t[radius][row];
}
void Canvas::fillRound(const Rect& r, int radius, Color c) {
    if (radius <= 0) { fill(r, c); return; }
    for (int row = 0; row < r.h; row++) {
        int inset = 0;
        if (row < radius) inset = corner_inset(radius, row);
        else if (row >= r.h - radius) inset = corner_inset(radius, r.h - 1 - row);
        Rect s = { r.x + inset, r.y + row, r.w - 2 * inset, 1 };
        fill(s, c);
    }
}
void Canvas::roundRect(const Rect& r, int radius, Color c) {
    if (r.empty()) return;
    for (int row = 0; row < r.h; row++) {
        int inset = 0;
        if (row < radius) inset = corner_inset(radius, row);
        else if (row >= r.h - radius) inset = corner_inset(radius, r.h - 1 - row);
        if (row == 0 || row == r.h - 1) { hline(r.x + inset, r.y + row, r.w - 2 * inset, c); }
        else { put(r.x + inset, r.y + row, c); put(r.x + r.w - 1 - inset, r.y + row, c); }
    }
}
void Canvas::gradV(const Rect& r, Color top, Color bottom) {
    if (r.h <= 0) return;
    for (int i = 0; i < r.h; i++) {
        int a = r.h > 1 ? (i * 255) / (r.h - 1) : 0;
        Rect s = { r.x, r.y + i, r.w, 1 };
        fill(s, blend(bottom, top, a));
    }
}
void Canvas::tint(const Rect& r, Color c, int alpha) {
    Rect a = { r.x + ox, r.y + oy, r.w, r.h };
    a = a.intersect(clip);
    for (int y = a.y; y < a.y + a.h; y++) {
        uint32_t* p = px + y * pitch + a.x;
        for (int x = 0; x < a.w; x++) p[x] = blend(c, p[x], alpha);
    }
}
void Canvas::shadow(const Rect& r, int spread, int maxAlpha) {
    for (int i = spread; i >= 1; i--) {
        Rect s = { r.x - i + 3, r.y - i + 4, r.w + 2 * i, r.h + 2 * i };
        tint(s, rgb(0, 0, 0), maxAlpha / (spread * 2) + 1 > 0 ? (maxAlpha / spread) / 3 : 4);
    }
}
void Canvas::bevel(const Rect& r, bool raised) {
    Theme& t = theme();
    Color hi = raised ? t.panelLight : t.panelDark, lo = raised ? t.panelDark : t.panelLight;
    hline(r.x, r.y, r.w, hi); vline(r.x, r.y, r.h, hi);
    hline(r.x, r.bottom() - 1, r.w, lo); vline(r.right() - 1, r.y, r.h, lo);
}
void Canvas::blit(const uint32_t* src, int sw, int sh, int x, int y) {
    Rect a = { x + ox, y + oy, sw, sh };
    Rect v = a.intersect(clip);
    for (int yy = v.y; yy < v.y + v.h; yy++)
        mx_copy32(px + yy * pitch + v.x, src + (yy - a.y) * sw + (v.x - a.x), (size_t)v.w);
}

int Canvas::glyph(int x, int y, uint32_t cp, Color fg, int scale) {
    const u8* g = font8x16[font_glyph_index(cp)];
    for (int row = 0; row < FONT_H; row++) {
        u8 bits = g[row];
        if (!bits) continue;
        for (int col = 0; col < FONT_W; col++) {
            if (bits & (0x80 >> col)) {
                if (scale == 1) put(x + col, y + row, fg);
                else { Rect r = { x + col * scale, y + row * scale, scale, scale }; fill(r, fg); }
            }
        }
    }
    return FONT_W * scale;
}
static u32 next_cp(const char*& s) {                       // minimal UTF-8 decode (2/3-byte)
    u32 cp = (u8)*s++;
    if (cp >= 0xC0) { int extra = cp >= 0xE0 ? 2 : 1; cp &= extra == 2 ? 0x0F : 0x1F; while (extra-- && *s) cp = (cp << 6) | ((u8)*s++ & 0x3F); }
    return cp;
}
int Canvas::monoText(int x, int y, const char* s, Color fg, int scale) {
    int cx = x; while (*s) cx += glyph(cx, y, next_cp(s), fg, scale); return cx - x;
}
void Canvas::putA(int x, int y, Color c, int a) {
    x += ox; y += oy;
    if (a <= 0 || x < clip.x || y < clip.y || x >= clip.x + clip.w || y >= clip.y + clip.h) return;
    u32* p = &px[y * pitch + x];
    *p = a >= 255 ? c : blend(c, *p, a);
}
static const UiFont& face_for(int scale, bool bold) { return scale >= 2 ? uiDisplay : (bold ? uiBold : uiRegular); }
// x is tracked in 1/8 px; ASCII uses the proportional face, anything else the 8x16 bitmap font.
static int ui_adv(const UiFont& f, u32 cp, int scale) { return (cp >= 0x20 && cp <= 0x7E) ? f.glyphs[cp - 0x20].adv8 : FONT_W * 8 * (scale >= 2 ? 2 : 1); }
static int draw_run(Canvas& c, int x, int y, const char* s, Color fg, int scale, bool bold) {
    const UiFont& f = face_for(scale, bold); int x8 = x * 8;
    while (*s) {
        u32 cp = next_cp(s);
        if (cp >= 0x20 && cp <= 0x7E) {
            const UiGlyph& g = f.glyphs[cp - 0x20]; int gx = (x8 + 4) / 8 + g.xoff;
            for (int row = 0; row < g.h; row++) for (int col = 0; col < g.w; col++) c.putA(gx + col, y + g.yoff + row, fg, f.bits[g.off + row * g.w + col]);
        } else c.glyph((x8 + 4) / 8, y + (scale >= 2 ? 8 : 0), cp, fg, scale >= 2 ? 2 : 1);
        x8 += ui_adv(f, cp, scale);
    }
    return (x8 - x * 8 + 7) / 8;
}
int Canvas::text(int x, int y, const char* s, Color fg, int scale) { return draw_run(*this, x, y, s, fg, scale, false); }
int Canvas::textB(int x, int y, const char* s, Color fg) { return draw_run(*this, x, y, s, fg, 1, true); }
static int measure(const char* s, int scale, bool bold, int limit) {
    const UiFont& f = face_for(scale, bold); int w8 = 0;
    for (int i = 0; *s && (limit < 0 || i < limit); i++) w8 += ui_adv(f, next_cp(s), scale);
    return (w8 + 7) / 8;
}
int Canvas::textWidth(const char* s, int scale) const { return measure(s, scale, false, -1); }
int Canvas::textWidthB(const char* s) const { return measure(s, 1, true, -1); }
int Canvas::textWidthN(const char* s, int n) const { return measure(s, 1, false, n); }
int Canvas::textMax(int x, int y, const char* s, Color fg, int maxPx, bool bold) {
    int tw = bold ? textWidthB(s) : textWidth(s);
    if (tw <= maxPx) return bold ? textB(x, y, s, fg) : text(x, y, s, fg);
    char buf[100]; int n = 0;
    while (s[n] && n < 96) {
        buf[n] = s[n]; buf[n + 1] = '.'; buf[n + 2] = '.'; buf[n + 3] = 0;
        if ((bold ? textWidthB(buf) : textWidth(buf)) > maxPx) break;
        n++;
    }
    if (n == 0) return 0;
    buf[n] = '.'; buf[n + 1] = '.'; buf[n + 2] = 0;
    return bold ? textB(x, y, buf, fg) : text(x, y, buf, fg);
}
void Canvas::textCentered(const Rect& r, const char* s, Color fg, int scale) {
    int tw = textWidth(s, scale), lh = scale >= 2 ? 32 : 16;
    text(r.x + (r.w - tw) / 2, r.y + (r.h - lh) / 2, s, fg, scale);
}
void Canvas::textCenteredB(const Rect& r, const char* s, Color fg) { textB(r.x + (r.w - textWidthB(s)) / 2, r.y + (r.h - 16) / 2, s, fg); }

// ---- official mX logo: stored once as a 192-px-wide coverage mask, area-averaged down to any size ----
int Canvas::logo(int x, int y, int width, Color ink) {
    int h = (logoH * width + logoW / 2) / logoW; if (h < 1) h = 1;
    Rect dst = { x + ox, y + oy, width, h }; Rect vis = dst.intersect(clip);
    for (int dy = vis.y - dst.y; dy < vis.y - dst.y + vis.h; dy++) {
        int sy0 = dy * logoH / h, sy1 = max(sy0 + 1, (dy + 1) * logoH / h);
        for (int dx = vis.x - dst.x; dx < vis.x - dst.x + vis.w; dx++) {
            int sx0 = dx * logoW / width, sx1 = max(sx0 + 1, (dx + 1) * logoW / width);
            int sum = 0, cnt = 0;
            for (int sy = sy0; sy < sy1 && sy < logoH; sy++) for (int sx = sx0; sx < sx1 && sx < logoW; sx++) { sum += logoMask[sy * logoW + sx]; cnt++; }
            putA(x + dx, y + dy, ink, cnt ? sum / cnt : 0);
        }
    }
    return h;
}

// ---- mouse cursor sprite: '#' = black outline, '.' = white fill ----
static const char* const cursor_art[CURSOR_H] = {
    "#           ", "##          ", "#.#         ", "#..#        ", "#...#       ", "#....#      ",
    "#.....#     ", "#......#    ", "#.......#   ", "#........#  ", "#.....#####.", "#..#..#     ",
    "#.# #..#    ", "##  #..#    ", "#    #..#   ", "     #..#   ", "      #..#  ", "      #..#  ",
    "       ##   "};
Color cursor_pixel(int x, int y, bool& opaque) {
    opaque = false;
    if (x < 0 || y < 0 || x >= CURSOR_W || y >= CURSOR_H) return 0;
    char c = cursor_art[y][x];
    if (c == '#') { opaque = true; return rgb(0, 0, 0); }
    if (c == '.') { opaque = true; return rgb(255, 255, 255); }
    return 0;
}

const char* icon_name(IconId id) {
    static const char* n[IC_COUNT] = {"none","start","terminal","files","settings","monitor","notepad","calc","about","folder","file",
        "user","network","bell","warning","info","error","ok","power","disk","recovery","display","keyboard","mouse","clock","sound","lock","diagnostics","store"};
    return (id >= 0 && id < IC_COUNT) ? n[id] : "?";
}

// ---- procedural icons: drawn at any size from simple shapes, no bitmap assets ----
void Canvas::icon(IconId id, int x, int y, int s) {
    Theme& t = theme();
    int u = s / 8 > 0 ? s / 8 : 1;          // one "unit"
    Rect full = { x, y, s, s };
    auto R = [&](int a, int b, int c, int d) { Rect r = { x + a * u, y + b * u, c * u, d * u }; return r; };
    switch (id) {
    case IC_START: {
        fillRound(full, max(2, s / 5), rgb(250, 250, 252));
        int lw = s - max(2, s / 6) * 2; logo(x + (s - lw) / 2, y + (s - (logoH * lw / logoW)) / 2, lw, rgb(14, 14, 18));
        break; }
    case IC_TERMINAL:
        fillRound(full, s / 8, rgb(24, 28, 38)); fill(R(0, 0, 8, 1), rgb(70, 76, 96));
        text(x + u, y + 2 * u, ">", rgb(120, 230, 150)); fill(R(4, 5, 2, 1), rgb(220, 220, 230)); break;
    case IC_FILES:
        fillRound(R(0, 2, 8, 6), 2, rgb(238, 190, 70)); fillRound(R(0, 1, 4, 2), 1, rgb(214, 160, 40));
        fillRound(R(0, 3, 8, 5), 2, rgb(250, 208, 96)); break;
    case IC_FOLDER:
        fillRound(R(0, 2, 8, 6), 2, rgb(238, 190, 70)); fillRound(R(0, 1, 4, 2), 1, rgb(214, 160, 40));
        fillRound(R(0, 3, 8, 5), 2, rgb(250, 208, 96)); break;
    case IC_FILE:
        fillRound(R(1, 0, 6, 8), 1, rgb(250, 250, 252)); rect(R(1, 0, 6, 8), t.panelDark);
        fill(R(2, 2, 4, 1), t.panelDark); fill(R(2, 4, 4, 1), t.panelDark); fill(R(2, 6, 3, 1), t.panelDark); break;
    case IC_SETTINGS:
        fillRound(full, s / 4, rgb(96, 104, 126));
        fillRound(R(2, 2, 4, 4), 2, rgb(220, 224, 236)); fillRound(R(3, 3, 2, 2), 1, rgb(96, 104, 126));
        fill(R(3, 0, 2, 1), rgb(220, 224, 236)); fill(R(3, 7, 2, 1), rgb(220, 224, 236));
        fill(R(0, 3, 1, 2), rgb(220, 224, 236)); fill(R(7, 3, 1, 2), rgb(220, 224, 236)); break;
    case IC_MONITOR:
        fillRound(full, s / 8, rgb(30, 34, 46));
        for (int i = 0; i < 4; i++) fill(R(1 + i * 2, 6 - (i % 3) * 1 - (i == 3 ? 2 : 0), 1, 1 + (i % 3) + (i == 3 ? 2 : 0)), rgb(110, 220, 150)); break;
    case IC_NOTEPAD:
        fillRound(R(1, 0, 6, 8), 1, rgb(255, 248, 200)); fill(R(1, 0, 6, 1), rgb(224, 92, 80));
        for (int i = 0; i < 3; i++) fill(R(2, 2 + i * 2, 4, 1), rgb(160, 150, 100)); break;
    case IC_CALC:
        fillRound(full, s / 8, rgb(52, 58, 76)); fill(R(1, 1, 6, 2), rgb(170, 230, 190));
        for (int r2 = 0; r2 < 3; r2++) for (int c2 = 0; c2 < 3; c2++) fill(R(1 + c2 * 2, 4 + r2 * 1 + (r2 > 0 ? r2 * 0 : 0), 1, 1), rgb(200, 206, 222)); break;
    case IC_ABOUT: case IC_INFO:
        fillRound(full, s / 2, t.accent); fill(R(3, 1, 2, 1), rgb(255, 255, 255)); fill(R(3, 3, 2, 4), rgb(255, 255, 255)); break;
    case IC_WARN:
        fillRound(full, s / 5, t.warn); fill(R(3, 1, 2, 4), rgb(255, 255, 255)); fill(R(3, 6, 2, 1), rgb(255, 255, 255)); break;
    case IC_ERROR:
        fillRound(full, s / 2, t.danger); line(x + 2 * u, y + 2 * u, x + 6 * u, y + 6 * u, rgb(255, 255, 255));
        line(x + 6 * u, y + 2 * u, x + 2 * u, y + 6 * u, rgb(255, 255, 255)); break;
    case IC_OK:
        fillRound(full, s / 2, t.ok); line(x + 2 * u, y + 4 * u, x + 3 * u, y + 5 * u, rgb(255, 255, 255));
        line(x + 3 * u, y + 5 * u, x + 6 * u, y + 2 * u, rgb(255, 255, 255)); break;
    case IC_USER:
        fillRound(R(2, 0, 4, 4), 2, rgb(150, 170, 210)); fillRound(R(0, 4, 8, 4), 3, rgb(120, 140, 190)); break;
    case IC_NET:
        fillRound(full, s / 2, rgb(40, 140, 200)); hline(x + u, y + 4 * u, 6 * u, rgb(255, 255, 255));
        vline(x + 4 * u, y + u, 6 * u, rgb(255, 255, 255)); rect(R(2, 1, 4, 6), rgb(255, 255, 255)); break;
    case IC_BELL:
        fillRound(R(2, 1, 4, 5), 2, rgb(250, 210, 80)); fill(R(1, 5, 6, 1), rgb(250, 210, 80)); fillRound(R(3, 6, 2, 2), 1, rgb(200, 160, 40)); break;
    case IC_POWER:
        fillRound(full, s / 2, rgb(200, 70, 70)); fill(R(3, 1, 2, 4), rgb(255, 255, 255)); break;
    case IC_DISK:
        fillRound(full, s / 8, rgb(110, 120, 140)); fill(R(1, 1, 6, 3), rgb(190, 196, 210)); fill(R(2, 5, 4, 2), rgb(60, 66, 84)); break;
    case IC_RECOVERY:
        fillRound(full, s / 2, rgb(70, 160, 110)); line(x + 2 * u, y + 5 * u, x + 4 * u, y + 2 * u, rgb(255, 255, 255));
        line(x + 4 * u, y + 2 * u, x + 6 * u, y + 5 * u, rgb(255, 255, 255)); hline(x + 2 * u, y + 5 * u, 4 * u, rgb(255, 255, 255)); break;
    case IC_DISPLAY:
        fillRound(R(0, 1, 8, 5), 1, rgb(40, 46, 64)); fill(R(1, 2, 6, 3), rgb(90, 150, 230)); fill(R(3, 6, 2, 1), rgb(120, 126, 146)); fill(R(2, 7, 4, 1), rgb(120, 126, 146)); break;
    case IC_KEYBOARD:
        fillRound(R(0, 2, 8, 5), 1, rgb(70, 76, 96));
        for (int r2 = 0; r2 < 3; r2++) for (int c2 = 0; c2 < 4; c2++) fill(R(1 + c2 * 2 - (c2 == 3 ? 1 : 0), 3 + r2 * 1 + 0, 1, 1), rgb(200, 206, 222)); break;
    case IC_MOUSE:
        fillRound(R(1, 0, 6, 8), 3, rgb(210, 214, 226)); vline(x + 4 * u, y, 3 * u, rgb(100, 106, 126)); break;
    case IC_CLOCK:
        fillRound(full, s / 2, rgb(240, 242, 248)); rect(full, rgb(90, 96, 116));
        line(x + 4 * u, y + 4 * u, x + 4 * u, y + 1 * u, rgb(40, 44, 60)); line(x + 4 * u, y + 4 * u, x + 6 * u, y + 4 * u, rgb(40, 44, 60)); break;
    case IC_SOUND:
        fill(R(1, 3, 2, 2), rgb(120, 126, 146)); fill(R(3, 2, 1, 4), rgb(120, 126, 146)); line(x + 5 * u, y + 2 * u, x + 6 * u, y + 4 * u, rgb(120, 126, 146)); line(x + 6 * u, y + 4 * u, x + 5 * u, y + 6 * u, rgb(120, 126, 146)); break;
    case IC_LOCK:
        fillRound(R(1, 3, 6, 5), 1, rgb(230, 190, 70)); rect(R(2, 0, 4, 4), rgb(120, 126, 146)); break;
    case IC_DIAG:
        fillRound(full, s / 8, rgb(36, 90, 80)); line(x + u, y + 5 * u, x + 3 * u, y + 5 * u, rgb(150, 255, 200));
        line(x + 3 * u, y + 5 * u, x + 4 * u, y + 1 * u, rgb(150, 255, 200)); line(x + 4 * u, y + 1 * u, x + 5 * u, y + 6 * u, rgb(150, 255, 200));
        line(x + 5 * u, y + 6 * u, x + 7 * u, y + 4 * u, rgb(150, 255, 200)); break;
    case IC_STORE:
        fillRound(full, s / 5, rgb(72, 108, 220));
        fillRound(R(1, 1, 3, 3), 1, rgb(255, 255, 255)); fillRound(R(4, 1, 3, 3), 1, rgb(190, 215, 255));
        fillRound(R(1, 4, 3, 3), 1, rgb(190, 215, 255)); fillRound(R(4, 4, 3, 3), 1, rgb(255, 214, 120)); break;
    default: break;
    }
}

} // namespace mx
