; gfx_fast.asm — the two hot loops of the compositor, in NASM (System V AMD64 ABI).
;   void mx_fill32(uint32_t* dst, uint32_t value, size_t count)
;   void mx_copy32(uint32_t* dst, const uint32_t* src, size_t count)
; rep stosd / rep movsd are fast on every x86-64 CPU (and under QEMU's TCG). Direction flag is
; guaranteed clear on entry by the ABI. Nothing here touches SSE/AVX state (the kernel does not
; save it across task switches).

BITS 64
section .text

global mx_fill32
mx_fill32:
    mov     eax, esi        ; value
    mov     rcx, rdx        ; count (dwords)
    rep     stosd           ; [rdi++] = eax, rcx times
    ret

global mx_copy32
mx_copy32:
    mov     rcx, rdx        ; count (dwords)
    rep     movsd           ; [rdi++] = [rsi++], rcx times
    ret

section .note.GNU-stack noalloc noexec nowrite progbits
