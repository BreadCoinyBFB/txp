#include "mx/sys.hpp"
#include "mx/kapi.hpp"
namespace mx {

constexpr int BLOCKS_TOTAL = 256;      // ramdisk size after the Stage 4 bump (drivers/storage/ramdisk.cx)

static Inode& ino(int i) { return inode_table[i]; }
static bool valid(int i) { return i >= 0 && i < VFS_MAX_INODES && ino(i).inode_type != INODE_FREE; }

const char* fs_basename(const char* p) { const char* b = p; for (; *p; p++) if (*p == '/' && p[1]) b = p + 1; return (*b == '/') ? b + 1 : b; }
void fs_join(char* out, int cap, const char* dir, const char* name) {
    int n = scopy(out, dir, cap);
    if (n == 0 || out[n - 1] != '/') scat(out, "/", cap);
    scat(out, name, cap);
}
void fs_parent(const char* path, char* out, int cap) {
    int n = scopy(out, path, cap);
    while (n > 1 && out[n - 1] == '/') out[--n] = 0;
    while (n > 1 && out[n - 1] != '/') out[--n] = 0;
    if (n > 1) out[n - 1] = 0;
    if (out[0] == 0) scopy(out, "/", cap);
}
bool fs_exists(const char* p) { return valid((int)vfs_resolve_path(p)); }
bool fs_is_dir(const char* p) { int i = (int)vfs_resolve_path(p); return valid(i) && ino(i).inode_type == INODE_DIR; }

static void fill_entry(int i, FsEntry* e) {
    scopy(e->name, ino(i).name, sizeof e->name); e->dir = ino(i).inode_type == INODE_DIR; e->size = ino(i).size; e->inode = i;
}
bool fs_stat(const char* p, FsEntry* e) { int i = (int)vfs_resolve_path(p); if (!valid(i)) return false; fill_entry(i, e); return true; }

int fs_list(const char* path, FsEntry* out, int max) {
    int d = (int)vfs_resolve_path(path);
    if (!valid(d) || ino(d).inode_type != INODE_DIR) return -1;
    int n = 0;
    for (int c = ino(d).first_child; c != -1 && n < max; c = ino(c).next_sibling) fill_entry(c, &out[n++]);
    for (int i = 1; i < n; i++) {                          // insertion sort: folders first, then case-insensitive name
        FsEntry t = out[i]; int j = i - 1;
        auto less = [](const FsEntry& a, const FsEntry& b) { if (a.dir != b.dir) return a.dir; const char* x = a.name; const char* y = b.name;
            while (*x && *y && lower(*x) == lower(*y)) { x++; y++; } return lower(*x) < lower(*y); };
        while (j >= 0 && less(t, out[j])) { out[j + 1] = out[j]; j--; }
        out[j + 1] = t;
    }
    return n;
}
bool fs_mkdir_p(const char* path) {
    char cur[128]; int n = 0; cur[0] = 0;
    const char* p = path;
    while (*p) {
        if (*p == '/') { p++; continue; }
        int k = 0; char comp[32];
        while (*p && *p != '/' && k < 31) comp[k++] = *p++;
        comp[k] = 0;
        cur[n++] = '/'; for (int i = 0; i < k && n < 126; i++) cur[n++] = comp[i]; cur[n] = 0;
        if (!fs_exists(cur)) { if (!vfs_mkdir(cur)) return false; }
        else if (!fs_is_dir(cur)) return false;
    }
    return true;
}
bool fs_read(const char* path, char* buf, int cap, int* outLen) {
    long fd = vfs_open(path); if (fd < 0) return false;
    long n = vfs_read(fd, buf, cap - 1); vfs_close(fd);
    if (n < 0) n = 0;
    buf[n] = 0; if (outLen) *outLen = (int)n; return true;
}
bool fs_write(const char* path, const char* data, int len) {
    if (len > VFS_BLOCK_SIZE) return false;
    if (!fs_exists(path)) { if (!vfs_create_file(path)) return false; }
    int i = (int)vfs_resolve_path(path); if (!valid(i) || ino(i).inode_type != INODE_FILE) return false;
    ino(i).size = 0;                                        // truncate (the single block stays allocated)
    long fd = vfs_open(path); if (fd < 0) return false;
    long w = len > 0 ? vfs_write(fd, data, len) : 0; vfs_close(fd);
    return w == len;
}
bool fs_delete(const char* path) {
    int i = (int)vfs_resolve_path(path); if (!valid(i) || i == 0) return false;
    if (ino(i).inode_type == INODE_DIR) {
        while (ino(i).first_child != -1) {
            char cp[160]; fs_join(cp, sizeof cp, path, ino(ino(i).first_child).name);
            if (!fs_delete(cp)) return false;
        }
    }
    return vfs_unlink(path) != 0;
}
static int child_named(int dir, const char* name) {
    for (int c = ino(dir).first_child; c != -1; c = ino(c).next_sibling) if (seq(ino(c).name, name)) return c;
    return -1;
}
bool fs_rename(const char* path, const char* nn) {
    int i = (int)vfs_resolve_path(path); if (!valid(i) || i == 0 || !nn[0] || slen(nn) > 30) return false;
    for (const char* c = nn; *c; c++) if (*c == '/') return false;
    int c2 = child_named(ino(i).parent, nn); if (c2 != -1 && c2 != i) return false;
    char* mem = (char*)kmalloc(slen(nn) + 1); if (!mem) return false;
    scopy(mem, nn, slen(nn) + 1);
    const char* old = ino(i).name; ino(i).name = mem; kfree((long)old);
    return true;
}
static void unlink_from_parent(int i) {
    int p = ino(i).parent;
    if (ino(p).first_child == i) ino(p).first_child = ino(i).next_sibling;
    else { int c = ino(p).first_child; while (c != -1 && ino(c).next_sibling != i) c = ino(c).next_sibling; if (c != -1) ino(c).next_sibling = ino(i).next_sibling; }
}
bool fs_move(const char* path, const char* destDir) {
    int i = (int)vfs_resolve_path(path), d = (int)vfs_resolve_path(destDir);
    if (!valid(i) || !valid(d) || i == 0 || ino(d).inode_type != INODE_DIR) return false;
    for (int a = d; a != -1; a = ino(a).parent) if (a == i) return false;     // can't move a folder into itself
    if (ino(i).parent == d) return true;
    if (child_named(d, ino(i).name) != -1) return false;
    unlink_from_parent(i);
    ino(i).parent = d; ino(i).next_sibling = ino(d).first_child; ino(d).first_child = i;
    return true;
}
bool fs_copy(const char* path, const char* destDir) {
    int i = (int)vfs_resolve_path(path), d = (int)vfs_resolve_path(destDir);
    if (!valid(i) || !valid(d) || ino(d).inode_type != INODE_DIR) return false;
    for (int a = d; a != -1; a = ino(a).parent) if (a == i && ino(i).inode_type == INODE_DIR) return false;
    char name[40]; scopy(name, ino(i).name, sizeof name);
    int tries = 0;
    while (child_named(d, name) != -1 && tries < 9) {
        if (tries == 0) sfmt(name, sizeof name, "%s copy", ino(i).name); else sfmt(name, sizeof name, "%s copy %d", ino(i).name, tries + 1);
        tries++;
    }
    if (slen(name) > 30) return false;
    char np[160]; fs_join(np, sizeof np, destDir, name);
    if (ino(i).inode_type == INODE_FILE) {
        char buf[VFS_BLOCK_SIZE + 1]; int n = 0;
        if (!fs_read(path, buf, sizeof buf, &n)) return false;
        return fs_write(np, buf, n);
    }
    if (!vfs_mkdir(np)) return false;
    FsEntry list[FS_MAX_LIST]; int n = fs_list(path, list, FS_MAX_LIST);
    for (int k = 0; k < n; k++) { char cp[160]; fs_join(cp, sizeof cp, path, list[k].name); if (!fs_copy(cp, np)) return false; }
    return true;
}
void fs_usage(int* iu, int* it, int* bu, int* bt) {
    int u = 0, b = 0;
    for (int i = 0; i < VFS_MAX_INODES; i++) if (ino(i).inode_type != INODE_FREE) { u++; if (ino(i).block != -1) b++; }
    if (iu) *iu = u; if (it) *it = VFS_MAX_INODES; if (bu) *bu = b; if (bt) *bt = BLOCKS_TOTAL;
}

// ---- ownership policy ----
void fs_owner(const char* p, char* out, int cap) {
    if (sstarts(p, "/home/")) { const char* q = p + 6; int n = 0; char u[20]; while (*q && *q != '/' && n < 19) u[n++] = *q++; u[n] = 0; scopy(out, u, cap); }
    else if (sstarts(p, "/shared")) scopy(out, "shared", cap);
    else scopy(out, "system", cap);
}
static bool in_dir(const char* p, const char* d) { int n = slen(d); return sstarts(p, d) && (p[n] == 0 || p[n] == '/'); }
bool fs_can_read(const char* p) {
    const User* u = users_current(); if (!u) return false;
    if (in_dir(p, "/home")) {
        if (seq(p, "/home")) return true;
        char own[20]; fs_owner(p, own, sizeof own);
        return seq(own, u->name) || (user_perms() & P_ADMIN);
    }
    return true;
}
bool fs_can_write(const char* p) {
    const User* u = users_current(); if (!u) return false;
    u32 pm = user_perms();
    if (in_dir(p, "/home")) { if (seq(p, "/home")) return pm & P_ADMIN; char own[20]; fs_owner(p, own, sizeof own); return seq(own, u->name) || (pm & P_ADMIN); }
    if (in_dir(p, "/shared")) return (pm & P_FILES_ALL) != 0;
    if (in_dir(p, "/system")) return (pm & P_FILES_SYSTEM) != 0;
    return (pm & P_ADMIN) != 0;
}

// ---------------------------------------------------------------- system context + kernel hooks
static int g_sysDepth = 0; static long g_sysPid = -1;
FsSys::FsSys() { if (g_sysDepth == 0) g_sysPid = task_current_pid(); g_sysDepth++; }
FsSys::~FsSys() { if (g_sysDepth > 0) g_sysDepth--; }
static bool sys_ctx() { return g_sysDepth > 0 && g_sysPid == task_current_pid(); }

static char g_denied[64]; static volatile long g_deniedTick = 0; static volatile bool g_deniedWrite = false;
bool fs_take_denied(char* out, int cap, bool* wasWrite) {
    if (!g_deniedTick) return false;
    scopy(out, g_denied, cap); if (wasWrite) *wasWrite = g_deniedWrite; g_deniedTick = 0; return true;
}
static void note_denied(const char* path, bool write) { scopy(g_denied, path, sizeof g_denied); g_deniedWrite = write; g_deniedTick = 1; }

static void inode_path(int i, char* out, int cap) {                     // absolute path of an inode
    const char* parts[12]; int n = 0;
    for (int a = i; a > 0 && n < 12; a = ino(a).parent) parts[n++] = ino(a).name;
    out[0] = 0; if (n == 0) { scopy(out, "/", cap); return; }
    while (n--) { scat(out, "/", cap); scat(out, parts[n], cap); }
}
extern "C" long gui_fs_check(const char* path, long write) {
    if (sys_ctx() || !users_current()) return 1;
    char abs[160];
    if (path[0] == '/') scopy(abs, path, sizeof abs);
    else { inode_path((int)vfs_cwd, abs, sizeof abs); fs_join(abs, sizeof abs, abs, path); }         // shell passes relative paths
    bool ok = write ? fs_can_write(abs) : fs_can_read(abs);
    if (!ok) note_denied(abs, write != 0);
    return ok ? 1 : 0;
}
extern "C" long gui_fs_check_inode(long inode, long write) {
    if (sys_ctx() || !users_current() || inode < 0 || inode >= VFS_MAX_INODES) return 1;
    char abs[160]; inode_path((int)inode, abs, sizeof abs);
    bool ok = write ? fs_can_write(abs) : fs_can_read(abs);
    if (!ok) note_denied(abs, write != 0);
    return ok ? 1 : 0;
}
}
