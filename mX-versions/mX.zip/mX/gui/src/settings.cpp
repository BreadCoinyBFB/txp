// settings.cpp — mX Settings. Every change applies immediately and is saved (config_save -> /system/config on the
// persistent data disk) so it is there at the next boot.
#include "mx/apps.hpp"
#include "mx/wm.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
#include "mx/display.hpp"
#include "mx/net.hpp"
#include "mx/desktop.hpp"
#include "mx/persist.hpp"
namespace mx {

static const u32 ACCENTS[8] = { 0x3A78E6, 0x8E5AE8, 0xE0508C, 0xE8604A, 0xE6A020, 0x3AA860, 0x20A8B0, 0x6C7A96 };
static const u32 SOLIDS[8] = { 0x203050, 0x1B1F2A, 0x24402F, 0x4A2B3A, 0x3B3F4A, 0x5A4A2E, 0x2D5063, 0x000000 };
static const char* WALLS[8] = { "Aurora", "Midnight", "Forest", "Grid", "Sunset", "Ocean", "Graphite", "Solid" };
static const int RES_W[3] = { 640, 800, 1024 }, RES_H[3] = { 480, 600, 768 };

struct SettingsApp : App {
    enum { P_DISPLAY, P_DESKTOP, P_SOUND, P_KEYBOARD, P_MOUSE, P_STORAGE, P_NETWORK, P_SYSTEM, P_USERS, P_TIME, P_COUNT };
    enum { CAT = 1, WALL = 100, ACC = 110, SOLID = 120, RES = 130, SCALE = 133, APPLYRES = 134, ICONS = 140, ISIZE = 141, TBPOS = 145, TBSIZE = 147, TBLAB = 150, PIN = 160,
           KBL = 170, KBD = 175, KBR = 180, SPEED = 185, SWAP = 186, MKEYS = 187, SAVENOW = 190, NETMODE = 200, NETAPPLY = 203, PING = 204, NETTEST = 205, DNSQ = 206, TCPQ = 207,
           FIELD = 220, HOSTAPPLY = 240, USER = 250, UADD = 260, UDEL = 261, UPASS = 262, UROLE = 263, LOCKNOW = 264, SIGNOUT = 265, ALOCK = 270, T24 = 280, TSEC = 281, TAPPLY = 282, TOAST = 283 };
    enum { D_NAME = 1, D_PASS, D_ADMIN, D_DELETE, D_OLDPASS };
    int page = P_DISPLAY; TextField F[12]; int focus = -1; Rect sliderRect = {0, 0, 0, 0}; int scrollY = 0, contentH = 0;
    char out[8][96]; int nout = 0; char kbd[64] = "Press any key..."; int selUser = 0; char newName[24] = "", newPass[24] = ""; int selRes = 1; bool selScale = false;
    NetTest nt[8]; int nnt = 0;

    void windowSpec(WindowSpec& s) override { s.title = "mX Settings"; s.frame = Rect{ 60, 30, 720, 480 }; s.flags = WF_RESIZABLE; s.minW = 600; s.minH = 400; }
    bool canWrite() { return (user_perms() & P_SETTINGS_WRITE) != 0; }
    void onCreate() override {
        Config& c = cfg(); F[0].set(c.ip); F[1].set(c.mask); F[2].set(c.gw); F[3].set(c.dns); F[4].set("example.com"); F[5].set(c.hostname); F[9].set("example.com"); F[10].set("80"); F[10].numeric = true; F[10].maxLen = 5;
        RtcTime t; hal_rtc_read(t); char b[8]; sfmt(b, 8, "%02d", t.hour); F[6].set(b); sfmt(b, 8, "%02d", t.minute); F[7].set(b); sfmt(b, 8, "%02d", t.second); F[8].set(b);
        for (int i = 6; i < 9; i++) { F[i].numeric = true; F[i].maxLen = 2; }
        F[5].maxLen = 20;
        const DisplayInfo& d = display_info(); selRes = 1; for (int i = 0; i < 3; i++) if (RES_W[i] == d.w && RES_H[i] == d.h) selRes = i; selScale = d.scale == 2;
    }
    void say(const char* s) { if (nout == 8) { for (int i = 1; i < 8; i++) scopy(out[i - 1], out[i], 96); nout = 7; } scopy(out[nout++], s, 96); invalidate(); }
    void deny() { notify(N_WARN, "Settings", "Read-only", "Your account can't change settings. Sign in as Member or Administrator."); }
    void save() { config_save(); config_apply(); desktop_layout_changed(); invalidate(); }

    void onAction(int id, int) override {
        Config& c = cfg();
        if (id >= CAT && id < CAT + P_COUNT) { page = id - CAT; focus = -1; scrollY = 0; for (auto& f : F) f.focused = false; invalidate(); return; }
        if (id >= FIELD && id < FIELD + 12) { focus = id - FIELD; for (int i = 0; i < 12; i++) F[i].focused = (i == focus); invalidate(); return; }
        if (id >= USER && id < USER + USERS_MAX) { selUser = id - USER; invalidate(); return; }
        bool w = canWrite();
        if (id >= WALL && id < WALL + 8) { if (!w) return deny(); c.wallpaper = id - WALL; save(); }
        else if (id >= SOLID && id < SOLID + 8) { if (!w) return deny(); c.wallpaper = 7; c.wallColor = SOLIDS[id - SOLID]; save(); }
        else if (id >= ACC && id < ACC + 8) { if (!w) return deny(); c.accent = ACCENTS[id - ACC]; save(); }
        else if (id >= RES && id < RES + 3) { selRes = id - RES; invalidate(); }
        else if (id == SCALE) { selScale = !selScale; invalidate(); }
        else if (id == APPLYRES) { if (!w) return deny(); if (!desktop_set_display(RES_W[selRes], RES_H[selRes], selScale ? 2 : 1, true)) notify(N_ERROR, "Display", "Couldn't change the display", "The graphics adapter refused this mode."); }
        else if (id == ICONS) { if (!w) return deny(); c.desktopIcons = !c.desktopIcons; save(); }
        else if (id >= ISIZE && id < ISIZE + 3) { if (!w) return deny(); c.iconSize = id - ISIZE; save(); }
        else if (id >= TBPOS && id < TBPOS + 2) { if (!w) return deny(); c.taskbarTop = (id == TBPOS + 1); save(); }
        else if (id >= TBSIZE && id < TBSIZE + 3) { if (!w) return deny(); c.taskbarSize = id - TBSIZE; save(); }
        else if (id == TBLAB) { if (!w) return deny(); c.taskbarLabels = !c.taskbarLabels; save(); }
        else if (id >= PIN && id < PIN + APPS_MAX) { const AppManifest* m = apps_at(id - PIN); if (!m) return; if (!w) return deny(); apps_set_desktop(m->id, !m->desktop); invalidate(); }
        else if (id == TOAST) { if (!w) return deny(); c.notifyToasts = !c.notifyToasts; save(); }
        else if (id >= KBL && id < KBL + 3) { if (!w) return deny(); c.kbLayout = id - KBL; save(); }
        else if (id >= KBD && id < KBD + 4) { if (!w) return deny(); c.kbDelay = id - KBD; kbd_set_typematic(c.kbDelay, c.kbRate); save(); }
        else if (id == KBR + 1) { if (!w) return deny(); bool ok = kbd_set_typematic(cfg().kbDelay, cfg().kbRate); save(); if (!ok) notify(N_INFO, "Keyboard", "Saved", "Repeat rate saved (this keyboard didn't acknowledge the change)."); }
        else if (id == SWAP) { if (!w) return deny(); c.mouseSwap = !c.mouseSwap; save(); }
        else if (id == MKEYS) { if (!w) return deny(); c.mouseKeys = !c.mouseKeys; save(); }
        else if (id == SAVENOW) { if (persist_force_save()) notify(N_OK, "Storage", "Saved", "Your files, accounts and settings were written to the data disk."); invalidate(); }
        else if (id == T24) { if (!w) return deny(); c.clock24 = !c.clock24; save(); }
        else if (id == TSEC) { if (!w) return deny(); c.showSeconds = !c.showSeconds; save(); }
        else if (id == NETMODE) { if (!w) return deny(); c.netMode = 0; save(); net_apply_config(); }
        else if (id == NETMODE + 1) { if (!w) return deny(); c.netMode = 1; save(); }
        else if (id == NETAPPLY) {
            if (!w || !(user_perms() & P_NETWORK)) return deny(); u8 t[4];
            if (!ip_parse(F[0].buf, t) || !ip_parse(F[1].buf, t) || !ip_parse(F[2].buf, t) || !ip_parse(F[3].buf, t)) { notify(N_ERROR, "Network", "Invalid address", "Use dotted-quad form, e.g. 10.0.2.15"); return; }
            scopy(c.ip, F[0].buf, 16); scopy(c.mask, F[1].buf, 16); scopy(c.gw, F[2].buf, 16); scopy(c.dns, F[3].buf, 16); c.netMode = 1; save(); net_apply_config(); notify(N_OK, "Network", "Settings applied", "Static IP configuration saved.");
        }
        else if (id == PING) doPing();
        else if (id == NETTEST) { if (!(user_perms() & P_NETWORK)) return deny(); say("Running connectivity test..."); nnt = net_diagnose(nt, 8); nout = 0; invalidate(); }
        else if (id == DNSQ) {
            if (!(user_perms() & P_NETWORK)) return deny(); char ip[16]; int ms = 0; nout = 0; char b[96];
            if (net_dns_query(F[4].buf, ip, &ms)) sfmt(b, sizeof b, "%s -> %s  (%d ms, via %s)", F[4].buf, ip, ms, net_info().dns); else sfmt(b, sizeof b, "No answer for \"%s\" from %s after %d ms", F[4].buf, net_info().dns, ms);
            say(b);
        }
        else if (id == TCPQ) {
            if (!(user_perms() & P_NETWORK)) return deny(); char ip[16]; char b[96]; nout = 0; int port = satoi(F[10].buf); if (port < 1 || port > 65535) { say("Port must be 1-65535."); return; }
            if (!net_resolve(F[9].buf, ip, 2000)) { say("Could not resolve that name."); return; }
            int cm = 0; sfmt(b, sizeof b, "Connecting to %s:%d ...", ip, port); say(b);
            if (net_tcp_connect(ip, (u16)port, 3000, &cm)) { sfmt(b, sizeof b, "Connected in %d ms.", cm); say(b); net_tcp_close(); if (port == 80) { char st[80]; int hm = 0; if (net_http_head(ip, 80, F[9].buf, st, sizeof st, &hm)) { sfmt(b, sizeof b, "HTTP: %s (%d ms)", st, hm); say(b); } } } else say("Connection failed or timed out.");
        }
        else if (id == HOSTAPPLY) { if (!w) return deny(); if (F[5].len > 0) { scopy(c.hostname, F[5].buf, sizeof c.hostname); save(); notify(N_OK, "Settings", "Computer name changed", c.hostname); } }
        else if (id == UADD) { if (!(user_perms() & P_USERS)) return deny(); dialog_prompt(this, D_NAME, "New user", "User name (letters, digits, _)", ""); }
        else if (id == UDEL) { const User* u = users_at(selUser); if (!(user_perms() & P_USERS) || !u) return deny(); char m[80]; sfmt(m, sizeof m, "Delete the account \"%s\"?\nIts home folder is kept.", u->name); dialog_confirm(this, D_DELETE, "Delete user", m); }
        else if (id == UROLE) { const User* u = users_at(selUser); if (!(user_perms() & P_USERS) || !u) return deny(); Role r = u->role == ROLE_ADMIN ? ROLE_MEMBER : ROLE_ADMIN; if (!users_set_role(u->name, r)) notify(N_ERROR, "Users", "Can't change role", "You can't demote yourself or the last administrator."); invalidate(); }
        else if (id == UPASS) { const User* u = users_at(selUser); if (!u) return; if ((user_perms() & P_USERS) || (users_current() && seq(u->name, users_current()->name))) open_set_password_dialog(u->name, false); else deny(); }
        else if (id == LOCKNOW) desktop_lock();
        else if (id == SIGNOUT) desktop_logout(false);
        else if (id >= ALOCK && id < ALOCK + 5) { if (!w) return deny(); static const int mins[5] = { 0, 1, 5, 15, 30 }; c.idleLockMin = mins[id - ALOCK]; save(); }
        else if (id == TAPPLY) {
            if (!(user_perms() & P_ADMIN)) return deny(); RtcTime t; hal_rtc_read(t); t.hour = satoi(F[6].buf); t.minute = satoi(F[7].buf); t.second = satoi(F[8].buf);
            if (t.hour > 23 || t.minute > 59 || t.second > 59) { notify(N_ERROR, "Date/Time", "Invalid time", "Use 00-23 : 00-59 : 00-59."); return; }
            if (hal_rtc_write(t)) notify(N_OK, "Date/Time", "Clock set", "The real-time clock was updated."); else notify(N_ERROR, "Date/Time", "Failed", "Could not write the RTC.");
        }
    }
    void onDialog(int tag, bool ok, const char* text) override {
        if (!ok) return;
        if (tag == D_NAME) { scopy(newName, text, sizeof newName); if (!newName[0]) return; dialog_prompt(this, D_PASS, "New user", "Password (empty = none, guests only)", "", true); }
        else if (tag == D_PASS) { scopy(newPass, text, sizeof newPass); dialog_confirm(this, D_ADMIN, "New user", "Make this user an Administrator?\n(No = Member)"); }
        else if (tag == D_ADMIN) {
            Role r = ok ? ROLE_ADMIN : ROLE_MEMBER; const char* why = nullptr;
            if (!users_password_acceptable(r, newPass, &why)) { notifyf(N_ERROR, "Users", "Password too weak", "%s", why ? why : ""); return; }
            if (users_add(newName, newName, r, newPass)) notifyf(N_OK, "Users", "User created", "%s was added.", newName); else notify(N_ERROR, "Users", "Couldn't add user", "Invalid or duplicate name, or the account table is full."); invalidate();
        }
        else if (tag == D_DELETE) { const User* u = users_at(selUser); if (u) { char n[16]; scopy(n, u->name, 16); if (users_remove(n)) notifyf(N_OK, "Users", "User removed", "%s", n); else notify(N_ERROR, "Users", "Can't remove", "You can't remove yourself or the last administrator."); } selUser = 0; invalidate(); }
    }
    void doPing() {
        if (!(user_perms() & P_NETWORK)) return deny();
        char ip[16]; nout = 0; say("Resolving...");
        if (!net_resolve(F[4].buf, ip, 2000)) { say("Could not resolve that name."); return; }
        char b[96]; sfmt(b, sizeof b, "PING %s", ip); say(b);
        int ok = 0; for (int i = 0; i < 3; i++) { int rtt = 0; if (net_ping(ip, &rtt, 1000)) { ok++; sfmt(b, sizeof b, "Reply from %s: time=%d ms", ip, rtt); } else sfmt(b, sizeof b, "Request %d timed out", i + 1); say(b); }
        sfmt(b, sizeof b, "%d/3 replies", ok); say(b);
    }
    void onMouse(const UiMouse& m) override {
        if (m.kind == UiMouse::Wheel) { scrollY = clamp(scrollY - m.wheel * 24, 0, max(0, contentH - (ch - 8))); invalidate(); return; }
        if (page == P_MOUSE && sliderRect.w > 0 && pressId == SPEED && (m.kind == UiMouse::Move || m.kind == UiMouse::Down) && canWrite()) {
            int v = 25 + clamp(m.x - 161 - sliderRect.x - 5, 0, sliderRect.w - 10) * 375 / (sliderRect.w - 10); v = (v + 2) / 5 * 5; cfg().mouseSpeed = clamp(v, 25, 400); config_apply(); invalidate();
        }
        if (page == P_KEYBOARD && sliderRect.w > 0 && pressId == KBR && (m.kind == UiMouse::Move || m.kind == UiMouse::Down) && canWrite()) {
            int v = 31 - clamp(m.x - 161 - sliderRect.x - 5, 0, sliderRect.w - 10) * 31 / (sliderRect.w - 10); cfg().kbRate = clamp(v, 0, 31); invalidate();
        }
        if (m.kind == UiMouse::Up && page == P_KEYBOARD && pressId == -1) { }
    }
    void onKey(const KeyEvent& e) override {
        if (e.down) { char b[64]; sfmt(b, sizeof b, "key=%d char='%c' mods=%d%s", (int)e.key, e.ch >= 32 ? (char)e.ch : ' ', (int)e.mods, e.repeat ? " (repeat)" : ""); scopy(kbd, b, sizeof kbd); invalidate(); }
        if (focus >= 0 && F[focus].key(e)) { if (focus == 4) doPing(); else if (focus == 5) onAction(HOSTAPPLY, 1); else if (focus <= 3) onAction(NETAPPLY, 1); else if (focus == 9 || focus == 10) onAction(TCPQ, 1); else onAction(TAPPLY, 1); }
    }
    void onFocus(bool) override {}

    void line(Canvas& p, int x, int& y, const char* k, const char* v, int kw = 140) { Theme& t = theme(); p.text(x, y, k, t.textDim); p.textMax(x + kw, y, v, t.text, p.w - x - kw - 20); y += 22; }
    void sect(Canvas& p, int x, int& y, const char* s) { Theme& t = theme(); y += 6; p.textB(x, y, s, t.text); y += 24; }
    void onPaint(Canvas& c) override {
        Theme& t = theme(); beginPaint(c); Config& cf = cfg(); bool w = canWrite();
        static const char* cats[P_COUNT] = { "Display", "Desktop", "Sound", "Keyboard", "Mouse", "Storage", "Network", "System", "Users", "Date & Time" };
        static const IconId ci[P_COUNT] = { IC_DISPLAY, IC_FILES, IC_SOUND, IC_KEYBOARD, IC_MOUSE, IC_DISK, IC_NET, IC_SETTINGS, IC_USER, IC_CLOCK };
        c.fill(Rect{ 0, 0, 160, c.h }, t.panel); c.vline(160, 0, c.h, t.panelDark);
        for (int i = 0; i < P_COUNT; i++) { Rect r = { 6, 8 + i * 34, 148, 30 }; if (page == i) c.fillRound(r, 4, t.accent); else if (hoverId == CAT + i) c.fillRound(r, 4, t.panelLight);
            c.icon(ci[i], r.x + 8, r.y + 6, 18); c.text(r.x + 34, r.y + 7, cats[i], page == i ? t.textOnAccent : t.text); addHit(r, CAT + i); }
        Canvas view = c.sub(Rect{ 161, 0, c.w - 161, c.h });
        Canvas p = view.sub(Rect{ 0, -scrollY, view.w, view.h + 2000 }); p.clip = view.clip.intersect(p.clip);
        int X = 22, y = 16; const int PW = view.w;
        p.textB(X, y, cats[page], t.text); y += 30;
        if (!w) { p.text(X, y - 6, "Read-only: your account can't change settings.", t.warn); y += 20; }
        switch (page) {
        case P_DISPLAY: {
            const DisplayInfo& d = display_info(); char b[96]; sfmt(b, sizeof b, "%dx%d, shown at %dx%d  (%s)", d.w, d.h, d.pw, d.ph, d.driver); line(p, X, y, "Current mode", b);
            sect(p, X, y, "Resolution & scaling");
            for (int i = 0; i < 3; i++) { sfmt(b, sizeof b, "%d x %d", RES_W[i], RES_H[i]); radio(p, X + i * 130, y, b, selRes == i, RES + i); } y += 26;
            checkbox(p, X, y, "Large UI: double every pixel (2x scaling) - easier to read on a phone", selScale, SCALE); y += 28;
            button(p, Rect{ X, y, 150, 28 }, "Apply resolution", APPLYRES, true, w && d.canSwitch);
            p.text(X + 162, y + 6, d.canSwitch ? "You get 10 s to confirm, then it reverts." : "Needs the Bochs/QEMU display adapter.", t.textDim); y += 34;
            p.text(X, y, "Termux: also  make run-gui GUI_MODE=1024x768x2  picks the mode at launch.", t.textDim); y += 26;
            sect(p, X, y, "Wallpaper");
            for (int i = 0; i < 8; i++) { int cx = X + (i % 4) * 112, cy = y + (i / 4) * 78; Rect r = { cx, cy, 104, 64 };
                static const u32 prev[8] = { 0x3C2F78, 0x12142A, 0x185040, 0x14284C, 0xB0507A, 0x16809A, 0x2E3038, 0 };
                p.fillRound(r, 4, i == 7 ? cf.wallColor : prev[i]); p.roundRect(r, 4, cf.wallpaper == i ? t.accent : t.panelDark); if (cf.wallpaper == i) p.roundRect(r.inset(1), 3, t.accent);
                p.fillRound(Rect{ r.x + 4, r.y + 44, r.w - 8, 16 }, 3, rgb(0, 0, 0)); p.textCentered(Rect{ r.x, r.y + 44, r.w, 16 }, WALLS[i], rgb(255, 255, 255)); addHitC(p, r, WALL + i); }
            y += 164; p.text(X, y, "Solid colour", t.textDim); y += 22;
            for (int i = 0; i < 8; i++) { Rect r = { X + i * 40, y, 32, 28 }; p.fillRound(r, 4, SOLIDS[i]); p.roundRect(r, 4, cf.wallpaper == 7 && cf.wallColor == SOLIDS[i] ? t.accent : t.panelDark); addHitC(p, r, SOLID + i); }
            y += 42; p.text(X, y, "Accent colour", t.textDim); y += 22;
            for (int i = 0; i < 8; i++) { Rect r = { X + i * 40, y, 32, 32 }; p.fillRound(r, 16, rgb((u8)(ACCENTS[i] >> 16), (u8)(ACCENTS[i] >> 8), (u8)ACCENTS[i])); if (cf.accent == ACCENTS[i]) p.roundRect(r.inset(-2), 18, t.text); addHitC(p, r, ACC + i); }
            y += 48; break; }
        case P_DESKTOP: {
            sect(p, X, y, "Taskbar");
            radio(p, X, y, "Bottom", !cf.taskbarTop, TBPOS); radio(p, X + 100, y, "Top", cf.taskbarTop, TBPOS + 1); y += 26;
            radio(p, X, y, "Compact", cf.taskbarSize == 0, TBSIZE); radio(p, X + 100, y, "Normal", cf.taskbarSize == 1, TBSIZE + 1); radio(p, X + 200, y, "Large", cf.taskbarSize == 2, TBSIZE + 2); y += 26;
            checkbox(p, X, y, "Show window titles on taskbar buttons", cf.taskbarLabels, TBLAB); y += 26; checkbox(p, X, y, "Show notification pop-ups", cf.notifyToasts, TOAST); y += 30;
            sect(p, X, y, "Desktop icons");
            checkbox(p, X, y, "Show icons on the desktop", cf.desktopIcons, ICONS); y += 26;
            radio(p, X, y, "Small", cf.iconSize == 0, ISIZE); radio(p, X + 100, y, "Medium", cf.iconSize == 1, ISIZE + 1); radio(p, X + 200, y, "Large", cf.iconSize == 2, ISIZE + 2); y += 30;
            p.text(X, y, "Icons shown on the desktop (pin / unpin applications):", t.textDim); y += 22;
            for (int i = 0; i < apps_count(); i++) { const AppManifest* m = apps_at(i); p.icon(m->icon, X + 2, y, 16); checkbox(p, X + 26, y, m->name, m->desktop, PIN + i); y += 24; }
            break; }
        case P_SOUND: p.text(X, y, "No audio driver yet.", t.text); y += 24; p.textMax(X, y, "Sound output (HDA/AC97/Sound Blaster) is planned for a later stage.", t.textDim, PW - 44); y += 22;
            p.textMax(X, y, "Notifications are visual-only until then.", t.textDim, PW - 44); break;
        case P_KEYBOARD: {
            sect(p, X, y, "Layout");
            radio(p, X, y, "US QWERTY", cf.kbLayout == 0, KBL); radio(p, X + 130, y, "Dvorak", cf.kbLayout == 1, KBL + 1); radio(p, X + 250, y, "Colemak", cf.kbLayout == 2, KBL + 2); y += 30;
            sect(p, X, y, "Key repeat");
            p.text(X, y, "Delay before repeating", t.textDim); y += 22; static const char* dl[4] = { "250 ms", "500 ms", "750 ms", "1000 ms" };
            for (int i = 0; i < 4; i++) radio(p, X + i * 110, y, dl[i], cf.kbDelay == i, KBD + i); y += 30;
            { char b[48]; static const int cps[32] = { 30, 27, 25, 23, 21, 20, 18, 17, 16, 15, 13, 12, 11, 10, 9, 8, 8, 7, 6, 6, 5, 5, 4, 4, 3, 3, 3, 2, 2, 2, 2, 2 }; sfmt(b, sizeof b, "Repeat speed: about %d characters/second", cps[cf.kbRate]); p.text(X, y, b, t.text); y += 24;
              sliderRect = Rect{ X, y, min(PW - 60, 360), 22 }; slider(p, sliderRect, 31 - cf.kbRate, 0, 31, KBR); y += 36; }
            button(p, Rect{ X, y, 130, 28 }, "Apply repeat rate", KBR + 1, false, w); y += 40;
            checkbox(p, X, y, "MouseKeys: Ctrl+Alt+arrows move the pointer, Ctrl+Alt+Space/Enter click", cf.mouseKeys, MKEYS); y += 34;
            p.text(X, y, "Key test (type here):", t.textDim); y += 22; { Rect r = { X, y, PW - 44, 30 }; p.fillRound(r, 3, t.field); p.roundRect(r, 3, t.panelDark); p.textMax(r.x + 8, r.y + 7, kbd, t.text, r.w - 16); y += 40; } break; }
        case P_MOUSE: line(p, X, y, "Device", mouse_present() ? (mouse_has_wheel() ? "PS/2 mouse with wheel" : "PS/2 mouse") : "none detected (use MouseKeys)");
            { char b[48]; sfmt(b, sizeof b, "Pointer speed: %d%%", cf.mouseSpeed); p.text(X, y + 4, b, t.text); y += 26; sliderRect = Rect{ X, y, min(PW - 60, 360), 22 }; slider(p, sliderRect, cf.mouseSpeed, 25, 400, SPEED); y += 40; }
            checkbox(p, X, y, "Swap left and right buttons", cf.mouseSwap, SWAP); y += 30; checkbox(p, X, y, "Enable MouseKeys (keyboard pointer)", cf.mouseKeys, MKEYS); y += 30; break;
        case P_STORAGE: { int iu, it, bu, bt; fs_usage(&iu, &it, &bu, &bt); char b[96]; const PersistInfo& pi = persist_info();
            sect(p, X, y, "Data disk");
            p.fillRound(Rect{ X, y, PW - 44, 44 }, 4, pi.present && pi.lastSaveOk ? blend(t.ok, t.window, 40) : blend(t.warn, t.window, 60)); p.textMax(X + 10, y + 5, pi.status, t.text, PW - 70); 
            if (pi.present) { long ago = (hal_ticks() - pi.lastSaveTick) / 100; sfmt(b, sizeof b, pi.seq ? "Last save %ld s ago. Changes are saved automatically a few seconds after you make them." : "Nothing saved yet.", ago); p.textMax(X + 10, y + 24, b, t.textDim, PW - 70); } y += 56;
            button(p, Rect{ X, y, 120, 28 }, "Save now", SAVENOW, true, pi.present); y += 40;
            sect(p, X, y, "Memory-resident file system");
            sfmt(b, sizeof b, "Files and folders: %d of %d", iu, it); p.text(X, y, b, t.text); y += 20; progress(p, Rect{ X, y, PW - 44, 14 }, iu * 100 / it, iu * 100 / it > 85 ? t.danger : t.accent); y += 28;
            sfmt(b, sizeof b, "Data blocks: %d of %d (%d KiB)", bu, bt, bt / 2); p.text(X, y, b, t.text); y += 20; progress(p, Rect{ X, y, PW - 44, 14 }, bu * 100 / bt, bu * 100 / bt > 85 ? t.danger : t.accent); y += 28;
            u64 tot = hal_total_mem_kb(), fr = hal_free_mem_kb(); sfmt(b, sizeof b, "Physical memory: %d KiB free of %d MiB", (int)fr, (int)(tot / 1024)); p.text(X, y, b, t.text); y += 26;
            p.textMax(X, y, "Your files live in /home/<you>; /shared is for everyone; /system is protected.", t.textDim, PW - 44); y += 20; break; }
        case P_NETWORK: { const NetInfo& ni = net_info(); char b[110];
            line(p, X, y, "Status", ni.status);
            if (ni.present) { sfmt(b, sizeof b, "%02x:%02x:%02x:%02x:%02x:%02x", ni.mac[0], ni.mac[1], ni.mac[2], ni.mac[3], ni.mac[4], ni.mac[5]); line(p, X, y, "MAC address", b);
                sfmt(b, sizeof b, "%d received / %d sent", (int)ni.rxPackets, (int)ni.txPackets); line(p, X, y, "Packets", b); sfmt(b, sizeof b, "%s / %s", ni.ip, ni.mask); line(p, X, y, "Address", b); sfmt(b, sizeof b, "gateway %s, DNS %s", ni.gw, ni.dns); line(p, X, y, "Routing", b); }
            sect(p, X, y, "IP configuration");
            radio(p, X, y, "Automatic (QEMU defaults 10.0.2.x)", cf.netMode == 0, NETMODE); y += 22; radio(p, X, y, "Static", cf.netMode == 1, NETMODE + 1); y += 26;
            static const char* nm[4] = { "IP address", "Subnet mask", "Gateway", "DNS server" };
            for (int i = 0; i < 4; i++) { p.text(X, y + 6, nm[i], t.textDim); F[i].paint(p, *this, Rect{ X + 120, y, 180, 26 }, FIELD + i); y += 32; }
            button(p, Rect{ X + 120, y, 90, 28 }, "Apply", NETAPPLY, true, w); y += 40;
            sect(p, X, y, "Connectivity test");
            button(p, Rect{ X, y, 170, 28 }, "Run network test", NETTEST, true); y += 36;
            for (int i = 0; i < nnt; i++) { Color col = nt[i].status == 0 ? t.ok : (nt[i].status == 1 ? t.warn : t.danger); p.icon(nt[i].status == 0 ? IC_OK : (nt[i].status == 1 ? IC_WARN : IC_ERROR), X, y, 14); p.textB(X + 20, y, nt[i].name, t.text); p.textMax(X + 160, y, nt[i].detail, col == t.ok ? t.textDim : col, PW - X - 180); y += 20; }
            sect(p, X, y, "DNS, ping and TCP tools");
            p.text(X, y + 6, "Host name", t.textDim); F[4].paint(p, *this, Rect{ X + 90, y, 190, 26 }, FIELD + 4); button(p, Rect{ X + 290, y, 70, 26 }, "DNS", DNSQ, false); button(p, Rect{ X + 366, y, 70, 26 }, "Ping", PING, true); y += 34;
            p.text(X, y + 6, "TCP connect", t.textDim); F[9].paint(p, *this, Rect{ X + 90, y, 190, 26 }, FIELD + 9); F[10].paint(p, *this, Rect{ X + 290, y, 60, 26 }, FIELD + 10); button(p, Rect{ X + 358, y, 78, 26 }, "Connect", TCPQ, true); y += 36;
            for (int i = 0; i < nout; i++) { p.textMax(X, y, out[i], t.text, PW - 44); y += 18; } break; }
        case P_SYSTEM: { char v[16], br[52], b[96]; hal_cpu_vendor(v); hal_cpu_brand(br);
            line(p, X, y, "Operating system", "mX 2026.10 (Stage 4.1)"); line(p, X, y, "Kernel", "Kernel24, x86-64"); line(p, X, y, "CPU", br); line(p, X, y, "CPU vendor", v);
            sfmt(b, sizeof b, "%d MiB", (int)(hal_total_mem_kb() / 1024)); line(p, X, y, "Memory", b); long up = hal_ticks() / 100; sfmt(b, sizeof b, "%dh %02dm %02ds", (int)(up / 3600), (int)(up / 60 % 60), (int)(up % 60)); line(p, X, y, "Uptime", b);
            line(p, X, y, "Interface font", uiFontFamily);
            y += 6; p.text(X, y + 6, "Computer name", t.textDim); F[5].paint(p, *this, Rect{ X + 140, y, 180, 26 }, FIELD + 5); button(p, Rect{ X + 330, y, 80, 26 }, "Rename", HOSTAPPLY, true, w); y += 40; break; }
        case P_USERS: { const User* me = users_current(); bool adm = (user_perms() & P_USERS) != 0; char b[96];
            sect(p, X, y, "Session");
            if (me) { sfmt(b, sizeof b, "%s (%s) - signed in at %s, %d min ago", me->display, role_name(me->role), users_session_clock(), (int)(users_session_seconds() / 60)); p.textMax(X, y, b, t.text, PW - 44); } y += 24;
            button(p, Rect{ X, y, 110, 28 }, "Lock now", LOCKNOW, true); button(p, Rect{ X + 118, y, 110, 28 }, "Sign out", SIGNOUT); y += 40;
            p.text(X, y, "Lock automatically after:", t.textDim); y += 22; static const char* al[5] = { "Never", "1 min", "5 min", "15 min", "30 min" }; static const int mins[5] = { 0, 1, 5, 15, 30 };
            for (int i = 0; i < 5; i++) radio(p, X + i * 96, y, al[i], cf.idleLockMin == mins[i], ALOCK + i); y += 32;
            sect(p, X, y, "Accounts");
            for (int i = 0; i < users_count(); i++) { const User* u = users_at(i); Rect r = { X, y, PW - 44, 34 }; bool s = i == selUser;
                p.fillRound(r, 4, s ? t.selection : t.panelLight); p.roundRect(r, 4, t.panelDark); p.icon(IC_USER, r.x + 8, r.y + 7, 20);
                sfmt(b, sizeof b, "%s%s", u->display, me && seq(me->name, u->name) ? "  (you)" : ""); p.textB(r.x + 38, r.y + 9, b, t.text);
                p.text(r.right() - 130, r.y + 9, role_name(u->role), t.textDim); addHitC(p, r, USER + i); y += 38; }
            y += 6;
            button(p, Rect{ X, y, 90, 28 }, "Add user", UADD, false, adm); button(p, Rect{ X + 98, y, 90, 28 }, "Delete", UDEL, false, adm); button(p, Rect{ X + 196, y, 140, 28 }, "Change password", UPASS, true);
            { const User* u = users_at(selUser); button(p, Rect{ X + 344, y, 130, 28 }, u && u->role == ROLE_ADMIN ? "Make member" : "Make admin", UROLE, false, adm); } y += 40;
            const User* u = users_at(selUser); if (u) { char h[96]; apps_perm_text(role_perms(u->role) & 0x7FF, h, sizeof h); p.text(X, y, "Permissions:", t.textDim); y += 20; p.textMax(X, y, h, t.text, PW - 44); y += 22; p.text(X, y, "Home folder:", t.textDim); p.text(X + 100, y, u->home, t.text); y += 24; }
            sect(p, X, y, "Security log");
            if (!(user_perms() & P_ADMIN)) { p.text(X, y, "Only administrators can read the security log.", t.textDim); y += 20; }
            else { for (int i = 0; i < min(audit_count(), 8); i++) { p.textMax(X, y, audit_line(i), t.text, PW - 44); y += 18; } if (audit_count() == 0) { p.text(X, y, "No events yet.", t.textDim); y += 18; } }
            break; }
        case P_TIME: { RtcTime rt; hal_rtc_read(rt); char b[64]; sfmt(b, sizeof b, "%04d-%02d-%02d  %02d:%02d:%02d", rt.year, rt.month, rt.day, rt.hour, rt.minute, rt.second); line(p, X, y, "Now", b);
            checkbox(p, X, y, "24-hour clock", cf.clock24, T24); y += 26; checkbox(p, X, y, "Show seconds", cf.showSeconds, TSEC); y += 34;
            p.text(X, y + 6, "Set time (admin)", t.textDim); F[6].paint(p, *this, Rect{ X + 140, y, 40, 26 }, FIELD + 6); p.text(X + 184, y + 5, ":", t.text); F[7].paint(p, *this, Rect{ X + 194, y, 40, 26 }, FIELD + 7); p.text(X + 238, y + 5, ":", t.text); F[8].paint(p, *this, Rect{ X + 248, y, 40, 26 }, FIELD + 8);
            button(p, Rect{ X + 300, y, 70, 26 }, "Set", TAPPLY, true, (user_perms() & P_ADMIN) != 0); y += 40; break; }
        }
        contentH = y + 20;
        if (contentH > view.h) { int th = max(30, view.h * view.h / contentH); int ty = scrollY * (view.h - th) / max(1, contentH - view.h); view.fillRound(Rect{ view.w - 7, ty, 4, th }, 2, t.panelDark); }
        else scrollY = 0;
    }
};
App* make_settings() { return new SettingsApp(); }

void apps_register_all() {
    apps_register_builtin("terminal", make_terminal); apps_register_builtin("files", make_files); apps_register_builtin("settings", make_settings);
    apps_register_builtin("monitor", make_monitor); apps_register_builtin("notepad", make_notepad); apps_register_builtin("calc", make_calc);
    apps_register_builtin("about", make_about); apps_register_builtin("appcenter", make_appcenter); apps_register_builtin("diag", make_diag); apps_register_builtin("recovery", make_recovery_tools);
}
} // namespace mx
