// files.cpp — mX Files: the graphical replacement for ls / cd / mkdir / rm / cp / mv.
#include "mx/apps.hpp"
#include "mx/wm.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
namespace mx {

static char g_clipPath[128]; static bool g_clipCut = false, g_clipHas = false;   // clipboard shared by all Files windows

struct FilesApp : App {
    char path[128]; FsEntry ent[FS_MAX_LIST]; int n = 0; int sel = -1; int scroll = 0;
    char hist[8][128]; int nh = 0; char pendingName[40] = ""; long lastClick = -1000; int lastIdx = -1;
    enum { B_BACK = 1, B_UP, B_NEWDIR, B_NEWFILE, B_RENAME, B_DELETE, B_COPY, B_CUT, B_PASTE, B_INFO, PLACE = 20, ROW = 100 };
    enum { T_NEWDIR = 1, T_NEWFILE, T_RENAME, T_DELETE };

    void windowSpec(WindowSpec& s) override { s.title = "mX Files"; s.frame = Rect{ 60, 40, 660, 420 }; s.flags = WF_RESIZABLE; s.minW = 520; s.minH = 260; }
    void onCreate() override { const User* u = users_current(); scopy(path, u ? u->home : "/", sizeof path); refresh(); }
    void refresh() {
        n = fs_list(path, ent, FS_MAX_LIST); if (n < 0) { n = 0; scopy(path, "/", sizeof path); n = fs_list(path, ent, FS_MAX_LIST); if (n < 0) n = 0; }
        if (sel >= n) sel = n - 1; scroll = clamp(scroll, 0, max(0, n - 1));
        char t[96]; sfmt(t, sizeof t, "mX Files - %s", path); if (win) win->title.set(t);
        invalidate();
    }
    void go(const char* p, bool pushHist = true) {
        if (!fs_is_dir(p)) { notifyf(N_ERROR, "Files", "Not a folder", "%s", p); return; }
        if (!fs_can_read(p)) { notifyf(N_ERROR, "Files", "Permission denied", "You can't open %s", p); return; }
        if (pushHist && nh < 8) scopy(hist[nh++], path, 128);
        else if (pushHist) { for (int i = 1; i < 8; i++) scopy(hist[i - 1], hist[i], 128); scopy(hist[7], path, 128); }
        scopy(path, p, sizeof path); sel = -1; scroll = 0; refresh();
    }
    void up() { char p[128]; fs_parent(path, p, sizeof p); if (!seq(p, path)) go(p); }
    void fullPath(int i, char* out, int cap) { fs_join(out, cap, path, ent[i].name); }
    void openSel() {
        if (sel < 0 || sel >= n) return; char p[160]; fullPath(sel, p, sizeof p);
        if (ent[sel].dir) go(p); else notepad_open_file(p);
    }
    bool needWrite(const char* what) {
        if (fs_can_write(path)) return true;
        notifyf(N_ERROR, "Files", "Permission denied", "You can't %s in %s", what, path); return false;
    }
    void doCopy(bool cut) { if (sel < 0) return; fullPath(sel, g_clipPath, sizeof g_clipPath); g_clipCut = cut; g_clipHas = true; invalidate(); }
    void doPaste() {
        if (!g_clipHas || !needWrite("paste")) return;
        bool ok = g_clipCut ? fs_move(g_clipPath, path) : fs_copy(g_clipPath, path);
        if (!ok) notifyf(N_ERROR, "Files", g_clipCut ? "Move failed" : "Copy failed", "Name clash, no space left, or the folder is inside itself.");
        else if (g_clipCut) g_clipHas = false;
        refresh();
    }
    void props() {
        if (sel < 0) return; char p[160], own[24], msg[200]; fullPath(sel, p, sizeof p); fs_owner(p, own, sizeof own);
        sfmt(msg, sizeof msg, "Name: %s\nType: %s\nLocation: %s\nSize: %d bytes\nOwner: %s\nInode: #%d\nYou can write here: %s",
             ent[sel].name, ent[sel].dir ? "Folder" : "File", path, ent[sel].size, own, ent[sel].inode, fs_can_write(p) ? "yes" : "no");
        dialog_message("Properties", msg, IC_INFO);
    }

    void onDialog(int tag, bool ok, const char* text) override {
        if (!ok) return;
        char p[160];
        if (tag == T_NEWDIR || tag == T_NEWFILE) {
            if (!text[0] || slen(text) > 30 || sfind(text, '/')) { notify(N_ERROR, "Files", "Invalid name", "Names can't be empty, contain '/', or exceed 30 characters."); return; }
            fs_join(p, sizeof p, path, text);
            bool r = tag == T_NEWDIR ? vfs_mkdir(p) : vfs_create_file(p);
            if (!r) notify(N_ERROR, "Files", "Couldn't create it", "The name already exists or the RAM disk is out of inodes."); refresh();
        } else if (tag == T_RENAME && sel >= 0) {
            fullPath(sel, p, sizeof p);
            if (!fs_rename(p, text)) notify(N_ERROR, "Files", "Rename failed", "Invalid name or it already exists."); refresh();
        } else if (tag == T_DELETE && sel >= 0) {
            fullPath(sel, p, sizeof p);
            if (!fs_delete(p)) notify(N_ERROR, "Files", "Delete failed", "Could not remove it."); sel = -1; refresh();
        }
    }
    static bool sfind(const char* s, char c) { for (; *s; s++) if (*s == c) return true; return false; }

    void onAction(int id, int btn) override {
        if (id >= ROW && id < ROW + FS_MAX_LIST) {
            int i = id - ROW; long now = ui_ticks();
            if (i == lastIdx && now - lastClick < 40) { sel = i; openSel(); lastIdx = -1; return; }
            sel = i; lastIdx = i; lastClick = now; (void)btn; invalidate(); return;
        }
        if (id >= PLACE && id < PLACE + 6) {
            const User* u = users_current(); char p[96];
            switch (id - PLACE) {
            case 0: go(u ? u->home : "/"); break;
            case 1: sfmt(p, sizeof p, "%s/Documents", u ? u->home : ""); go(p); break;
            case 2: go("/shared"); break; case 3: go("/system"); break; case 4: go("/"); break; default: break;
            }
            return;
        }
        switch (id) {
        case B_BACK: if (nh > 0) { char p[128]; scopy(p, hist[--nh], sizeof p); go(p, false); } break;
        case B_UP: up(); break;
        case B_NEWDIR: if (needWrite("create folders")) dialog_prompt(this, T_NEWDIR, "New folder", "Folder name", "New folder"); break;
        case B_NEWFILE: if (needWrite("create files")) dialog_prompt(this, T_NEWFILE, "New file", "File name", "untitled.txt"); break;
        case B_RENAME: if (sel >= 0 && needWrite("rename")) dialog_prompt(this, T_RENAME, "Rename", "New name", ent[sel].name); break;
        case B_DELETE: if (sel >= 0 && needWrite("delete")) { char m[96]; sfmt(m, sizeof m, "Delete \"%s\"%s?", ent[sel].name, ent[sel].dir ? " and everything in it" : ""); dialog_confirm(this, T_DELETE, "Delete", m); } break;
        case B_COPY: doCopy(false); break; case B_CUT: if (needWrite("move")) doCopy(true); break;
        case B_PASTE: doPaste(); break; case B_INFO: props(); break;
        }
    }
    void onMouse(const UiMouse& m) override { if (m.kind == UiMouse::Wheel) { scroll = clamp(scroll - m.wheel, 0, max(0, n - 1)); invalidate(); } }
    void onKey(const KeyEvent& e) override {
        if (!e.down) return;
        if (e.key == K_UP && sel > 0) { sel--; keepVisible(); } else if (e.key == K_DOWN && sel < n - 1) { sel++; keepVisible(); }
        else if (e.key == K_ENTER) openSel(); else if (e.key == K_BACKSPACE) up();
        else if (e.key == K_DELETE) onAction(B_DELETE, 1); else if (e.key == K_F2) onAction(B_RENAME, 1); else if (e.key == K_F5) refresh();
        else if ((e.mods & MOD_CTRL) && e.key == K_CHAR) { char ch = lower((char)e.ch); if (ch == 'c') doCopy(false); else if (ch == 'x') onAction(B_CUT, 1); else if (ch == 'v') doPaste(); }
        invalidate();
    }
    void keepVisible() { int rows = max(1, (ch - 62 - 22 - 22) / 22); if (sel < scroll) scroll = sel; if (sel >= scroll + rows) scroll = sel - rows + 1; }
    void onTick(long) override { static int k = 0; if (++k % 20 == 0) refresh(); }          // pick up changes made by the shell/other windows

    void onPaint(Canvas& c) override {
        Theme& t = theme(); beginPaint(c);
        // toolbar
        c.fill(Rect{ 0, 0, c.w, 36 }, t.panel); c.hline(0, 35, c.w, t.panelDark);
        struct B { const char* l; int id; bool en; } bs[] = { {"\xE2\x86\x90", B_BACK, nh > 0}, {"\xE2\x86\x91", B_UP, true}, {"+Folder", B_NEWDIR, true}, {"+File", B_NEWFILE, true},
            {"Rename", B_RENAME, sel >= 0}, {"Delete", B_DELETE, sel >= 0}, {"Copy", B_COPY, sel >= 0}, {"Cut", B_CUT, sel >= 0}, {"Paste", B_PASTE, g_clipHas}, {"Info", B_INFO, sel >= 0} };
        int x = 6; for (auto& b : bs) { int w = c.textWidth(b.l) + 16; button(c, Rect{ x, 5, w, 26 }, b.l, b.id, false, b.en); x += w + 4; if (b.id == B_UP || b.id == B_NEWFILE || b.id == B_DELETE) x += 6; }
        // path bar
        c.fill(Rect{ 0, 36, c.w, 26 }, t.panelLight); c.hline(0, 61, c.w, t.panelDark); c.text(10, 41, path, t.text);
        // sidebar
        int top = 62, bottom = c.h - 22; c.fill(Rect{ 0, top, 130, bottom - top }, t.panel); c.vline(130, top, bottom - top, t.panelDark);
        static const char* pl[5] = { "Home", "Documents", "Shared", "System", "Root /" }; static const IconId pi[5] = { IC_USER, IC_FOLDER, IC_FOLDER, IC_SETTINGS, IC_DISK };
        for (int i = 0; i < 5; i++) {
            Rect r = { 4, top + 6 + i * 28, 122, 26 }; bool hov = hoverId == PLACE + i;
            if (hov) c.fillRound(r, 3, t.panelLight); c.icon(pi[i], r.x + 6, r.y + 5, 16); c.text(r.x + 28, r.y + 5, pl[i], t.text); addHit(r, PLACE + i);
        }
        // list
        Rect lr = { 131, top, c.w - 131, bottom - top }; c.fill(lr, t.field);
        int nameW = max(120, lr.w - 230); int cx1 = lr.x + 8 + 24 + nameW, cx2 = cx1 + 70, cx3 = cx2 + 70;
        c.fill(Rect{ lr.x, top, lr.w, 22 }, t.panel); c.hline(lr.x, top + 21, lr.w, t.panelDark);
        c.text(lr.x + 34, top + 3, "Name", t.textDim); c.text(cx1, top + 3, "Type", t.textDim); c.text(cx2, top + 3, "Size", t.textDim); c.text(cx3, top + 3, "Owner", t.textDim);
        int rows = (lr.h - 22) / 22;
        for (int r = 0; r < rows && scroll + r < n; r++) {
            int i = scroll + r; Rect rr = { lr.x, top + 22 + r * 22, lr.w, 22 };
            bool s = i == sel; bool hov = hoverId == ROW + i;
            if (s) c.fill(rr, t.selection); else if (hov) c.fill(rr, blend(t.accent, t.field, 25));
            c.icon(ent[i].dir ? IC_FOLDER : IC_FILE, rr.x + 8, rr.y + 3, 16);
            c.textMax(rr.x + 34, rr.y + 3, ent[i].name, s ? t.text : t.text, nameW);
            c.text(cx1, rr.y + 3, ent[i].dir ? "Folder" : "File", t.textDim);
            char sz[16]; if (ent[i].dir) sz[0] = 0; else sfmt(sz, sizeof sz, "%d B", ent[i].size); c.text(cx2, rr.y + 3, sz, t.textDim);
            char p[160], own[24]; fs_join(p, sizeof p, path, ent[i].name); fs_owner(p, own, sizeof own); c.textMax(cx3, rr.y + 3, own, t.textDim, 80);
            addHit(rr, ROW + i);
        }
        if (n == 0) c.text(lr.x + 20, top + 40, "This folder is empty.", t.textDim);
        // status bar
        c.fill(Rect{ 0, c.h - 22, c.w, 22 }, t.panel); c.hline(0, c.h - 22, c.w, t.panelDark);
        char st[120]; int iu, it, bu, bt; fs_usage(&iu, &it, &bu, &bt);
        sfmt(st, sizeof st, "%d item%s", n, n == 1 ? "" : "s"); if (sel >= 0) { scat(st, " | selected: ", sizeof st); scat(st, ent[sel].name, sizeof st); }
        c.textMax(8, c.h - 19, st, t.textDim, c.w - 220);
        char us[48]; sfmt(us, sizeof us, "%s%d/%d inodes", g_clipHas ? (g_clipCut ? "[cut] " : "[copied] ") : "", iu, it); c.text(c.w - 8 - c.textWidth(us), c.h - 19, us, t.textDim);
    }
};
App* make_files() { return new FilesApp(); }

} // namespace mx
