#include "mx/wm.hpp"
#include "mx/hal.hpp"
namespace mx {

static WindowManager g_wm;
WindowManager& wm() { return g_wm; }

Rect Window::client() const {
    if (maximized) { Rect r = { frame.x, frame.y + TITLE_H, frame.w, frame.h - TITLE_H }; return r; }
    Rect r = { frame.x + BORDER, frame.y + TITLE_H, frame.w - 2 * BORDER, frame.h - TITLE_H - BORDER };
    return r;
}

void WindowManager::init(const Rect& w) { work = w; n = 0; focus = nullptr; mode = M_NONE; }
void WindowManager::setWorkArea(const Rect& r) {
    work = r;
    for (int i = 0; i < n; i++) {
        Window* w = z[i];
        if (w->maximized) { w->frame = work; w->app->onResize(w->clientW(), w->clientH()); continue; }
        Rect f = w->frame; bool changed = false;
        if (f.w > work.w) { f.w = max(work.w, w->minW); changed = true; }
        if (f.h > work.h) { f.h = max(work.h, w->minH); changed = true; }
        int nx = clamp(f.x, work.x, max(work.x, work.right() - f.w)), ny = clamp(f.y, work.y, max(work.y, work.bottom() - f.h));
        if (nx != f.x || ny != f.y) { f.x = nx; f.y = ny; changed = true; }
        if (changed) { w->frame = f; w->restore = f; w->app->onResize(w->clientW(), w->clientH()); }
    }
    ui_invalidate();
}

Window* WindowManager::create(App* app, const char* title, Rect f, u32 flags, IconId icon, int minW, int minH) {
    if (n >= WM_MAX || !app) return nullptr;
    Window* w = new Window();
    w->id = nextId++; w->title.set(title); w->flags = flags; w->icon = icon; w->app = app; w->minW = minW; w->minH = minH;
    if (flags & WF_CENTER) { f.x = work.x + (work.w - f.w) / 2; f.y = work.y + (work.h - f.h) / 2; }
    else { int off = (n % 6) * 26; f.x += off; f.y += off; }    // cascade
    f.x = clamp(f.x, work.x, max(work.x, work.right() - 60)); f.y = clamp(f.y, work.y, max(work.y, work.bottom() - TITLE_H));
    w->frame = f; w->restore = f;
    app->win = w;
    z[n++] = w;
    app->onCreate();
    setFocus(w);
    ui_invalidate();
    return w;
}

void WindowManager::remove(Window* w) {
    int idx = -1;
    for (int i = 0; i < n; i++) if (z[i] == w) idx = i;
    if (idx < 0) return;
    for (int i = idx; i < n - 1; i++) z[i] = z[i + 1];
    n--;
    if (focus == w) {
        focus = nullptr;
        for (int i = n - 1; i >= 0; i--) if (!z[i]->minimized) { focus = z[i]; break; }
        if (focus) focus->app->onFocus(true);
    }
    if (drag == w) { drag = nullptr; mode = M_NONE; }
    delete w->app; delete w;
    ui_invalidate();
}
void WindowManager::requestClose(Window* w) { if (w) w->closing = true; ui_invalidate(); }
void WindowManager::reapClosed() {
    for (int i = n - 1; i >= 0; i--) {
        Window* w = z[i];
        if (!w->closing) continue;
        if (w->app->onClose()) remove(w); else w->closing = false;
    }
}
void WindowManager::closeAll() { while (n > 0) remove(z[n - 1]); }

Window* WindowManager::find(const App* a) const { for (int i = 0; i < n; i++) if (z[i]->app == a) return z[i]; return nullptr; }
Window* WindowManager::modal() const { for (int i = n - 1; i >= 0; i--) if ((z[i]->flags & WF_MODAL) && !z[i]->minimized) return z[i]; return nullptr; }

void WindowManager::raise(Window* w) {
    int idx = -1;
    for (int i = 0; i < n; i++) if (z[i] == w) idx = i;
    if (idx < 0 || idx == n - 1) return;
    for (int i = idx; i < n - 1; i++) z[i] = z[i + 1];
    z[n - 1] = w; ui_invalidate();
}
void WindowManager::setFocus(Window* w) {
    if (focus == w) { if (w) raise(w); return; }
    if (focus) focus->app->onFocus(false);
    focus = w;
    if (w) { if (w->minimized) w->minimized = false; raise(w); w->app->onFocus(true); }
    ui_invalidate();
}
void WindowManager::minimize(Window* w) {
    if (w->flags & WF_NOMIN) return;
    w->minimized = true;
    if (focus == w) {
        focus = nullptr;
        for (int i = n - 1; i >= 0; i--) if (!z[i]->minimized) { focus = z[i]; break; }
    }
    ui_invalidate();
}
void WindowManager::restore(Window* w) { w->minimized = false; setFocus(w); }
void WindowManager::toggleMaximize(Window* w) {
    if (!(w->flags & WF_RESIZABLE) || (w->flags & WF_NOMAX)) return;
    if (w->maximized) { w->maximized = false; w->frame = w->restore; }
    else { w->restore = w->frame; w->maximized = true; w->frame = work; }
    w->app->onResize(w->clientW(), w->clientH());
    ui_invalidate();
}
void WindowManager::cycleFocus(bool back) {
    if (n < 2) return;
    int cur = -1;
    for (int i = 0; i < n; i++) if (z[i] == focus) cur = i;
    for (int step = 1; step <= n; step++) {
        int i = back ? (cur + step) % n : ((cur - step) % n + n) % n;   // z[] is bottom..top; the window below the top is next
        if (z[i] != focus && !(z[i]->minimized && (z[i]->flags & WF_NOTASKBAR))) { setFocus(z[i]); return; }
    }
}
void WindowManager::taskbarClick(Window* w) {
    if (w->minimized) restore(w);
    else if (w == focus) minimize(w);
    else setFocus(w);
}

Rect WindowManager::closeBtn(const Window* w) const { Rect r = { w->frame.right() - (w->maximized ? 0 : BORDER) - 24, w->frame.y + 3, 22, 20 }; return r; }
Rect WindowManager::maxBtn(const Window* w) const { Rect r = closeBtn(w); r.x -= 24; return r; }
Rect WindowManager::minBtn(const Window* w) const { Rect r = maxBtn(w); r.x -= 24; return r; }

WindowManager::Hit WindowManager::hitTest(const Window* w, int x, int y, int* ed) const {
    if (ed) *ed = 0;
    if (!w->frame.contains(x, y)) return HT_NONE;
    if (!(w->flags & WF_NOCLOSE) && closeBtn(w).contains(x, y)) return HT_CLOSE;
    if (!(w->flags & (WF_NOMAX)) && (w->flags & WF_RESIZABLE) && maxBtn(w).contains(x, y)) return HT_MAX;
    if (!(w->flags & WF_NOMIN) && minBtn(w).contains(x, y)) return HT_MIN;
    if ((w->flags & WF_RESIZABLE) && !w->maximized) {
        int e = 0; const int g = 5;
        if (x < w->frame.x + g) e |= 1; if (x >= w->frame.right() - g) e |= 2;
        if (y < w->frame.y + g) e |= 4; if (y >= w->frame.bottom() - g) e |= 8;
        if (e) { if (ed) *ed = e; return HT_SIZE; }
    }
    if (y < w->frame.y + TITLE_H) return HT_TITLE;
    return HT_CLIENT;
}

Window* WindowManager::windowAt(int x, int y) const {
    for (int i = n - 1; i >= 0; i--) if (!z[i]->minimized && z[i]->frame.contains(x, y)) return z[i];
    return nullptr;
}

// ---------------- painting ----------------
void WindowManager::drawWindow(Canvas& c, Window* w) {
    Theme& t = theme();
    bool act = (w == focus);
    Rect f = w->frame;
    if (!w->maximized) c.shadow(f, 8, act ? 90 : 50);
    // frame + title bar
    c.fill(f, act ? t.border : t.titleInactive);
    Rect tb = { f.x + 1, f.y + 1, f.w - 2, TITLE_H - 1 };
    if (act) c.gradV(tb, t.titleActiveA, t.titleActiveB); else c.gradV(tb, blend(t.titleInactive, rgb(255,255,255), 60), t.titleInactive);
    if (w->icon != IC_NONE) c.icon(w->icon, f.x + 7, f.y + 5, 16);
    c.textMax(f.x + (w->icon != IC_NONE ? 28 : 8), f.y + 5, w->title, t.textOnAccent, f.w - 130, true);
    // buttons
    struct B { Rect r; Hit h; const char* g; bool on; Color hov; };
    B bs[3] = {
        { minBtn(w), HT_MIN, "_", !(w->flags & WF_NOMIN), rgb(255, 255, 255) },
        { maxBtn(w), HT_MAX, w->maximized ? "\xE2\x96\xA1" : "\xE2\x96\xA1", (w->flags & WF_RESIZABLE) && !(w->flags & WF_NOMAX), rgb(255, 255, 255) },
        { closeBtn(w), HT_CLOSE, "\xE2\x9C\x95", !(w->flags & WF_NOCLOSE), t.danger } };
    int mx_, my_; mouse_position(mx_, my_);
    for (int i = 0; i < 3; i++) {
        if (!bs[i].on) continue;
        bool hover = bs[i].r.contains(mx_, my_) && windowAt(mx_, my_) == w;
        bool pressed = (mode == M_BTN && drag == w && btn == bs[i].h && hover);
        if (hover) c.tint(bs[i].r, bs[i].h == HT_CLOSE ? t.danger : rgb(255, 255, 255), pressed ? 150 : 90);
        int cx = bs[i].r.x + bs[i].r.w / 2, cy = bs[i].r.y + bs[i].r.h / 2; Color wc = t.textOnAccent;
        if (bs[i].h == HT_MIN) { c.hline(cx - 5, cy + 4, 10, wc); c.hline(cx - 5, cy + 5, 10, wc); }
        else if (bs[i].h == HT_MAX) {
            if (w->maximized) { c.rect(Rect{ cx - 3, cy - 5, 8, 8 }, wc); c.rect(Rect{ cx - 5, cy - 3, 8, 8 }, wc); }
            else { c.rect(Rect{ cx - 5, cy - 5, 10, 10 }, wc); c.hline(cx - 5, cy - 4, 10, wc); }
        } else { c.line(cx - 4, cy - 4, cx + 4, cy + 4, wc); c.line(cx - 4, cy - 3, cx + 3, cy + 4, wc); c.line(cx + 4, cy - 4, cx - 4, cy + 4, wc); c.line(cx + 3, cy - 4, cx - 4, cy + 3, wc); }
    }
    // client area
    Rect cl = w->client();
    c.fill(cl, t.window);
    Canvas cc = c.sub(cl);
    w->app->beginPaint(cc);
    w->app->onPaint(cc);
    if (!act && !(w->flags & WF_MODAL) && modal()) c.tint(cl, rgb(0, 0, 0), 40);
}

void WindowManager::paint(Canvas& c) {
    for (int i = 0; i < n; i++) if (!z[i]->minimized) drawWindow(c, z[i]);
}

// ---------------- input ----------------
void WindowManager::applyResize(int mx_, int my_) {
    Window* w = drag; Rect f = startFrame;
    int ddx = mx_ - sx, ddy = my_ - sy;
    int x0 = f.x, y0 = f.y, x1 = f.right(), y1 = f.bottom();
    if (edges & 1) x0 = min(f.x + ddx, x1 - w->minW);
    if (edges & 2) x1 = max(f.right() + ddx, x0 + w->minW);
    if (edges & 4) y0 = min(f.y + ddy, y1 - w->minH);
    if (edges & 8) y1 = max(f.bottom() + ddy, y0 + w->minH);
    y0 = max(y0, work.y);
    Rect nf = { x0, y0, x1 - x0, y1 - y0 };
    w->frame = nf; w->restore = nf;
    w->app->onResize(w->clientW(), w->clientH());
}

bool WindowManager::mouse(const MouseEvent& e, u32 prevButtons) {
    bool leftDown = (e.buttons & 1) && !(prevButtons & 1);
    bool leftUp = !(e.buttons & 1) && (prevButtons & 1);
    bool rightDown = (e.buttons & 2) && !(prevButtons & 2);
    bool rightUp = !(e.buttons & 2) && (prevButtons & 2);
    Window* mod = modal();

    // ongoing drags own the mouse
    if (mode == M_MOVE && drag) {
        if (e.buttons & 1) {
            Window* w = drag;
            if (w->maximized) {                         // dragging a maximized window restores it under the pointer
                Rect r = w->restore; w->maximized = false;
                r.x = e.x - r.w / 2; r.y = e.y - 10; w->frame = r; dx = e.x - r.x; dy = e.y - r.y;
                w->app->onResize(w->clientW(), w->clientH());
            }
            w->frame.x = e.x - dx; w->frame.y = max(work.y - 0, e.y - dy);
            w->frame.y = min(w->frame.y, work.bottom() - TITLE_H);
            w->restore = w->frame; ui_invalidate();
        }
        if (leftUp) {
            if (drag->frame.y <= work.y && (drag->flags & WF_RESIZABLE) && e.y <= work.y + 1) toggleMaximize(drag);   // snap-to-top maximizes
            mode = M_NONE; drag = nullptr; ui_invalidate();
        }
        return true;
    }
    if (mode == M_SIZE && drag) {
        if (e.buttons & 1) { applyResize(e.x, e.y); ui_invalidate(); }
        if (leftUp) { mode = M_NONE; drag = nullptr; }
        return true;
    }
    if (mode == M_BTN && drag) {
        if (leftUp) {
            int ed; Hit h = hitTest(drag, e.x, e.y, &ed);
            Window* w = drag; Hit want = btn; mode = M_NONE; drag = nullptr;
            if (h == want) {
                if (want == HT_CLOSE) requestClose(w);
                else if (want == HT_MIN) minimize(w);
                else if (want == HT_MAX) toggleMaximize(w);
            }
            ui_invalidate();
        }
        return true;
    }

    Window* w = windowAt(e.x, e.y);
    if (mod && w != mod) {                              // modal dialog: swallow clicks elsewhere
        if (leftDown || rightDown) { setFocus(mod); }
        return w != nullptr || leftDown;
    }
    // client-area routing: mouse is captured by the window where a press started
    static Window* capture = nullptr; static int captureBtn = 0;
    if (capture && (e.buttons & 7) == 0 && !(prevButtons & 7)) capture = nullptr;
    Window* target = capture ? capture : w;
    if (!target) { if (leftDown || rightDown) setFocus(nullptr); return false; }

    int edgesOut = 0; Hit h = hitTest(target, e.x, e.y, &edgesOut);
    if (!capture && (leftDown || rightDown)) {
        if (target != focus) setFocus(target);
        if (leftDown) {
            if (h == HT_CLOSE || h == HT_MAX || h == HT_MIN) { mode = M_BTN; drag = target; btn = h; ui_invalidate(); return true; }
            if (h == HT_SIZE) { mode = M_SIZE; drag = target; edges = edgesOut; startFrame = target->frame; sx = e.x; sy = e.y; return true; }
            if (h == HT_TITLE) {
                long now = hal_ticks();
                if (lastClickWin == target && now - lastClickTick < 40 && abs_(e.x - lastClickX) < 6 && abs_(e.y - lastClickY) < 6) {
                    lastClickWin = nullptr; toggleMaximize(target); return true;     // double-click titlebar
                }
                lastClickWin = target; lastClickTick = now; lastClickX = e.x; lastClickY = e.y;
                mode = M_MOVE; drag = target; dx = e.x - target->frame.x; dy = e.y - target->frame.y; return true;
            }
        }
        if (h == HT_CLIENT) { capture = target; captureBtn = leftDown ? 1 : 2; }
    }
    if (h == HT_CLIENT || capture == target) {
        Rect cl = target->client();
        UiMouse m; m.x = e.x - cl.x; m.y = e.y - cl.y; m.buttons = e.buttons; m.wheel = e.wheel; m.button = 0;
        if (leftDown) { m.kind = UiMouse::Down; m.button = 1; }
        else if (rightDown) { m.kind = UiMouse::Down; m.button = 2; }
        else if (leftUp) { m.kind = UiMouse::Up; m.button = 1; }
        else if (rightUp) { m.kind = UiMouse::Up; m.button = 2; }
        else if (e.wheel) m.kind = UiMouse::Wheel;
        else m.kind = UiMouse::Move;
        (void)captureBtn;
        target->app->dispatchMouse(m);
        if (m.kind == UiMouse::Down && m.button == 1) {         // synthesize Double on a quick second press in client area
            static long lastT = -1000; static int lx = 0, ly = 0; static Window* lw = nullptr;
            long now = hal_ticks();
            if (lw == target && now - lastT < 40 && abs_(m.x - lx) < 6 && abs_(m.y - ly) < 6) {
                UiMouse d = m; d.kind = UiMouse::Double; target->app->dispatchMouse(d); lw = nullptr;
            } else { lw = target; lastT = now; lx = m.x; ly = m.y; }
        }
    } else if (!capture) {
        // hovering over decorations: let the client clear its hover state
        UiMouse m = { UiMouse::Move, -1, -1, 0, 0, e.buttons };
        if (e.dx || e.dy) target->app->dispatchMouse(m);
    }
    return true;
}

bool WindowManager::key(const KeyEvent& e) {
    if (!e.down) { if (focus) { focus->app->onKey(e); } return focus != nullptr; }
    if ((e.mods & MOD_ALT) && e.key == K_TAB) { cycleFocus(e.mods & MOD_SHIFT); return true; }
    if ((e.mods & MOD_ALT) && e.key == K_F4 && focus && !(focus->flags & WF_NOCLOSE)) { requestClose(focus); return true; }
    if (focus) { focus->app->onKey(e); return true; }
    return false;
}
void WindowManager::tick(long ticks) { for (int i = 0; i < n; i++) z[i]->app->onTick(ticks); }

} // namespace mx
