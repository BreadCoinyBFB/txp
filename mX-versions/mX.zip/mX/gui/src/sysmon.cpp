// sysmon.cpp — System Monitor: live CPU/RAM, process list, running applications, devices, diagnostics.
#include "mx/apps.hpp"
#include "mx/wm.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
#include "mx/display.hpp"
#include "mx/pci.hpp"
#include "mx/net.hpp"
#include "mx/sysstat.hpp"
namespace mx {

struct MonitorApp : App {
    enum { TAB = 1, B_RUN = 10, B_END = 11, B_FOCUS = 12, B_CLOSEWIN = 13, PROC = 100, WIN = 200 };
    int tab = 0; u8 cpuH[60], ramH[60]; int nh = 0; long lastSample = 0; DiagResult dr[24]; int ndr = 0; bool diagRan = false; int scroll = 0;
    ProcInfo procs[PROC_MAX]; int np = 0; int selPid = -1; int selWin = -1;
    explicit MonitorApp(int t) : tab(t) { for (int i = 0; i < 60; i++) cpuH[i] = ramH[i] = 0; }
    void windowSpec(WindowSpec& s) override { s.title = tab == 4 ? "Diagnostics" : "System Monitor"; s.frame = Rect{ 70, 40, 640, 440 }; s.flags = WF_RESIZABLE; s.minW = 560; s.minH = 320; }
    void onCreate() override { sample(); if (tab == 4) runDiag(); }
    void sample() {
        sysstat_update(); np = sysstat_processes(procs, PROC_MAX);
        u64 tot = hal_total_mem_kb(), fr = hal_free_mem_kb();
        if (nh == 60) { for (int i = 1; i < 60; i++) { cpuH[i - 1] = cpuH[i]; ramH[i - 1] = ramH[i]; } nh = 59; }
        cpuH[nh] = (u8)clamp(sysstat_cpu_percent(), 0, 100); ramH[nh] = (u8)(tot ? (tot - fr) * 100 / tot : 0); nh++;
    }
    void runDiag() { ndr = diag_run(dr, 24); diagRan = true; invalidate(); }
    void onTick(long now) override { if (now - lastSample >= 100) { lastSample = now; sample(); invalidate(); } }
    void onAction(int id, int) override {
        if (id >= TAB && id < TAB + 5) { tab = id - TAB; scroll = 0; if (tab == 4 && !diagRan) runDiag(); if (win) win->title.set(tab == 4 ? "Diagnostics" : "System Monitor"); invalidate(); }
        else if (id == B_RUN) runDiag();
        else if (id >= PROC && id < PROC + PROC_MAX) { selPid = procs[id - PROC].pid; invalidate(); }
        else if (id == B_END) {
            if (!(user_perms() & P_PROCESS)) { notify(N_WARN, "System Monitor", "Not allowed", "Your account can't end processes."); return; }
            for (int i = 0; i < np; i++) if (procs[i].pid == selPid) {
                if (procs[i].isGui || procs[i].pid <= 1) { notify(N_WARN, "System Monitor", "Protected", "The desktop and the idle task can't be ended."); return; }
                task_kill(selPid); notifyf(N_INFO, "System Monitor", "Process ended", "%s (pid %d)", procs[i].name, selPid); selPid = -1; sample();
            }
        }
        else if (id >= WIN && id < WIN + WM_MAX) { Window* w = wm().at(id - WIN); if (w) selWin = w->id; invalidate(); }
        else if (id == B_FOCUS || id == B_CLOSEWIN) { for (int i = 0; i < wm().count(); i++) if (wm().at(i)->id == selWin) { if (id == B_FOCUS) wm().setFocus(wm().at(i)); else if (wm().at(i)->app != this) wm().requestClose(wm().at(i)); return; } }
    }
    void onMouse(const UiMouse& m) override { if (m.kind == UiMouse::Wheel) { scroll = clamp(scroll - m.wheel, 0, 40); invalidate(); } }

    void graph(Canvas& c, const Rect& g, const u8* h, Color col, const char* label, int now) {
        Theme& t = theme(); c.fillRound(g, 4, rgb(22, 26, 36));
        for (int k = 1; k < 4; k++) c.hline(g.x + 2, g.y + g.h * k / 4, g.w - 4, rgb(40, 46, 60));
        int bw = max(2, (g.w - 8) / 60);
        for (int i = 0; i < nh; i++) { int bh = h[i] * (g.h - 10) / 100; Rect b = { g.x + 4 + (60 - nh + i) * bw, g.bottom() - 4 - bh, bw - 1, bh }; c.fill(b, col); }
        char s[40]; sfmt(s, sizeof s, "%s %d%%", label, now); c.fillRound(Rect{ g.x + 6, g.y + 5, c.textWidthB(s) + 12, 20 }, 3, rgb(0, 0, 0)); c.textB(g.x + 12, g.y + 7, s, rgb(235, 238, 245)); (void)t;
    }
    void onPaint(Canvas& c) override {
        Theme& t = theme(); beginPaint(c);
        c.fill(Rect{ 0, 0, c.w, 34 }, t.panel); c.hline(0, 33, c.w, t.panelDark);
        static const char* names[5] = { "Overview", "Processes", "Apps", "Devices", "Diagnostics" };
        for (int i = 0; i < 5; i++) button(c, Rect{ 8 + i * 104, 5, 100, 26 }, names[i], TAB + i, tab == i);
        char b[110]; int y = 46;
        if (tab == 0) {
            char v[16], br[52]; hal_cpu_vendor(v); hal_cpu_brand(br);
            c.textB(16, y, "Processor", t.text); c.textMax(120, y, br, t.text, c.w - 136); y += 22;
            int half = (c.w - 40) / 2; int gh = clamp(c.h / 4, 70, 130);
            u64 tot = hal_total_mem_kb(), fr = hal_free_mem_kb(); int usedPct = tot ? (int)((tot - fr) * 100 / tot) : 0;
            graph(c, Rect{ 16, y, half, gh }, cpuH, rgb(100, 200, 255), "CPU", sysstat_cpu_percent()); graph(c, Rect{ 24 + half, y, half, gh }, ramH, rgb(170, 130, 255), "RAM", usedPct); y += gh + 14;
            long up = hal_ticks() / 100; sfmt(b, sizeof b, "%dh %02dm %02ds", (int)(up / 3600), (int)(up / 60 % 60), (int)(up % 60));
            auto row = [&](const char* k, const char* val) { c.text(16, y, k, t.textDim); c.textMax(150, y, val, t.text, c.w - 166); y += 19; };
            row("Uptime", b); sfmt(b, sizeof b, "%d MiB installed, %d KiB free (%d%% in use)", (int)(tot / 1024), (int)fr, usedPct); row("Memory", b);
            sfmt(b, sizeof b, "%d KiB free", (int)(hal_heap_free() / 1024)); row("Kernel heap", b);
            sfmt(b, sizeof b, "%d running, %d windows open", np, wm().count()); row("Tasks", b);
            const DisplayInfo& d = display_info(); sfmt(b, sizeof b, "%dx%d (%dx scaling), %s", d.w, d.h, d.scale, d.driver); row("Display", b);
            const NetInfo& ni = net_info(); sfmt(b, sizeof b, "%s  -  %d in / %d out packets", ni.status, (int)ni.rxPackets, (int)ni.txPackets); row("Network", b);
        } else if (tab == 1) {
            c.text(16, y, "PID", t.textDim); c.text(66, y, "Name", t.textDim); c.text(230, y, "State", t.textDim); c.text(310, y, "CPU", t.textDim); c.text(380, y, "Stack in use", t.textDim); y += 22;
            for (int i = 0; i < np; i++) {
                Rect r = { 8, y, c.w - 16, 22 }; bool s = procs[i].pid == selPid;
                if (s) c.fillRound(r, 3, t.selection); else if (hoverId == PROC + i) c.fillRound(r, 3, t.panelLight);
                sfmt(b, sizeof b, "%d", procs[i].pid); c.text(16, y + 3, b, t.text);
                c.textMax(66, y + 3, procs[i].name, t.text, 150, procs[i].isGui); if (procs[i].isGui) c.text(66 + c.textWidthB(procs[i].name) + 6, y + 3, "(desktop)", t.textDim);
                c.text(230, y + 3, sysstat_state_name(procs[i].state), t.textDim);
                sfmt(b, sizeof b, "%d.%d%%", procs[i].cpuTenths / 10, procs[i].cpuTenths % 10); c.text(310, y + 3, b, t.text);
                progress(c, Rect{ 350, y + 6, 20, 10 }, procs[i].cpuTenths / 10, t.accent);
                if (procs[i].stackUsed) { sfmt(b, sizeof b, "%d KiB", procs[i].stackUsed / 1024); c.text(380, y + 3, b, t.textDim); } else c.text(380, y + 3, procs[i].state == 2 ? "(running)" : "-", t.textDim);
                addHit(r, PROC + i); y += 24;
            }
            button(c, Rect{ 16, c.h - 40, 120, 28 }, "End process", B_END, false, selPid > 0 && (user_perms() & P_PROCESS));
            c.text(148, c.h - 34, "Tasks use 32 KiB kernel stacks; CPU % is measured per task over the last 2 s.", t.textDim);
        } else if (tab == 2) {
            c.text(16, y, "Application windows", t.textDim); y += 22;
            for (int i = 0; i < wm().count() && y + 30 < c.h - 50; i++) {
                Window* w = wm().at(i); Rect r = { 8, y, c.w - 16, 30 }; bool s = w->id == selWin;
                if (s) c.fillRound(r, 3, t.selection); else if (hoverId == WIN + i) c.fillRound(r, 3, t.panelLight);
                c.icon(w->icon, r.x + 6, r.y + 5, 20); c.textMax(r.x + 36, r.y + 7, w->title, t.text, r.w - 150);
                c.text(r.right() - 100, r.y + 7, w->minimized ? "Minimised" : (w == wm().focused() ? "Active" : "Open"), t.textDim); addHit(r, WIN + i); y += 34;
            }
            button(c, Rect{ 16, c.h - 40, 100, 28 }, "Switch to", B_FOCUS, true, selWin > 0); button(c, Rect{ 124, c.h - 40, 110, 28 }, "Close window", B_CLOSEWIN, false, selWin > 0);
        } else if (tab == 3) {
            c.text(16, y, "Bus   ID         Vendor / Class", t.textDim); y += 22;
            for (int i = scroll; i < pci_count() && y < c.h - 18; i++) {
                const PciDev& d = pci_get(i);
                sfmt(b, sizeof b, "%02x:%02x.%d %04x:%04x", d.bus, d.dev, d.func, d.vendor, d.device); c.text(16, y, b, t.text);
                sfmt(b, sizeof b, "%s - %s", pci_vendor_name(d.vendor), pci_class_name(d)); c.textMax(190, y, b, t.textDim, c.w - 206); y += 20;
            }
            if (pci_count() == 0) c.text(16, y, "No PCI devices enumerated.", t.textDim);
        } else {
            button(c, Rect{ c.w - 130, 38, 120, 26 }, "Run again", B_RUN, true);
            int fail = 0, warn = 0; for (int i = 0; i < ndr; i++) { if (dr[i].status == 2) fail++; else if (dr[i].status == 1) warn++; }
            sfmt(b, sizeof b, "%d checks - %d warnings - %d failures", ndr, warn, fail); c.textB(16, 44, b, fail ? t.danger : t.text); y = 76;
            for (int i = scroll; i < ndr && y < c.h - 20; i++) {
                Color col = dr[i].status == 0 ? t.ok : (dr[i].status == 1 ? t.warn : t.danger);
                c.fillRound(Rect{ 16, y + 1, 44, 16 }, 3, col); c.textB(20, y, diag_status_name(dr[i].status), rgb(255, 255, 255));
                c.text(70, y, dr[i].name, t.text); c.textMax(250, y, dr[i].detail, t.textDim, c.w - 262); y += 22;
            }
        }
    }
};
App* make_monitor() { return new MonitorApp(0); }
App* make_diag() { return new MonitorApp(4); }

} // namespace mx
