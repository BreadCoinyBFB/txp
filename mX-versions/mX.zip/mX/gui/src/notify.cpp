#include "mx/sys.hpp"
#include "mx/hal.hpp"
#include "mx/ui.hpp"
namespace mx {
static Note g_notes[24]; static int g_n = 0;            // g_notes[0] = newest
static constexpr long TOAST_TICKS = 500;                 // 5 s at 100 Hz

void notify(Sev s, const char* app, const char* title, const char* body) {
    for (int i = (g_n < 24 ? g_n : 23); i > 0; i--) g_notes[i] = g_notes[i - 1];
    if (g_n < 24) g_n++;
    Note& n = g_notes[0];
    n.sev = s; scopy(n.app, app, sizeof n.app); scopy(n.title, title, sizeof n.title); scopy(n.body, body, sizeof n.body);
    n.tick = hal_ticks(); n.read = false; n.toastUntil = n.tick + TOAST_TICKS;
    char log[160]; sfmt(log, sizeof log, "[notify] %s: %s - %s\n", app, title, body); hal_log(log);
    ui_invalidate();
}
void notifyf(Sev s, const char* app, const char* title, const char* fmt, ...) {
    char b[100]; va_list ap; va_start(ap, fmt); svfmt(b, sizeof b, fmt, ap); va_end(ap);
    notify(s, app, title, b);
}
int notes_count() { return g_n; }
const Note& notes_at(int i) { return g_notes[i]; }
int notes_unread() { int c = 0; for (int i = 0; i < g_n; i++) if (!g_notes[i].read) c++; return c; }
void notes_mark_all_read() { for (int i = 0; i < g_n; i++) g_notes[i].read = true; ui_invalidate(); }
void notes_clear() { g_n = 0; ui_invalidate(); }
int notes_active_toasts(const Note** out, int max, long now) {
    int c = 0;
    for (int i = 0; i < g_n && c < max; i++) if (g_notes[i].toastUntil > now) out[c++] = &g_notes[i];
    return c;
}
void notes_dismiss_toasts() { for (int i = 0; i < g_n; i++) g_notes[i].toastUntil = 0; ui_invalidate(); }
void notes_rearm_toasts() { long now = hal_ticks(); int k = 0; for (int i = 0; i < g_n && k < 3; i++) if (!g_notes[i].read) { g_notes[i].toastUntil = now + TOAST_TICKS; k++; } ui_invalidate(); }
IconId note_icon(Sev s) { return s == N_ERROR ? IC_ERROR : (s == N_WARN ? IC_WARN : (s == N_OK ? IC_OK : IC_INFO)); }
}
