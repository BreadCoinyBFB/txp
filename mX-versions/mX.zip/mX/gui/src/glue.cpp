// glue.cpp — the seam between the C++ GUI and the cX kernel/shell. Everything exported here uses plain
// `long`/pointer arguments because that is the ABI cxc generates (see docs/STAGE4.md).
#include "mx/desktop.hpp"
#include "mx/apps.hpp"
#include "mx/display.hpp"
#include "mx/recovery.hpp"
#include "mx/net.hpp"
#include "mx/persist.hpp"
#include "mx/pci.hpp"
#include "mx/hal.hpp"
#include "mx/kapi.hpp"
using namespace mx;

extern "C" {
// original VGA text backend (screen.cx, functions renamed screen_* -> vga_*)
void vga_init(void); void vga_clear(void); void vga_set_color(long fg, long bg); void vga_putchar(long c); void vga_backspace(void);
void vga_print(const char* s); void vga_print_hex(long v); void vga_print_dec(long v);
long kbd_read_char(void);
extern void (*__init_array_start[])(void);
extern void (*__init_array_end[])(void);
}

static bool g_gui = false, g_panic = false;
static bool to_term() { return g_gui && !g_panic && term_active(); }

extern "C" {
// ---- screen API used by the shell, routed to the Terminal window while it exists ----
void screen_init(void) { if (!g_gui) vga_init(); }
void screen_clear(void) { if (to_term()) term_clear(); else vga_clear(); }
void screen_set_color(long fg, long bg) { if (to_term()) term_color((int)fg, (int)bg); else vga_set_color(fg, bg); }
void screen_putchar(long c) { if (to_term()) term_putc((char)c); else vga_putchar(c); }
void screen_backspace(void) { if (to_term()) term_backspace(); else vga_backspace(); }
void screen_print(const char* s) { if (to_term()) term_puts(s); else vga_print(s); }
void screen_print_hex(long v) {
    if (!to_term()) { vga_print_hex(v); return; }
    char b[20]; int n = 0; u64 x = (u64)v; do { int d = (int)(x & 15); b[n++] = (char)(d < 10 ? '0' + d : 'A' + d - 10); x >>= 4; } while (x);
    term_puts("0x"); while (n) term_putc(b[--n]);
}
void screen_print_dec(long v) {
    if (!to_term()) { vga_print_dec(v); return; }
    if (v == 0) { term_putc('0'); return; }
    char b[20]; int n = 0; while (v > 0) { b[n++] = (char)('0' + v % 10); v /= 10; } while (n) term_putc(b[--n]);
}
// ---- shell input: the Terminal window's key queue in GUI mode, the raw keyboard ring otherwise ----
long shell_read_char(void) { return (g_gui && term_active()) ? term_read_char() : kbd_read_char(); }

// ---- interrupt hooks (called from keyboard.cx / isr.cx) ----
void gui_key_raw(long code) { input_scancode((u8)code); }
void gui_mouse_irq(void) { mouse_irq(); }
void gui_set_bootinfo(long addr, long w, long h, long pitch, long bpp) { display_set_bootinfo((u64)addr, (int)w, (int)h, (int)pitch, (int)bpp); }
// ---- crash / panic hooks (isr.cx, panic.cx) ----
void gui_emergency(void) {            // give the VGA text console back so the panic text is visible
    if (g_panic) return; g_panic = true;
    if (g_gui) { display_text_mode(); }
}
void gui_note_crash(long vector, long err, long frame_rip) { recovery_note_crash((u8)vector, (u32)err, (u32)frame_rip, "exception"); }
void gui_note_panic(const char* msg) { recovery_note_crash(255, 0, 0, msg); }

// ---- boot entry (init.cx calls this before the text shell) ----
long gui_boot(void) {
    for (void (**f)(void) = __init_array_start; f < __init_array_end; f++) (*f)();   // C++ static constructors
    recovery_boot_begin();
    if (!display_init(800, 600)) {            // no usable framebuffer: stay in text mode (also the Safe Environment)
        hal_log("[gui] no framebuffer driver matched - staying in text mode\n");
        recovery_mark_stable();
        return 0;
    }
    g_gui = true;
    persist_init(); users_init(); apps_register_all(); bool manifestsOk = apps_install_manifests(); apps_scan(); config_load();
    { int ins, insFail, fromVfs, fb; apps_stats(&ins, &insFail, &fromVfs, &fb); int iu, it, bu, bt; fs_usage(&iu, &it, &bu, &bt);
      char l[160]; sfmt(l, sizeof l, "[gui] manifests: installed=%d writeFail=%d scanned=%d builtinFallback=%d | inodes %d/%d blocks %d/%d | dirsOk=%d\n", ins, insFail, fromVfs, fb, iu, it, bu, bt, (int)manifestsOk); hal_log(l);
      if (fb > 0 || !manifestsOk) notifyf(N_WARN, "System", "App manifests unreadable", "wrote %d, read %d, defaults %d. Run Diagnostics.", ins, fromVfs, fb); }
    net_init(); mouse_hw_init(); input_init(800, 600); desktop_init(800, 600);
    if (mouse_present()) notify(N_INFO, "Devices", "Mouse detected", mouse_has_wheel() ? "PS/2 mouse with scroll wheel." : "PS/2 mouse.");
    else notify(N_WARN, "Devices", "No mouse", "Use Ctrl+Alt+arrow keys to move the pointer.");
    if (net_info().present) notifyf(N_INFO, "Devices", "Network adapter", "%s", net_info().name);
    { int w = cfg().resW, h = cfg().resH, sc = cfg().scale, fw = 0, fh = 0, fs = 1;
      if (fwcfg_display_request(&fw, &fh, &fs)) { w = fw; h = fh; sc = fs; cfg().resW = w; cfg().resH = h; cfg().scale = sc; config_save(); hal_log("[gui] display mode requested by QEMU fw_cfg (GUI_MODE)\n"); }
      if ((w != 800 || h != 600 || sc != 1) && !desktop_set_display(w, h, sc, false)) { notifyf(N_WARN, "Display", "Saved resolution unavailable", "%dx%d @%dx isn't supported here; staying at 800x600.", w, h, sc); } }
    if (cfg().kbRate != 11 || cfg().kbDelay != 1) kbd_set_typematic(cfg().kbDelay, cfg().kbRate);
    hal_log("[gui] desktop up\n");
    desktop_run_forever();
    return 1;
}
}
