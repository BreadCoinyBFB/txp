#include "mx/sys.hpp"
#include "mx/input.hpp"
namespace mx {
static Config g_cfg;
Config& cfg() { return g_cfg; }
static const char* CFG_PATH = "/system/config/settings.cfg";

void config_defaults() {
    Config& c = g_cfg; mem_set(&c, 0, sizeof c);
    c.wallpaper = 0; c.accent = 0x3A78E6; c.clock24 = true; c.showSeconds = false; c.desktopIcons = true;
    c.mouseKeys = true; c.mouseSwap = false; c.notifyToasts = true; c.mouseSpeed = 100;
    scopy(c.hostname, "mx-desktop", sizeof c.hostname); c.netMode = 0;
    c.resW = 800; c.resH = 600; c.scale = 1; c.taskbarTop = false; c.taskbarLabels = true; c.taskbarSize = 1; c.iconSize = 1; c.wallColor = 0x203050; c.idleLockMin = 0; c.kbLayout = 0; c.kbDelay = 1; c.kbRate = 11;
    scopy(c.ip, "10.0.2.15", 16); scopy(c.mask, "255.255.255.0", 16); scopy(c.gw, "10.0.2.2", 16); scopy(c.dns, "10.0.2.3", 16);
}
void config_apply() {
    theme_set_accent(rgb((u8)(g_cfg.accent >> 16), (u8)(g_cfg.accent >> 8), (u8)g_cfg.accent));
    mouse_set_speed(g_cfg.mouseSpeed); mouse_set_swap(g_cfg.mouseSwap); mousekeys_enable(g_cfg.mouseKeys); input_set_layout(g_cfg.kbLayout);
}
void config_save() {
    Config& c = g_cfg; char b[500];
    sfmt(b, sizeof b, "wallpaper=%d\naccent=%x\nclock24=%d\nseconds=%d\nicons=%d\nmousekeys=%d\nswap=%d\ntoasts=%d\nspeed=%d\nhost=%s\nnet=%d\nip=%s\nmask=%s\ngw=%s\ndns=%s\nres=%dx%dx%d\ntbtop=%d\ntbsize=%d\ntblabels=%d\nisize=%d\nwallc=%x\nautolock=%d\nkb=%d,%d,%d\n",
         c.wallpaper, c.accent, c.clock24, c.showSeconds, c.desktopIcons, c.mouseKeys, c.mouseSwap, c.notifyToasts, c.mouseSpeed, c.hostname, c.netMode, c.ip, c.mask, c.gw, c.dns,
         c.resW, c.resH, c.scale, c.taskbarTop, c.taskbarSize, c.taskbarLabels, c.iconSize, c.wallColor, c.idleLockMin, c.kbLayout, c.kbDelay, c.kbRate);
    FsSys sys; fs_mkdir_p("/system/config");
    fs_write(CFG_PATH, b, slen(b));
}
static u32 parse_hex(const char* s) { u32 v = 0; for (; *s; s++) { int d = (*s >= '0' && *s <= '9') ? *s - '0' : (*s >= 'a' && *s <= 'f') ? *s - 'a' + 10 : (*s >= 'A' && *s <= 'F') ? *s - 'A' + 10 : -1; if (d < 0) break; v = v * 16 + (u32)d; } return v; }
void config_load() {
    config_defaults();
    char b[512]; int n = 0;
    if (fs_read(CFG_PATH, b, sizeof b, &n)) {
        Config& c = g_cfg; int i = 0;
        while (i < n) {
            char key[16], val[40]; int k = 0, v = 0;
            while (i < n && b[i] != '=' && b[i] != '\n' && k < 15) key[k++] = b[i++]; key[k] = 0;
            if (i < n && b[i] == '=') i++;
            while (i < n && b[i] != '\n' && v < 39) val[v++] = b[i++]; val[v] = 0;
            while (i < n && b[i] != '\n') i++; i++;
            if (seq(key, "wallpaper")) c.wallpaper = clamp(satoi(val), 0, 7);
            else if (seq(key, "accent")) c.accent = parse_hex(val);
            else if (seq(key, "clock24")) c.clock24 = satoi(val) != 0;
            else if (seq(key, "seconds")) c.showSeconds = satoi(val) != 0;
            else if (seq(key, "icons")) c.desktopIcons = satoi(val) != 0;
            else if (seq(key, "mousekeys")) c.mouseKeys = satoi(val) != 0;
            else if (seq(key, "swap")) c.mouseSwap = satoi(val) != 0;
            else if (seq(key, "toasts")) c.notifyToasts = satoi(val) != 0;
            else if (seq(key, "speed")) c.mouseSpeed = clamp(satoi(val), 25, 400);
            else if (seq(key, "host")) scopy(c.hostname, val, sizeof c.hostname);
            else if (seq(key, "net")) c.netMode = satoi(val);
            else if (seq(key, "ip")) scopy(c.ip, val, 16); else if (seq(key, "mask")) scopy(c.mask, val, 16);
            else if (seq(key, "gw")) scopy(c.gw, val, 16); else if (seq(key, "dns")) scopy(c.dns, val, 16);
            else if (seq(key, "res")) { int a = 0, bb = 0, cc = 0, f = 0; const char* p = val; for (; *p; p++) { if (*p == 'x') f++; else if (*p >= '0' && *p <= '9') { if (f == 0) a = a * 10 + (*p - '0'); else if (f == 1) bb = bb * 10 + (*p - '0'); else cc = cc * 10 + (*p - '0'); } } if (a >= 320 && a <= 1024 && bb >= 200 && bb <= 768) { c.resW = a; c.resH = bb; c.scale = cc == 2 ? 2 : 1; } }
            else if (seq(key, "tbtop")) c.taskbarTop = satoi(val) != 0; else if (seq(key, "tbsize")) c.taskbarSize = clamp(satoi(val), 0, 2);
            else if (seq(key, "tblabels")) c.taskbarLabels = satoi(val) != 0; else if (seq(key, "isize")) c.iconSize = clamp(satoi(val), 0, 2);
            else if (seq(key, "wallc")) c.wallColor = parse_hex(val); else if (seq(key, "autolock")) c.idleLockMin = clamp(satoi(val), 0, 120);
            else if (seq(key, "kb")) { int f[3] = { 0, 1, 11 }, q = 0; for (const char* p = val; *p && q < 3; p++) { if (*p == ',') q++; else if (*p >= '0' && *p <= '9') { if (p == val || p[-1] == ',') f[q] = 0; f[q] = f[q] * 10 + (*p - '0'); } } c.kbLayout = clamp(f[0], 0, 2); c.kbDelay = clamp(f[1], 0, 3); c.kbRate = clamp(f[2], 0, 31); }
        }
    }
    config_apply();
}
}
