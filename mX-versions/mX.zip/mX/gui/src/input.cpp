#include "mx/input.hpp"
#include "mx/kapi.hpp"

namespace mx {

// ---------------- rings ----------------
template <class T, int N> struct Ring {
    T buf[N]; volatile u32 head = 0, tail = 0;
    bool push(const T& v) { u32 h = head; u32 n = (h + 1) % N; if (n == tail) return false; buf[h] = v; asm volatile("" ::: "memory"); head = n; return true; }
    bool pop(T& v) { u32 t = tail; if (t == head) return false; v = buf[t]; asm volatile("" ::: "memory"); tail = (t + 1) % N; return true; }
};
static Ring<KeyEvent, 64> g_keys;
static Ring<MouseEvent, 64> g_mouse;

static u8  g_mods = 0;
static bool g_down[256];
static bool g_ext = false;
static int g_sw = 800, g_sh = 600;

// ---------------- keyboard (scancode set 1) ----------------
// Layout tables indexed by scancode (set 1). 0 = US QWERTY, 1 = Dvorak, 2 = Colemak.
static const char SC_NORMAL[3][59] = {
    "\0\0" "1234567890-=" "\0\0" "qwertyuiop[]" "\0\0" "asdfghjkl;'`" "\0" "\\" "zxcvbnm,./" "\0*\0 ",
    "\0\0" "1234567890[]" "\0\0" "',.pyfgcrl/=" "\0\0" "aoeuidhtns-`" "\0" "\\" ";qjkxbmwvz" "\0*\0 ",
    "\0\0" "1234567890-=" "\0\0" "qwfpgjluy;[]" "\0\0" "arstdhneio'`" "\0" "\\" "zxcvbkm,./" "\0*\0 " };
static const char SC_SHIFT[3][59] = {
    "\0\0" "!@#$%^&*()_+" "\0\0" "QWERTYUIOP{}" "\0\0" "ASDFGHJKL:\"~" "\0" "|" "ZXCVBNM<>?" "\0*\0 ",
    "\0\0" "!@#$%^&*(){}" "\0\0" "\"<>PYFGCRL?+" "\0\0" "AOEUIDHTNS_~" "\0" "|" ":QJKXBMWVZ" "\0*\0 ",
    "\0\0" "!@#$%^&*()_+" "\0\0" "QWFPGJLUY:{}" "\0\0" "ARSTDHNEIO\"~" "\0" "|" "ZXCVBKM<>?" "\0*\0 " };
static int g_layout = 0;
void input_set_layout(int l) { g_layout = clamp(l, 0, 2); }
int input_layout() { return g_layout; }

static void push_key(u16 key, u8 ch, bool down, bool repeat) {
    KeyEvent e = { key, ch, g_mods, down, repeat };
    g_keys.push(e);
}
static void mousekeys_key(u16 key, bool down);
static bool g_mousekeys = true;

void input_scancode(u8 raw) {
    if (raw == 0xE0) { g_ext = true; return; }
    if (raw == 0xE1) return;                       // Pause/Break prefix: ignored
    bool down = !(raw & 0x80);
    u8 code = raw & 0x7F;
    bool ext = g_ext; g_ext = false;
    u16 key = K_NONE; u8 ch = 0;

    if (!ext) {
        switch (code) {
        case 0x01: key = K_ESC; break;      case 0x0E: key = K_BACKSPACE; break; case 0x0F: key = K_TAB; break;
        case 0x1C: key = K_ENTER; ch = '\n'; break;
        case 0x1D: key = K_LCTRL; break;    case 0x2A: key = K_LSHIFT; break;   case 0x36: key = K_RSHIFT; break;
        case 0x38: key = K_LALT; break;     case 0x39: key = K_SPACE; ch = ' '; break; case 0x3A: key = K_CAPS; break;
        case 0x57: key = K_F11; break;      case 0x58: key = K_F12; break;
        default:
            if (code >= 0x3B && code <= 0x44) key = (u16)(K_F1 + (code - 0x3B));
            else if (code < 58) {
                bool shift = (g_mods & MOD_SHIFT) != 0;
                char c = shift ? SC_SHIFT[g_layout][code] : SC_NORMAL[g_layout][code];
                bool letter = (SC_NORMAL[g_layout][code] >= 'a' && SC_NORMAL[g_layout][code] <= 'z');
                if (letter && (g_mods & MOD_CAPS)) c = shift ? SC_NORMAL[g_layout][code] : SC_SHIFT[g_layout][code];
                if (c) { key = K_CHAR; ch = (u8)c; }
            }
        }
    } else {
        switch (code) {
        case 0x1D: key = K_RCTRL; break;  case 0x38: key = K_RALT; break;
        case 0x47: key = K_HOME; break;   case 0x48: key = K_UP; break;     case 0x49: key = K_PGUP; break;
        case 0x4B: key = K_LEFT; break;   case 0x4D: key = K_RIGHT; break;  case 0x4F: key = K_END; break;
        case 0x50: key = K_DOWN; break;   case 0x51: key = K_PGDN; break;   case 0x52: key = K_INSERT; break;
        case 0x53: key = K_DELETE; break; case 0x5B: case 0x5C: key = K_SUPER; break;
        case 0x1C: key = K_ENTER; ch = '\n'; break;
        case 0x35: key = K_CHAR; ch = '/'; break;
        }
    }
    if (key == K_NONE) return;

    // modifier tracking
    u8 bit = 0;
    switch (key) {
    case K_LSHIFT: case K_RSHIFT: bit = MOD_SHIFT; break;
    case K_LCTRL: case K_RCTRL: bit = MOD_CTRL; break;
    case K_LALT: case K_RALT: bit = MOD_ALT; break;
    case K_SUPER: bit = MOD_SUPER; break;
    default: break;
    }
    if (bit) {
        if (down) g_mods |= bit; else g_mods &= (u8)~bit;
    }
    if (key == K_CAPS && down && !g_down[(ext ? 128 : 0) + code]) g_mods ^= MOD_CAPS;
    bool repeat = down && g_down[(ext ? 128 : 0) + code];
    g_down[(ext ? 128 : 0) + code] = down;

    if (g_mousekeys && (g_mods & MOD_CTRL) && (g_mods & MOD_ALT)) {
        if (key == K_UP || key == K_DOWN || key == K_LEFT || key == K_RIGHT || key == K_SPACE || key == K_ENTER) {
            mousekeys_key(key, down);
            return;
        }
    }
    push_key(key, ch, down, repeat);
}

bool input_next_key(KeyEvent& e) { return g_keys.pop(e); }
void input_inject_key(const KeyEvent& e) { g_keys.push(e); }
u8 input_mods() { return g_mods; }

// ---------------- mouse ----------------
static int g_mx = 400, g_my = 300;
static u8  g_buttons = 0;
static int g_speed = 100;
static bool g_swap = false, g_present = false, g_wheel = false;
static u8  g_pkt[4]; static int g_pi = 0;

void input_init(int w, int h) { g_sw = w; g_sh = h; g_mx = w / 2; g_my = h / 2; }
void input_set_bounds(int w, int h) { g_sw = w; g_sh = h; g_mx = clamp(g_mx, 0, w - 1); g_my = clamp(g_my, 0, h - 1); }
bool input_next_mouse(MouseEvent& e) { return g_mouse.pop(e); }
void input_inject_mouse(const MouseEvent& e) {
    g_mx = clamp(e.x, 0, g_sw - 1); g_my = clamp(e.y, 0, g_sh - 1);
    MouseEvent m = e; m.x = g_mx; m.y = g_my;
    g_buttons = e.buttons;
    g_mouse.push(m);
}
void mouse_warp(int x, int y) { g_mx = clamp(x, 0, g_sw - 1); g_my = clamp(y, 0, g_sh - 1); }
void mouse_position(int& x, int& y) { x = g_mx; y = g_my; }
bool mouse_present() { return g_present; }
bool mouse_has_wheel() { return g_wheel; }
void mouse_set_speed(int pct) { g_speed = clamp(pct, 25, 400); }
int  mouse_speed() { return g_speed; }
void mouse_set_swap(bool s) { g_swap = s; }
bool mouse_swapped() { return g_swap; }
void mousekeys_enable(bool on) { g_mousekeys = on; }
bool mousekeys_enabled() { return g_mousekeys; }

static void mousekeys_key(u16 key, bool down) {
    int step = (g_mods & MOD_SHIFT) ? 2 : 12;
    MouseEvent m = { g_mx, g_my, 0, 0, 0, g_buttons, 0 };
    if (key == K_SPACE || key == K_ENTER) {
        u8 bit = key == K_SPACE ? 1 : 2;
        u8 nb = down ? (u8)(g_buttons | bit) : (u8)(g_buttons & ~bit);
        m.changed = (u8)(nb ^ g_buttons); m.buttons = nb;
    } else if (down) {
        if (key == K_UP) m.dy = -step; if (key == K_DOWN) m.dy = step;
        if (key == K_LEFT) m.dx = -step; if (key == K_RIGHT) m.dx = step;
    } else return;
    m.x = clamp(g_mx + m.dx, 0, g_sw - 1); m.y = clamp(g_my + m.dy, 0, g_sh - 1);
    g_mx = m.x; g_my = m.y; g_buttons = m.buttons;
    g_mouse.push(m);
}

void mouse_irq() {
    u8 b = inb(0x60);
    if (g_pi == 0 && !(b & 0x08)) return;          // out of sync: first byte always has bit 3 set
    g_pkt[g_pi++] = b;
    int need = g_wheel ? 4 : 3;
    if (g_pi < need) return;
    g_pi = 0;
    u8 f = g_pkt[0];
    if (f & 0xC0) return;                          // overflow: drop packet
    int dx = (int)g_pkt[1] - ((f << 4) & 0x100);
    int dy = (int)g_pkt[2] - ((f << 3) & 0x100);
    int wheel = 0;
    if (g_wheel) { int w = g_pkt[3] & 0x0F; wheel = (w & 8) ? w - 16 : w; }
    dx = dx * g_speed / 100; dy = dy * g_speed / 100;
    if (dx == 0 && (g_pkt[1] != 0)) dx = (int)g_pkt[1] > 127 ? -1 : 1;   // never swallow slow movement entirely
    u8 btn = f & 7;
    if (g_swap) btn = (u8)((btn & 4) | ((btn & 1) << 1) | ((btn & 2) >> 1));
    MouseEvent m;
    m.dx = dx; m.dy = -dy; m.wheel = wheel;
    g_mx = clamp(g_mx + dx, 0, g_sw - 1);
    g_my = clamp(g_my - dy, 0, g_sh - 1);
    m.x = g_mx; m.y = g_my; m.changed = (u8)(btn ^ g_buttons); m.buttons = btn; g_buttons = btn;
    g_mouse.push(m);
}

// ---- PS/2 controller plumbing ----
static bool wait_write() { for (int i = 0; i < 200000; i++) { if (!(inb(0x64) & 2)) return true; } return false; }
static bool wait_read()  { for (int i = 0; i < 200000; i++) { if (inb(0x64) & 1) return true; } return false; }
static bool aux_write(u8 v) {
    if (!wait_write()) return false; outb(0x64, 0xD4);
    if (!wait_write()) return false; outb(0x60, v);
    if (!wait_read()) return false;
    return inb(0x60) == 0xFA;                      // ACK
}
bool kbd_set_typematic(int delay, int rate) {            // PS/2 keyboard command 0xF3: bits 0-4 repeat rate, 5-6 delay
    u64 fl = irq_save(); bool ok = false;
    u8 v = (u8)(((delay & 3) << 5) | (rate & 31));
    if (wait_write()) { outb(0x60, 0xF3); if (wait_read() && inb(0x60) == 0xFA && wait_write()) { outb(0x60, v); ok = wait_read() && inb(0x60) == 0xFA; } }
    irq_restore(fl); return ok;
}
bool mouse_hw_init() {
    u64 fl = irq_save();                           // keyboard IRQ1 must not steal our replies
    bool ok = false;
    if (wait_write()) {
        outb(0x64, 0xA8);                          // enable aux port
        outb(0x64, 0x20); u8 cfg = 0x47;
        if (wait_read()) cfg = inb(0x60);
        cfg |= 0x02; cfg &= (u8)~0x20;             // aux IRQ on, aux clock on
        if (wait_write()) { outb(0x64, 0x60); if (wait_write()) outb(0x60, cfg); }
        while (inb(0x64) & 1) (void)inb(0x60);     // flush
        if (aux_write(0xF6)) {                     // defaults
            // IntelliMouse magic knock: sample rates 200,100,80 then read ID (3 = wheel)
            aux_write(0xF3); aux_write(200); aux_write(0xF3); aux_write(100); aux_write(0xF3); aux_write(80);
            aux_write(0xF2);
            u8 id = 0; if (wait_read()) id = inb(0x60);
            g_wheel = (id == 3);
            aux_write(0xF3); aux_write(100);       // 100 samples/s
            ok = aux_write(0xF4);                  // enable streaming
        }
    }
    g_present = ok; g_pi = 0;
    irq_restore(fl);
    return ok;
}

} // namespace mx
