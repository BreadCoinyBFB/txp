// ata.cpp — minimal ATA PIO (LBA28) driver for the mX data disk. Kernel only.
// Probe order: secondary master, secondary slave, primary slave. PRIMARY MASTER IS NEVER USED: that's the boot disk.
// QEMU: -drive file=XLoader/mxdata.img,format=raw,if=ide,index=2   (make run-gui adds it)
#include "mx/persist.hpp"
#include "mx/kapi.hpp"
namespace mx {

namespace {
struct Chan { u16 io, ctl; };
const Chan CH[2] = { { 0x1F0, 0x3F6 }, { 0x170, 0x376 } };
struct Drive { u16 io, ctl; int drv; bool ok; u32 sectors; char model[41]; };
Drive g_d;

inline void insw(u16 port, void* a, int n) { asm volatile("rep insw" : "+D"(a), "+c"(n) : "d"(port) : "memory"); }
inline void outsw(u16 port, const void* a, int n) { asm volatile("rep outsw" : "+S"(a), "+c"(n) : "d"(port) : "memory"); }
void delay400(u16 ctl) { for (int i = 0; i < 4; i++) (void)inb(ctl); }
bool wait_not_busy(u16 io) { for (int i = 0; i < 400000; i++) { u8 s = inb((u16)(io + 7)); if (!(s & 0x80)) return true; } return false; }
bool wait_drq(u16 io) {
    for (int i = 0; i < 400000; i++) { u8 s = inb((u16)(io + 7)); if (s & 0x01 || s & 0x20) return false; if (!(s & 0x80) && (s & 0x08)) return true; }
    return false;
}
void select(const Drive& d, u32 lba) { outb((u16)(d.io + 6), (u8)(0xE0 | (d.drv << 4) | ((lba >> 24) & 0x0F))); delay400(d.ctl); }

bool ident(u16 io, u16 ctl, int drv, Drive& out) {
    outb(ctl, 0x02);                                          // nIEN: no interrupts, we poll
    outb((u16)(io + 6), (u8)(0xA0 | (drv << 4))); delay400(ctl);
    u8 st = inb((u16)(io + 7)); if (st == 0x00 || st == 0xFF) return false;          // nothing attached / floating bus
    outb((u16)(io + 2), 0); outb((u16)(io + 3), 0); outb((u16)(io + 4), 0); outb((u16)(io + 5), 0);
    outb((u16)(io + 7), 0xEC);                                // IDENTIFY DEVICE
    if (inb((u16)(io + 7)) == 0) return false;
    if (!wait_not_busy(io)) return false;
    if (inb((u16)(io + 4)) || inb((u16)(io + 5))) return false;                       // ATAPI/SATA signature: not a plain ATA disk
    if (!wait_drq(io)) return false;
    u16 id[256]; insw(io, id, 256);
    out.io = io; out.ctl = ctl; out.drv = drv; out.sectors = (u32)id[60] | ((u32)id[61] << 16);
    for (int i = 0; i < 20; i++) { out.model[i * 2] = (char)(id[27 + i] >> 8); out.model[i * 2 + 1] = (char)(id[27 + i] & 0xFF); }
    out.model[40] = 0; for (int i = 39; i >= 0 && (out.model[i] == ' ' || out.model[i] == 0); i--) out.model[i] = 0;
    out.ok = out.sectors >= 2048; return out.ok;
}
bool ata_read(u32 lba, u8* buf) {
    if (!g_d.ok || lba >= g_d.sectors) return false;
    if (!wait_not_busy(g_d.io)) return false;
    select(g_d, lba);
    outb((u16)(g_d.io + 2), 1); outb((u16)(g_d.io + 3), (u8)lba); outb((u16)(g_d.io + 4), (u8)(lba >> 8)); outb((u16)(g_d.io + 5), (u8)(lba >> 16));
    outb((u16)(g_d.io + 7), 0x20);
    delay400(g_d.ctl);
    if (!wait_not_busy(g_d.io) || !wait_drq(g_d.io)) return false;
    insw(g_d.io, buf, 256); return true;
}
bool ata_write(u32 lba, const u8* buf) {
    if (!g_d.ok || lba >= g_d.sectors) return false;
    if (!wait_not_busy(g_d.io)) return false;
    select(g_d, lba);
    outb((u16)(g_d.io + 2), 1); outb((u16)(g_d.io + 3), (u8)lba); outb((u16)(g_d.io + 4), (u8)(lba >> 8)); outb((u16)(g_d.io + 5), (u8)(lba >> 16));
    outb((u16)(g_d.io + 7), 0x30);
    delay400(g_d.ctl);
    if (!wait_not_busy(g_d.io) || !wait_drq(g_d.io)) return false;
    outsw(g_d.io, buf, 256);
    if (!wait_not_busy(g_d.io)) return false;
    outb((u16)(g_d.io + 7), 0xE7);                            // FLUSH CACHE
    return wait_not_busy(g_d.io);
}
}

bool blockdev_probe(BlockDev& out, bool* foreign) {
    struct Cand { int ch, drv; } order[3] = { { 1, 0 }, { 1, 1 }, { 0, 1 } };   // never { 0, 0 }
    for (auto& c : order) {
        Drive d; mem_set(&d, 0, sizeof d);
        if (!ident(CH[c.ch].io, CH[c.ch].ctl, c.drv, d)) continue;
        g_d = d;
        u8 s0[512];
        if (!ata_read(0, s0)) continue;
        bool blank = true, ours = s0[0] == 'm' && s0[1] == 'X' && s0[2] == 'F' && s0[3] == 'S';
        for (int i = 0; i < 512 && blank; i++) if (s0[i] != 0 && s0[i] != 0xFF) blank = false;
        if (!ours && !blank) { if (foreign) *foreign = true; g_d.ok = false; continue; }   // somebody else's data: hands off
        out.present = true; out.sectors = d.sectors; out.read = ata_read; out.write = ata_write;
        sfmt(out.name, sizeof out.name, "%s (%s %s)", d.model[0] ? d.model : "ATA disk", c.ch ? "secondary" : "primary", c.drv ? "slave" : "master");
        return true;
    }
    out.present = false; return false;
}
} // namespace mx
