#include "mx/persist.hpp"
#include "mx/sys.hpp"
#include "mx/kapi.hpp"
#include "mx/hal.hpp"
#include "mx/ui.hpp"
namespace mx {
static inline void ui_invalidate_hook() { ui_invalidate(); }

// ---------------------------------------------------------------- on-disk format
//  LBA 0            superblock  "mXFS" (sector size 512)
//  LBA SLOT_A..     snapshot slot A : [header][16 sectors of inode records][up to 256 data sectors]
//  LBA SLOT_B..     snapshot slot B
constexpr u32 SLOT_SECTORS = 1 + 16 + 256, SLOT_A = 8, SLOT_B = SLOT_A + SLOT_SECTORS, INODE_SECTORS = 16, MIN_SECTORS = SLOT_B + SLOT_SECTORS;
struct __attribute__((packed)) Super { char magic[4]; u32 version, total, slotA, slotB, crc; };
struct __attribute__((packed)) SnapHdr { char magic[4]; u32 seq, nInodes, nBlocks, payloadCrc, hdrCrc; };
struct __attribute__((packed)) Rec { u8 type, nameLen; i16 parent, firstChild, nextSibling, block; u16 size; char name[48]; u8 pad[4]; };   // 64 bytes
static_assert(sizeof(Rec) == 64, "inode record must be 64 bytes");

static BlockDev g_dev; static PersistInfo g_pi; static bool g_foreign = false;
static u32 g_lastFp = 0; static bool g_haveFp = false; static long g_lastChange = 0; static u32 g_pendingFp = 0; static bool g_failNotified = false;

u32 crc32(const void* data, size_t len, u32 seed) {
    static u32 table[256]; static bool init = false;
    if (!init) { for (u32 i = 0; i < 256; i++) { u32 c = i; for (int k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1; table[i] = c; } init = true; }
    u32 c = ~seed; const u8* p = (const u8*)data;
    for (size_t i = 0; i < len; i++) c = table[(c ^ p[i]) & 0xFF] ^ (c >> 8);
    return ~c;
}
const PersistInfo& persist_info() { return g_pi; }

static void describe() {
    if (!g_pi.present) scopy(g_pi.status, g_foreign ? "A disk was found but it holds someone else's data - not touching it. Files are lost at shutdown." : "No data disk attached - files are lost at shutdown. (make run-gui adds one.)", sizeof g_pi.status);
    else if (!g_pi.lastSaveOk && g_pi.seq == 0 && !g_pi.restored) sfmt(g_pi.status, sizeof g_pi.status, "%s: ready, nothing saved yet", g_pi.device);
    else sfmt(g_pi.status, sizeof g_pi.status, "%s: %s, snapshot #%u in slot %c, %d files", g_pi.device, g_pi.lastSaveOk ? "saved" : "SAVE FAILED", g_pi.seq, g_pi.slot ? 'B' : 'A', g_pi.lastFiles);
}

// ---------------------------------------------------------------- fingerprint (dirty detection, also catches shell changes)
static u32 fingerprint() {
    u32 h = 2166136261u;
    auto mix = [&](const void* d, size_t n) { const u8* p = (const u8*)d; for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 16777619u; } };
    for (int i = 0; i < VFS_MAX_INODES; i++) {
        const Inode& n = inode_table[i]; mix(&n.inode_type, 4);
        if (n.inode_type == INODE_FREE) continue;
        mix(&n.parent, 4); mix(&n.first_child, 4); mix(&n.next_sibling, 4); mix(&n.size, 4); if (n.name) mix(n.name, (size_t)slen(n.name));
        if (n.block != -1 && n.size > 0) { char b[VFS_BLOCK_SIZE]; storage_read_block(n.block, b); mix(b, (size_t)min(n.size, VFS_BLOCK_SIZE)); }
    }
    return h;
}

// ---------------------------------------------------------------- save
static bool write_sector(u32 lba, const void* d) { return g_dev.write(lba, (const u8*)d); }
static bool do_save() {
    if (!g_pi.mounted) return false;
    int slot = g_pi.seq == 0 ? 0 : 1 - g_pi.slot; u32 base = slot ? SLOT_B : SLOT_A;
    // compact block numbering
    static i16 newBlock[VFS_MAX_INODES]; int nb = 0, files = 0, nInodes = 0;
    for (int i = 0; i < VFS_MAX_INODES; i++) { newBlock[i] = -1; if (inode_table[i].inode_type == INODE_FREE) continue; nInodes++; if (inode_table[i].inode_type == INODE_FILE) files++; if (inode_table[i].block != -1) newBlock[i] = (i16)nb++; }
    u8 inoBuf[INODE_SECTORS * 512]; mem_set(inoBuf, 0, sizeof inoBuf); Rec* rec = (Rec*)inoBuf;
    for (int i = 0; i < VFS_MAX_INODES; i++) {
        const Inode& n = inode_table[i]; Rec& r = rec[i]; r.type = (u8)n.inode_type; r.parent = -1; r.firstChild = -1; r.nextSibling = -1; r.block = -1;
        if (n.inode_type == INODE_FREE) continue;
        r.parent = (i16)n.parent; r.firstChild = (i16)n.first_child; r.nextSibling = (i16)n.next_sibling; r.block = newBlock[i]; r.size = (u16)n.size;
        r.nameLen = (u8)min(slen(n.name), 47); mem_cpy(r.name, n.name, r.nameLen);
    }
    u32 crc = crc32(inoBuf, sizeof inoBuf);
    for (u32 s = 0; s < INODE_SECTORS; s++) if (!write_sector(base + 1 + s, inoBuf + s * 512)) return false;
    for (int i = 0; i < VFS_MAX_INODES; i++) if (newBlock[i] != -1) {
        char b[VFS_BLOCK_SIZE]; storage_read_block(inode_table[i].block, b);
        crc = crc32(b, 512, crc);
        if (!write_sector(base + 1 + INODE_SECTORS + (u32)newBlock[i], b)) return false;
    }
    SnapHdr h; mem_set(&h, 0, sizeof h); mem_cpy(h.magic, "mXSN", 4); h.seq = g_pi.seq + 1; h.nInodes = (u32)nInodes; h.nBlocks = (u32)nb; h.payloadCrc = crc; h.hdrCrc = crc32(&h, sizeof h - 4);
    u8 sec[512]; mem_set(sec, 0, 512); mem_cpy(sec, &h, sizeof h);
    if (!write_sector(base, sec)) return false;               // header LAST: a torn save leaves this slot invalid, the other one intact
    g_pi.seq = h.seq; g_pi.slot = slot; g_pi.lastFiles = files; g_pi.lastBlocks = nb; g_pi.lastSaveTick = hal_ticks();
    return true;
}
bool persist_force_save() {
    if (!g_pi.present || !g_pi.mounted) return false;
    u32 fp = fingerprint();
    bool ok = do_save(); g_pi.lastSaveOk = ok;
    if (ok) { g_lastFp = fp; g_haveFp = true; g_failNotified = false; }
    else if (!g_failNotified) { g_failNotified = true; notify(N_ERROR, "Storage", "Couldn't save to disk", "Your changes are still in memory. Check the data disk."); }
    describe(); ui_invalidate_hook(); return ok;
}
bool persist_flush() { if (!g_pi.present || !g_pi.mounted) return false; if (g_haveFp && fingerprint() == g_lastFp) return true; return persist_force_save(); }
void persist_tick(long now) {
    static long next = 0; if (now < next || !g_pi.present || !g_pi.mounted) return; next = now + 100;      // look once a second
    u32 fp = fingerprint();
    if (!g_haveFp) { g_lastFp = fp; g_haveFp = true; return; }
    if (fp == g_lastFp) { g_pendingFp = fp; return; }
    if (fp != g_pendingFp) { g_pendingFp = fp; g_lastChange = now; return; }                 // still changing: wait
    if (now - g_lastChange >= 300) persist_force_save();                                     // quiet for ~3 s: save
}

// ---------------------------------------------------------------- restore
static bool read_header(u32 base, SnapHdr& h) {
    u8 sec[512]; if (!g_dev.read(base, sec)) return false; mem_cpy(&h, sec, sizeof h);
    return mem_cmp(h.magic, "mXSN", 4) == 0 && h.hdrCrc == crc32(&h, sizeof h - 4) && h.nInodes <= (u32)VFS_MAX_INODES && h.nBlocks <= 256;
}
static bool payload_ok(u32 base, const SnapHdr& h) {
    u8 sec[512]; u32 crc = 0;
    for (u32 s = 0; s < INODE_SECTORS + h.nBlocks; s++) { if (!g_dev.read(base + 1 + s, sec)) return false; crc = crc32(sec, 512, crc); }
    return crc == h.payloadCrc;
}
static bool apply(u32 base, const SnapHdr& h) {
    u8 inoBuf[INODE_SECTORS * 512];
    for (u32 s = 0; s < INODE_SECTORS; s++) if (!g_dev.read(base + 1 + s, inoBuf + s * 512)) return false;
    const Rec* rec = (const Rec*)inoBuf;
    for (int i = 0; i < VFS_MAX_INODES; i++) {                                               // validate before touching the live VFS
        const Rec& r = rec[i]; if (r.type == 0) continue;
        if (r.type > 2 || r.nameLen > 47 || r.parent < -1 || r.parent >= VFS_MAX_INODES || r.firstChild < -1 || r.firstChild >= VFS_MAX_INODES || r.nextSibling < -1 || r.nextSibling >= VFS_MAX_INODES || r.block >= (i16)h.nBlocks) return false;
    }
    if (rec[0].type != INODE_DIR) return false;
    for (int i = 1; i < VFS_MAX_INODES; i++) { inode_table[i].inode_type = INODE_FREE; inode_table[i].first_child = -1; inode_table[i].next_sibling = -1; inode_table[i].parent = -1; inode_table[i].block = -1; inode_table[i].size = 0; }
    inode_table[0].first_child = rec[0].firstChild; inode_table[0].next_sibling = -1;
    for (int i = 1; i < VFS_MAX_INODES; i++) {
        const Rec& r = rec[i]; if (r.type == 0) continue;
        Inode& n = inode_table[i]; char* nm = (char*)kmalloc(r.nameLen + 1); if (!nm) return false;
        mem_cpy(nm, r.name, r.nameLen); nm[r.nameLen] = 0;
        n.inode_type = r.type; n.name = nm; n.parent = r.parent; n.first_child = r.firstChild; n.next_sibling = r.nextSibling; n.size = r.size; n.block = -1;
        if (r.block >= 0) {
            long b = storage_alloc_block(); if (b < 0) return false;
            char buf[VFS_BLOCK_SIZE]; if (!g_dev.read(base + 1 + INODE_SECTORS + (u32)r.block, (u8*)buf)) return false;
            storage_write_block(b, buf); n.block = (i32)b;
        }
    }
    return true;
}

void persist_init() {
    mem_set(&g_pi, 0, sizeof g_pi); mem_set(&g_dev, 0, sizeof g_dev); g_foreign = false; g_haveFp = false;
    if (!blockdev_probe(g_dev, &g_foreign) || !g_dev.present || g_dev.sectors < MIN_SECTORS) { g_pi.present = false; g_dev.present = false; describe(); return; }
    g_pi.present = true; scopy(g_pi.device, g_dev.name, sizeof g_pi.device); g_pi.sectors = g_dev.sectors;
    u8 sec[512]; Super sb;
    if (!g_dev.read(0, sec)) { g_pi.present = false; describe(); return; }
    mem_cpy(&sb, sec, sizeof sb);
    if (mem_cmp(sb.magic, "mXFS", 4) != 0 || sb.crc != crc32(&sb, sizeof sb - 4)) {          // blank disk: format it
        mem_set(&sb, 0, sizeof sb); mem_cpy(sb.magic, "mXFS", 4); sb.version = 1; sb.total = g_dev.sectors; sb.slotA = SLOT_A; sb.slotB = SLOT_B; sb.crc = crc32(&sb, sizeof sb - 4);
        mem_set(sec, 0, 512); mem_cpy(sec, &sb, sizeof sb);
        u8 zero[512]; mem_set(zero, 0, 512);
        if (!g_dev.write(0, sec) || !g_dev.write(SLOT_A, zero) || !g_dev.write(SLOT_B, zero)) { g_pi.present = false; describe(); return; }
        g_pi.mounted = true; describe(); return;
    }
    g_pi.mounted = true;
    SnapHdr ha, hb; bool va = read_header(SLOT_A, ha) && payload_ok(SLOT_A, ha), vb = read_header(SLOT_B, hb) && payload_ok(SLOT_B, hb);
    int pick = -1; if (va && vb) pick = hb.seq > ha.seq ? 1 : 0; else if (va) pick = 0; else if (vb) pick = 1;
    if (pick < 0) { describe(); return; }                                                   // formatted but empty (first boot) - or both slots damaged
    const SnapHdr& h = pick ? hb : ha;
    if (!apply(pick ? SLOT_B : SLOT_A, h)) {                                                // apply() validates first, so a bad slot rarely half-applies
        SnapHdr& other = pick ? ha : hb; bool ov = pick ? va : vb;
        if (!(ov && apply(pick ? SLOT_A : SLOT_B, other))) { notify(N_ERROR, "Storage", "Saved files could not be restored", "The snapshot on the data disk is damaged; starting empty."); describe(); return; }
        pick = 1 - pick;
    }
    g_pi.seq = (pick ? hb : ha).seq; g_pi.slot = pick; g_pi.restored = true; g_pi.lastSaveOk = true;
    int files = 0; for (int i = 0; i < VFS_MAX_INODES; i++) if (inode_table[i].inode_type == INODE_FILE) files++;
    g_pi.lastFiles = files; g_pi.lastBlocks = (int)(pick ? hb : ha).nBlocks;
    g_lastFp = fingerprint(); g_haveFp = true; g_pendingFp = g_lastFp;
    describe();
}
} // namespace mx
