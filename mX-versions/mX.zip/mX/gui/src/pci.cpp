// pci.cpp — PCI configuration mechanism #1 (ports 0xCF8/0xCFC). Enough to find the
// Bochs/QEMU VGA adapter (framebuffer BAR) and network cards.
#include "mx/pci.hpp"
#include "mx/kapi.hpp"
namespace mx {

static PciDev g_dev[PCI_MAX];
static int g_n = 0;

u32 pci_read32(u8 b, u8 d, u8 f, u8 off) {
    outl(0xCF8, 0x80000000u | ((u32)b << 16) | ((u32)d << 11) | ((u32)f << 8) | (off & 0xFC));
    return inl(0xCFC);
}
void pci_write32(u8 b, u8 d, u8 f, u8 off, u32 v) {
    outl(0xCF8, 0x80000000u | ((u32)b << 16) | ((u32)d << 11) | ((u32)f << 8) | (off & 0xFC));
    outl(0xCFC, v);
}
int pci_scan() {
    g_n = 0;
    for (int b = 0; b < 8; b++)
        for (int d = 0; d < 32; d++) {
            u32 id = pci_read32((u8)b, (u8)d, 0, 0);
            if ((id & 0xFFFF) == 0xFFFF) continue;
            u32 hdr = pci_read32((u8)b, (u8)d, 0, 0x0C);
            int nf = (hdr & 0x800000) ? 8 : 1;
            for (int f = 0; f < nf && g_n < PCI_MAX; f++) {
                id = pci_read32((u8)b, (u8)d, (u8)f, 0);
                if ((id & 0xFFFF) == 0xFFFF) continue;
                PciDev& p = g_dev[g_n++];
                p.bus = (u8)b; p.dev = (u8)d; p.func = (u8)f;
                p.vendor = (u16)(id & 0xFFFF); p.device = (u16)(id >> 16);
                u32 cl = pci_read32((u8)b, (u8)d, (u8)f, 0x08);
                p.cls = (u8)(cl >> 24); p.sub = (u8)(cl >> 16); p.prog = (u8)(cl >> 8);
                p.irq = (u8)(pci_read32((u8)b, (u8)d, (u8)f, 0x3C) & 0xFF);
                for (int i = 0; i < 6; i++) p.bar[i] = pci_read32((u8)b, (u8)d, (u8)f, (u8)(0x10 + 4 * i));
            }
        }
    return g_n;
}
int pci_count() { return g_n; }
const PciDev& pci_get(int i) { return g_dev[i]; }
void pci_enable(const PciDev& d, bool busmaster) {
    u32 cmd = pci_read32(d.bus, d.dev, d.func, 0x04);
    cmd |= 0x3; if (busmaster) cmd |= 0x4;
    pci_write32(d.bus, d.dev, d.func, 0x04, cmd);
}
const PciDev* pci_find(u16 v, u16 dv) {
    for (int i = 0; i < g_n; i++) if (g_dev[i].vendor == v && g_dev[i].device == dv) return &g_dev[i];
    return nullptr;
}
const char* pci_vendor_name(u16 v) {
    switch (v) {
    case 0x8086: return "Intel"; case 0x1234: return "QEMU/Bochs"; case 0x10EC: return "Realtek";
    case 0x1AF4: return "Red Hat (virtio)"; case 0x15AD: return "VMware"; case 0x80EE: return "VirtualBox";
    case 0x1022: return "AMD"; case 0x10DE: return "NVIDIA"; case 0x1B36: return "Red Hat (QEMU)"; default: return "Unknown vendor";
    }
}
const char* pci_class_name(const PciDev& d) {
    switch (d.cls) {
    case 0x01: return d.sub == 0x01 ? "IDE controller" : (d.sub == 0x06 ? "SATA controller" : "Storage controller");
    case 0x02: return "Network adapter";
    case 0x03: return "Display adapter";
    case 0x04: return "Multimedia device";
    case 0x06: return d.sub == 0x00 ? "Host bridge" : (d.sub == 0x01 ? "ISA bridge" : "PCI bridge");
    case 0x0C: return d.sub == 0x03 ? "USB controller" : "Serial bus controller";
    default: return "Other device";
    }
}
} // namespace mx
