// appcenter.cpp — mX Application Center: browse installed applications, see versions / permissions / details,
// launch, pin to the desktop, and uninstall (or reinstall) the ones that aren't core system apps.
#include "mx/apps.hpp"
#include "mx/wm.hpp"
namespace mx {

static const struct { u32 bit; const char* name; const char* what; } PERMS[] = {
    { P_FILES_ALL, "files", "Read and write shared files, and open other users' folders if you're an administrator" },
    { P_FILES_SYSTEM, "system-files", "Write to the protected /system folder" },
    { P_SETTINGS_READ, "settings-read", "See system settings" },
    { P_SETTINGS_WRITE, "settings", "Change system settings" },
    { P_NETWORK, "network", "Use the network (ping, DNS, TCP)" },
    { P_NOTIFY, "notify", "Show notifications" },
    { P_ADMIN, "admin", "Administrator-only actions" },
    { P_PROCESS, "process", "Start and stop processes" },
    { P_TERMINAL, "terminal", "Run shell commands" },
    { P_USERS, "users", "Manage user accounts" },
    { P_SYSMON, "sysmon", "See system and process information" },
    { P_RECOVERY, "recovery", "Reset settings and accounts, enter safe mode" } };

struct AppCenterApp : App {
    enum { B_OPEN = 1, B_PIN, B_UNINSTALL, B_CLOSE, B_INSTALL, LIST = 100, REMOVED = 200 };
    char sel[16] = ""; bool selRemoved = false; int listScroll = 0;
    const char* removedIds[10]; const char* removedNames[10]; int nRemoved = 0;
    void windowSpec(WindowSpec& s) override { s.title = "App Center"; s.frame = Rect{ 70, 36, 690, 440 }; s.flags = WF_RESIZABLE; s.minW = 560; s.minH = 340; }
    void onCreate() override { if (apps_count() > 0) scopy(sel, apps_at(0)->id, sizeof sel); refresh(); }
    void refresh() { nRemoved = apps_removed(removedIds, removedNames, 10); if (!selRemoved && !apps_find(sel) && apps_count() > 0) scopy(sel, apps_at(0)->id, sizeof sel); invalidate(); }
    void onTick(long) override { static int k = 0; if (++k % 10 == 0) invalidate(); }                 // running state
    void onMouse(const UiMouse& m) override { if (m.kind == UiMouse::Wheel && m.x < 220) { listScroll = clamp(listScroll - m.wheel * 30, 0, max(0, (apps_count() + nRemoved) * 40 + 60 - ch)); invalidate(); } }
    void onDialog(int tag, bool ok, const char*) override {
        if (tag == B_UNINSTALL && ok) {
            if (apps_uninstall(sel)) { notifyf(N_OK, "App Center", "Uninstalled", "The application was removed. You can reinstall it here."); } else notify(N_ERROR, "App Center", "Couldn't uninstall", "Core apps can't be removed, and only administrators may uninstall.");
            refresh();
        }
    }
    void onAction(int id, int) override {
        if (id >= LIST && id < LIST + APPS_MAX) { const AppManifest* m = apps_at(id - LIST); if (m) { scopy(sel, m->id, sizeof sel); selRemoved = false; invalidate(); } return; }
        if (id >= REMOVED && id < REMOVED + 10) { if (id - REMOVED < nRemoved) { scopy(sel, removedIds[id - REMOVED], sizeof sel); selRemoved = true; invalidate(); } return; }
        if (id == B_OPEN) app_launch(sel);
        else if (id == B_PIN) { const AppManifest* m = apps_find(sel); if (m && !apps_set_desktop(sel, !m->desktop)) notify(N_ERROR, "App Center", "Couldn't update", "The manifest could not be rewritten."); }
        else if (id == B_CLOSE) app_close_all(sel);
        else if (id == B_UNINSTALL) { const AppManifest* m = apps_find(sel); if (!m) return; char t[80]; sfmt(t, sizeof t, "Uninstall \"%s\"?", m->name); dialog_confirm(this, B_UNINSTALL, "Uninstall", t); }
        else if (id == B_INSTALL) { if (apps_install(sel)) { selRemoved = false; notify(N_OK, "App Center", "Installed", "The application is back."); } else notify(N_ERROR, "App Center", "Couldn't install", "Only administrators can install applications."); refresh(); }
        refresh();
    }
    void onPaint(Canvas& c) override {
        Theme& t = theme(); beginPaint(c);
        int lw = 220; c.fill(Rect{ 0, 0, lw, c.h }, t.panel); c.vline(lw, 0, c.h, t.panelDark);
        c.textB(12, 10, "Installed", t.text); char cnt[24]; sfmt(cnt, sizeof cnt, "%d", apps_count()); c.text(lw - 12 - c.textWidth(cnt), 10, cnt, t.textDim);
        int y = 34 - listScroll;
        for (int i = 0; i < apps_count() && y < c.h; i++) {
            const AppManifest* m = apps_at(i); Rect r = { 6, y, lw - 12, 36 }; bool s = !selRemoved && seq(m->id, sel);
            if (s) c.fillRound(r, 4, t.accent); else if (hoverId == LIST + i) c.fillRound(r, 4, t.panelLight);
            c.icon(m->icon, r.x + 6, r.y + 6, 24); c.textMax(r.x + 38, r.y + 3, m->name, s ? t.textOnAccent : t.text, r.w - 44, true);
            char v[40]; sfmt(v, sizeof v, "v%s%s", m->version, app_running(m->id) ? "  - running" : ""); c.text(r.x + 38, r.y + 18, v, s ? blend(t.textOnAccent, t.accent, 200) : t.textDim);
            addHit(r, LIST + i); y += 40;
        }
        if (nRemoved > 0) {
            y += 6; c.textB(12, y, "Available to install", t.text); y += 24;
            for (int j = 0; j < nRemoved && y + 30 < c.h; j++) {
                Rect r = { 6, y, lw - 12, 30 }; bool s = selRemoved && seq(removedIds[j], sel);
                if (s) c.fillRound(r, 4, t.accent); else if (hoverId == REMOVED + j) c.fillRound(r, 4, t.panelLight);
                c.text(r.x + 10, r.y + 7, removedNames[j], s ? t.textOnAccent : t.textDim); addHit(r, REMOVED + j); y += 34;
            }
        }
        // ---- details ----
        int x = lw + 20; int dw = c.w - lw - 40;
        if (selRemoved) {
            c.textB(x, 20, "Not installed", t.text); c.text(x, 44, "This built-in application was uninstalled.", t.textDim);
            button(c, Rect{ x, 76, 120, 30 }, "Install", B_INSTALL, true, (user_perms() & P_ADMIN) != 0); return;
        }
        const AppManifest* m = apps_find(sel); if (!m) { c.text(x, 24, "Select an application.", t.textDim); return; }
        c.icon(m->icon, x, 18, 56); c.textB(x + 70, 22, m->name, t.text); c.text(x + 2 + 70, 44, "Version ", t.textDim); c.text(x + 70 + c.textWidth("Version "), 44, m->version, t.text);
        bool running = app_running(m->id); c.text(x + 70, 62, running ? "Running" : "Not running", running ? t.ok : t.textDim);
        int by = 92; u32 have = user_perms(); bool can = (have & m->perms) == m->perms;
        button(c, Rect{ x, by, 86, 28 }, "Open", B_OPEN, true, can);
        button(c, Rect{ x + 94, by, 130, 28 }, m->desktop ? "Unpin from desktop" : "Pin to desktop", B_PIN);
        button(c, Rect{ x + 232, by, 76, 28 }, "Close", B_CLOSE, false, running);
        button(c, Rect{ x + 316, by, 92, 28 }, "Uninstall", B_UNINSTALL, false, !m->core && (have & P_ADMIN));
        int y2 = by + 44;
        if (!can) { c.fillRound(Rect{ x, y2, dw, 22 }, 3, blend(t.warn, t.window, 60)); c.text(x + 8, y2 + 3, "Your account doesn't have the permissions this app needs.", t.text); y2 += 30; }
        if (m->core) { c.text(x, y2, "Core system app - it can't be uninstalled.", t.textDim); y2 += 24; }
        c.textB(x, y2, "Details", t.text); y2 += 24;
        auto row = [&](const char* k, const char* v) { c.text(x, y2, k, t.textDim); c.textMax(x + 100, y2, v, t.text, dw - 100); y2 += 20; };
        row("Identifier", m->id); row("Runs from", m->exec); row("Resources", m->resources); row("Instances", m->singleton ? "One at a time" : "Several windows allowed");
        row("Manifest", "/system/apps/*.mxapp");
        y2 += 8; c.textB(x, y2, "Permissions", t.text); y2 += 24;
        bool any = false;
        for (auto& p : PERMS) if (m->perms & p.bit) {
            any = true; bool ok = (have & p.bit) != 0; c.icon(ok ? IC_OK : IC_WARN, x, y2 - 1, 14); c.textB(x + 20, y2, p.name, t.text); c.textMax(x + 112, y2, p.what, t.textDim, dw - 112); y2 += 20;
            if (y2 > c.h - 20) break;
        }
        if (!any) c.text(x, y2, "No special permissions.", t.textDim);
    }
};
App* make_appcenter() { return new AppCenterApp(); }

} // namespace mx
