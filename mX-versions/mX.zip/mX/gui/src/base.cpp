#include "mx/base.hpp"
namespace mx {

int slen(const char* s) { int n = 0; while (s[n]) n++; return n; }
int scmp(const char* a, const char* b) {
    while (*a && *a == *b) { a++; b++; }
    return (int)(u8)*a - (int)(u8)*b;
}
bool seq(const char* a, const char* b) { return scmp(a, b) == 0; }
bool sstarts(const char* s, const char* p) { while (*p) { if (*s++ != *p++) return false; } return true; }
int scopy(char* d, const char* s, int cap) {
    if (cap <= 0) return 0;
    int i = 0;
    while (s[i] && i < cap - 1) { d[i] = s[i]; i++; }
    d[i] = 0;
    return i;
}
int scat(char* d, const char* s, int cap) {
    int n = slen(d);
    if (n >= cap - 1) return n;
    return n + scopy(d + n, s, cap - n);
}
char lower(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
bool streq_nocase(const char* a, const char* b) {
    while (*a && *b) { if (lower(*a) != lower(*b)) return false; a++; b++; }
    return *a == *b;
}
int satoi(const char* s) {
    int sign = 1, v = 0;
    while (*s == ' ') s++;
    if (*s == '-') { sign = -1; s++; }
    while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; }
    return v * sign;
}

void* mem_set(void* p, int v, size_t n) { u8* b = (u8*)p; while (n--) *b++ = (u8)v; return p; }
void* mem_cpy(void* d, const void* s, size_t n) { u8* a = (u8*)d; const u8* b = (const u8*)s; while (n--) *a++ = *b++; return d; }
int mem_cmp(const void* a, const void* b, size_t n) {
    const u8* x = (const u8*)a; const u8* y = (const u8*)b;
    while (n--) { if (*x != *y) return (int)*x - (int)*y; x++; y++; }
    return 0;
}

namespace {
struct Out { char* p; int cap; int n; void put(char c) { if (n < cap - 1) p[n] = c; n++; } };
void put_num(Out& o, u64 v, int base, int width, bool zero, bool neg) {
    char tmp[24]; int t = 0;
    if (v == 0) tmp[t++] = '0';
    while (v) { int d = (int)(v % (u64)base); tmp[t++] = (char)(d < 10 ? '0' + d : 'a' + d - 10); v /= (u64)base; }
    int total = t + (neg ? 1 : 0);
    if (neg && zero) o.put('-');
    for (int i = total; i < width; i++) o.put(zero ? '0' : ' ');
    if (neg && !zero) o.put('-');
    while (t) o.put(tmp[--t]);
}
}

int svfmt(char* out, int cap, const char* f, va_list ap) {
    Out o = { out, cap, 0 };
    while (*f) {
        if (*f != '%') { o.put(*f++); continue; }
        f++;
        bool zero = false; int width = 0; bool lng = false;
        if (*f == '0') { zero = true; f++; }
        while (*f >= '0' && *f <= '9') { width = width * 10 + (*f - '0'); f++; }
        if (*f == 'l') { lng = true; f++; if (*f == 'l') f++; }
        char c = *f ? *f++ : 0;
        switch (c) {
        case 's': { const char* s = va_arg(ap, const char*); if (!s) s = "(null)";
                    int l = slen(s); for (int i = l; i < width; i++) o.put(' '); while (*s) o.put(*s++); break; }
        case 'd': { i64 v = lng ? va_arg(ap, i64) : (i64)va_arg(ap, int);
                    bool neg = v < 0; put_num(o, neg ? (u64)(-v) : (u64)v, 10, width, zero, neg); break; }
        case 'u': { u64 v = lng ? va_arg(ap, u64) : (u64)va_arg(ap, unsigned); put_num(o, v, 10, width, zero, false); break; }
        case 'x': { u64 v = lng ? va_arg(ap, u64) : (u64)va_arg(ap, unsigned); put_num(o, v, 16, width, zero, false); break; }
        case 'c': o.put((char)va_arg(ap, int)); break;
        case '%': o.put('%'); break;
        default: o.put('%'); if (c) o.put(c); break;
        }
    }
    if (cap > 0) out[o.n < cap ? o.n : cap - 1] = 0;
    return o.n < cap ? o.n : cap - 1;
}
int sfmt(char* out, int cap, const char* fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int n = svfmt(out, cap, fmt, ap);
    va_end(ap);
    return n;
}

} // namespace mx
