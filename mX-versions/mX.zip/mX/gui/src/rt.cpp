// rt.cpp — the tiny C++ runtime a freestanding kernel needs: the mem* functions GCC may emit calls to,
// operator new/delete on top of Kernel24's heap, and the pure-virtual trap. No exceptions, no RTTI,
// no static constructors anywhere in the GUI (globals are plain data initialised by init functions).
#include "mx/kapi.hpp"
// These are written with `rep` string instructions on purpose: an ordinary C loop in memset()/memcpy() can be
// "optimised" by the compiler back into a call to memset()/memcpy() — i.e. infinite recursion — and loops in
// memcmp()/strlen() can become bcmp()/strlen() calls. Inline asm cannot be pattern-matched.
extern "C" {
void* memset(void* d, int v, size_t n) { void* r = d; asm volatile("rep stosb" : "+D"(d), "+c"(n) : "a"(v) : "memory"); return r; }
void* memcpy(void* d, const void* s, size_t n) { void* r = d; asm volatile("rep movsb" : "+D"(d), "+S"(s), "+c"(n) : : "memory"); return r; }
void* memmove(void* d, const void* s, size_t n) {
    void* r = d;
    if ((uintptr_t)d <= (uintptr_t)s || (uintptr_t)d >= (uintptr_t)s + n) asm volatile("rep movsb" : "+D"(d), "+S"(s), "+c"(n) : : "memory");
    else { d = (char*)d + n - 1; s = (const char*)s + n - 1; asm volatile("std; rep movsb; cld" : "+D"(d), "+S"(s), "+c"(n) : : "memory"); }
    return r;
}
int memcmp(const void* x, const void* y, size_t n) {
    const unsigned char* a = (const unsigned char*)x; const unsigned char* b = (const unsigned char*)y;
    for (size_t i = 0; i < n; i++) { asm volatile("" ::: "memory"); if (a[i] != b[i]) return (int)a[i] - (int)b[i]; }
    return 0;
}
int bcmp(const void* x, const void* y, size_t n) { return memcmp(x, y, n); }
size_t strlen(const char* s) { size_t n = ~(size_t)0; const char* p = s; asm volatile("repne scasb" : "+D"(p), "+c"(n) : "a"(0) : "memory", "cc"); return (size_t)(p - s - 1); }
void __cxa_pure_virtual() { asm volatile("cli; hlt"); for (;;) {} }
}
void* operator new(size_t n) { void* p = (void*)kmalloc((long)n); if (p) { unsigned char* b = (unsigned char*)p; for (size_t i = 0; i < n; i++) b[i] = 0; } return p; }
void* operator new[](size_t n) { return operator new(n); }
void operator delete(void* p) noexcept { if (p) kfree((long)p); }
void operator delete(void* p, size_t) noexcept { if (p) kfree((long)p); }
void operator delete[](void* p) noexcept { if (p) kfree((long)p); }
void operator delete[](void* p, size_t) noexcept { if (p) kfree((long)p); }
