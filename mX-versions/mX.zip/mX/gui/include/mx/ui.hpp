// ui.hpp — the application framework: App base class, Window, immediate-mode widget helpers.
//
// Apps paint in onPaint(); every clickable thing is registered as a "hit region" while painting
// (button(), addHit()), and the framework turns a completed click on a region into onAction(id).
// That keeps event handling out of the paint path, so an action may freely open/close windows.
#pragma once
#include "mx/base.hpp"
#include "mx/gfx.hpp"
#include "mx/input.hpp"

namespace mx {

struct Window;
struct WindowSpec { const char* title; Rect frame; unsigned flags; int minW, minH; };
struct UiMouse {
    enum Kind { Move, Down, Up, Wheel, Double } kind;
    int x, y;            // client-relative
    int button;          // 1 left, 2 right, 4 middle (for Down/Up)
    int wheel;
    u8  buttons;
};

void ui_invalidate();            // schedule a repaint of the whole scene
bool ui_take_dirty();
long ui_ticks();

struct App {
    Window* win = nullptr;
    // ---- lifecycle ----
    virtual ~App() {}
    virtual void windowSpec(WindowSpec& s) { s.title = "Window"; s.frame = Rect{ 60, 40, 420, 300 }; s.flags = 1; s.minW = 200; s.minH = 120; }
    virtual void onCreate() {}
    virtual void onPaint(Canvas& c) = 0;         // c: origin = client top-left, clipped to client
    virtual void onMouse(const UiMouse&) {}      // after hit-region handling
    virtual void onAction(int /*id*/, int /*button*/) {}
    virtual void onKey(const KeyEvent&) {}
    virtual void onTick(long /*ticks*/) {}       // ~10 Hz
    virtual bool onClose() { return true; }      // return false to veto closing
    virtual void onResize(int, int) {}
    virtual void onFocus(bool) {}
    virtual void onDialog(int /*tag*/, bool /*ok*/, const char* /*text*/) {}   // result of dialog_prompt/confirm

    // ---- framework state (don't touch from apps except through helpers) ----
    static constexpr int MAX_HITS = 128;
    struct Hit { Rect r; int id; };
    Hit hits[MAX_HITS]; int nhits = 0;
    int mouseX = -1, mouseY = -1; u8 mouseBtn = 0;
    int hoverId = -1, pressId = -1;
    int cw = 0, ch = 0;                          // client size at last paint
    int baseOx = 0, baseOy = 0;                  // absolute origin of the client canvas (hit regions are client-relative)

    void beginPaint(Canvas& c);
    void addHit(const Rect& r, int id);                         // r in CLIENT coordinates
    void addHitC(const Canvas& c, const Rect& r, int id);       // r in the coordinates of any (sub-)canvas c: translated + clipped
    int  hitAt(int x, int y) const;
    void dispatchMouse(const UiMouse& m);
    void invalidate() { ui_invalidate(); }
    void close();                                // ask the WM to close our window

    // ---- widgets (paint + register hit region) ----
    void button(Canvas& c, const Rect& r, const char* label, int id, bool primary = false, bool enabled = true);
    void iconButton(Canvas& c, const Rect& r, IconId ic, const char* tip, int id, bool enabled = true);
    void checkbox(Canvas& c, int x, int y, const char* label, bool on, int id);
    void radio(Canvas& c, int x, int y, const char* label, bool on, int id);
    void slider(Canvas& c, const Rect& r, int value, int lo, int hi, int id);
    void progress(Canvas& c, const Rect& r, int pct, Color col);
    void panel(Canvas& c, const Rect& r);        // raised group box
    void heading(Canvas& c, int x, int y, const char* s);
};

// single-line text input
struct TextField {
    char buf[64]; int len = 0, cur = 0; bool password = false, focused = false; int maxLen = 40;
    bool numeric = false;
    TextField() { buf[0] = 0; }
    void set(const char* s) { len = scopy(buf, s, 64); cur = len; }
    void clear() { buf[0] = 0; len = cur = 0; }
    bool key(const KeyEvent& e);                 // returns true when Enter was pressed
    void paint(Canvas& c, App& a, const Rect& r, int id);
};

constexpr int TITLE_H = 26, BORDER = 3;
enum WinFlag { WF_RESIZABLE = 1, WF_NOMIN = 2, WF_NOMAX = 4, WF_NOCLOSE = 8, WF_NOTASKBAR = 16, WF_MODAL = 32, WF_CENTER = 64 };

struct Window {
    int id = 0;
    FStr<48> title;
    Rect frame = {0, 0, 0, 0}, restore = {0, 0, 0, 0};
    bool minimized = false, maximized = false, closing = false;
    u32 flags = 0; IconId icon = IC_NONE;
    int minW = 160, minH = 100;
    App* app = nullptr;
    Rect client() const;
    int  clientW() const { return client().w; }
    int  clientH() const { return client().h; }
};

Window* app_open(App* a, IconId icon);   // creates the window described by a->windowSpec()

} // namespace mx
