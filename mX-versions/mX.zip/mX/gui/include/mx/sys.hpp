// sys.hpp — mX system services used by the desktop and apps: user accounts, notifications,
// persistent settings, and a friendlier filesystem layer on top of Kernel24's VFS.
#pragma once
#include "mx/base.hpp"
#include "mx/gfx.hpp"
namespace mx {

// ---------------------------------------------------------------- permissions & users
enum Perm : u32 {
    P_FILES_ALL = 1,        // read/write outside the user's own home (/shared, /system read)
    P_FILES_SYSTEM = 2,     // write to /system
    P_SETTINGS_READ = 4, P_SETTINGS_WRITE = 8,
    P_NETWORK = 16, P_NOTIFY = 32, P_ADMIN = 64, P_PROCESS = 128, P_TERMINAL = 256, P_USERS = 512, P_SYSMON = 1024,
    P_RECOVERY = 2048
};
enum Role { ROLE_GUEST = 0, ROLE_MEMBER = 1, ROLE_ADMIN = 2 };
const char* role_name(Role r);
u32 role_perms(Role r);
u32 perm_from_name(const char* n);

struct User {
    char name[16]; char display[24]; Role role; u32 salt; u32 hash[8]; bool used; bool noPassword; char home[40];
    int iters; int fails; long lockUntil;        // key-stretching rounds; consecutive failed sign-ins; tick until which sign-in is refused
};
constexpr int USERS_MAX = 8;
void users_init();                              // creates default accounts + their home folders
int  users_count();
const User* users_at(int i);
const User* users_find(const char* name);
const User* users_current();
u32  user_perms();                              // permissions of the logged-in user (0 if none)
enum LoginResult { LOGIN_OK = 0, LOGIN_BAD, LOGIN_LOCKED };
LoginResult users_login(const char* name, const char* password);
void users_logout();
LoginResult users_unlock(const char* name, const char* password);     // lock-screen unlock (same lockout rules, audit "unlocked")
long users_lock_remaining(const char* name);     // seconds until a locked account may try again
long users_session_seconds();                    // how long the current user has been signed in
const char* users_session_clock();               // "HH:MM" they signed in
bool users_password_acceptable(Role role, const char* pw, const char** why);   // policy: length + common passwords
bool users_set_role(const char* name, Role r);
void audit(const char* user, const char* event); // append to the security log
int  audit_count();
const char* audit_line(int i);                   // 0 = newest
bool users_add(const char* name, const char* display, Role role, const char* password);
bool users_remove(const char* name);
bool users_set_password(const char* name, const char* newPassword);
bool users_check_password(const char* name, const char* password);
bool users_default_password_active();           // true while admin still has the factory password

// ---------------------------------------------------------------- notifications
enum Sev { N_INFO = 0, N_OK, N_WARN, N_ERROR };
struct Note { Sev sev; char app[20]; char title[40]; char body[100]; long tick; bool read; long toastUntil; };
void notify(Sev s, const char* app, const char* title, const char* body);
void notifyf(Sev s, const char* app, const char* title, const char* fmt, ...);
int  notes_count();
const Note& notes_at(int i);                    // 0 = newest
int  notes_unread();
void notes_mark_all_read();
void notes_clear();
int  notes_active_toasts(const Note** out, int max, long nowTicks);
void notes_dismiss_toasts();
void notes_rearm_toasts();                      // after login: show what piled up while signed out
IconId note_icon(Sev s);

// ---------------------------------------------------------------- persistent settings
struct Config {
    int  wallpaper;        // 0 aurora, 1 midnight, 2 forest, 3 grid, 4 sunset, 5 ocean, 6 graphite, 7 solid colour
    u32  accent;           // 0xRRGGBB
    bool clock24, showSeconds, desktopIcons, mouseKeys, mouseSwap, notifyToasts;
    int  mouseSpeed;       // percent
    char hostname[24];
    int  netMode;          // 0 DHCP-style default, 1 static
    char ip[16], mask[16], gw[16], dns[16];
    // --- Stage 4.1 ---
    int  resW, resH, scale;            // logical desktop size and pixel-doubling (1 or 2)
    bool taskbarTop, taskbarLabels;    // taskbar position; window titles on taskbar buttons
    int  taskbarSize;                  // 0 compact, 1 normal, 2 large
    int  iconSize;                     // desktop icons: 0 small, 1 medium, 2 large
    u32  wallColor;                    // solid-colour wallpaper (wallpaper == 7)
    int  idleLockMin;                  // lock the screen after N idle minutes (0 = never)
    int  kbLayout, kbDelay, kbRate;    // 0 US, 1 Dvorak, 2 Colemak; typematic delay (0..3) and rate (0..31, 0 = fastest)
};
Config& cfg();
void config_defaults();
void config_load();                              // /system/config/settings.cfg (RAM disk for now)
void config_save();
void config_apply();                             // push into theme/mouse drivers

// ---------------------------------------------------------------- filesystem layer
struct FsEntry { char name[32]; bool dir; int size; int inode; };
constexpr int FS_MAX_LIST = 64;
int  fs_list(const char* path, FsEntry* out, int max);      // sorted: folders first, then name
bool fs_exists(const char* path);
bool fs_is_dir(const char* path);
bool fs_stat(const char* path, FsEntry* out);
bool fs_mkdir_p(const char* path);
bool fs_read(const char* path, char* buf, int cap, int* outLen);
bool fs_write(const char* path, const char* data, int len);  // create or truncate+write (max 512 bytes)
bool fs_delete(const char* path);                            // recursive
bool fs_rename(const char* path, const char* newName);
bool fs_move(const char* path, const char* destDir);
bool fs_copy(const char* path, const char* destDir);        // recursive; renames "x" -> "x copy" on clash
void fs_join(char* out, int cap, const char* dir, const char* name);
void fs_parent(const char* path, char* out, int cap);
const char* fs_basename(const char* path);
bool fs_take_denied(char* path, int cap, bool* wasWrite);   // set by the kernel VFS hook when a shell/app action was refused
void fs_usage(int* inodesUsed, int* inodesTotal, int* blocksUsed, int* blocksTotal);
// ownership/permission policy on top of the (ownerless) VFS
void fs_owner(const char* path, char* out, int cap);        // user name, "shared" or "system"
bool fs_can_read(const char* path);
bool fs_can_write(const char* path);

// Run filesystem operations as the system (bypasses per-user checks) for the lifetime of the object.
struct FsSys { FsSys(); ~FsSys(); };
// ---------------------------------------------------------------- app registry
struct App;
typedef App* (*AppFactory)();
struct AppManifest {
    char id[16]; char name[24]; char version[12]; IconId icon; char exec[28]; u32 perms; char resources[40];
    bool singleton, hidden, desktop, core; AppFactory factory;
};
constexpr int APPS_MAX = 20;
void apps_register_builtin(const char* id, AppFactory f);   // binds "builtin:<id>" to code
bool apps_install_manifests();                              // writes /system/apps/<id>.mxapp for the built-ins; false if any write failed
void apps_stats(int* installed, int* installFail, int* fromVfs, int* fallback);
int  apps_scan();                                           // reads every manifest from the VFS
int  apps_count();
const AppManifest* apps_at(int i);
const AppManifest* apps_find(const char* id);
// ---- application management (mX App Center) ----
bool apps_set_desktop(const char* id, bool onDesktop);      // pin/unpin a desktop icon (rewrites the manifest)
bool apps_uninstall(const char* id);                        // removes the manifest + leaves a tombstone; core apps are protected
bool apps_install(const char* id);                          // restores a built-in app that was uninstalled
int  apps_removed(const char** ids, const char** names, int max);   // built-ins currently uninstalled
bool app_running(const char* id);                           // is a window of this app open?
int  app_close_all(const char* id);                         // closes its windows, returns how many
bool app_launch(const char* id);                            // permission-checked; focuses singletons
const char* apps_perm_text(u32 perms, char* out, int cap);

} // namespace mx
