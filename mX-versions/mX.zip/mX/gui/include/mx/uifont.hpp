// uifont.hpp — pre-rasterised anti-aliased proportional UI fonts (see tools/gen_ui_font.py).
#pragma once
#include "mx/base.hpp"
namespace mx {
struct UiGlyph { u8 w, h; i8 xoff, yoff; u8 adv8; u16 off; };      // adv8: advance in 1/8 px; yoff: top row inside the 16 px line box
struct UiFont { const UiGlyph* glyphs; const u8* bits; };           // 95 glyphs: ASCII 0x20..0x7E, 8-bit coverage
extern const UiFont uiRegular, uiBold, uiDisplay;   // 13 px, 13 px bold, 26 px bold (headings)
extern const char* const uiFontFamily;
}
