// persist.hpp — persistent storage. Kernel24's filesystem lives in RAM (128 inodes, one 512-byte block per
// file). Stage 4.1 makes it survive reboots WITHOUT replacing it: the whole tree + file contents are saved as a
// crash-safe snapshot ("mXFS") on a separate data disk, and restored into the RAM filesystem at boot.
//
//   * two snapshot slots (A/B): a save writes the inactive slot, header last, so a power cut mid-save leaves the
//     previous snapshot intact; restore picks the newest slot whose CRC-32 checks out;
//   * saves are automatic (a few seconds after the last change, including changes made from the shell) and
//     forced on logout / shutdown / restart;
//   * the data disk is never the boot disk: the driver refuses primary-master and any disk that isn't blank or
//     already mXFS, so it can't clobber a foreign disk.
#pragma once
#include "mx/base.hpp"
namespace mx {

struct BlockDev {
    bool present; u32 sectors; char name[48];
    bool (*read)(u32 lba, u8* buf512);
    bool (*write)(u32 lba, const u8* buf512);
};
// kernel: ATA PIO (ata.cpp). host: a RAM disk (host/fake_hw.cpp). Returns false when no usable data disk exists.
bool blockdev_probe(BlockDev& out, bool* sawForeignDisk);

struct PersistInfo {
    bool present;          // a data disk was found
    bool mounted;          // its superblock is valid (formatted)
    bool restored;         // a snapshot was loaded this boot
    bool lastSaveOk;
    char device[48]; u32 sectors;
    u32 seq; int slot;     // last snapshot sequence number / slot (0=A, 1=B)
    long lastSaveTick; int lastFiles, lastBlocks;
    char status[110];      // one-line human description for Settings > Storage
};
void persist_init();                       // probe, mount (format if blank), restore the snapshot into the VFS
void persist_tick(long nowTicks);          // call regularly: saves once the filesystem has been quiet for ~3 s
bool persist_flush();                      // save right now if anything changed (logout, shutdown, "Save now")
bool persist_force_save();                 // save even if unchanged
const PersistInfo& persist_info();
u32  crc32(const void* data, size_t len, u32 seed = 0);
}
extern "C" {
long storage_alloc_block(void);            // drivers/storage/ramdisk.cx
void storage_read_block(long block, char* buf);
void storage_write_block(long block, char* buf);
}
