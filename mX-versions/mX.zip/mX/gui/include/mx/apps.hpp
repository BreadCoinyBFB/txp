#pragma once
#include "mx/ui.hpp"
#include "mx/sys.hpp"
namespace mx {
App* make_terminal(); App* make_files(); App* make_settings(); App* make_monitor(); App* make_notepad();
App* make_calc(); App* make_about(); App* make_diag(); App* make_recovery_tools(); App* make_appcenter();
Window* open_set_password_dialog(const char* user, bool forced);   // modal two-field "choose a new password" window
Window* notepad_open_file(const char* path);
void apps_register_all();             // binds every built-in factory (call before apps_scan)

// modal dialogs; results arrive in owner->onDialog(tag, ok, text)
Window* dialog_prompt(App* owner, int tag, const char* title, const char* label, const char* initial, bool password = false);
Window* dialog_confirm(App* owner, int tag, const char* title, const char* message);
Window* dialog_message(const char* title, const char* message, IconId icon);

// terminal <-> shell plumbing (cX shell calls these through the screen_* / input exports in glue.cpp)
bool term_active();
void term_putc(char c); void term_backspace(); void term_clear(); void term_color(int fg, int bg);
void term_puts(const char* s);
long term_read_char();                // blocks (yielding) until the Terminal window delivers a key
void term_shell_died();

// diagnostics
struct DiagResult { char name[30]; int status; char detail[64]; };   // 0 pass, 1 warn, 2 fail
int diag_run(DiagResult* out, int max);
const char* diag_status_name(int s);
}
