// base.hpp — freestanding basics shared by every mX GUI module: fixed-width
// types, Rect/Color, tiny string helpers and a printf-lite. There is no libc
// in the kernel, so everything here is self-contained. NOTE: no floating
// point anywhere in the GUI (the kernel does not save/restore SSE state across
// task switches — everything is built with -mgeneral-regs-only).
#pragma once
// No system headers on purpose: the kernel build uses -nostdinc, and on Termux a clang pointed at x86-64 would
// otherwise find the *Android/libc++* headers (which refuse to compile for a bare-metal target). The fixed-width
// types and varargs come straight from compiler builtins, which GCC and clang both provide. The host test build
// (MX_HOST) uses the real headers.
#ifdef MX_HOST
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#else
typedef __INT8_TYPE__ int8_t;     typedef __INT16_TYPE__ int16_t;     typedef __UINT8_TYPE__ uint8_t;   typedef __UINT16_TYPE__ uint16_t;
typedef __UINT32_TYPE__ uint32_t; typedef __UINT64_TYPE__ uint64_t;
typedef __INT32_TYPE__ int32_t;   typedef __INT64_TYPE__ int64_t;
typedef __SIZE_TYPE__ size_t;     typedef __UINTPTR_TYPE__ uintptr_t;
typedef __builtin_va_list va_list;
#define va_start(v, l) __builtin_va_start(v, l)
#define va_end(v)      __builtin_va_end(v)
#define va_arg(v, t)   __builtin_va_arg(v, t)
#endif

namespace mx {

typedef uint8_t u8;   typedef uint16_t u16;
typedef uint32_t u32; typedef uint64_t u64;
typedef int32_t i32;  typedef int64_t i64;  typedef int8_t i8;  typedef int16_t i16;

template <class T> static inline T min(T a, T b) { return a < b ? a : b; }
template <class T> static inline T max(T a, T b) { return a > b ? a : b; }
template <class T> static inline T clamp(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }
template <class T> static inline T abs_(T v) { return v < 0 ? -v : v; }

struct Rect {
    int x, y, w, h;
    int right() const { return x + w; }
    int bottom() const { return y + h; }
    bool contains(int px, int py) const { return px >= x && py >= y && px < x + w && py < y + h; }
    bool empty() const { return w <= 0 || h <= 0; }
    Rect intersect(const Rect& o) const {
        int x0 = max(x, o.x), y0 = max(y, o.y);
        int x1 = min(right(), o.right()), y1 = min(bottom(), o.bottom());
        Rect r = { x0, y0, x1 - x0, y1 - y0 };
        if (r.w < 0) r.w = 0;
        if (r.h < 0) r.h = 0;
        return r;
    }
    Rect unite(const Rect& o) const {
        if (empty()) return o;
        if (o.empty()) return *this;
        int x0 = min(x, o.x), y0 = min(y, o.y);
        int x1 = max(right(), o.right()), y1 = max(bottom(), o.bottom());
        Rect r = { x0, y0, x1 - x0, y1 - y0 };
        return r;
    }
    Rect inset(int d) const { Rect r = { x + d, y + d, w - 2 * d, h - 2 * d }; return r; }
    Rect moved(int dx, int dy) const { Rect r = { x + dx, y + dy, w, h }; return r; }
};

typedef uint32_t Color; // 0x00RRGGBB
static inline constexpr Color rgb(u8 r, u8 g, u8 b) { return ((Color)r << 16) | ((Color)g << 8) | b; }
static inline u8 cr(Color c) { return (c >> 16) & 0xFF; }
static inline u8 cg(Color c) { return (c >> 8) & 0xFF; }
static inline u8 cb(Color c) { return c & 0xFF; }
// a over b, alpha 0..255
static inline Color blend(Color a, Color b, int alpha) {
    int ia = 255 - alpha;
    return rgb((u8)((cr(a) * alpha + cr(b) * ia + 127) / 255),
               (u8)((cg(a) * alpha + cg(b) * ia + 127) / 255),
               (u8)((cb(a) * alpha + cb(b) * ia + 127) / 255));
}

// ---- strings (all bounded; every writer takes a capacity) ----
int  slen(const char* s);
int  scmp(const char* a, const char* b);
bool seq(const char* a, const char* b);
bool sstarts(const char* s, const char* prefix);
int  scopy(char* dst, const char* src, int cap);          // returns length written
int  scat(char* dst, const char* src, int cap);           // append, returns new length
int  sfmt(char* out, int cap, const char* fmt, ...);      // %s %d %u %x %c %% (+ width/0-pad, %lu %lld not needed)
int  svfmt(char* out, int cap, const char* fmt, va_list ap);
int  satoi(const char* s);
char lower(char c);
bool streq_nocase(const char* a, const char* b);
void* mem_set(void* p, int v, size_t n);
void* mem_cpy(void* d, const void* s, size_t n);
int  mem_cmp(const void* a, const void* b, size_t n);

// fixed-capacity string, no heap
template <int N> struct FStr {
    char s[N];
    FStr() { s[0] = 0; }
    FStr(const char* t) { scopy(s, t, N); }
    void set(const char* t) { scopy(s, t, N); }
    void add(const char* t) { scat(s, t, N); }
    void clear() { s[0] = 0; }
    int  len() const { return slen(s); }
    const char* c() const { return s; }
    operator const char*() const { return s; }
};

} // namespace mx
