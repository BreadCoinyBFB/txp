// kapi.hpp — everything the GUI needs from the rest of Kernel24 / the cX shell.
// All cross-language calls use 64-bit integers only: cX passes every argument as a
// full 64-bit register and reads RAX whole, so `long` on both sides is the safe ABI.
#pragma once
#include "mx/base.hpp"

extern "C" {
// --- Kernel24 (cX) ---
long kmalloc(long size);
void kfree(long ptr);
long timer_ticks(void);               // 100 Hz PIT ticks since boot
long timer_uptime_seconds(void);
long vmm_map(long virt, long phys, long flags);
long pmm_free_pages(void);
long pmm_total_pages(void);
long heap_free_bytes(void);
extern long system_memory_kb;
long sys_yield(void);
long sys_exit(long code);
long task_create(long entry, const char* name);
long task_kill(long pid);
long task_current_pid(void);

// --- filesystem (fs/vfs.cx). `string` params are NUL-terminated char*. ---
long vfs_mkdir(const char* path);
long vfs_create_file(const char* path);
long vfs_resolve_path(const char* path);   // inode index or -1
long vfs_open(const char* path);           // fd or -1
long vfs_close(long fd);
long vfs_read(long fd, char* buf, long max_len);
long vfs_write(long fd, const char* buf, long len);
long vfs_unlink(const char* path);
extern long vfs_cwd;

// --- mX shell (cX) ---
void shell_main(void);

// --- exported BY the GUI to cX (called from shell/input.cx, screen dispatch, isr.cx, ...) ---
long gui_boot(void);                       // init.cx: nonzero = GUI ran (never returns in practice)
}

namespace mx {

// mirrors fs/vfs.cx `struct Inode` (verified against cxc codegen: 40 bytes, size at +32)
struct Inode {
    int32_t inode_type;   // 0 free, 1 file, 2 dir
    int32_t _pad0;
    const char* name;
    int32_t parent;
    int32_t first_child;
    int32_t next_sibling;
    int32_t block;
    int32_t size;
    int32_t _pad1;
};
static_assert(sizeof(Inode) == 40, "Inode layout must match fs/vfs.cx");
constexpr int INODE_FREE = 0, INODE_FILE = 1, INODE_DIR = 2;
constexpr int VFS_MAX_INODES = 128;   // raised from 32 in Stage 4 (see docs/STAGE4.md)
constexpr int VFS_BLOCK_SIZE = 512;

} // namespace mx

extern "C" mx::Inode inode_table[];

// ---- port I/O + CPU helpers (inline asm; usable in any ring-0 context) ----
namespace mx {
static inline void outb(u16 p, u8 v)  { asm volatile("outb %0,%1" : : "a"(v), "Nd"(p)); }
static inline u8   inb(u16 p)         { u8 v; asm volatile("inb %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline void outw(u16 p, u16 v) { asm volatile("outw %0,%1" : : "a"(v), "Nd"(p)); }
static inline u16  inw(u16 p)         { u16 v; asm volatile("inw %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline void outl(u16 p, u32 v) { asm volatile("outl %0,%1" : : "a"(v), "Nd"(p)); }
static inline u32  inl(u16 p)         { u32 v; asm volatile("inl %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline u64  irq_save()         { u64 f; asm volatile("pushfq; popq %0; cli" : "=r"(f) : : "memory"); return f; }
static inline void irq_restore(u64 f) { if (f & 0x200) asm volatile("sti" : : : "memory"); }
static inline void cpu_relax()        { asm volatile("pause"); }
}
