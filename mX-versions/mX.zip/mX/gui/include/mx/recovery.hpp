// recovery.hpp — boot recovery: a boot-attempt counter and last-crash record kept in battery-backed
// CMOS RAM (survives resets and the lack of a disk driver), plus safe-environment helpers.
#pragma once
#include "mx/base.hpp"
namespace mx {
struct CrashInfo { bool valid; u8 vector; u32 rip, err; char msg[9]; };
void recovery_boot_begin();              // call first thing in gui_boot(): counts this boot attempt
void recovery_mark_stable();             // call once the desktop has been up a few seconds
bool recovery_forced();                  // true after 3 consecutive boots that never reached "stable"
int  recovery_attempts();
bool recovery_get_crash(CrashInfo& out);
void recovery_clear_crash();
void recovery_note_crash(u8 vector, u32 err, u32 rip, const char* msg);   // exceptions / panic()
void recovery_request_recovery_next(bool on);
bool recovery_next_requested();
void recovery_announce_crash();          // notification on the desktop if the last session crashed
void recovery_reset_settings();
void recovery_reset_users();
void recovery_enter_safe_shell();        // leave graphics, run the text shell (never returns)
}
