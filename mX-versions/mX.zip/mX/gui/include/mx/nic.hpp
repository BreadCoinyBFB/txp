#pragma once
#include "mx/base.hpp"
namespace mx {
// What the protocol stack needs from a network card driver.
struct NicOps {
    bool (*send)(const u8* frame, int len);       // raw Ethernet frame (no FCS)
    int  (*recv)(u8* buf, int max);               // one frame or 0 when the ring is empty
    bool (*link)();
    u8   mac[6];
    char name[44];
};
// implemented by rtl8139.cpp (kernel) or the host test's fake card
bool nic_probe(NicOps& out, bool& sawUnsupported);
}
