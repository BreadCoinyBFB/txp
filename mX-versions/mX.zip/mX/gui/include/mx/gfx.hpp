// gfx.hpp — software 2D drawing for mX's desktop: a Canvas is a clipped,
// origin-shifted view onto a 32-bit XRGB pixel buffer. Everything draws with
// integer math only (no FPU/SSE in kernel context).
#pragma once
#include "mx/base.hpp"
#include "mx/font.hpp"
#include "mx/uifont.hpp"

extern "C" {
// Implemented in gfx_fast.asm for the kernel (rep stosd / rep movsd); the host
// test build provides C versions in host/fast_c.cpp.
void mx_fill32(uint32_t* dst, uint32_t value, size_t count);
void mx_copy32(uint32_t* dst, const uint32_t* src, size_t count);
}

namespace mx {

enum IconId {
    IC_NONE = 0, IC_START, IC_TERMINAL, IC_FILES, IC_SETTINGS, IC_MONITOR, IC_NOTEPAD, IC_CALC,
    IC_ABOUT, IC_FOLDER, IC_FILE, IC_USER, IC_NET, IC_BELL, IC_WARN, IC_INFO, IC_ERROR, IC_OK,
    IC_POWER, IC_DISK, IC_RECOVERY, IC_DISPLAY, IC_KEYBOARD, IC_MOUSE, IC_CLOCK, IC_SOUND, IC_LOCK, IC_DIAG, IC_STORE,
    IC_COUNT
};

struct Theme {
    Color desktopTop, desktopBottom;
    Color panel, panelDark, panelLight, window, text, textDim, textOnAccent;
    Color accent, accentDark, accentLight;
    Color titleActiveA, titleActiveB, titleInactive, border;
    Color ok, warn, danger, selection, field;
};
Theme& theme();
void theme_set_accent(Color accent);

struct Canvas {
    uint32_t* px = nullptr;
    int w = 0, h = 0, pitch = 0;   // VIEW size (what apps lay out against); pitch in pixels
    int bw = 0, bh = 0;            // underlying buffer size
    Rect clip = {0, 0, 0, 0};      // buffer coordinates
    int ox = 0, oy = 0;            // origin of drawing coordinates, buffer coordinates

    Canvas() {}
    Canvas(uint32_t* p, int w_, int h_, int pitch_) : px(p), w(w_), h(h_), pitch(pitch_), bw(w_), bh(h_) { clip.x = 0; clip.y = 0; clip.w = w_; clip.h = h_; }

    // A canvas whose (0,0) is r's top-left (in this canvas' coordinates) and which cannot draw outside r.
    Canvas sub(const Rect& r) const;
    Rect   bounds() const { Rect r = { 0, 0, w, h }; return r; }
    Rect   localClip() const { Rect r = { clip.x - ox, clip.y - oy, clip.w, clip.h }; return r; }

    void put(int x, int y, Color c);
    Color get(int x, int y) const;
    void fill(const Rect& r, Color c);
    void rect(const Rect& r, Color c);                     // 1px outline
    void hline(int x, int y, int len, Color c);
    void vline(int x, int y, int len, Color c);
    void line(int x0, int y0, int x1, int y1, Color c);
    void fillRound(const Rect& r, int radius, Color c);
    void roundRect(const Rect& r, int radius, Color c);    // outline
    void gradV(const Rect& r, Color top, Color bottom);
    void tint(const Rect& r, Color c, int alpha);          // alpha blend a flat color over existing pixels
    void shadow(const Rect& r, int spread, int maxAlpha);  // soft drop shadow outside r
    void bevel(const Rect& r, bool raised);
    void blit(const uint32_t* src, int sw, int sh, int x, int y);

    // --- text. The UI font is the anti-aliased proportional face (Inter once you add it, see tools/gen_ui_font.py).
    //     scale 1 = regular 13 px, scale >= 2 = the 26 px display face. Symbols outside ASCII fall back to the
    //     8x16 bitmap font. The bitmap font is still used for the Terminal and Notepad (monospace grids).
    int  text(int x, int y, const char* s, Color fg, int scale = 1);
    int  textB(int x, int y, const char* s, Color fg);                          // bold 13 px
    int  textMax(int x, int y, const char* s, Color fg, int maxPx, bool bold = false);  // truncates with ".." when too wide
    int  textWidth(const char* s, int scale = 1) const;
    int  textWidthB(const char* s) const;
    int  textWidthN(const char* s, int n) const;                                // width of the first n bytes (caret placement)
    void textCentered(const Rect& r, const char* s, Color fg, int scale = 1);
    void textCenteredB(const Rect& r, const char* s, Color fg);
    int  glyph(int x, int y, uint32_t cp, Color fg, int scale = 1);             // 8x16 bitmap glyph (monospace grids)
    int  monoText(int x, int y, const char* s, Color fg, int scale = 1);
    void putA(int x, int y, Color c, int alpha);                                // alpha-blended pixel
    int  logo(int x, int y, int width, Color ink);                              // official mX logo, tinted; returns height
    void icon(IconId id, int x, int y, int size);
};

// 12x19 arrow cursor drawn straight onto a buffer, blending with whatever is behind it.
constexpr int CURSOR_W = 12, CURSOR_H = 19;
Color cursor_pixel(int x, int y, bool& opaque);  // sprite lookup, for the compositor
const char* icon_name(IconId id);

} // namespace mx
