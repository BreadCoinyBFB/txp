// sysstat.hpp — live CPU / process accounting for the System Monitor.
// The kernel scheduler calls sysstat_sample() on every timer tick (100 Hz) with the task that was running; the GUI
// marks the moments it is sleeping in `hlt` as idle, so "CPU %" is real work, not time spent waiting for interrupts.
#pragma once
#include "mx/base.hpp"
namespace mx {
struct ProcInfo { int pid; char name[20]; int state; int cpuTenths; int stackUsed; bool isGui; };   // cpuTenths: 0..1000 over the last ~2 s
constexpr int PROC_MAX = 16;
void sysstat_sample(long taskIndex);             // IRQ context
void sysstat_idle(bool on);                      // wrap the HLT in hal_yield
void sysstat_update();                           // GUI calls ~1/s: closes the sampling window
int  sysstat_cpu_percent();                      // whole machine, last second
int  sysstat_processes(ProcInfo* out, int max);
const char* sysstat_state_name(int s);
}
extern "C" void gui_sched_sample(long taskIndex);
