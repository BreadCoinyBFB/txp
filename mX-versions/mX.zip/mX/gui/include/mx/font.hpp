#pragma once
#include "mx/base.hpp"
namespace mx {
constexpr int FONT_W = 8, FONT_H = 16, FONT_GLYPHS = 111;
extern const uint8_t font8x16[FONT_GLYPHS][16];
int font_glyph_index(uint32_t codepoint);
}
