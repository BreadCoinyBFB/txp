#pragma once
#include "mx/base.hpp"
namespace mx {
struct PciDev {
    u8 bus, dev, func; u16 vendor, device; u8 cls, sub, prog, irq; u32 bar[6];
};
constexpr int PCI_MAX = 32;
int  pci_scan();                              // enumerates buses 0..7 via config mechanism #1; returns count
int  pci_count();
const PciDev& pci_get(int i);
u32  pci_read32(u8 bus, u8 dev, u8 fn, u8 off);
void pci_write32(u8 bus, u8 dev, u8 fn, u8 off, u32 v);
void pci_enable(const PciDev& d, bool busmaster);   // memory + I/O space (+ bus mastering for DMA NICs)
const char* pci_vendor_name(u16 v);
const char* pci_class_name(const PciDev& d);
const PciDev* pci_find(u16 vendor, u16 device);
}
