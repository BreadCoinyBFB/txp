// display.hpp — getting pixels onto a screen. Backends: a framebuffer handed over by
// XLoader in BootInfo (future VBE bootloader work), or the Bochs/QEMU "BGA" adapter
// programmed directly through its I/O ports (works under QEMU -vga std, Bochs, VirtualBox).
#pragma once
#include "mx/base.hpp"
namespace mx {
// w,h = LOGICAL size (what the desktop draws at); pw,ph = what the monitor really shows (logical x scale).
struct DisplayInfo { bool ok; int w, h, pitchPixels; u32* lfb; u64 phys; char driver[32]; int pw, ph, scale; bool canSwitch; };
void display_set_bootinfo(u64 addr, int w, int h, int pitchBytes, int bpp);   // from kernel_main
bool display_init(int w, int h);
// Reprogram the adapter at runtime (BGA only): logical w x h shown at `scale` (1 or 2) = physical (w*scale) x (h*scale).
// Scale 2 doubles every pixel, so a phone-sized VNC view stays readable. Returns false (and changes nothing) on failure.
bool display_set_mode(int w, int h, int scale);
// QEMU `-fw_cfg name=opt/mx/display,string=1024x768x2`: lets `make run-gui GUI_MODE=...` pick a mode from the host side.
bool fwcfg_display_request(int* w, int* h, int* scale);              // tries BootInfo fb, then BGA
const DisplayInfo& display_info();
void display_present(const u32* scene, int scenePitch, const Rect& r);  // copy a rect scene -> screen
void display_present_block(const u32* src, int srcPitch, int dx, int dy, int w, int h);   // arbitrary block -> screen
void display_text_mode();                     // panic path: give the text console back
}
