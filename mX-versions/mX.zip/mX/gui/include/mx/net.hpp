// net.hpp — Stage 4 basic networking: NIC detection (PCI), IP configuration, ARP/IPv4/ICMP/UDP and
// DNS on top of a polled RTL8139 driver (QEMU: -nic user,model=rtl8139). No TCP yet (later TXP work).
#pragma once
#include "mx/base.hpp"
namespace mx {
struct NetInfo {
    bool present;            // a supported NIC was found and initialised
    bool detectedOther;      // a NIC was seen on PCI but there is no driver for it
    char name[44];
    u8   mac[6];
    bool linkUp;
    char ip[16], mask[16], gw[16], dns[16];
    u64  rxPackets, txPackets, rxDropped;
    char status[64];
};
void net_init();                                   // scan PCI, bring up the NIC, apply cfg() addressing
const NetInfo& net_info();
void net_apply_config();                           // re-read cfg() (static/default) addressing
void net_poll();                                   // drain the RX ring (called from the GUI loop)
// Blocking helpers (poll the NIC, yield to the scheduler): return false on timeout/failure.
bool net_resolve(const char* host, char* ip16, int timeoutMs);          // dotted quad or DNS A lookup
bool net_ping(const char* ip16, int* rttMs, int timeoutMs);
// TCP client (one connection at a time). All blocking; they poll the NIC and yield, with millisecond timeouts.
bool net_tcp_connect(const char* ip16, u16 port, int timeoutMs, int* connectMs);
int  net_tcp_send(const u8* data, int len);                 // returns bytes acknowledged (== len), or -1
int  net_tcp_recv(u8* buf, int max, int timeoutMs);         // >0 bytes, 0 = timeout, -1 = connection closed/reset
void net_tcp_close();
bool net_tcp_open();
// diagnostics shown in Settings > Network
struct NetTest { char name[28]; int status; char detail[80]; };         // 0 ok, 1 warn, 2 fail
int  net_diagnose(NetTest* out, int max);                   // link, address, gateway, DNS, TCP to the internet, HTTP
bool net_dns_query(const char* host, char* ip16, int* ms);  // resolve using the configured DNS server and time it
bool net_http_head(const char* ip16, u16 port, const char* host, char* statusLine, int cap, int* ms);
// pure protocol helpers (also unit-tested on the host)
bool ip_parse(const char* s, u8 out[4]);
void ip_format(const u8 ip[4], char* out16);
u16  ip_checksum(const void* data, int len);
}
