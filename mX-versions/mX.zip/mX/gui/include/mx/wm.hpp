// wm.hpp — the mX window manager: stacking, focus, move/resize, decorations, minimize/maximize/close.
#pragma once
#include "mx/ui.hpp"
namespace mx {

constexpr int WM_MAX = 24;

class WindowManager {
public:
    void init(const Rect& workArea);
    void setWorkArea(const Rect& r);
    Rect workArea() const { return work; }

    Window* create(App* app, const char* title, Rect frame, u32 flags, IconId icon, int minW = 160, int minH = 100);
    void requestClose(Window* w);
    void closeAll();
    void reapClosed();                       // destroys windows whose closing flag was set (safe point: top of frame)

    void raise(Window* w);
    void setFocus(Window* w);
    Window* focused() const { return focus; }
    void minimize(Window* w);
    void restore(Window* w);
    void toggleMaximize(Window* w);
    void cycleFocus(bool backwards);         // Alt+Tab
    void taskbarClick(Window* w);

    int  count() const { return n; }
    Window* at(int i) const { return z[i]; } // z[0] = bottom
    Window* find(const App* app) const;
    Window* modal() const;

    void paint(Canvas& c);                   // paints every visible window, bottom to top
    // return true if the event was consumed by a window (so the desktop shouldn't see it)
    bool mouse(const MouseEvent& e, u32 prevButtons);
    bool key(const KeyEvent& e);
    void tick(long ticks);
    Window* windowAt(int x, int y) const;

    enum Hit { HT_NONE, HT_CLIENT, HT_TITLE, HT_CLOSE, HT_MAX, HT_MIN, HT_SIZE };
    Hit hitTest(const Window* w, int x, int y, int* edges) const;
    Rect closeBtn(const Window* w) const; Rect maxBtn(const Window* w) const; Rect minBtn(const Window* w) const;

private:
    Window* z[WM_MAX]; int n = 0; int nextId = 1;
    Window* focus = nullptr;
    Rect work = {0, 0, 800, 564};
    // drag state
    enum Mode { M_NONE, M_MOVE, M_SIZE, M_BTN } mode = M_NONE;
    Window* drag = nullptr; int dx = 0, dy = 0, edges = 0; Rect startFrame = {0, 0, 0, 0}; int sx = 0, sy = 0; Hit btn = HT_NONE;
    long lastClickTick = -1000; int lastClickX = 0, lastClickY = 0; Window* lastClickWin = nullptr;
    void drawWindow(Canvas& c, Window* w);
    void applyResize(int mx_, int my_);
    void remove(Window* w);
};
WindowManager& wm();

} // namespace mx
