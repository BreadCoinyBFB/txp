// input.hpp — raw keyboard scancodes and PS/2 mouse packets in, clean events out.
// Producers run in IRQ context (single producer / single consumer rings, no locks);
// the GUI task is the only consumer.
#pragma once
#include "mx/base.hpp"
namespace mx {

enum Key : u16 {
    K_NONE = 0, K_ESC = 1, K_BACKSPACE, K_TAB, K_ENTER, K_SPACE, K_DELETE, K_INSERT, K_HOME, K_END,
    K_PGUP, K_PGDN, K_UP, K_DOWN, K_LEFT, K_RIGHT, K_LSHIFT, K_RSHIFT, K_LCTRL, K_RCTRL, K_LALT, K_RALT,
    K_SUPER, K_CAPS, K_F1, K_F2, K_F3, K_F4, K_F5, K_F6, K_F7, K_F8, K_F9, K_F10, K_F11, K_F12, K_CHAR /* printable: see ch */
};
enum Mod : u8 { MOD_SHIFT = 1, MOD_CTRL = 2, MOD_ALT = 4, MOD_SUPER = 8, MOD_CAPS = 16 };

struct KeyEvent { u16 key; u8 ch; u8 mods; bool down; bool repeat; };
struct MouseEvent { int x, y; int dx, dy, wheel; u8 buttons; u8 changed; }; // buttons bit0=L bit1=R bit2=M

void input_init(int screenW, int screenH);
void input_set_bounds(int w, int h);
// IRQ side
void input_scancode(u8 raw);            // called from the IRQ1 hook (cX keyboard handler)
void mouse_irq();                       // IRQ12 handler body (reads port 0x60)
// consumer side
bool input_next_key(KeyEvent& e);
bool input_next_mouse(MouseEvent& e);
void input_inject_key(const KeyEvent& e);   // tests + MouseKeys
void input_inject_mouse(const MouseEvent& e);
u8   input_mods();
// mouse hardware
bool mouse_hw_init();                   // PS/2 aux enable; returns false if no mouse answered
bool mouse_present();
bool mouse_has_wheel();
void mouse_set_speed(int pct);          // 25..400
void mouse_set_swap(bool swap);
bool mouse_swapped();
int  mouse_speed();
void mouse_warp(int x, int y);
void mouse_position(int& x, int& y);
void input_set_layout(int layout);       // 0 US QWERTY, 1 Dvorak, 2 Colemak
int  input_layout();
bool kbd_set_typematic(int delay, int rate);   // delay 0..3 (250..1000 ms), rate 0..31 (30..2 cps); PS/2 only
// MouseKeys: Ctrl+Alt+arrows move the pointer, Ctrl+Alt+Space/Enter click (for keyboard-only/VNC use)
void mousekeys_enable(bool on);
bool mousekeys_enabled();
}
