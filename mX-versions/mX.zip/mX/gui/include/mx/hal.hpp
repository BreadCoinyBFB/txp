// hal.hpp — hardware abstraction the GUI talks to. The kernel build implements
// these against real ports (hal_kernel.cpp); the host test build fakes them
// (host/fake_kernel.cpp) so every GUI module can be run and screenshotted on a PC.
#pragma once
#include "mx/base.hpp"
namespace mx {
long hal_ticks();                       // 100 Hz
void hal_yield();
void hal_reboot();
void hal_poweroff();
void hal_log(const char* s);            // serial (kernel) / stderr (host)
struct RtcTime { int year, month, day, hour, minute, second, weekday; };
void hal_rtc_read(RtcTime& t);
bool hal_rtc_write(const RtcTime& t);
void hal_cmos_read(int off, u8* out, int n);   // persistent bytes (recovery state)
void hal_cmos_write(int off, const u8* in, int n);
void hal_cpu_vendor(char* out13);
void hal_cpu_brand(char* out49);
u64  hal_free_mem_kb();
u64  hal_total_mem_kb();
u64  hal_heap_free();
}
