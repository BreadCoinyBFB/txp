// desktop.hpp — the compositor and desktop shell: wallpaper, desktop icons, taskbar, start menu,
// notification toasts + center, login screen, lock screen and the main event loop.
#pragma once
#include "mx/ui.hpp"
#include "mx/wm.hpp"
namespace mx {

enum Screen { SCR_SPLASH, SCR_RECOVERY, SCR_LOGIN, SCR_DESKTOP, SCR_LOCK };

// Runs the GUI forever (kernel) — or, with `frames`/script hooks, a bounded number of steps (host tests).
void desktop_init(int w, int h);
void desktop_set_screen(Screen s);
Screen desktop_screen();
void desktop_step();                 // process input, tick, paint if dirty, present — one iteration
void desktop_run_forever();
void desktop_logout(bool lock);
void desktop_lock();                 // lock the screen, keep every window open
bool desktop_set_display(int w, int h, int scale, bool withRevertTrial);   // change resolution/scaling now; trial = 10 s "keep?" banner
void desktop_layout_changed();       // taskbar position/size or desktop-icon settings changed
void desktop_note_activity();        // resets the idle-lock timer
int  desktop_width(); int desktop_height();
void desktop_power(int action);      // 0 shutdown, 1 reboot
Canvas& desktop_scene();
void desktop_present_all();
void desktop_toggle_notification_center();
void desktop_open_start();
bool desktop_boot_stable();          // true once we've been on the desktop long enough to call the boot "good"

// recovery hooks (implemented in recovery.cpp)
bool recovery_requested();
void recovery_paint(Canvas& c);
void recovery_key(const KeyEvent& e);
void recovery_mouse(const UiMouse& m);
}
