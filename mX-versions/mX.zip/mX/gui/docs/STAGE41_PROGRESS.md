# Stage 4.1 progress — STATUS: all 8 mission items implemented; host-verified (111 tests), NOT yet booted on QEMU
Read `STAGE41.md` for the design and the verified / unverified list.
## Next
1. `make run-gui` on Termux (VNC viewer -> 127.0.0.1:5901). First boot formats `XLoader/mxdata.img`.
2. Read `XLoader/build/serial.log`. Likely first-contact fixes: ATA probe, BGA runtime mode switch, fw_cfg, TCP vs SLIRP.
3. Add real Inter: copy Inter-Regular.ttf / Inter-Bold.ttf to gui/tools/fonts and run `python3 gui/tools/gen_ui_font.py`.
4. Ideas: VBE in XLoader for real hardware, TCP server side, USB, audio, window snapping/virtual desktops.
