# Stage 4 progress (resume file — read this first in a new chat)

STATUS: all nine Stage 4 feature areas are implemented; compile/link/host-test verified; NOT yet booted in QEMU.
New code = freestanding C++ + NASM in `mX/gui/`. Design + verified/unverified list: `gui/docs/STAGE4.md`.

## Next steps (in order)
1. `make run-gui` (Termux: VNC viewer -> 127.0.0.1:5901). Read `XLoader/build/serial.log` for `[gui]` lines.
2. Expect to debug first-contact items: NASM build of gfx_fast.asm, BGA mode + LFB mapping, PS/2 mouse, RTL8139, VGA font reload, shell task in Terminal.
3. Then: ATA PIO disk driver (persist users/settings/files), VBE in XLoader for real hardware, TCP, audio.

## Handy
`make gui-test` = 54 host tests + screenshots (/tmp/shots). `make cx-check` = all cX files. `gui/tools/asm-check.sh` = assemble NASM subset with GNU as.
