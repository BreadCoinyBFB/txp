# mX Stage 4.1 — personalization, persistence, security

Everything here is on top of Stage 4 (`STAGE4.md`). Same rules: freestanding C++ + NASM in `mX/gui`, small hooks in the cX kernel.

## Run it
```
make run-gui                                  # creates XLoader/mxdata.img (8 MiB) the first time and attaches it as the data disk
make run-gui GUI_MODE=1024x768x2              # pick resolution + 2x scaling from the host side (Termux-friendly, via QEMU fw_cfg)
make reset-data                               # erase the data disk (files, accounts, settings)
make gui-test                                 # host tests + screenshots (111 checks)
```
First sign-in: `admin` / `admin` → mX makes you choose a real password straight away. Everything you change is saved to the data disk.

## What's new (by mission item)
| # | Mission | Where | Notes |
|---|---|---|---|
| 1 | Desktop personalization | `desktop.cpp`, Settings → Display / Desktop | 8 wallpapers (+8 solid colours), accent colours; resolution 640x480 / 800x600 / 1024x768 with **2x pixel scaling**, switched live over the Bochs VBE ports with a **10-second "keep this?" revert banner**; taskbar top/bottom, 3 sizes, titles on/off; desktop icons small/medium/large, per-app pin/unpin |
| 2 | Persistent file system | `ata.cpp`, `persist.cpp` | ATA PIO driver (secondary master first; **never the boot disk, never a disk holding someone else's data**); whole tree + files saved as a crash-safe A/B snapshot with CRC-32; auto-save ~3 s after the last change (including shell changes), forced on logout/shutdown; restore at boot. `/home/<user>` private, `/shared`, `/system` protected |
| 3 | Complete Settings | `settings.cpp` | Display, Desktop, Sound (honest: no driver), Keyboard (US/Dvorak/Colemak, repeat delay + rate sent to the PS/2 keyboard), Mouse, Storage (disk status, Save now), Network, System, Users, Date & Time. Every control applies immediately and is saved. Scrollable pages |
| 4 | System Monitor | `sysmon.cpp`, `sysstat.cpp` | Live CPU graph (idle time excluded) + RAM graph, **process list** read from the kernel task table with per-task CPU %, End process, running **application windows** (switch/close), devices, diagnostics (now includes a filesystem write test) |
| 5 | Networking | `netstack.cpp` | **TCP client** (handshake, send with retransmit, receive, close), DNS timing, HTTP HEAD, a **connectivity test** (adapter, link, IP config, gateway, DNS, TCP, HTTP) and DNS / ping / TCP-connect tools in Settings → Network |
| 6 | App Center | `appcenter.cpp`, `appreg.cpp` | Browse installed apps, versions, identifier, resources, **permissions explained**, whether *you* may run it, running state; Open / Pin / Close / **Uninstall** (non-core, admin) and **reinstall**. Uninstall removes the manifest and leaves a tombstone so it stays gone |
| 7 | Accounts & security | `users.cpp`, `desktop.cpp`, `fs.cpp`, `vfs.cx` hooks | Passwords: salted **3000-round stretched SHA-256**, constant-time compare, stored per account on disk; **lockout** after 3 failures with exponential back-off; **password policy**; **forced password change** for the factory admin; **lock screen** (windows stay open) + **idle auto-lock**; session info, sign out, audit log (`/system/log/auth.log`); **file permissions enforced by the kernel VFS** — the shell is bound by them too |
| 8 | Design | `ui_font_data.cpp`, `logo_data.cpp` | Proportional anti-aliased UI font (regular/bold/display) and the **official mX logo** (splash, login, start button, About, window icons). **Inter**: not installable offline here → Instrument Sans stand-in; drop `Inter-Regular.ttf` + `Inter-Bold.ttf` into `gui/tools/fonts/` and run `python3 gui/tools/gen_ui_font.py` (needs Pillow) and Inter is used automatically |

## Memory
Scene buffer sized for 1024x768 logical (3 MiB `.bss`); kernel image ends ~4.5 MiB of the 8 MiB identity map. 2x scaling needs up to 12 MiB of video RAM (QEMU std-vga has 16).

## Hooks added to cX in 4.1
`vfs.cx` (5 permission checks), `scheduler.cx` (1 call per tick for CPU accounting). Both pass `make cx-check`.

## Verified here vs. first contact on your QEMU
Verified: host tests (111), kernel-flag compile with zero warnings and **zero SSE instructions**, symbol link-check against all cX/asm objects, persistence round-trips including a corrupted newest snapshot, TCP against a fake server, permission hooks, lock/idle/forced-password flows, and screenshots of every new screen.
**Not verified (needs real QEMU):** ATA PIO against QEMU's IDE, BGA mode switching at runtime and the 2x scaled present, fw_cfg reading, PS/2 typematic command, the per-tick CPU sampling hook, TCP/DNS against real SLIRP, and the VGA text-mode font restore. Check `XLoader/build/serial.log` (`[gui] ...`) first if something misbehaves; Settings → Storage and the Diagnostics app say exactly which disk/steps failed.
