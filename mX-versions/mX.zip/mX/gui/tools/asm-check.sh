#!/bin/sh
# asm-check.sh — assembles a (simple, instruction-only) NASM file with GNU as so it can be
# verified on machines without nasm. Handles exactly the subset gfx_fast.asm uses:
# BITS/section/global directives and ';' comments. Usage: tools/asm-check.sh src/gfx_fast.asm out.o
set -e
in="$1"; out="$2"
sed -e 's/^BITS 64.*/.intel_syntax noprefix/' \
    -e 's/^section \.text.*/.text/' \
    -e '/^section \.note/d' \
    -e 's/^global \(.*\)/.globl \1/' \
    -e 's/;/#/' "$in" > "$out.s"
as --64 -o "$out" "$out.s"
