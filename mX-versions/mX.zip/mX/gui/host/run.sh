#!/bin/sh
# Builds the REAL GUI sources against the host fakes, runs the tests, converts screenshots to PNG.
set -e
cd "$(dirname "$0")/.."
mkdir -p /tmp/shots build
SRC="src/base.cpp src/gfx.cpp src/font_data.cpp src/input.cpp src/ui.cpp src/wm.cpp src/desktop.cpp src/users.cpp src/notify.cpp src/config.cpp src/fs.cpp src/appreg.cpp \
     src/apps_small.cpp src/terminal.cpp src/files.cpp src/settings.cpp src/sysmon.cpp src/diag.cpp src/recovery.cpp src/netstack.cpp src/ui_font_data.cpp src/logo_data.cpp src/persist.cpp src/appcenter.cpp src/sysstat.cpp"
g++ -std=c++17 -g -O1 -DMX_HOST -Wall -Wno-misleading-indentation -Iinclude $SRC host/fake_kernel.cpp host/fake_hw.cpp host/host_main.cpp -o build/host_tests
RC=0; ./build/host_tests || RC=$?
python3 - <<'PY'
import glob, os
from PIL import Image
for p in sorted(glob.glob('/tmp/shots/*.ppm')):
    Image.open(p).save(p[:-4] + '.png'); os.remove(p)
print("PNG screenshots in /tmp/shots")
PY
exit $RC
