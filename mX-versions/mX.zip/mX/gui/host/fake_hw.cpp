// host/fake_hw.cpp — fake PCI bus + a fake NIC that behaves like QEMU's user-mode (SLIRP) network:
// answers ARP for the gateway/DNS, ICMP echo to 10.0.2.2, and DNS A queries. This lets the REAL
// netstack.cpp run end-to-end on the host.
#include "mx/pci.hpp"
#include "mx/nic.hpp"
#include "mx/net.hpp"
#include "mx/persist.hpp"
#include <string.h>
namespace mx {
static PciDev g_p[4]; static int g_np = 0;
int pci_scan() { g_np = 4;
    g_p[0] = { 0, 0, 0, 0x8086, 0x1237, 0x06, 0x00, 0, 0, {0} }; g_p[1] = { 0, 1, 0, 0x8086, 0x7000, 0x06, 0x01, 0, 0, {0} };
    g_p[2] = { 0, 2, 0, 0x1234, 0x1111, 0x03, 0x00, 0, 0, {0xFD000008} }; g_p[3] = { 0, 3, 0, 0x10EC, 0x8139, 0x02, 0x00, 0, 11, {0xC001} }; return g_np; }
int pci_count() { return g_np; } const PciDev& pci_get(int i) { return g_p[i]; }
u32 pci_read32(u8, u8, u8, u8) { return 0; } void pci_write32(u8, u8, u8, u8, u32) {} void pci_enable(const PciDev&, bool) {}
const PciDev* pci_find(u16 v, u16 d) { for (int i = 0; i < g_np; i++) if (g_p[i].vendor == v && g_p[i].device == d) return &g_p[i]; return nullptr; }
const char* pci_vendor_name(u16 v) { return v == 0x8086 ? "Intel" : v == 0x1234 ? "QEMU/Bochs" : v == 0x10EC ? "Realtek" : "Unknown vendor"; }
const char* pci_class_name(const PciDev& d) { return d.cls == 2 ? "Network adapter" : d.cls == 3 ? "Display adapter" : d.cls == 6 ? "Bridge" : "Other device"; }

// ---- fake data disk: 2 MiB RAM image that survives a simulated reboot ----
static u8 g_img[2 * 1024 * 1024]; bool g_imgPresent = true; bool g_imgFail = false;
static bool img_read(u32 lba, u8* b) { if (g_imgFail || lba >= sizeof g_img / 512) return false; memcpy(b, g_img + lba * 512, 512); return true; }
static bool img_write(u32 lba, const u8* b) { if (g_imgFail || lba >= sizeof g_img / 512) return false; memcpy(g_img + lba * 512, b, 512); return true; }
unsigned char* host_img() { return g_img; }
bool blockdev_probe(BlockDev& o, bool* foreign) { if (foreign) *foreign = false; if (!g_imgPresent) { o.present = false; return false; }
    o.present = true; o.sectors = sizeof g_img / 512; o.read = img_read; o.write = img_write; scopy(o.name, "host RAM data disk (2 MiB)", sizeof o.name); return true; }

void host_disk_wipe() { memset(g_img, 0, sizeof g_img); }
void host_disk_corrupt(u32 lba) { g_img[(size_t)lba * 512 + 100] ^= 0x5A; }
void host_disk_present(bool p) { g_imgPresent = p; }
}
namespace mx {
// ---- fake SLIRP ----
static u8 q[8][1600]; static int ql[8]; static int qh = 0, qt = 0; bool g_fakeNicLink = true;
static const u8 GWMAC[6] = { 0x52, 0x55, 10, 0, 2, 2 };
static void put16(u8* p, u16 v) { p[0] = (u8)(v >> 8); p[1] = (u8)v; }
static u16 get16(const u8* p) { return (u16)((p[0] << 8) | p[1]); }
static void enqueue(const u8* f, int n) { memcpy(q[qh], f, (size_t)n); ql[qh] = n; qh = (qh + 1) % 8; }
static void reply_ip(const u8* eth, u8 proto, const u8* srcip, const u8* dstip, const u8* payload, int len) {
    u8 f[1600]; memcpy(f, eth + 6, 6); memcpy(f + 6, GWMAC, 6); put16(f + 12, 0x0800);
    u8* p = f + 14; p[0] = 0x45; p[1] = 0; put16(p + 2, (u16)(20 + len)); put16(p + 4, 7); put16(p + 6, 0); p[8] = 64; p[9] = proto; put16(p + 10, 0);
    memcpy(p + 12, srcip, 4); memcpy(p + 16, dstip, 4); put16(p + 10, ip_checksum(p, 20)); memcpy(p + 20, payload, (size_t)len); enqueue(f, 14 + 20 + len);
}
static bool fake_send(const u8* f, int len) {
    u16 type = get16(f + 12); const u8* p = f + 14;
    if (type == 0x0806 && get16(p + 6) == 1) {                                     // ARP who-has 10.0.2.2/3
        if (p[24] == 10 && p[25] == 0 && p[26] == 2 && (p[27] == 2 || p[27] == 3)) {
            u8 r[60]; memcpy(r, f + 6, 6); memcpy(r + 6, GWMAC, 6); put16(r + 12, 0x0806); u8* a = r + 14; put16(a, 1); put16(a + 2, 0x0800); a[4] = 6; a[5] = 4; put16(a + 6, 2);
            memcpy(a + 8, GWMAC, 6); memcpy(a + 14, p + 24, 4); memcpy(a + 18, p + 8, 6); memcpy(a + 24, p + 14, 4); memset(r + 42, 0, 18); enqueue(r, 60);
        }
    } else if (type == 0x0800) {
        int ihl = (p[0] & 15) * 4; const u8* pl = p + ihl; int pn = get16(p + 2) - ihl;
        if (p[9] == 1 && pl[0] == 8 && p[19] == 2) { u8 r[200]; memcpy(r, pl, (size_t)pn); r[0] = 0; put16(r + 2, 0); put16(r + 2, ip_checksum(r, pn)); reply_ip(f, 1, p + 16, p + 12, r, pn); }
        else if (p[9] == 6 && get16(pl + 2) == 80) {                                 // fake web server on port 80 (any address)
            static u32 ssq = 5000; u8 fl = pl[13]; u32 cseq = ((u32)pl[4] << 24) | ((u32)pl[5] << 16) | ((u32)pl[6] << 8) | pl[7]; int th = (pl[12] >> 4) * 4; int dl = pn - th; const u8* dd = pl + th;
            auto seg = [&](u8 flags, u32 sq, u32 ak, const char* data, int n) {
                u8 t[600]; memset(t, 0, 20); memcpy(t, pl + 2, 2); memcpy(t + 2, pl, 2);
                t[4] = (u8)(sq >> 24); t[5] = (u8)(sq >> 16); t[6] = (u8)(sq >> 8); t[7] = (u8)sq; t[8] = (u8)(ak >> 24); t[9] = (u8)(ak >> 16); t[10] = (u8)(ak >> 8); t[11] = (u8)ak;
                t[12] = 0x50; t[13] = flags; put16(t + 14, 8192); if (n) memcpy(t + 20, data, (size_t)n); reply_ip(f, 6, p + 16, p + 12, t, 20 + n); };
            if (fl & 2) seg(0x12, ssq, cseq + 1, "", 0);                                       // SYN -> SYN|ACK
            else if (dl > 0) {
                seg(0x10, ssq + 1, cseq + (u32)dl, "", 0);                                      // ACK the request
                const char* resp = "HTTP/1.0 200 OK\r\nServer: mX-fake\r\nContent-Length: 5\r\n\r\nhello"; if (!memcmp(dd, "HEAD", 4)) resp = "HTTP/1.0 200 OK\r\nServer: mX-fake\r\n\r\n";
                int rl = (int)strlen(resp); seg(0x18, ssq + 1, cseq + (u32)dl, resp, rl); seg(0x11, ssq + 1 + (u32)rl, cseq + (u32)dl, "", 0);   // data then FIN|ACK
            } else if (fl & 1) seg(0x10, ssq + 2, cseq + 1, "", 0);                              // client FIN -> ACK
        }
        else if (p[9] == 17 && get16(pl + 2) == 53) {                              // DNS: answer A 93.184.216.34 for anything
            const u8* d = pl + 8; int dn = pn - 8; u8 r[400]; memset(r, 0, sizeof r); put16(r, get16(d)); put16(r + 2, 0x8180); put16(r + 4, 1); put16(r + 6, 1);
            int qlen = dn - 12; memcpy(r + 12, d + 12, (size_t)qlen); int o = 12 + qlen; r[o++] = 0xC0; r[o++] = 12; put16(r + o, 1); put16(r + o + 2, 1); put16(r + o + 4, 0); put16(r + o + 6, 60); put16(r + o + 8, 4); o += 10;
            r[o++] = 93; r[o++] = 184; r[o++] = 216; r[o++] = 34;
            u8 u[420]; put16(u, 53); memcpy(u + 2, pl, 2); put16(u + 4, (u16)(8 + o)); put16(u + 6, 0); memcpy(u + 8, r, (size_t)o); u[2] = pl[0]; u[3] = pl[1]; put16(u, 53); put16(u + 2, get16(pl));
            reply_ip(f, 17, p + 16, p + 12, u, 8 + o);
        }
    }
    (void)len; return true;
}
static int fake_recv(u8* b, int max) { if (qt == qh) return 0; int n = ql[qt]; if (n > max) n = max; memcpy(b, q[qt], (size_t)n); qt = (qt + 1) % 8; return n; }
static bool fake_link() { return g_fakeNicLink; }
bool nic_probe(NicOps& o, bool& other) { other = false; o.send = fake_send; o.recv = fake_recv; o.link = fake_link; u8 m[6] = { 0x52, 0x54, 0, 0x12, 0x34, 0x56 }; memcpy(o.mac, m, 6); scopy(o.name, "Realtek RTL8139 Fast Ethernet (host fake)", 44); return true; }
}
