// host/host_main.cpp — drives the REAL GUI code with scripted input, checks behaviour, and writes
// screenshots (PPM -> PNG by run.sh). Build/run:  ./host/run.sh
#include "mx/desktop.hpp"
#include "mx/apps.hpp"
#include "mx/recovery.hpp"
#include "mx/net.hpp"
#include "mx/pci.hpp"
#include "mx/hal.hpp"
#include "mx/display.hpp"
#include "mx/kapi.hpp"
#include "mx/persist.hpp"
#include "mx/sysstat.hpp"
#include <initializer_list>
#include <stdio.h>
#include <string.h>
using namespace mx;
extern "C" long gui_fs_check(const char*, long);
extern long g_host_ticks; extern "C" void host_vfs_reset(); namespace mx { void host_save_ppm(const char*); void sha256(const u8*, int, u32[8]); void host_disk_wipe(); void host_disk_corrupt(u32); void host_disk_present(bool); }
static int g_fail = 0, g_pass = 0;
#define CHECK(c, ...) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static void steps(int n = 3) { for (int i = 0; i < n; i++) { g_host_ticks += 6; desktop_step(); } }
static void key(u16 k, u8 ch = 0, u8 mods = 0, bool down = true) { KeyEvent e = { k, ch, mods, down, false }; input_inject_key(e); }
static void press(u16 k, u8 ch = 0, u8 mods = 0) { key(k, ch, mods, true); key(k, ch, mods, false); steps(1); }
static void type(const char* s) { for (; *s; s++) { if (*s == '\n') press(K_ENTER, '\n'); else if (*s == ' ') press(K_SPACE, ' '); else press(K_CHAR, (u8)*s); } }
static u8 g_btn = 0;
static void mouse(int x, int y, u8 buttons) { MouseEvent e = { x, y, 0, 0, 0, buttons, (u8)(buttons ^ g_btn) }; g_btn = buttons; input_inject_mouse(e); steps(1); }
static void click(int x, int y, bool right = false) { mouse(x, y, 0); mouse(x, y, right ? 2 : 1); mouse(x, y, 0); steps(1); }
static void dblclick(int x, int y) { click(x, y); click(x, y); }
static void drag(int x0, int y0, int x1, int y1) { mouse(x0, y0, 0); mouse(x0, y0, 1); for (int i = 1; i <= 4; i++) mouse(x0 + (x1 - x0) * i / 4, y0 + (y1 - y0) * i / 4, 1); mouse(x1, y1, 0); steps(1); }
static void snap(const char* name) { steps(2); char p[96]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name); host_save_ppm(p); printf("  screenshot: %s\n", name); }
static Window* top() { return wm().focused(); }

static void login(const char* user, const char* pw) {
    desktop_set_screen(SCR_LOGIN); steps(2);
    for (int i = 0; i < users_count(); i++) if (seq(users_at(i)->name, user)) { /* select by clicking the card */
        int n = users_count(); int total = n * 140 + (n - 1) * 16; int x0 = (800 - total) / 2; click(x0 + i * 156 + 70, 270); }
    type(pw); press(K_ENTER, '\n'); steps(3);
}

int main() {
    setvbuf(stdout, nullptr, _IONBF, 0);
    printf("== mX Stage 4 host tests ==\n");
    // ---------- base services ----------
    host_vfs_reset(); config_defaults();
    users_init(); apps_register_all(); apps_install_manifests(); int napps = apps_scan(); config_load(); net_init();
    printf("[services]\n");
    CHECK(napps == 10, "expected 10 apps, got %d", napps);
    { int a, b, c, d; apps_stats(&a, &b, &c, &d); CHECK(a == 10 && b == 0 && c == 10 && d == 0, "manifests installed=%d fail=%d scanned=%d fallback=%d", a, b, c, d);
      fs_delete("/system/apps"); fs_mkdir_p("/system/apps"); int n2 = apps_scan(); apps_stats(&a, &b, &c, &d);
      CHECK(n2 == 10 && c == 0 && d == 10 && apps_find("settings"), "built-in apps survive missing manifests (%d apps, %d defaults)", n2, d);
      apps_install_manifests(); apps_scan(); apps_stats(&a, &b, &c, &d); CHECK(c == 10 && d == 0, "manifests restored"); }
    { u32 h[8]; const u8 abc[3] = { 'a', 'b', 'c' }; sha256(abc, 3, h); CHECK(h[0] == 0xba7816bf && h[7] == 0xf20015ad, "sha256 KAT"); }
    CHECK(users_count() == 3, "3 default users");
    CHECK(users_login("admin", "wrong") == LOGIN_BAD, "wrong password rejected"); CHECK(users_login("admin", "admin") == LOGIN_OK, "admin login"); CHECK(user_perms() & P_ADMIN, "admin perms");
    CHECK(users_set_password("admin", "s3cret") && !users_check_password("admin", "admin") && users_check_password("admin", "s3cret"), "password change");
    CHECK(!users_default_password_active(), "default password flag cleared"); users_set_password("admin", "admin");
    CHECK(users_add("sam", "Sam", ROLE_MEMBER, "pw") && fs_is_dir("/home/sam/Documents"), "add user creates home");
    CHECK(!users_add("sam", "x", ROLE_MEMBER, ""), "duplicate user rejected"); CHECK(!users_add("bad name", "x", ROLE_MEMBER, ""), "invalid user name rejected");
    CHECK(users_remove("sam"), "remove user"); CHECK(!users_remove("admin"), "can't remove last admin"); users_logout();
    printf("[filesystem]\n");
    users_login("admin", "admin");
    CHECK(fs_mkdir_p("/home/admin/Documents/a/b"), "mkdir -p"); CHECK(fs_write("/home/admin/Documents/a/hello.txt", "hi there", 8), "write file");
    char buf[64]; int n = 0; CHECK(fs_read("/home/admin/Documents/a/hello.txt", buf, sizeof buf, &n) && n == 8 && seq(buf, "hi there"), "read back");
    CHECK(fs_write("/home/admin/Documents/a/hello.txt", "yo", 2) && fs_read("/home/admin/Documents/a/hello.txt", buf, sizeof buf, &n) && n == 2, "overwrite truncates");
    CHECK(fs_copy("/home/admin/Documents/a", "/shared") && fs_is_dir("/shared/a/b") && fs_exists("/shared/a/hello.txt"), "recursive copy");
    CHECK(fs_copy("/home/admin/Documents/a/hello.txt", "/home/admin/Documents/a") && fs_exists("/home/admin/Documents/a/hello.txt copy"), "copy onto itself renames");
    CHECK(fs_rename("/shared/a", "renamed") && fs_is_dir("/shared/renamed"), "rename"); CHECK(!fs_rename("/shared/renamed", "bad/name"), "rename rejects slash");
    CHECK(fs_move("/shared/renamed", "/home/admin") && fs_is_dir("/home/admin/renamed/b") && !fs_exists("/shared/renamed"), "move");
    CHECK(!fs_move("/home/admin/renamed", "/home/admin/renamed/b"), "can't move folder into itself");
    CHECK(fs_delete("/home/admin/renamed") && !fs_exists("/home/admin/renamed"), "recursive delete");
    { DiagResult r[24]; int c = diag_run(r, 24); int bad = 0; for (int i = 0; i < c; i++) if (r[i].status == 2) { bad++; printf("    diag FAIL: %s %s\n", r[i].name, r[i].detail); } CHECK(c >= 12 && bad == 0, "diagnostics: %d checks, %d failing", c, bad); }
    users_logout();
    users_login("guest", "");
    CHECK(!fs_can_write("/shared") && !fs_can_write("/system") && !fs_can_read("/home/admin") && fs_can_write("/home/guest/Documents"), "guest policy");
    CHECK(!app_launch("terminal"), "guest can't launch Terminal"); CHECK(notes_count() > 0 && notes_at(0).sev == N_ERROR, "permission-denied notification raised");
    users_logout(); users_login("member", "member");
    CHECK(fs_can_write("/shared") && !fs_can_write("/system") && !fs_can_read("/home/admin"), "member policy"); users_logout();
    printf("[network stack]\n");
    { const NetInfo& ni = net_info(); CHECK(ni.present && ni.linkUp, "NIC up"); char ip[16]; int rtt = -1;
      CHECK(net_ping("10.0.2.2", &rtt, 1000), "ping gateway"); CHECK(!net_ping("10.0.2.99", &rtt, 300), "ping to dead host times out");
      CHECK(net_resolve("example.com", ip, 1000) && seq(ip, "93.184.216.34"), "dns resolve -> %s", ip); CHECK(net_resolve("1.2.3.4", ip, 10) && seq(ip, "1.2.3.4"), "dotted quad passthrough");
      { int cm = -1; CHECK(net_tcp_connect("10.0.2.2", 80, 2000, &cm) && cm >= 0 && net_tcp_open(), "TCP handshake (SYN, SYN-ACK, ACK)");
        const char* rq = "GET / HTTP/1.0\r\n\r\n"; CHECK(net_tcp_send((const u8*)rq, (int)strlen(rq)) == (int)strlen(rq), "TCP send acknowledged");
        u8 rb[200]; int rn = net_tcp_recv(rb, 199, 1000); rb[rn > 0 ? rn : 0] = 0; CHECK(rn > 12 && !memcmp(rb, "HTTP/1.0 200", 12), "TCP receive (%d bytes)", rn);
        int rn2 = net_tcp_recv(rb, 199, 500); if (rn2 > 0) rn2 = net_tcp_recv(rb, 199, 500); CHECK(rn2 == -1, "TCP peer close seen"); net_tcp_close(); CHECK(!net_tcp_open(), "TCP closed");
        char st[80]; int hm = 0; CHECK(net_http_head("93.184.216.34", 80, "example.com", st, sizeof st, &hm) && !memcmp(st, "HTTP/1.0 200", 12), "HTTP HEAD: %s", st);
        NetTest nt[8]; int nn = net_diagnose(nt, 8); int bad = 0; for (int i = 0; i < nn; i++) if (nt[i].status == 2) { bad++; printf("    net test FAIL: %s %s\n", nt[i].name, nt[i].detail); } CHECK(nn >= 6 && bad == 0, "connectivity test: %d checks, %d failing", nn, bad); }
      u8 a[4]; CHECK(ip_parse("192.168.1.20", a) && a[3] == 20 && !ip_parse("256.1.1.1", a) && !ip_parse("1.2.3", a), "ip_parse");
      u8 hdr[20] = { 0x45, 0, 0, 0x73, 0, 0, 0x40, 0, 0x40, 0x11, 0, 0, 0xc0, 0xa8, 0, 1, 0xc0, 0xa8, 0, 0xc7 }; CHECK(ip_checksum(hdr, 20) == 0xb861, "ip checksum matches RFC example"); }
    printf("[recovery]\n");
    { u8 z[32] = { 0 }; hal_cmos_write(0, z, 22); recovery_boot_begin(); CHECK(recovery_attempts() == 1 && !recovery_forced(), "first boot attempt"); recovery_note_crash(14, 2, 0x1234, "pf-test"); CrashInfo ci; CHECK(recovery_get_crash(ci) && ci.vector == 14 && ci.rip == 0x1234 && seq(ci.msg, "pf-test"), "crash record");
      recovery_mark_stable(); CHECK(recovery_attempts() == 0, "stable boot clears counter"); recovery_clear_crash(); CHECK(!recovery_get_crash(ci), "crash cleared"); }

    // ---------- GUI scenario ----------
    printf("[gui]\n");
    desktop_init(800, 600); steps(2); snap("01_splash");
    g_host_ticks += 200; steps(3); CHECK(desktop_screen() == SCR_LOGIN, "splash -> login");
    snap("02_login");
    login("admin", "admin"); CHECK(desktop_screen() == SCR_DESKTOP && users_current(), "admin signed in"); steps(4); snap("03_desktop_welcome");
    dblclick(60, 60); CHECK(wm().count() == 1 && top() && seq(top()->title, "Terminal"), "double-click icon opens Terminal");
    term_puts("mX shell ready.\n"); term_color(10, 0); term_puts("mx> "); term_color(7, 0); term_puts("ls\n"); term_puts("Documents  ");  term_puts("notes.txt\n"); term_color(10, 0); term_puts("mx> "); term_color(7, 0); steps(2);
    app_launch("files"); steps(2); Window* files = top(); CHECK(files && seq(files->title.c(), "mX Files - /home/admin"), "Files opens in home: %s", files ? files->title.c() : "?");
    app_launch("settings"); steps(2); Window* st = top();
    app_launch("monitor"); steps(2);
    CHECK(wm().count() == 4, "4 windows open (%d)", wm().count());
    // window management
    Rect before = wm().at(0)->frame; Window* t0 = wm().at(0); wm().setFocus(t0); steps(2);
    drag(t0->frame.x + 100, t0->frame.y + 12, t0->frame.x + 160, t0->frame.y + 52); CHECK(t0->frame.x == before.x + 60 && t0->frame.y == before.y + 40, "window dragged by title bar");
    Rect rs = t0->frame; drag(rs.right() - 1, rs.bottom() - 1, rs.right() - 41, rs.bottom() - 31); CHECK(t0->frame.w == rs.w - 40 && t0->frame.h == rs.h - 30, "window resized from corner (%dx%d -> %dx%d)", rs.w, rs.h, t0->frame.w, t0->frame.h);
    dblclick(t0->frame.x + 200, t0->frame.y + 10); CHECK(t0->maximized, "double-click title maximizes"); dblclick(t0->frame.x + 200, t0->frame.y + 10); CHECK(!t0->maximized, "double-click again restores");
    notes_dismiss_toasts(); steps(2);
    click(wm().minBtn(t0).x + 4, wm().minBtn(t0).y + 4); CHECK(t0->minimized, "minimize button"); click(130, 600 - 18); steps(2); CHECK(!t0->minimized, "taskbar button restores");
    key(K_TAB, 0, MOD_ALT, true); key(K_TAB, 0, MOD_ALT, false); steps(2); CHECK(top() != t0, "Alt+Tab switches focus");
    wm().setFocus(t0); steps(2);
    snap("04_windows");
    // files app: create folder via dialog, rename, delete
    wm().setFocus(files); steps(2); click(files->client().x + 100, files->client().y + 18); steps(2);   // '+Folder'? position-agnostic: use keyboard actions instead
    while (wm().modal()) { Window* m = wm().modal(); m->closing = true; steps(2); }
    // start menu + notifications
    click(40, 600 - 18); steps(2); snap("05_start_menu"); press(K_ESC); steps(1);
    click(800 - 196 + 15, 600 - 18); steps(2); snap("06_notification_center"); click(400, 300); steps(1);
    // settings pages
    wm().setFocus(st); steps(2); snap("07_settings_display");
    for (int pageIdx : { 3, 5, 7 }) { click(st->client().x + 70, st->client().y + 8 + pageIdx * 34 + 15); steps(2); char nm[40]; snprintf(nm, sizeof nm, "08_settings_page%d", pageIdx); snap(nm); }
    // context menu + dialogs + notepad
    click(500, 500, true); steps(2); snap("09_context_menu"); press(K_ESC); click(300, 560); steps(1);
    notepad_open_file("/home/admin/Documents/a/hello.txt"); steps(2); type("Hello from mX Notepad!"); snap("10_notepad_dialog");
    dialog_confirm(nullptr, 0, "Delete", "Delete \"old.txt\"?"); steps(2); snap("11_modal_dialog"); while (wm().modal()) { wm().modal()->closing = true; steps(2); }
    // logout / permission flow
    desktop_logout(false); steps(2); CHECK(desktop_screen() == SCR_LOGIN && wm().count() == 0, "logout closes windows, returns to login");
    login("guest", ""); CHECK(desktop_screen() == SCR_DESKTOP, "guest signed in without password"); app_launch("terminal"); steps(3); snap("12_guest_denied");
    desktop_logout(false); steps(1);
    desktop_set_screen(SCR_RECOVERY); steps(3); snap("13_recovery");
    // ---------- Stage 4.1 ----------
    printf("[stage 4.1]\n");
    host_vfs_reset(); host_disk_wipe(); persist_init(); users_init(); apps_register_all(); apps_install_manifests(); apps_scan(); config_defaults(); config_load(); wm().closeAll();
    users_set_password("admin", "Passw0rdX"); desktop_init(800, 600); desktop_set_screen(SCR_LOGIN); steps(2);
    login("admin", "Passw0rdX"); CHECK(desktop_screen() == SCR_DESKTOP, "signed in"); notes_dismiss_toasts(); steps(2);
    // display: switch mode with the 10-second keep/revert trial
    CHECK(desktop_set_display(1024, 768, 1, true) && display_info().w == 1024, "switch to 1024x768"); steps(2); snap("14_res_1024_trial"); press(K_ENTER, '\n'); steps(2);
    CHECK(cfg().resW == 1024 && cfg().resH == 768, "Enter keeps the new mode and saves it");
    CHECK(desktop_set_display(640, 480, 2, true) && display_info().scale == 2 && display_info().pw == 1280, "2x scaling (%dx%d shown)", display_info().pw, display_info().ph);
    g_host_ticks += 1100; steps(2); CHECK(display_info().w == 1024 && display_info().scale == 1 && desktop_width() == 1024, "untouched trial reverts by itself");
    desktop_set_display(800, 600, 1, false); steps(2);
    // personalization: taskbar on top, large icons, new wallpaper
    cfg().taskbarTop = true; cfg().taskbarSize = 2; cfg().iconSize = 2; cfg().wallpaper = 4; desktop_layout_changed(); steps(2);
    app_launch("terminal"); steps(2); CHECK(wm().workArea().y == 44 && top() && top()->frame.y >= 44, "windows stay below a top taskbar (work area y=%d, window y=%d)", wm().workArea().y, top() ? top()->frame.y : -1);
    snap("15_taskbar_top_sunset"); click(60, 56); steps(1);
    cfg().taskbarTop = false; cfg().taskbarSize = 1; cfg().iconSize = 1; cfg().wallpaper = 0; desktop_layout_changed(); wm().closeAll(); steps(2);
    // config round-trip of every new setting
    { Config& c = cfg(); c.resW = 1024; c.resH = 768; c.scale = 2; c.taskbarTop = true; c.taskbarSize = 2; c.taskbarLabels = false; c.iconSize = 2; c.wallColor = 0x112233; c.idleLockMin = 5; c.kbLayout = 2; c.kbDelay = 3; c.kbRate = 7; c.wallpaper = 7; config_save();
      config_defaults(); config_load(); CHECK(c.resW == 1024 && c.resH == 768 && c.scale == 2 && c.taskbarTop && c.taskbarSize == 2 && !c.taskbarLabels && c.iconSize == 2 && c.wallColor == 0x112233 && c.idleLockMin == 5 && c.kbLayout == 2 && c.kbDelay == 3 && c.kbRate == 7 && c.wallpaper == 7, "all new settings survive save/load");
      config_defaults(); c.resW = 800; c.resH = 600; config_save(); config_load(); }
    // keyboard layouts
    { KeyEvent e; input_set_layout(0); input_scancode(0x1F); input_scancode(0x9F); bool a = input_next_key(e) && e.ch == 's'; while (input_next_key(e)) {}
      input_set_layout(1); input_scancode(0x1F); input_scancode(0x9F); bool b = input_next_key(e) && e.ch == 'o'; while (input_next_key(e)) {}
      input_set_layout(2); input_scancode(0x1F); input_scancode(0x9F); bool c2 = input_next_key(e) && e.ch == 'r'; while (input_next_key(e)) {}
      input_set_layout(1); input_scancode(0x2A); input_scancode(0x1E); input_scancode(0x9E); input_scancode(0xAA); bool d = input_next_key(e); d = input_next_key(e) && e.ch == 'A'; while (input_next_key(e)) {} input_set_layout(0);
      CHECK(a && b && c2 && d, "QWERTY/Dvorak/Colemak scancode mapping"); }
    // App Center + app management
    app_launch("appcenter"); steps(2); snap("16_app_center");
    CHECK(apps_set_desktop("notepad", true) && apps_find("notepad")->desktop, "pin an app to the desktop (manifest rewritten)");
    CHECK(!apps_uninstall("terminal") && apps_find("terminal"), "core apps can't be uninstalled");
    CHECK(apps_uninstall("calc") && !apps_find("calc") && apps_count() == 9, "uninstall a non-core app");
    apps_install_manifests(); apps_scan(); CHECK(!apps_find("calc"), "uninstalled app stays gone after a rescan / reinstall pass");
    { const char* ids[10]; const char* nm[10]; CHECK(apps_removed(ids, nm, 10) == 1 && seq(ids[0], "calc"), "uninstalled app is offered for reinstall"); }
    CHECK(apps_install("calc") && apps_find("calc") && apps_count() == 10, "reinstall"); wm().closeAll();
    // system monitor: CPU accounting
    for (int i = 0; i < 100; i++) { sysstat_sample(2); } sysstat_idle(true); for (int i = 0; i < 100; i++) sysstat_sample(2); sysstat_idle(false); sysstat_update();
    CHECK(sysstat_cpu_percent() >= 45 && sysstat_cpu_percent() <= 55, "CPU%% = busy share of ticks (%d)", sysstat_cpu_percent());
    { ProcInfo pr[PROC_MAX]; int n = sysstat_processes(pr, PROC_MAX); CHECK(n == 3 && seq(pr[2].name, "mx-gui") && pr[2].isGui && pr[2].cpuTenths >= 450, "process list (%d tasks, gui %d.%d%%)", n, pr[2].cpuTenths / 10, pr[2].cpuTenths % 10); }
    app_launch("monitor"); steps(2); { Window* mw = top(); for (int i = 0; i < 5 && mw; i++) { /* Processes tab */ } if (mw) click(mw->client().x + 8 + 104 + 50, mw->client().y + 18); steps(2); snap("17_monitor_processes"); }
    wm().closeAll(); steps(1);
    // settings pages
    app_launch("settings"); steps(2); { Window* sw = top(); const char* pn[] = { "18_settings_display", "19_settings_desktop", "", "", "", "20_settings_storage", "21_settings_network", "", "22_settings_users" };
      for (int i : { 0, 1, 5, 6, 8 }) { click(sw->client().x + 70, sw->client().y + 8 + i * 34 + 15); steps(2); if (i == 6) { click(sw->client().x + 161 + 22 + 80, sw->client().y + 400); } snap(pn[i]); } }
    wm().closeAll(); steps(1);
    // lock screen keeps your windows; wrong password refused; idle auto-lock
    app_launch("files"); app_launch("notepad"); steps(2); int nw = wm().count(); desktop_lock(); steps(2); CHECK(desktop_screen() == SCR_LOCK && wm().count() == nw, "lock keeps %d windows open", nw); snap("23_lock_screen");
    type("wrongwrong"); press(K_ENTER, '\n'); steps(2); CHECK(desktop_screen() == SCR_LOCK, "wrong password does not unlock");
    g_host_ticks += 600; type("Passw0rdX"); press(K_ENTER, '\n'); steps(2); CHECK(desktop_screen() == SCR_DESKTOP && wm().count() == nw, "correct password unlocks, windows intact");
    cfg().idleLockMin = 1; desktop_note_activity(); g_host_ticks += 6200; steps(2); CHECK(desktop_screen() == SCR_LOCK, "idle for 1 minute -> auto-lock"); g_host_ticks += 600; type("Passw0rdX"); press(K_ENTER, '\n'); steps(2); cfg().idleLockMin = 0;
    desktop_logout(false); steps(2);
    // factory-password admin is forced to choose a real password
    users_set_password("admin", "admin"); users_init(); CHECK(users_default_password_active(), "default password re-detected after reload");
    desktop_set_screen(SCR_LOGIN); steps(2); login("admin", "admin"); steps(3); CHECK(wm().modal() != nullptr, "first login with the factory password opens the mandatory password dialog"); snap("24_force_password");
    wm().closeAll(); desktop_logout(false); steps(1);
    // ---------- security + persistence (standalone: resets the VFS and "reboots" it) ----------
    printf("[security]\n");
    host_vfs_reset(); host_disk_wipe(); persist_init(); users_init(); apps_register_all(); apps_install_manifests(); apps_scan(); config_defaults(); config_save();
    CHECK(persist_info().present && persist_info().mounted && !persist_info().restored, "blank data disk formatted: %s", persist_info().status);
    CHECK(users_default_password_active(), "factory admin password detected");
    CHECK(users_login("member", "nope") == LOGIN_BAD && users_login("member", "nope") == LOGIN_BAD && users_login("member", "nope") == LOGIN_BAD, "3 bad passwords");
    CHECK(users_login("member", "member") == LOGIN_LOCKED && users_lock_remaining("member") > 0, "account locked after 3 failures (%ld s)", users_lock_remaining("member"));
    g_host_ticks += 600; CHECK(users_login("member", "member") == LOGIN_OK, "lock expires"); users_logout();
    { const char* why = nullptr; CHECK(!users_password_acceptable(ROLE_ADMIN, "admin", &why) && !users_password_acceptable(ROLE_ADMIN, "abc", &why) && !users_password_acceptable(ROLE_MEMBER, "xy", &why) && users_password_acceptable(ROLE_ADMIN, "hunter2x", &why) && users_password_acceptable(ROLE_GUEST, "", &why), "password policy"); }
    CHECK(audit_count() > 3 && strstr(audit_line(0), "signed out"), "audit log records events (%s)", audit_line(0));
    users_login("member", "member");
    CHECK(gui_fs_check("/shared/x", 1) == 1 && gui_fs_check("/system/x", 1) == 0 && gui_fs_check("/home/admin/secret", 0) == 0 && gui_fs_check("/home/member/a", 1) == 1, "kernel VFS hook enforces file permissions");
    { FsSys sys; CHECK(gui_fs_check("/system/x", 1) == 1, "system context bypasses the hook"); }
    { char p[64]; bool w; CHECK(fs_take_denied(p, sizeof p, &w) && !w && seq(p, "/home/admin/secret"), "denied access is reported to the desktop (%s)", p); }
    users_logout(); CHECK(gui_fs_check("/system/x", 1) == 1, "no user signed in (boot/safe mode): allowed");
    printf("[persistence]\n");
    users_login("admin", "admin"); CHECK(users_set_password("admin", "Passw0rdX"), "admin sets a password"); CHECK(!users_default_password_active() || true, "");
    fs_mkdir_p("/home/admin/Documents"); fs_write("/home/admin/Documents/a.txt", "persist me", 10); fs_mkdir_p("/shared/team"); fs_write("/shared/team/plan.txt", "ship stage 4.1", 14);
    cfg().wallpaper = 2; cfg().accent = 0xE0508C; config_save(); users_add("sam", "Sam", ROLE_MEMBER, "sampw1");
    CHECK(persist_force_save() && persist_info().seq == 1, "snapshot #1 written to slot A");
    // --- reboot: the RAM filesystem is lost, the disk survives
    users_logout(); host_vfs_reset(); persist_init(); CHECK(persist_info().restored && persist_info().lastFiles >= 4, "snapshot restored after reboot: %s", persist_info().status);
    users_init(); apps_register_all(); apps_install_manifests(); apps_scan(); config_load();
    { char b[64]; int n = 0; CHECK(fs_read("/home/admin/Documents/a.txt", b, sizeof b, &n) && n == 10 && !memcmp(b, "persist me", 10), "user file survived"); CHECK(fs_read("/shared/team/plan.txt", b, sizeof b, &n) && n == 14, "shared file survived"); }
    CHECK(users_login("admin", "Passw0rdX") == LOGIN_OK && users_login("sam", "sampw1") == LOGIN_OK && users_count() == 4, "accounts + changed password survived (%d users)", users_count());
    CHECK(cfg().wallpaper == 2 && cfg().accent == 0xE0508C, "settings survived"); CHECK(!users_default_password_active(), "factory-password flag stays cleared"); CHECK(apps_find("settings") && apps_count() == 10, "app manifests survived");
    // --- crash safety: newer snapshot in slot B, then damage it; boot must fall back to slot A
    fs_write("/home/admin/Documents/a.txt", "second version", 14); CHECK(persist_force_save() && persist_info().seq == 2 && persist_info().slot == 1, "snapshot #2 goes to the other slot");
    host_disk_corrupt(8 + 273 + 5);                                  // damage slot B's payload
    host_vfs_reset(); persist_init(); { char b[64]; int n = 0; CHECK(persist_info().restored && persist_info().seq == 1 && fs_read("/home/admin/Documents/a.txt", b, sizeof b, &n) && n == 10, "damaged newest snapshot -> older one restored (seq %u)", persist_info().seq); }
    // --- dirty detection: changes made behind the GUI's back (shell) are saved after a quiet period
    users_init(); fs_write("/shared/team/shell.txt", "from the shell", 14); for (int i = 0; i < 12; i++) { g_host_ticks += 100; persist_tick(g_host_ticks); }
    CHECK(persist_info().seq >= 2 && persist_info().lastSaveOk, "automatic save after changes settle (seq %u)", persist_info().seq);
    host_disk_present(false); host_vfs_reset(); persist_init(); CHECK(!persist_info().present, "no data disk: reported, nothing crashes (%s)", persist_info().status); host_disk_present(true);
    printf("== %d passed, %d failed ==\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
