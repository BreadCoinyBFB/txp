// host/fake_kernel.cpp — a PC-side stand-in for Kernel24 so the real GUI code can be built, driven
// with scripted input, and screenshotted without QEMU. It mirrors fs/vfs.cx closely enough that the
// GUI's filesystem layer exercises the same semantics (single 512-byte block per file, 128 inodes).
#include "mx/kapi.hpp"
#include "mx/hal.hpp"
#include "mx/display.hpp"
#include "mx/pci.hpp"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
using namespace mx;

extern "C" {
Inode inode_table[VFS_MAX_INODES];
long vfs_cwd = 0; long system_memory_kb = 131072;
struct FakeTask { int id, state; long rsp, kstack, pml4; unsigned char isUser, pad[3]; int exitCode; const char* name; };
FakeTask task_table[16] = { { 1, 1, 0x200000 - 9000, 0x200000, 0, 0, {0}, 0, "idle" }, { 2, 1, 0x300000 - 4200, 0x300000, 0, 0, {0}, 0, "shell" }, { 3, 2, 0x400000 - 6000, 0x400000, 0, 0, {0}, 0, "mx-gui" } };
int current_task = 2;
static char g_disk[256][512]; static bool g_used[256];
static struct Fd { bool in_use; int inode, offset; } g_fd[16];

long kmalloc(long n) { return (long)malloc((size_t)n); }
void kfree(long p) { free((void*)p); }
long pmm_free_pages() { return 1000; } long pmm_total_pages() { return 2048; } long heap_free_bytes() { return 1500000; }
long sys_yield() { return 0; } long sys_exit(long) { return 0; }
long task_create(long, const char*) { return 5; } long task_kill(long) { return 1; } long task_current_pid() { return 3; }
long timer_ticks() { extern long g_host_ticks; return g_host_ticks; }
long timer_uptime_seconds() { return timer_ticks() / 100; }
long vmm_map(long, long, long) { return 1; }
void shell_main() {}

long storage_alloc_block() { for (int i = 0; i < 256; i++) if (!g_used[i]) { g_used[i] = true; return i; } return -1; }
void storage_read_block(long b, char* buf) { memcpy(buf, g_disk[b], 512); }
void storage_write_block(long b, char* buf) { memcpy(g_disk[b], buf, 512); }
static void vfs_reset() {
    memset(inode_table, 0, sizeof inode_table); memset(g_used, 0, sizeof g_used); memset(g_fd, 0, sizeof g_fd);
    inode_table[0].inode_type = 2; inode_table[0].name = "/"; inode_table[0].parent = -1; inode_table[0].first_child = -1; inode_table[0].next_sibling = -1; inode_table[0].block = -1;
}
void host_vfs_reset() { vfs_reset(); }
static int find_child(int dir, const char* name) {
    if (dir < 0 || inode_table[dir].inode_type != 2) return -1;
    for (int c = inode_table[dir].first_child; c != -1; c = inode_table[c].next_sibling) if (!strcmp(inode_table[c].name, name)) return c;
    return -1;
}
long vfs_resolve_path(const char* path) {
    int cur = path[0] == '/' ? 0 : (int)vfs_cwd; const char* p = path;
    while (*p) {
        while (*p == '/') p++;
        if (!*p) break;
        char comp[64]; int k = 0; while (*p && *p != '/' && k < 63) comp[k++] = *p++; comp[k] = 0;
        cur = find_child(cur, comp); if (cur < 0) return -1;
    }
    return cur;
}
static int create(int dir, const char* name, int type) {
    if (dir < 0 || inode_table[dir].inode_type != 2 || find_child(dir, name) != -1) return -1;
    int slot = -1; for (int i = 0; i < VFS_MAX_INODES; i++) if (inode_table[i].inode_type == 0) { slot = i; break; }
    if (slot < 0) return -1;
    inode_table[slot].inode_type = type; inode_table[slot].name = strdup(name); inode_table[slot].parent = dir; inode_table[slot].first_child = -1;
    inode_table[slot].next_sibling = inode_table[dir].first_child; inode_table[slot].block = -1; inode_table[slot].size = 0; inode_table[dir].first_child = slot;
    return slot;
}
static long make(const char* path, int type) {
    char parent[128]; strncpy(parent, path, 127); parent[127] = 0;
    char* slash = strrchr(parent, '/'); char name[64]; int dir;
    if (slash) { strncpy(name, slash + 1, 63); name[63] = 0; if (slash == parent) parent[1] = 0; else *slash = 0; dir = (int)vfs_resolve_path(parent); }
    else { strncpy(name, path, 63); name[63] = 0; dir = (int)vfs_cwd; }
    return create(dir, name, type) >= 0;
}
long vfs_mkdir(const char* p) { return make(p, 2); }
long vfs_create_file(const char* p) { return make(p, 1); }
long vfs_open(const char* p) {
    int i = (int)vfs_resolve_path(p); if (i < 0 || inode_table[i].inode_type != 1) return -1;
    for (int f = 0; f < 16; f++) if (!g_fd[f].in_use) { g_fd[f] = { true, i, 0 }; return f; }
    return -1;
}
long vfs_close(long fd) { if (fd >= 0 && fd < 16) g_fd[fd].in_use = false; return 0; }
long vfs_read(long fd, char* buf, long max) {
    if (fd < 0 || fd >= 16 || !g_fd[fd].in_use) return -1; Inode& n = inode_table[g_fd[fd].inode];
    if (n.block == -1) return 0; int rem = n.size - g_fd[fd].offset; if (rem <= 0) return 0; if (rem > max) rem = (int)max;
    memcpy(buf, g_disk[n.block] + g_fd[fd].offset, (size_t)rem); g_fd[fd].offset += rem; return rem;
}
long vfs_write(long fd, const char* buf, long len) {
    if (fd < 0 || fd >= 16 || !g_fd[fd].in_use) return -1; Inode& n = inode_table[g_fd[fd].inode];
    if (n.block == -1) { int b = -1; for (int i = 0; i < 256; i++) if (!g_used[i]) { b = i; break; } if (b < 0) return -1; g_used[b] = true; n.block = b; n.size = 0; }
    int space = 512 - g_fd[fd].offset; if (space <= 0) return 0; int w = len > space ? space : (int)len;
    memcpy(g_disk[n.block] + g_fd[fd].offset, buf, (size_t)w); g_fd[fd].offset += w; if (g_fd[fd].offset > n.size) n.size = g_fd[fd].offset; return w;
}
long vfs_unlink(const char* p) {
    int i = (int)vfs_resolve_path(p); if (i <= 0) return 0; int par = inode_table[i].parent;
    if (inode_table[i].block != -1) g_used[inode_table[i].block] = false;
    if (inode_table[par].first_child == i) inode_table[par].first_child = inode_table[i].next_sibling;
    else { int c = inode_table[par].first_child; while (c != -1 && inode_table[c].next_sibling != i) c = inode_table[c].next_sibling; if (c != -1) inode_table[c].next_sibling = inode_table[i].next_sibling; }
    inode_table[i].inode_type = 0; return 1;
}
}

// ---------------- HAL ----------------
long g_host_ticks = 1000;
static u8 g_cmos[64];
namespace mx {
long hal_ticks() { return g_host_ticks; }
void hal_yield() { g_host_ticks++; }
void hal_reboot() { fprintf(stderr, "[host] reboot\n"); }
void hal_poweroff() { fprintf(stderr, "[host] poweroff\n"); }
void hal_log(const char* s) { fputs(s, stderr); }
void hal_rtc_read(RtcTime& t) { long s = g_host_ticks / 100; t = { 2026, 10, 12, (int)(10 + s / 3600) % 24, (int)(30 + s / 60) % 60, (int)(s % 60), 1 }; }
bool hal_rtc_write(const RtcTime&) { return true; }
void hal_cmos_read(int o, u8* out, int n) { memcpy(out, g_cmos + o, (size_t)n); }
void hal_cmos_write(int o, const u8* in, int n) { memcpy(g_cmos + o, in, (size_t)n); }
void hal_cpu_vendor(char* o) { strcpy(o, "GenuineIntel"); }
void hal_cpu_brand(char* o) { strcpy(o, "QEMU Virtual CPU version 2.5+"); }
u64 hal_free_mem_kb() { return 3900; } u64 hal_total_mem_kb() { return 131072; } u64 hal_heap_free() { return 1500000; }

// ---------------- display (framebuffer in RAM) ----------------
static u32 g_fb[1024 * 768]; static DisplayInfo g_di = { true, 800, 600, 1024, g_fb, 0, "Host framebuffer", 800, 600, 1, true };
void display_set_bootinfo(u64, int, int, int, int) {}
bool display_init(int, int) { return true; }
const DisplayInfo& display_info() { return g_di; }
bool display_set_mode(int w, int h, int scale) { if (w > 1024 || h > 768 || w < 320 || h < 200 || (scale != 1 && scale != 2)) return false; g_di.w = w; g_di.h = h; g_di.pw = w * scale; g_di.ph = h * scale; g_di.scale = scale; memset(g_fb, 0, sizeof g_fb); return true; }
bool fwcfg_display_request(int*, int*, int*) { return false; }
void display_present_block(const u32* src, int sp, int dx, int dy, int w, int h) { for (int y = 0; y < h; y++) memcpy(g_fb + (dy + y) * 1024 + dx, src + y * sp, (size_t)w * 4); }
void display_present(const u32* s, int sp, const Rect& r0) { Rect r = r0.intersect(Rect{ 0, 0, g_di.w, g_di.h }); if (!r.empty()) display_present_block(s + r.y * sp + r.x, sp, r.x, r.y, r.w, r.h); }
void display_text_mode() {}
void host_save_ppm(const char* path) {
    FILE* f = fopen(path, "wb"); fprintf(f, "P6\n%d %d\n255\n", g_di.w, g_di.h);
    for (int y = 0; y < g_di.h; y++) for (int x = 0; x < g_di.w; x++) { u32 p = g_fb[y * 1024 + x]; u8 rgb3[3] = { (u8)(p >> 16), (u8)(p >> 8), (u8)p }; fwrite(rgb3, 1, 3, f); }
    fclose(f);
}
}
extern "C" {
void mx_fill32(uint32_t* d, uint32_t v, size_t n) { while (n--) *d++ = v; }
void mx_copy32(uint32_t* d, const uint32_t* s, size_t n) { memcpy(d, s, n * 4); }
}
