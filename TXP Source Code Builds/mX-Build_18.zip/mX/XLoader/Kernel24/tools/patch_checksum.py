#!/usr/bin/env python3
"""Patches a 32-bit additive checksum into a Kernel24 image's header.

Layout (see docs/memory-map.md): offset 0 = magic (untouched by this
script), offset 4 = checksum (patched here), offset 8+ = payload.

The checksum is simply the sum of every payload byte (offset 8 to the end
of the file), truncated to 32 bits. This has to run *after* the image has
already been padded to its full reserved disk size, since the checksum
must cover exactly the bytes XLoader will read back from disk — padding
included. kernel24_verify (kernel/loader.asm) recomputes this identically
at boot time and refuses to jump into the kernel if it doesn't match.
"""
import sys


def patch(path: str) -> None:
    with open(path, "rb") as f:
        data = bytearray(f.read())

    if len(data) < 8:
        sys.exit(f"error: {path} is only {len(data)} bytes, smaller than the 8-byte header")

    checksum = sum(data[8:]) & 0xFFFFFFFF
    data[4:8] = checksum.to_bytes(4, "little")

    with open(path, "wb") as f:
        f.write(data)

    print(f"patch_checksum: wrote 0x{checksum:08X} into {path}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(f"usage: {sys.argv[0]} <kernel-image>")
    patch(sys.argv[1])
