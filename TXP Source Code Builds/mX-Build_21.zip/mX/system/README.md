# system/

Reserved for system-level configuration and drivers beyond what
Kernel24 already has built in (screen, keyboard — both under
`XLoader/Kernel24/`, not here, since they're compiled into the kernel
image itself, same reasoning as `bin/`).

Likely candidates once there's a filesystem to read config from at
boot: hostname/prompt persistence (right now `hostname`/`prompt` reset
to their defaults on every reboot — see shell/builtin/hostname.cx and
shell/prompt.cx), and any driver that doesn't need to be compiled into
Kernel24 itself.
