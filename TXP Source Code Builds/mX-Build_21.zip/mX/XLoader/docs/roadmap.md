# XLoader roadmap

## Phase 1 — It should boot ✅
Power on → prints `XLoader v1.0`.

## Phase 2 — Disk loading ✅
1. Read sectors (`include/disk.inc`, LBA via INT 13h extensions) ✅
2. Load Kernel24 (`kernel/loader.asm`) ✅ — loads whatever's at LBA 17
   on disk today; swap in the real Kernel24 binary once it exists, nothing
   else needs to change.

## Phase 3 — Long mode ✅
Real Mode → Protected Mode → 64-bit Long Mode → jump to Kernel24 ✅

## Stage 2 checklist ✅
- [x] Verify Stage 2 loaded correctly — stage1 checks `STAGE2_MAGIC`
      (last 4 bytes of stage2's disk slot) before jumping in
- [x] Print "Stage 2"
- [x] Enable the A20 line — 4-method fallback chain, halts with a clear
      error if all of them fail (`boot/a20.asm`)
- [x] Detect available memory — `boot/memory.asm`, INT 15h/E820, stored at
      `MEMORY_MAP_ADDR` for Kernel24 to read once it exists
- [x] Build the GDT
- [x] Enter Protected Mode (32-bit)
- [x] Prepare paging structures
- [x] Enter Long Mode (64-bit)
- [x] Load Kernel24 into memory
- [x] Verify the kernel image — `kernel24_verify` checks `KERNEL24_MAGIC`
      plus a build-time-computed checksum over the whole payload
- [x] Boot information — `boot/bootinfo.asm` builds a 48-byte BootInfo
      struct (boot drive, memory map, reserved framebuffer fields) and
      passes it to Kernel24 via RDI
- [x] Jump to Kernel24

Tested with a placeholder stub (`kernel/kernel24_stub.asm`) carrying the
required header, that reads its BootInfo pointer back and prints two of its
fields on screen — so the whole chain, including both verification steps
and the hand-off itself, is exercised before Kernel24 exists for real.

## Verification

Everything in this project's checklist (stage1/stage2 handoff, memory
detection, GDT/protected mode/paging/long mode, Kernel24 load+verify,
BootInfo hand-off) was implemented in earlier passes. This pass focused on
actually *testing* it rather than just reviewing it: NASM 3.02 was built
from the source archive in `tools/archives/` (no prebuilt binary or network
access was available), which surfaced and fixed two build-configuration
bugs unrelated to XLoader itself, and one real, build-breaking bug in this
project — `%include` paths written as `"../include/foo.inc"` assumed
resolution relative to the including file's directory, but NASM resolves
them relative to the working directory `make` is run from. Fixed by
switching to bare filenames plus `-I` search paths in the `Makefile`
(`NASMFLAGS`).

With a working assembler, the real `build/disk.img` was assembled and
inspected byte-for-byte: boot signatures, the `STAGE2_MAGIC` and
`KERNEL24_MAGIC`/checksum placement, and — via `ndisasm` — the actual
machine code for every mode transition (GDT contents, `CR0`/`CR4`/`CR3`/
`EFER` MSR sequence, both far jumps), the A20 4-method cascade, memory
detection, `BootInfo` field construction, and the Kernel24 stub's hand-off
demo. All of it disassembles to exactly what the source intends.

What this doesn't cover: actually booting the image in an emulator (no
QEMU available in this environment) or on real hardware — `make run` on
your end is still the final word on runtime behavior. But the machine code
itself is now confirmed correct by direct inspection, not just by having
been carefully written.

## Not started
- Kernel24 itself
- mX (the OS)
- Anything past the initial jump (interrupts, drivers, ...)

