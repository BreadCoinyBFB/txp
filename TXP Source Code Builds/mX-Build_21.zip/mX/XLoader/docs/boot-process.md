# Boot process

```
BIOS
  │  loads LBA 0 (512 bytes) to 0x7C00, jumps to it with DL = boot drive
  ▼
stage1.asm  (real mode)
  │  print "XLoader v1.0"
  │  confirm the BIOS supports INT 13h extensions (LBA reads)
  │  read LBA 1-16 into 0x8000
  │  verify STAGE2_MAGIC is present at the end of that range
  ▼
stage2.asm  (real mode)
  │  print "Stage 2"
  │  enable the A20 line (4 fallback methods — see docs/memory-map.md;
  │    halts with an on-screen error if all of them fail)
  │  read Kernel24's sectors (LBA 17-144) into a staging buffer at 0x10000
  │  detect available memory (INT 15h/E820) → 0xA000
  │  build the BootInfo structure → 0xA700
  │  lgdt, set CR0.PE, far jump  ──────────────────┐
  ▼                                                 │ reloads CS
protected_mode_entry  (32-bit protected mode)       │
  │  reload segment registers, set up a 32-bit stack│
  │  copy the staged Kernel24 bytes up to 0x100000  │
  │  verify KERNEL24_MAGIC and its checksum (halts w/ on-screen error if
  │    either doesn't match)                        │
  │  build page tables, set CR4.PAE, CR3, EFER.LME, │
  │  CR0.PG, far jump  ─────────────────────────────┘ reloads CS again
  ▼
long_mode_entry  (64-bit long mode)
  │  reload segment registers, set up a throwaway stack
  │  RDI = 0xA700 (BootInfo pointer — System V AMD64 first-argument register)
  │  jmp KERNEL24_ENTRY_ADDR (0x100008 — past Kernel24's header)
  ▼
Kernel24
```

## Why two far jumps, not one

Setting `CR0.PE` (or later, `CR0.PG` with `EFER.LME` already set) changes
what mode the CPU *will* decode instructions in, but `CS` still holds its
old descriptor cache until it's explicitly reloaded — and a `far jmp` is the
only way to reload `CS` with a new descriptor. Skip either far jump and the
CPU keeps executing in the previous mode's instruction encoding, silently
misinterpreting everything that follows.

## What's deliberately not here yet

- **4 KiB page tables / a real page-fault handler** — not needed yet; see
  `docs/memory-map.md` for why 2 MiB pages are enough for now.
- **E820 fallbacks** (`INT 15h AX=E801h`/`AX=88h`) for BIOSes old enough to
  lack E820 — `detect_memory` degrades to "0 entries found" on those rather
  than crashing, which is enough for now.
- **UEFI boot** — this is a legacy-BIOS/MBR loader end to end.
