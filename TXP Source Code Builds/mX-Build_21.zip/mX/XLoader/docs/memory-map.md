# Memory map

Everything below is defined once, in `include/boot.inc` — this is the prose
version of that file.

| Address              | Contents                                          |
|----------------------|----------------------------------------------------|
| `0x00000000`         | IVT + BIOS Data Area (BIOS-owned, untouched)       |
| `0x00007000`         | 1 byte: saved boot drive number                    |
| `0x00007C00`         | Stage1 (loaded here by the BIOS; 512 bytes)        |
| `0x00007C00` (grows down) | Real-mode stack                              |
| `0x00008000`         | Stage2 (loaded by stage1; 8 KiB reserved, last 4 bytes = `STAGE2_MAGIC`) |
| `0x00001000`–`0x3FFF`| Long mode page tables (PML4, PDPT, PD — 4 KiB each)|
| `0x0000A000`         | E820 memory map: dword count, then up to 64 24-byte entries |
| `0x0000A700`         | BootInfo structure (48 bytes) — see below          |
| `0x00010000`         | Kernel24 staging buffer (raw sectors, real mode)   |
| `0x00090000`         | Throwaway stack used only during the final hand-off|
| `0x00100000` (1 MiB) | Kernel24's load address — 8-byte header (`KERNEL24_MAGIC` + checksum), real entry point is `KERNEL24_ENTRY_ADDR` (+8) |
| `0x000B8000`         | VGA text buffer (used by the Kernel24 stub, and by `kernel24_verify` on failure) |

## Disk layout (raw image, 512-byte sectors)

| LBA        | Contents            | Size reserved |
|------------|----------------------|---------------|
| 0          | Stage1 (boot sector) | 1 sector (512 B) |
| 1–16       | Stage2                | 16 sectors (8 KiB) |
| 17–144     | Kernel24 (stub for now) | 128 sectors (64 KiB) |

Both reserved sizes are generous headroom, not tight fits — `make` will
refuse to build (with a clear error) if either stage2 or Kernel24 ever grows
past its slot, rather than silently producing a corrupt image. Bump
`STAGE2_SECTORS` / `KERNEL24_SECTORS` in `include/boot.inc` (and, for
Kernel24, the matching `KERNEL_SIZE` in the `Makefile`) if that happens.

## The Kernel24 image contract

Whatever gets built into the Kernel24 disk slot must start with exactly
this layout (see `kernel/kernel24_stub.asm` for a minimal example):

```
offset 0:  dd KERNEL24_MAGIC     ; checked by kernel24_verify
offset 4:  dd <checksum>         ; patched in at build time — see below
offset 8:  <your real entry point, in 64-bit code>
```

XLoader jumps to `KERNEL24_ENTRY_ADDR` (`KERNEL24_LOAD_ADDR + 8`), not
`KERNEL24_LOAD_ADDR` itself — the header occupies those first 8 bytes, so
jumping straight to offset 0 would execute it as (garbage) instructions.

The checksum is a plain 32-bit sum of every payload byte (offset 8 to the
end of the reserved slot), computed by `tools/patch_checksum.py` as a
post-build step and independently recomputed by `kernel24_verify` at boot
time. It's not cryptographic — the goal is catching truncation or a bad
disk read, not tampering. If you replace the stub with a real build system,
make sure whatever produces the final image runs that same patch step
afterward (`make` already does this for the stub — see the `$(KERNEL_BIN)`
rule in the `Makefile`).

## BootInfo: what Kernel24 receives

Right before the final jump, XLoader points `RDI` at a 48-byte structure
(built by `boot/bootinfo.asm`) and leaves it there — the System V AMD64
calling convention passes the first argument in `RDI`, so a Kernel24
written in C can declare `void kmain(struct boot_info *info)` and it just
works with no glue code:

| Offset | Size | Field | Notes |
|--------|------|-------|-------|
| 0  | 4 | `magic`              | `BOOTINFO_MAGIC` |
| 4  | 4 | `boot_drive`         | BIOS drive number |
| 8  | 4 | `memory_map_count`   | number of E820 entries |
| 12 | 4 | `reserved`           | padding, keeps the next field 8-byte aligned |
| 16 | 8 | `memory_map_addr`    | pointer to the E820 entries at `0xA004` |
| 24 | 8 | `framebuffer_addr`   | `0` — not available yet |
| 32 | 4 | `framebuffer_width`  | `0` |
| 36 | 4 | `framebuffer_height` | `0` |
| 40 | 4 | `framebuffer_pitch`  | `0` |
| 44 | 4 | `framebuffer_bpp`    | `0` |

The framebuffer fields are reserved and zeroed rather than omitted — XLoader
is still BIOS VGA text mode, but the struct's shape won't need to change
once a real framebuffer exists, only those values will. `kernel/kernel24_stub.asm`
reads `boot_drive` and `memory_map_count` back out and prints them, which is
as much of a smoke test for this hand-off as makes sense before Kernel24
itself exists.

## A20: why four methods

`boot/a20.asm` tries, in order — stopping as soon as `check_a20`'s
wraparound test confirms success — doing nothing (some BIOSes/emulators
leave it on already), the BIOS (`INT 15h AX=2401h`), fast A20 (port
`0x92`), and finally the legacy PS/2 keyboard-controller dance. QEMU and
essentially anything from the last 20 years succeeds at fast A20 alone, but
real hardware is where the extra fallbacks earn their keep. If all four
fail, stage2 halts with an on-screen error rather than silently continuing
into a state where "load Kernel24 at 1 MiB" would actually corrupt address
0 (the IVT) instead.

## Why 2 MiB pages instead of 4 KiB ones

The long-mode page tables (`boot/longmode.asm`) identity-map the first 8 MiB
using four 2 MiB pages: one PML4 entry → one PDPT entry → four PD entries,
each with the `PS` (page size) bit set. That's the entire page-table setup —
no 4 KiB-granularity page table array needed. 8 MiB comfortably covers
XLoader's own code, the page tables themselves, the kernel staging buffer,
and Kernel24's 1 MiB load address with room to grow.
