# x86_64-elf-cxc

A native cX compiler: cX source straight to a real ELF64 object file, no
C, no transpilation, no hosted toolchain. Built specifically so Kernel24
could drop C entirely — see `../../Kernel24/docs/cx-integration.md`.

```
file.cx → lexer → parser → semantic analysis → IR → x86-64 assembly → nasm → real .o
```

## Design decisions worth knowing

**The backend emits assembly text, then calls `nasm -f elf64`, rather
than hand-encoding machine code bytes.** "Generate x86-64 machine code
(or assembly)" was explicitly open either way, and hand-rolling correct
REX/ModRM/SIB encoding for every instruction is a large, easy-to-get-
subtly-wrong undertaking on its own. Leaning on nasm — already used
throughout XLoader/Kernel24 and independently verified — makes the
highest-risk part of a first native backend (instruction encoding)
someone else's already-solved problem, while `backend/x86_64.cpp` still
does all the actual compiler work: instruction selection, stack layout,
calling-convention marshaling, control-flow lowering.

**Linking adopts GNU `ld`** rather than a from-scratch linker — also
explicitly an option per the brief. `linker/linker.cpp` drives it.

**Every value lives in its own 8-byte stack slot** (see `ir/ir.hpp`'s
top comment) — no register allocator. Slower than one would produce, but
straightforward to generate correctly and easy to verify by reading the
output.

## Known gaps

- **No `float`** — would need SSE codegen or soft-float; nothing in
  Kernel24 currently needs it.
- **Struct-by-value parameters are not supported** — returning a struct by
  value is (see below), but passing one as an argument isn't. Every real
  call site in Kernel24 passes structs by pointer, so this hasn't come up.
- **Struct-by-value return uses a hidden pointer unconditionally** — not
  the real System V rule (register-pack if ≤16 bytes, hidden pointer
  otherwise). The caller always passes a destination address as an
  implicit first argument; the callee writes there and returns void. This
  is a deliberate simplification, safe specifically because it's never a
  contract with anything outside this compiler's own output — nothing
  here calls into or is called from externally-compiled code expecting
  real SysV struct-return semantics.
- **Max 6 integer/pointer arguments per call** — the six System V argument
  registers, no stack-passed-argument support. No real function exceeds
  this today.
- **`console.print`/`write`/`read_int`/`read_line` are not implemented.**
  Deliberately: those exist in the original `cxc` for hosted programs
  with a libc behind them. This compiler targets freestanding code with
  no libc at all, so they wouldn't mean anything here.

## Verification

Built and actually exercised, not just read over: every real Kernel24
`.cx` file compiles clean through this pipeline, and the resulting
object files were tested by **linking them against a small C harness and
running the result** — checking real computed values (`align_up`,
`bitmap_bit_mask`, etc.) and real pointer/struct behavior
(`bootinfo_validate` against valid/invalid/null pointers), not just
"assembles without error." All checks passed. The full kernel — every
`.cx` file through this compiler, linked with the hand-written assembly
via XLoader's existing `linker.ld` — builds to exactly the expected
65536-byte image with `_start` landing at the exact address XLoader's
computed jump requires.

Two real bugs came out of that process, both fixed:
- An IR-construction bug where address-taking instructions never
  allocated their own destination register, silently aliasing unrelated
  values onto the same stack slot.
- String-literal labels (`.Lstr0`, ...) used NASM's dot-prefix local-label
  convention by accident, which scopes a label to the nearest preceding
  non-local label — wrong for symbols meant to be referenced from many
  different functions. Renamed away from the dot prefix.

A second, targeted pass specifically adversarial-tested the parser and
struct handling: multi-level pointers (`T**`) failed to parse (fixed —
`parseType` only consumed one `*`), `nullptr` was rejected as a struct-
pointer initializer (fixed — `nullptr` is now compatible with any
pointer type), and struct-by-value returns weren't implemented in `ir.cpp`
at all (implemented — see "Known gaps" above for the calling-convention
tradeoff that made this tractable). All three were confirmed fixed by
compiling and, where possible, actually executing the previously-failing
cases — including a direct test of the struct-return mechanism itself,
not just that it links.
