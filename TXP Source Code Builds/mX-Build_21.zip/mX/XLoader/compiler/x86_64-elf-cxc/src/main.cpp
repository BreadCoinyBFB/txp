// main.cpp — x86_64-elf-cxc: compiles one cX file straight to a real
// ELF64 object file (no intermediate C, no hosted toolchain), or links
// object files together (adopting GNU ld — see linker/linker.hpp).
//
//   x86_64-elf-cxc <file.cx> [-o <output.o>] [--emit-asm]
//   x86_64-elf-cxc --link -T <script.ld> -o <output> <obj1.o> <obj2.o> ...
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "lexer/lexer.hpp"
#include "parser/parser.hpp"
#include "semantic/semantic.hpp"
#include "ir/ir.hpp"
#include "backend/x86_64.hpp"
#include "backend/elf64.hpp"
#include "linker/linker.hpp"

static std::string readFile(const std::string& path) {
    std::ifstream f(path);
    if (!f) throw std::runtime_error("cannot open '" + path + "'");
    std::ostringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

static int runLink(int argc, char** argv) {
    std::string script, output;
    std::vector<std::string> objects;
    for (int i = 2; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-T" && i + 1 < argc) { script = argv[++i]; }
        else if (arg == "-o" && i + 1 < argc) { output = argv[++i]; }
        else objects.push_back(arg);
    }
    if (output.empty() || objects.empty()) {
        std::cerr << "usage: x86_64-elf-cxc --link -T <script.ld> -o <output> <obj...>\n";
        return 1;
    }
    try {
        cx::linker::link(objects, script, output);
    } catch (const std::exception& e) {
        std::cerr << "x86_64-elf-cxc: " << e.what() << "\n";
        return 1;
    }
    std::cout << "x86_64-elf-cxc: linked '" << output << "'\n";
    return 0;
}

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "usage: x86_64-elf-cxc <file.cx> [-o <output.o>] [--emit-asm]\n"
                      "       x86_64-elf-cxc --link -T <script.ld> -o <output> <obj...>\n";
        return 1;
    }
    if (std::string(argv[1]) == "--link") return runLink(argc, argv);

    std::string inputPath = argv[1];
    std::string outputPath;
    bool emitAsm = false;
    for (int i = 2; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-o" && i + 1 < argc) outputPath = argv[++i];
        else if (arg == "--emit-asm") emitAsm = true;
    }
    if (outputPath.empty()) {
        auto dot = inputPath.rfind('.');
        outputPath = (dot == std::string::npos ? inputPath : inputPath.substr(0, dot)) + ".o";
    }

    try {
        std::string source = readFile(inputPath);
        cx::Lexer lexer(source);
        auto tokens = lexer.tokenize();
        cx::Parser parser(tokens);
        auto program = parser.parseProgram();

        cx::SemanticAnalyzer sema;
        sema.analyze(*program);

        cx::ir::Module mod = cx::ir::lower(*program);

        std::ostringstream asmOut;
        cx::backend::emitAssembly(mod, asmOut);

        if (emitAsm) {
            std::cout << asmOut.str();
            return 0;
        }

        cx::backend::assembleToElf64(asmOut.str(), outputPath);
        std::cout << "x86_64-elf-cxc: built '" << outputPath << "'\n";
    } catch (const cx::ParseError& e) {
        std::cerr << "x86_64-elf-cxc: parse error at line " << e.line << ": " << e.what() << "\n";
        return 1;
    } catch (const cx::SemaError& e) {
        std::cerr << "x86_64-elf-cxc: semantic error at line " << e.line << ": " << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << e.what() << "\n";
        return 1;
    }
    return 0;
}
