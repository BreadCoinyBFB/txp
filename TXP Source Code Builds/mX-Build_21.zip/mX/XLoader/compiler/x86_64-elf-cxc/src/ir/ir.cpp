// ir.cpp — see ir.hpp
#include "ir.hpp"
#include <stdexcept>
#include <unordered_set>

namespace cx::ir {

namespace {

// ---- type-string helpers (same rules as semantic/semantic.cpp — cX has
// one canonical string representation for every type, so duplicating
// these three is simpler and safer than exposing sema's internals) ----
bool isArrayType(const std::string& t) { return t.find('[') != std::string::npos; }
std::string arrayElemType(const std::string& t) {
    auto pos = t.find('[');
    return pos == std::string::npos ? t : t.substr(0, pos);
}
int arraySize(const std::string& t) {
    auto open = t.find('['), close = t.find(']');
    if (open == std::string::npos || close == std::string::npos || close <= open + 1) return 0;
    return std::stoi(t.substr(open + 1, close - open - 1));
}
bool isPointerType(const std::string& t) { return !t.empty() && t.back() == '*' && !isArrayType(t); }
std::string pointeeType(const std::string& t) { return t.substr(0, t.size() - 1); }

struct Fail : std::runtime_error {
    explicit Fail(const std::string& msg) : std::runtime_error("x86_64-elf-cxc: " + msg) {}
};

int typeSize(const std::string& type, const Module& mod) {
    if (isArrayType(type)) return typeSize(arrayElemType(type), mod) * arraySize(type);
    if (isPointerType(type)) return 8;
    if (type == "int") return 4;
    if (type == "long") return 8;
    if (type == "bool") return 1;
    if (type == "char") return 1;
    if (type == "string") return 8;   // pointer to bytes in .rodata
    if (type == "void") return 0;
    auto it = mod.structs.find(type);
    if (it != mod.structs.end()) return it->second.totalSize;
    if (type == "float") throw Fail("float is not supported by this backend yet (see README.md)");
    throw Fail("unknown type '" + type + "'");
}

// Whether a value of this type is sign-extended (true) or zero-extended
// (false) when loaded from memory narrower than 64 bits. Pointers/arrays
// are always 8 bytes already, so this only matters for int/char/bool —
// char and bool are conventionally unsigned byte values in cX (no
// negative chars), matching the C backend's `char` == `unsigned char`-ish
// treatment for these built-ins.
bool isSignedType(const std::string& type) {
    return type == "int" || type == "long";
}

} // namespace

// ============================================================================
// Struct layout
// ============================================================================
static void computeStructLayouts(Program& program, Module& mod) {
    // Two passes: register every struct name first (so field types that
    // reference another struct, in either order, resolve), then compute
    // offsets. Natural (C-like) alignment: each field aligns to its own
    // size (capped at 8), and the struct's total size rounds up to its
    // largest field's alignment.
    for (auto& d : program.declarations) {
        if (auto* sd = dynamic_cast<StructDecl*>(d.get())) {
            mod.structs[sd->name] = StructLayout{};
        }
    }
    for (auto& d : program.declarations) {
        auto* sd = dynamic_cast<StructDecl*>(d.get());
        if (!sd) continue;
        StructLayout layout;
        int offset = 0, maxAlign = 1;
        for (auto& f : sd->fields) {
            int size = typeSize(f.type, mod);
            int align = size < 8 ? size : 8;
            if (align < 1) align = 1;
            offset = (offset + align - 1) / align * align;
            layout.fields.push_back({f.name, f.type, offset, size});
            offset += size;
            if (align > maxAlign) maxAlign = align;
        }
        layout.totalSize = (offset + maxAlign - 1) / maxAlign * maxAlign;
        mod.structs[sd->name] = layout;
    }
}

// ============================================================================
// Per-function lowering
// ============================================================================
namespace {

// Folds a const initializer expression to a compile-time integer. Only
// handles what the real source actually uses (int/long/char/bool
// literals, and unary minus over one) — anything fancier is a deliberate
// "not yet" rather than a silent wrong answer.
long long foldConstExpr(Expr& e) {
    if (auto* i = dynamic_cast<IntLiteralExpr*>(&e)) return std::stoll(i->value, nullptr, 0);
    if (auto* c = dynamic_cast<CharLiteralExpr*>(&e)) return c->value.empty() ? 0 : (unsigned char)c->value[0];
    if (auto* b = dynamic_cast<BoolLiteralExpr*>(&e)) return b->value ? 1 : 0;
    if (auto* u = dynamic_cast<UnaryExpr*>(&e)) {
        if (u->op == "-") return -foldConstExpr(*u->operand);
        if (u->op == "~") return ~foldConstExpr(*u->operand);
    }
    throw Fail("const initializer at line " + std::to_string(e.line) +
               " is too complex for this backend (only literal constants are folded)");
}

struct GlobalInfo { std::string type; bool isConst; long long constValue; };

class FuncBuilder {
public:
    FuncBuilder(Module& mod, std::unordered_map<std::string, GlobalInfo>& globals,
                std::unordered_map<std::string, FunctionDecl*>& funcs)
        : mod_(mod), globals_(globals), funcs_(funcs) {}

    Function build(FunctionDecl& decl) {
        fn_.name = decl.name;
        fn_.isExtern = false;
        fn_.returnType = decl.returnType;
        pushScope();

        // Struct-by-value return: rather than the full System V classification
        // rules (return in RAX:RDX if <=16 bytes, else hidden pointer), this
        // backend always uses a hidden pointer, unconditionally. That's a
        // deliberate, documented simplification (see README.md) — it's only
        // ever a contract between this compiler's own callers and callees
        // (nothing here interoperates with externally-compiled code that
        // returns structs by value), so internal consistency is all that
        // actually matters.
        if (mod_.structs.count(decl.returnType)) {
            returnsStruct_ = true;
            hiddenReturnSlot_ = newNamedLocal("__cx_ret", 8);
            paramTypes_.push_back(decl.returnType + "*");
        }

        for (auto& p : decl.params) {
            int slot = newNamedLocal(p.name, typeSize(p.type, mod_));
            paramTypes_.push_back(p.type);
            (void)slot;
        }
        fn_.paramCount = (int)decl.params.size() + (returnsStruct_ ? 1 : 0);
        if (fn_.paramCount > 6) {
            throw Fail("function '" + decl.name + "' has more than 6 parameters" +
                       std::string(returnsStruct_ ? " (counting the hidden pointer a struct "
                                                     "return needs)" : "") +
                       ", which this backend doesn't support yet (all real System V integer "
                       "argument registers used)");
        }
        emitBlock(*decl.body);
        // Every path should already return explicitly (semantic analysis
        // doesn't enforce this the way a stricter language would), but a
        // void function falling off the end needs a bare `ret` — emit one
        // unconditionally; a dead `ret` after an explicit one is harmless.
        Instr r; r.op = Op::Ret; r.hasDst = false;
        fn_.code.push_back(r);
        popScope();
        return std::move(fn_);
    }

private:
    Module& mod_;
    std::unordered_map<std::string, GlobalInfo>& globals_;
    std::unordered_map<std::string, FunctionDecl*>& funcs_;
    Function fn_;
    std::vector<std::unordered_map<std::string, int>> scopes_;
    std::vector<std::string> paramTypes_;
    bool returnsStruct_ = false;
    int hiddenReturnSlot_ = -1;
    std::unordered_map<int, std::string> localTypes_; // slot -> cX type string
    std::vector<std::pair<std::string, std::string>> loopLabels_; // (break, continue)
    int labelCounter_ = 0;

    void pushScope() { scopes_.emplace_back(); }
    void popScope() { scopes_.pop_back(); }

    int newTemp(const std::string& type) {
        int idx = (int)fn_.locals.size();
        fn_.locals.push_back({"", typeSize(type, mod_), false});
        localTypes_[idx] = type;
        return idx;
    }
    int newNamedLocal(const std::string& name, int size) {
        int idx = (int)fn_.locals.size();
        fn_.locals.push_back({name, size, (int)fn_.locals.size() < fn_.paramCount});
        scopes_.back()[name] = idx;
        return idx;
    }
    int declareLocal(const std::string& name, const std::string& type) {
        int idx = newNamedLocal(name, typeSize(type, mod_));
        localTypes_[idx] = type;
        return idx;
    }
    int lookupLocalSlot(const std::string& name) {
        for (auto it = scopes_.rbegin(); it != scopes_.rend(); ++it) {
            auto f = it->find(name);
            if (f != it->end()) return f->second;
        }
        return -1;
    }
    std::string newLabel(const std::string& hint) {
        return ".L" + hint + std::to_string(labelCounter_++) + "_" + fn_.name;
    }
    VReg emit(Instr i) {
        VReg d = i.dst;
        fn_.code.push_back(std::move(i));
        return d;
    }

    // ---- statements ----
    void emitBlock(BlockStmt& block) {
        pushScope();
        for (auto& s : block.statements) emitStmt(*s);
        popScope();
    }

    void emitStmt(Stmt& stmt) {
        if (auto* let = dynamic_cast<LetStmt*>(&stmt)) { emitLet(*let); return; }
        if (auto* ret = dynamic_cast<ReturnStmt*>(&stmt)) {
            if (returnsStruct_ && ret->value) {
                VReg hiddenPtr = loadFrom(emit(mk(Op::AddrLocal, hiddenReturnSlot_)), newTemp("long"), "long");
                std::string retType = fn_.returnType;
                if (auto* call = dynamic_cast<CallExpr*>(ret->value.get())) {
                    emitCall(*call, hiddenPtr);
                } else {
                    copyAggregate(hiddenPtr, emitAddr(*ret->value), typeSize(retType, mod_));
                }
                Instr r; r.op = Op::Ret; r.hasDst = false; emit(r);
                return;
            }
            Instr r; r.op = Op::Ret;
            if (ret->value) { r.hasDst = true; r.lhs = emitExpr(*ret->value); }
            emit(r);
            return;
        }
        if (auto* es = dynamic_cast<ExprStmt*>(&stmt)) { emitExpr(*es->expr); return; }
        if (auto* block = dynamic_cast<BlockStmt*>(&stmt)) { emitBlock(*block); return; }
        if (auto* ifs = dynamic_cast<IfStmt*>(&stmt)) {
            std::string elseLabel = newLabel("else");
            std::string endLabel = newLabel("endif");
            VReg cond = emitExpr(*ifs->condition);
            Instr jz; jz.op = Op::JumpIfZero; jz.lhs = cond; jz.symbol = elseLabel;
            emit(jz);
            emitStmt(*ifs->thenBranch);
            if (ifs->elseBranch) {
                Instr j; j.op = Op::Jump; j.symbol = endLabel; emit(j);
                Instr lbl; lbl.op = Op::Label; lbl.symbol = elseLabel; emit(lbl);
                emitStmt(*ifs->elseBranch);
                Instr end; end.op = Op::Label; end.symbol = endLabel; emit(end);
            } else {
                Instr lbl; lbl.op = Op::Label; lbl.symbol = elseLabel; emit(lbl);
            }
            return;
        }
        if (auto* w = dynamic_cast<WhileStmt*>(&stmt)) {
            std::string top = newLabel("wtop"), end = newLabel("wend");
            loopLabels_.push_back({end, top});
            Instr t; t.op = Op::Label; t.symbol = top; emit(t);
            VReg cond = emitExpr(*w->condition);
            Instr jz; jz.op = Op::JumpIfZero; jz.lhs = cond; jz.symbol = end; emit(jz);
            emitStmt(*w->body);
            Instr j; j.op = Op::Jump; j.symbol = top; emit(j);
            Instr e; e.op = Op::Label; e.symbol = end; emit(e);
            loopLabels_.pop_back();
            return;
        }
        if (auto* f = dynamic_cast<ForStmt*>(&stmt)) {
            pushScope();
            if (f->init) emitStmt(*f->init);
            std::string top = newLabel("ftop"), end = newLabel("fend"), post = newLabel("fpost");
            loopLabels_.push_back({end, post});
            Instr t; t.op = Op::Label; t.symbol = top; emit(t);
            if (f->cond) {
                VReg cond = emitExpr(*f->cond);
                Instr jz; jz.op = Op::JumpIfZero; jz.lhs = cond; jz.symbol = end; emit(jz);
            }
            emitStmt(*f->body);
            Instr p; p.op = Op::Label; p.symbol = post; emit(p);
            if (f->post) emitExpr(*f->post);
            Instr j; j.op = Op::Jump; j.symbol = top; emit(j);
            Instr e; e.op = Op::Label; e.symbol = end; emit(e);
            loopLabels_.pop_back();
            popScope();
            return;
        }
        if (dynamic_cast<BreakStmt*>(&stmt)) {
            Instr j; j.op = Op::Jump; j.symbol = loopLabels_.back().first; emit(j);
            return;
        }
        if (dynamic_cast<ContinueStmt*>(&stmt)) {
            Instr j; j.op = Op::Jump; j.symbol = loopLabels_.back().second; emit(j);
            return;
        }
        throw Fail("unsupported statement kind at line " + std::to_string(stmt.line));
    }

    void emitLet(LetStmt& let) {
        // Global/extern-scope lets never reach here — lower() handles
        // those directly as ir::Global entries before any function body
        // is walked.
        const std::string& type = let.resolvedType.empty() ? let.type : let.resolvedType;
        int slot = declareLocal(let.name, type);

        if (!let.init) return; // uninitialized local — e.g. `let buf: char[20];`

        if (isArrayType(type) && dynamic_cast<ArrayLiteralExpr*>(let.init.get())) {
            auto* lit = static_cast<ArrayLiteralExpr*>(let.init.get());
            std::string elemType = arrayElemType(type);
            int elemSize = typeSize(elemType, mod_);
            VReg base = emit(mk(Op::AddrLocal, slot));
            for (size_t i = 0; i < lit->elements.size(); i++) {
                VReg val = emitExpr(*lit->elements[i]);
                VReg addr = offsetPtr(base, (long long)i * elemSize);
                storeAt(addr, val, elemSize);
            }
            return;
        }

        if (mod_.structs.count(type)) {
            VReg destAddr = emit(mk(Op::AddrLocal, slot));
            if (auto* call = dynamic_cast<CallExpr*>(let.init.get())) {
                emitCall(*call, destAddr); // writes straight into destAddr, no extra copy
            } else {
                copyAggregate(destAddr, emitAddr(*let.init), typeSize(type, mod_));
            }
            return;
        }

        VReg val = emitExpr(*let.init);
        VReg addr = emit(mk(Op::AddrLocal, slot));
        storeAt(addr, val, typeSize(type, mod_));
    }

    // ---- expressions: value context ----
    VReg emitExpr(Expr& e) {
        if (mod_.structs.count(e.exprType)) return emitAddr(e);
        if (auto* i = dynamic_cast<IntLiteralExpr*>(&e)) return emit(mkConst(std::stoll(i->value, nullptr, 0)));
        if (auto* c = dynamic_cast<CharLiteralExpr*>(&e)) return emit(mkConst(c->value.empty() ? 0 : (unsigned char)c->value[0]));
        if (auto* b = dynamic_cast<BoolLiteralExpr*>(&e)) return emit(mkConst(b->value ? 1 : 0));
        if (dynamic_cast<NullptrExpr*>(&e)) return emit(mkConst(0));
        if (auto* s = dynamic_cast<StringLiteralExpr*>(&e)) {
            int idx = (int)mod_.strings.size();
            mod_.strings.push_back(s->value);
            Instr in; in.op = Op::AddrString; in.imm = idx; in.dst = newTemp("string");
            return emit(in);
        }
        if (auto* id = dynamic_cast<IdentifierExpr*>(&e)) return loadIdentifier(id->name, e.exprType);
        if (auto* un = dynamic_cast<UnaryExpr*>(&e)) return emitUnary(*un);
        if (auto* bin = dynamic_cast<BinaryExpr*>(&e)) return emitBinary(*bin);
        if (auto* asn = dynamic_cast<AssignExpr*>(&e)) return emitAssign(*asn);
        if (auto* call = dynamic_cast<CallExpr*>(&e)) return emitCall(*call);
        if (auto* cast = dynamic_cast<CastExpr*>(&e)) return emitCast(*cast);
        if (dynamic_cast<MemberExpr*>(&e) || dynamic_cast<IndexExpr*>(&e)) {
            VReg addr = emitAddr(e);
            VReg dst = newTemp(e.exprType);
            return loadFrom(addr, dst, e.exprType);
        }
        throw Fail("unsupported expression kind at line " + std::to_string(e.line));
    }

    // ---- expressions: address (lvalue) context ----
    VReg emitAddr(Expr& e) {
        if (auto* id = dynamic_cast<IdentifierExpr*>(&e)) {
            int slot = lookupLocalSlot(id->name);
            if (slot >= 0) return emit(mk(Op::AddrLocal, slot));
            auto g = globals_.find(id->name);
            if (g != globals_.end() && !g->second.isConst) {
                Instr in; in.op = Op::AddrGlobal; in.symbol = id->name; in.dst = newTemp(id->exprType + "*");
                return emit(in);
            }
            throw Fail("'" + id->name + "' at line " + std::to_string(e.line) + " is not addressable");
        }
        if (auto* un = dynamic_cast<UnaryExpr*>(&e)) {
            if (un->op == "*") return emitExpr(*un->operand); // *p as an address IS p's value
        }
        if (auto* idx = dynamic_cast<IndexExpr*>(&e)) {
            VReg base = isArrayType(idx->array->exprType) ? emitAddr(*idx->array) : emitExpr(*idx->array);
            VReg index = emitExpr(*idx->index);
            int elemSize = typeSize(e.exprType, mod_);
            VReg scaled = emit(mkBin(Op::Mul, index, emit(mkConst(elemSize))));
            return emit(mkBin(Op::Add, base, scaled));
        }
        if (auto* mem = dynamic_cast<MemberExpr*>(&e)) {
            std::string objType = mem->object->exprType;
            VReg base = isPointerType(objType) ? emitExpr(*mem->object) : emitAddr(*mem->object);
            std::string structName = isPointerType(objType) ? pointeeType(objType) : objType;
            auto it = mod_.structs.find(structName);
            if (it == mod_.structs.end()) throw Fail("'" + structName + "' is not a struct type");
            const StructField* f = it->second.find(mem->member);
            if (!f) throw Fail("no field '" + mem->member + "' on struct '" + structName + "'");
            return offsetPtr(base, f->offset);
        }
        if (auto* lit = dynamic_cast<StructLiteralExpr*>(&e)) {
            int slot = newTemp(lit->structName);
            VReg addr = emit(mk(Op::AddrLocal, slot));
            auto& layout = mod_.structs.at(lit->structName);
            for (auto& [fieldName, fieldExpr] : lit->fields) {
                const StructField* f = layout.find(fieldName);
                if (!f) throw Fail("no field '" + fieldName + "' on struct '" + lit->structName + "'");
                VReg fieldAddr = offsetPtr(addr, f->offset);
                if (mod_.structs.count(f->type)) {
                    copyAggregate(fieldAddr, emitAddr(*fieldExpr), f->size);
                } else {
                    storeAt(fieldAddr, emitExpr(*fieldExpr), f->size);
                }
            }
            return addr;
        }
        if (auto* call = dynamic_cast<CallExpr*>(&e)) {
            if (!mod_.structs.count(call->exprType)) throw Fail("call at line " +
                std::to_string(e.line) + " does not return a struct and is not addressable");
            return emitCall(*call);
        }
        throw Fail("expression at line " + std::to_string(e.line) + " is not addressable");
    }

    VReg loadIdentifier(const std::string& name, const std::string& type) {
        int slot = lookupLocalSlot(name);
        if (slot >= 0) {
            if (isArrayType(type)) return emit(mk(Op::AddrLocal, slot)); // arrays decay to their address
            VReg addr = emit(mk(Op::AddrLocal, slot));
            return loadFrom(addr, newTemp(type), type);
        }
        auto g = globals_.find(name);
        if (g != globals_.end()) {
            if (g->second.isConst) return emit(mkConst(g->second.constValue));
            if (isArrayType(type)) {
                Instr in; in.op = Op::AddrGlobal; in.symbol = name; in.dst = newTemp(type);
                return emit(in);
            }
            Instr in; in.op = Op::AddrGlobal; in.symbol = name; in.dst = newTemp(type + "*");
            VReg addr = emit(in);
            return loadFrom(addr, newTemp(type), type);
        }
        throw Fail("undeclared identifier '" + name + "'");
    }

    VReg loadFrom(VReg addr, VReg dst, const std::string& type) {
        int size = typeSize(type, mod_);
        Instr ld; ld.op = Op::Load; ld.lhs = addr; ld.dst = dst;
        ld.size = size; ld.isUnsigned = !isSignedType(type);
        return emit(ld);
    }
    void storeAt(VReg addr, VReg val, int size) {
        Instr st; st.op = Op::Store; st.lhs = addr; st.rhs = val; st.size = size;
        emit(st);
    }
    VReg offsetPtr(VReg base, long long delta) {
        if (delta == 0) return base;
        return emit(mkBin(Op::Add, base, emit(mkConst(delta))));
    }

    // Copies `size` bytes from *srcAddr to *dstAddr, 8 bytes at a time with
    // a smaller trailing chunk if size isn't a multiple of 8 — used for
    // every struct-to-struct move (let-init, return, assignment), since a
    // struct value is always represented by its address in this IR (see
    // ir.hpp's opening comment: nothing here holds an aggregate directly
    // in a single 8-byte vreg).
    void copyAggregate(VReg dstAddr, VReg srcAddr, int size) {
        int off = 0;
        while (off + 8 <= size) {
            VReg v = newTemp("long");
            emit(Instr{Op::Load, v, offsetPtr(srcAddr, off), NO_VREG, 0, "", 8, false, {}, false});
            storeAt(offsetPtr(dstAddr, off), v, 8);
            off += 8;
        }
        if (off < size) {
            int rem = size - off;
            VReg v = newTemp("int");
            emit(Instr{Op::Load, v, offsetPtr(srcAddr, off), NO_VREG, 0, "", rem, true, {}, false});
            storeAt(offsetPtr(dstAddr, off), v, rem);
        }
    }

    VReg emitUnary(UnaryExpr& un) {
        if (un.op == "&") return emitAddr(*un.operand);
        if (un.op == "*") {
            VReg addr = emitExpr(*un.operand);
            return loadFrom(addr, newTemp(un.exprType), un.exprType);
        }
        VReg v = emitExpr(*un.operand);
        Op op = un.op == "-" ? Op::Neg : un.op == "!" ? Op::LNot : Op::BNot;
        Instr i; i.op = op; i.lhs = v; i.dst = newTemp(un.exprType);
        return emit(i);
    }

    VReg emitBinary(BinaryExpr& bin) {
        // && and || short-circuit: the right side is only evaluated when
        // it can actually change the answer.
        if (bin.op == "&&" || bin.op == "||") {
            VReg result = newTemp("bool");
            std::string rightLabel = newLabel(bin.op == "&&" ? "andrhs" : "orrhs");
            std::string endLabel = newLabel(bin.op == "&&" ? "andend" : "orend");
            VReg lhs = emitExpr(*bin.left);
            storeAt(emit(mk(Op::AddrLocal, result)), lhs, 1);
            if (bin.op == "&&") {
                Instr jz; jz.op = Op::JumpIfZero; jz.lhs = lhs; jz.symbol = endLabel; emit(jz);
            } else {
                Instr jnz; jnz.op = Op::JumpIfNotZero; jnz.lhs = lhs; jnz.symbol = endLabel; emit(jnz);
            }
            Instr rl; rl.op = Op::Label; rl.symbol = rightLabel; emit(rl);
            VReg rhs = emitExpr(*bin.right);
            storeAt(emit(mk(Op::AddrLocal, result)), rhs, 1);
            Instr el; el.op = Op::Label; el.symbol = endLabel; emit(el);
            return loadFrom(emit(mk(Op::AddrLocal, result)), newTemp("bool"), "bool");
        }

        // Pointer arithmetic: p + i / i + p scales i by the pointee size;
        // p - p (same type) yields an element count, not a byte count.
        if ((bin.op == "+" || bin.op == "-") &&
            (isPointerType(bin.left->exprType) || isPointerType(bin.right->exprType))) {
            if (isPointerType(bin.left->exprType) && isPointerType(bin.right->exprType)) {
                VReg l = emitExpr(*bin.left), r = emitExpr(*bin.right);
                VReg diff = emit(mkBin(Op::Sub, l, r));
                int elemSize = typeSize(pointeeType(bin.left->exprType), mod_);
                if (elemSize <= 1) return diff;
                return emit(mkBin(Op::SDiv, diff, emit(mkConst(elemSize))));
            }
            bool leftIsPtr = isPointerType(bin.left->exprType);
            Expr& ptrExpr = leftIsPtr ? *bin.left : *bin.right;
            Expr& intExpr = leftIsPtr ? *bin.right : *bin.left;
            VReg ptr = emitExpr(ptrExpr);
            VReg i = emitExpr(intExpr);
            int elemSize = typeSize(pointeeType(ptrExpr.exprType), mod_);
            VReg scaled = emit(mkBin(Op::Mul, i, emit(mkConst(elemSize))));
            return emit(mkBin(bin.op == "+" ? Op::Add : Op::Sub, ptr, scaled));
        }

        VReg l = emitExpr(*bin.left), r = emitExpr(*bin.right);
        static const std::unordered_map<std::string, Op> ops = {
            {"+", Op::Add}, {"-", Op::Sub}, {"*", Op::Mul}, {"/", Op::SDiv}, {"%", Op::SMod},
            {"&", Op::BAnd}, {"|", Op::BOr}, {"^", Op::BXor}, {"<<", Op::Shl}, {">>", Op::Shr},
            {"==", Op::CmpEq}, {"!=", Op::CmpNe}, {"<", Op::CmpLt}, {"<=", Op::CmpLe},
            {">", Op::CmpGt}, {">=", Op::CmpGe},
        };
        auto it = ops.find(bin.op);
        if (it == ops.end()) throw Fail("unsupported operator '" + bin.op + "'");
        return emit(mkBin(it->second, l, r, bin.exprType));
    }

    VReg emitAssign(AssignExpr& asn) {
        VReg addr = emitAddr(*asn.target);
        std::string targetType = asn.target->exprType;
        if (mod_.structs.count(targetType)) {
            if (asn.op != "=") throw Fail("compound assignment on a struct at line " +
                                           std::to_string(asn.line) + " doesn't make sense");
            copyAggregate(addr, emitAddr(*asn.value), typeSize(targetType, mod_));
            return addr;
        }
        int size = typeSize(targetType, mod_);
        VReg val;
        if (asn.op == "=") {
            val = emitExpr(*asn.value);
        } else {
            VReg cur = loadFrom(addr, newTemp(targetType), targetType);
            VReg rhs = emitExpr(*asn.value);
            Op op = asn.op == "+=" ? Op::Add : asn.op == "-=" ? Op::Sub
                  : asn.op == "*=" ? Op::Mul : Op::SDiv;
            val = emit(mkBin(op, cur, rhs));
        }
        storeAt(addr, val, size);
        return val;
    }

    // dstAddr: for a struct-returning call, where the result should be
    // written (an address). NO_VREG means "allocate a fresh temp" —
    // the common case; emitLet passes an existing local's address instead
    // so `let x: T = call(...)` doesn't need a copy on top of the call.
    VReg emitCall(CallExpr& call, VReg dstAddr = NO_VREG) {
        auto* callee = dynamic_cast<IdentifierExpr*>(call.callee.get());
        if (!callee) throw Fail("only direct calls to a named function are supported (line " +
                                 std::to_string(call.line) + ")");
        std::string retType = call.exprType;
        bool structReturn = mod_.structs.count(retType) > 0;

        Instr in; in.op = Op::Call; in.symbol = callee->name;
        if (structReturn) {
            if (dstAddr == NO_VREG) dstAddr = emit(mk(Op::AddrLocal, newTemp(retType)));
            in.args.push_back(dstAddr);
        }
        for (auto& a : call.args) in.args.push_back(emitExpr(*a));
        if (in.args.size() > 6) {
            throw Fail("call at line " + std::to_string(call.line) + " passes more than 6 "
                       "arguments" + std::string(structReturn ? " (counting the hidden struct-return "
                       "pointer)" : "") + ", which this backend doesn't support yet");
        }

        if (structReturn) {
            in.hasDst = false;
            emit(in);
            return dstAddr;
        }
        in.hasDst = !retType.empty() && retType != "void";
        if (in.hasDst) in.dst = newTemp(retType);
        emit(in);
        return in.hasDst ? in.dst : NO_VREG;
    }

    VReg emitCast(CastExpr& cast) {
        VReg v = emitExpr(*cast.operand);
        std::string from = cast.operand->exprType, to = cast.targetType;
        int fromSize = typeSize(from, mod_), toSize = typeSize(to, mod_);
        if (toSize <= fromSize) return v; // narrowing/no-op: memory stores already truncate correctly
        Instr i; i.op = isSignedType(from) ? Op::SextTo64 : Op::ZextTo64;
        i.lhs = v; i.size = fromSize; i.dst = newTemp(to);
        return emit(i);
    }

    Instr mk(Op op, VReg imm_or_slot) {
        Instr i; i.op = op; i.imm = imm_or_slot; i.dst = newTemp("long"); return i;
    }
    Instr mkConst(long long v) {
        Instr i; i.op = Op::ConstI; i.imm = v; i.dst = newTemp("long"); return i;
    }
    Instr mkBin(Op op, VReg l, VReg r, const std::string& resultType = "long") {
        Instr i; i.op = op; i.lhs = l; i.rhs = r; i.dst = const_cast<FuncBuilder*>(this)->newTemp(resultType);
        return i;
    }
};

} // namespace

// ============================================================================
// Module-level lowering
// ============================================================================
Module lower(Program& program) {
    Module mod;
    computeStructLayouts(program, mod);

    std::unordered_map<std::string, GlobalInfo> globals;
    std::unordered_map<std::string, FunctionDecl*> funcs;

    // Register every global/extern/const and every function signature
    // first, so function bodies (compiled next) can see all of them
    // regardless of declaration order — matches how semantic analysis
    // itself resolves top-level names.
    for (auto& d : program.declarations) {
        if (auto* let = dynamic_cast<LetStmt*>(d.get())) {
            if (!let->isGlobal) continue;
            const std::string& type = let->resolvedType.empty() ? let->type : let->resolvedType;
            if (let->isConst) {
                long long v = let->init ? foldConstExpr(*let->init) : 0;
                globals[let->name] = {type, true, v};
            } else {
                Global g; g.name = let->name; g.size = typeSize(type, mod);
                if (let->init) { g.hasInit = true; g.initValue = foldConstExpr(*let->init); }
                mod.globals.push_back(g);
                globals[let->name] = {type, false, 0};
            }
        } else if (auto* ext = dynamic_cast<ExternVarDecl*>(d.get())) {
            Global g; g.name = ext->name; g.isExtern = true;
            g.size = typeSize(ext->type, mod);
            mod.globals.push_back(g);
            globals[ext->name] = {ext->type, false, 0};
        } else if (auto* fn = dynamic_cast<FunctionDecl*>(d.get())) {
            funcs[fn->name] = fn;
        }
    }

    for (auto& d : program.declarations) {
        auto* fn = dynamic_cast<FunctionDecl*>(d.get());
        if (!fn) continue;
        if (fn->isExtern) {
            Function f; f.name = fn->name; f.isExtern = true; f.returnType = fn->returnType;
            mod.functions.push_back(std::move(f));
            continue;
        }
        if (fn->name == "main" && fn->body->statements.empty()) continue; // cX's required-but-unused main
        FuncBuilder builder(mod, globals, funcs);
        mod.functions.push_back(builder.build(*fn));
    }

    return mod;
}

} // namespace cx::ir
