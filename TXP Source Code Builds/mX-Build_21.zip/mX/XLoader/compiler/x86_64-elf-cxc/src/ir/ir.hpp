// ir.hpp — a small three-address-code IR sitting between the
// semantically-checked AST and the x86-64 backend.
//
// Design choice worth stating up front: every value lives in its own
// stack slot (see backend/x86_64.cpp) — no register allocator. Every IR
// instruction's operands are loaded from memory into a couple of fixed
// scratch registers, computed, and stored back. This is slower than a
// real allocator would produce, but it's straightforward to generate
// correctly and easy to verify by disassembly, which matters far more
// for a first native backend than performance does.
#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include "../parser/ast.hpp"

namespace cx::ir {

using VReg = int;
constexpr VReg NO_VREG = -1;

enum class Op {
    ConstI,          // dst = imm
    AddrLocal,       // dst = address of locals[imm]
    AddrGlobal,      // dst = address of global `symbol`
    AddrString,      // dst = address of strings[imm]
    Load,            // dst = *(T*)lhs, T is `size` bytes, sign/zero-extended per isUnsigned
    Store,           // *(T*)lhs = rhs, truncated to `size` bytes
    Move,            // dst = lhs
    Add, Sub, Mul, SDiv, SMod,
    BAnd, BOr, BXor, Shl, Shr,
    CmpEq, CmpNe, CmpLt, CmpLe, CmpGt, CmpGe,  // signed; dst = 0 or 1
    Neg, LNot, BNot,
    SextTo64,        // dst = sign-extend lhs from `size` bytes to 64
    ZextTo64,        // dst = zero-extend lhs from `size` bytes to 64
    Label,           // symbol = this instruction's own address
    Jump,            // -> symbol
    JumpIfZero,      // lhs == 0 -> symbol
    JumpIfNotZero,   // lhs != 0 -> symbol
    Call,            // dst (if hasDst) = symbol(args...) — max 6 args, all integer/pointer class
    Ret,             // return lhs (if hasDst), else bare return
};

struct Instr {
    Op op;
    VReg dst = NO_VREG, lhs = NO_VREG, rhs = NO_VREG;
    long long imm = 0;
    std::string symbol;
    int size = 8;              // memory width in bytes for Load/Store/Sext/Zext (1, 2, 4, or 8)
    bool isUnsigned = false;   // Load: zero-extend (true) vs sign-extend (false)
    std::vector<VReg> args;    // Call
    bool hasDst = false;       // Call: result present; Ret: value present
};

struct Local {
    std::string name;   // empty for compiler-generated temporaries
    int size = 8;
    bool isParam = false;
};

struct Function {
    std::string name;
    bool isExtern = false;
    std::string returnType;    // cX type string, "" = void
    std::vector<Local> locals; // params first (in order), then user locals, then temporaries
    int paramCount = 0;
    std::vector<Instr> code;
};

struct Global {
    std::string name;
    int size = 8;
    bool isExtern = false;
    bool hasInit = false;
    long long initValue = 0;
};

struct StructField { std::string name, type; int offset, size; };
struct StructLayout {
    int totalSize = 0;
    std::vector<StructField> fields;
    const StructField* find(const std::string& name) const {
        for (auto& f : fields) if (f.name == name) return &f;
        return nullptr;
    }
};

struct Module {
    std::vector<Function> functions;
    std::vector<Global> globals;
    std::vector<std::string> strings;  // string literal pool; AddrString.imm indexes into this
    std::unordered_map<std::string, StructLayout> structs;
};

// Lowers a semantically-checked Program (see semantic/semantic.hpp — must
// be run first, IR generation trusts every Expr::exprType it finds) into
// this IR. Throws std::runtime_error with a descriptive message for any
// construct this backend doesn't support yet (see README.md's "Known
// gaps" — e.g. struct-by-value params, float, more than 6 arguments).
Module lower(Program& program);

} // namespace cx::ir
