// linker.cpp — see linker.hpp
#include "linker.hpp"
#include <array>
#include <cstdio>
#include <fstream>
#include <memory>
#include <stdexcept>

namespace cx::linker {

static std::string runCommand(const std::string& cmd) {
    std::array<char, 256> buf;
    std::string output;
    std::unique_ptr<FILE, decltype(&pclose)> pipe(popen((cmd + " 2>&1").c_str(), "r"), pclose);
    if (!pipe) throw std::runtime_error("failed to launch: " + cmd);
    size_t n;
    while ((n = fread(buf.data(), 1, buf.size(), pipe.get())) > 0) output.append(buf.data(), n);
    return output;
}

void link(const std::vector<std::string>& objectFiles,
          const std::string& linkerScript,
          const std::string& outputPath,
          const std::vector<std::string>& extraFlags) {
    if (objectFiles.empty()) throw std::runtime_error("link: no object files given");

    std::string cmd = "ld -nostdlib -static";
    if (!linkerScript.empty()) cmd += " -T \"" + linkerScript + "\"";
    for (auto& f : extraFlags) cmd += " " + f;
    cmd += " -o \"" + outputPath + "\"";
    for (auto& o : objectFiles) cmd += " \"" + o + "\"";

    std::string log = runCommand(cmd);

    std::ifstream check(outputPath, std::ios::binary);
    if (!check.good()) {
        throw std::runtime_error("ld failed to produce " + outputPath + ":\n" + log);
    }
}

} // namespace cx::linker
