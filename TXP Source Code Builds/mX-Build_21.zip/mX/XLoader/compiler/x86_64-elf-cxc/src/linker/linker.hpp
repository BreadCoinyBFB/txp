// linker.hpp — see linker.cpp. This project adopts GNU ld rather than
// writing a linker from scratch (explicitly one of the two options laid
// out for this compiler) — see README.md for why.
#pragma once
#include <string>
#include <vector>

namespace cx::linker {

// Links `objectFiles` (a mix of x86_64-elf-cxc output and/or hand-written
// assembly .o files — ld doesn't care which produced which) into
// `outputPath` using `linkerScript` (a real GNU ld linker script, e.g.
// XLoader's Kernel24/linker.ld). Throws std::runtime_error with ld's own
// error output on failure.
void link(const std::vector<std::string>& objectFiles,
          const std::string& linkerScript,
          const std::string& outputPath,
          const std::vector<std::string>& extraFlags = {});

} // namespace cx::linker
