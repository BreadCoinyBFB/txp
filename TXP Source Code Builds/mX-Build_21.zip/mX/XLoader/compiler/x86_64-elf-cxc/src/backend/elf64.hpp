// elf64.hpp — see elf64.cpp
#pragma once
#include <string>

namespace cx::backend {

// Assembles `asmText` (NASM syntax) into a real ELF64 relocatable object
// file at `outputPath`, via nasm -f elf64. Throws std::runtime_error with
// nasm's own error output if assembly fails — that's almost always a bug
// in the assembly this backend generated, not in the input .cx.
void assembleToElf64(const std::string& asmText, const std::string& outputPath);

// Runs a handful of sanity checks against a produced .o file (ELF magic,
// class = 64-bit, machine = x86-64) — catches "the wrong nasm ran" or
// similar integration mistakes early, with a clear message, rather than
// producing a mysterious failure three tools later at link time.
void verifyElf64(const std::string& path);

} // namespace cx::backend
