// x86_64.hpp — see x86_64.cpp
#pragma once
#include <ostream>
#include "../ir/ir.hpp"

namespace cx::backend {
void emitAssembly(const ir::Module& mod, std::ostream& out);
}
