// registers.hpp — the physical x86-64 registers and System V AMD64
// calling-convention tables the backend needs. No code, just names — see
// x86_64.cpp for how they're actually used.
#pragma once
#include <array>
#include <string>

namespace cx::backend {

// The first 6 integer/pointer arguments, in order, per the System V
// AMD64 ABI. cX functions never take more than 6 params (see ir.cpp) so
// this table is always enough — no stack-passed arguments to handle.
inline const std::array<const char*, 6> kArgRegs64 = {
    "rdi", "rsi", "rdx", "rcx", "r8", "r9"
};
// 32-bit view of the same registers, for when a narrower load is correct.
inline const std::array<const char*, 6> kArgRegs32 = {
    "edi", "esi", "edx", "ecx", "r8d", "r9d"
};

// Two general-purpose scratch registers the instruction lowering uses to
// pull operands out of their stack slots, compute, and store the result
// back. Never live across an IR instruction boundary, so nothing needs
// saving/restoring around their use — see x86_64.cpp's emitInstr.
inline constexpr const char* kScratchA64 = "rax";
inline constexpr const char* kScratchA32 = "eax";
inline constexpr const char* kScratchA8  = "al";
inline constexpr const char* kScratchB64 = "rcx";
inline constexpr const char* kScratchB32 = "ecx";
inline constexpr const char* kScratchB8  = "cl";
// A third scratch register, needed only for shift instructions (whose
// count operand the CPU insists on finding specifically in CL) while a
// left-hand value already occupies A/B.
inline constexpr const char* kScratchC64 = "rdx";

inline constexpr const char* kReturnReg64 = "rax";

} // namespace cx::backend
