// elf64.cpp — see elf64.hpp. Drives nasm as the actual ELF64 object-file
// writer/instruction encoder (see x86_64.cpp's top comment for why), and
// does a light sanity check on what comes out.
#include "elf64.hpp"
#include <cstdio>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <array>
#include <memory>
#include <cstdlib>

namespace cx::backend {

static std::string runCommand(const std::string& cmd) {
    std::array<char, 256> buf;
    std::string output;
    std::string full = cmd + " 2>&1";
    std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(full.c_str(), "r"), pclose);
    if (!pipe) throw std::runtime_error("failed to launch: " + cmd);
    size_t n;
    while ((n = fread(buf.data(), 1, buf.size(), pipe.get())) > 0) {
        output.append(buf.data(), n);
    }
    return output;
}

void assembleToElf64(const std::string& asmText, const std::string& outputPath) {
    std::string asmPath = outputPath + ".gen.asm";
    {
        std::ofstream f(asmPath);
        if (!f) throw std::runtime_error("cannot write temporary file " + asmPath);
        f << asmText;
    }

    std::string cmd = "nasm -O0 -f elf64 \"" + asmPath + "\" -o \"" + outputPath + "\"";
    std::string log = runCommand(cmd);

    std::ifstream check(outputPath, std::ios::binary);
    bool exists = check.good();
    check.close();

    if (!exists) {
        throw std::runtime_error(
            "nasm failed to produce " + outputPath + ":\n" + log +
            "\n(generated assembly kept at " + asmPath + " for inspection)");
    }
    // Assembly succeeded — the intermediate .asm is only useful for
    // debugging a failure, so don't leave it lying around.
    std::remove(asmPath.c_str());

    verifyElf64(outputPath);
}

void verifyElf64(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open " + path + " to verify");
    unsigned char header[20] = {0};
    f.read(reinterpret_cast<char*>(header), sizeof(header));
    if (f.gcount() < 20) throw std::runtime_error(path + " is too small to be a valid ELF64 object");

    if (header[0] != 0x7F || header[1] != 'E' || header[2] != 'L' || header[3] != 'F') {
        throw std::runtime_error(path + " does not start with the ELF magic bytes — "
                                  "nasm did not produce what we expected");
    }
    if (header[4] != 2) { // ELFCLASS64
        throw std::runtime_error(path + " is not a 64-bit ELF file (EI_CLASS != ELFCLASS64)");
    }
    if (header[5] != 1) { // ELFDATA2LSB
        throw std::runtime_error(path + " is not little-endian (EI_DATA != ELFDATA2LSB)");
    }
    unsigned e_machine = header[18] | (header[19] << 8);
    if (e_machine != 0x3E) { // EM_X86_64
        throw std::runtime_error(path + " has e_machine=" + std::to_string(e_machine) +
                                  ", expected EM_X86_64 (0x3E)");
    }
}

} // namespace cx::backend
