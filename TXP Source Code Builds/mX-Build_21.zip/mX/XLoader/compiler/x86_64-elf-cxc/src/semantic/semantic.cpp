// semantic.cpp — implementation of cX semantic analysis
#include "semantic.hpp"
#include <cstdlib>

namespace cx {

void SemanticAnalyzer::error(const std::string& msg, int line) {
    throw SemaError("cX semantic error at line " + std::to_string(line) + ": " + msg, line);
}

void SemanticAnalyzer::pushScope() { scopes_.emplace_back(); constFlags_.emplace_back(); }
void SemanticAnalyzer::popScope() { scopes_.pop_back(); constFlags_.pop_back(); }

void SemanticAnalyzer::declareVar(const std::string& name, const std::string& type, int line, bool isConst) {
    auto& top = scopes_.back();
    if (top.count(name)) {
        error("redeclaration of variable '" + name + "' in the same scope", line);
    }
    top[name] = type;
    constFlags_.back()[name] = isConst;
}

std::string SemanticAnalyzer::lookupVar(const std::string& name) const {
    for (auto it = scopes_.rbegin(); it != scopes_.rend(); ++it) {
        auto found = it->find(name);
        if (found != it->end()) return found->second;
    }
    auto g = globals_.find(name);
    if (g != globals_.end()) return g->second;
    return "";
}

bool SemanticAnalyzer::lookupIsConst(const std::string& name) const {
    for (auto it = constFlags_.rbegin(); it != constFlags_.rend(); ++it) {
        auto found = it->find(name);
        if (found != it->end()) return found->second;
    }
    auto g = globalConstFlags_.find(name);
    if (g != globalConstFlags_.end()) return g->second;
    return false;
}

bool SemanticAnalyzer::isArrayType(const std::string& t) {
    return t.find('[') != std::string::npos;
}

std::string SemanticAnalyzer::arrayElemType(const std::string& t) {
    auto pos = t.find('[');
    return pos == std::string::npos ? t : t.substr(0, pos);
}

std::string SemanticAnalyzer::arraySizeStr(const std::string& t) {
    auto open = t.find('[');
    auto close = t.find(']');
    if (open == std::string::npos || close == std::string::npos || close <= open + 1) return "";
    return t.substr(open + 1, close - open - 1);
}

bool SemanticAnalyzer::isPointerType(const std::string& t) {
    return !t.empty() && t.back() == '*';
}

std::string SemanticAnalyzer::pointeeType(const std::string& t) {
    return t.empty() ? t : t.substr(0, t.size() - 1);
}

bool SemanticAnalyzer::isKnownType(const std::string& t) const {
    static const std::unordered_map<std::string, bool> builtins = {
        {"int", true}, {"float", true}, {"char", true}, {"bool", true},
        {"string", true}, {"void", true}, {"long", true},
    };
    return builtins.count(t) || structs_.count(t);
}

void SemanticAnalyzer::validateType(const std::string& type, int line) {
    if (isArrayType(type)) {
        std::string elem = arrayElemType(type);
        if (isArrayType(elem)) {
            error("nested array types aren't supported yet", line);
        }
        if (isPointerType(elem)) {
            std::string pointee = pointeeType(elem);
            if (isPointerType(pointee) || isArrayType(pointee)) {
                error("only one level of pointer indirection is supported", line);
            }
            if (!pointee.empty() && pointee != "void" && !isKnownType(pointee)) {
                error("unknown pointee type in array type '" + type + "'", line);
            }
            return;
        }
        if (elem.empty() || !isKnownType(elem)) {
            error("unknown element type in array type '" + type + "'", line);
        }
        return;
    }
    if (isPointerType(type)) {
        std::string pointee = pointeeType(type);
        if (isPointerType(pointee) || isArrayType(pointee)) {
            error("only one level of pointer indirection is supported", line);
        }
        if (!pointee.empty() && pointee != "void" && !isKnownType(pointee)) {
            error("unknown pointee type '" + pointee + "'", line);
        }
        return;
    }
    if (!isKnownType(type)) {
        error("unknown type '" + type + "'", line);
    }
}

bool SemanticAnalyzer::isLiteralExpr(Expr& e) const {
    if (dynamic_cast<IntLiteralExpr*>(&e)) return true;
    if (dynamic_cast<FloatLiteralExpr*>(&e)) return true;
    if (dynamic_cast<StringLiteralExpr*>(&e)) return true;
    if (dynamic_cast<CharLiteralExpr*>(&e)) return true;
    if (dynamic_cast<BoolLiteralExpr*>(&e)) return true;
    if (dynamic_cast<NullptrExpr*>(&e)) return true;
    if (auto* arr = dynamic_cast<ArrayLiteralExpr*>(&e)) {
        for (auto& el : arr->elements) {
            if (!isLiteralExpr(*el)) return false;
        }
        return true;
    }
    if (auto* cast = dynamic_cast<CastExpr*>(&e)) {
        return isLiteralExpr(*cast->operand);
    }
    return false;
}

void SemanticAnalyzer::analyze(Program& program) {
    // Pass 1a: register struct names as placeholders so forward references
    // between structs (and functions declared before their param structs) work.
    for (auto& declPtr : program.declarations) {
        if (auto* st = dynamic_cast<StructDecl*>(declPtr.get())) {
            if (structs_.count(st->name)) {
                error("struct '" + st->name + "' is already defined", st->line);
            }
            structs_[st->name] = {};
        }
    }

    // Pass 1b: validate struct fields now that all struct names are known.
    for (auto& declPtr : program.declarations) {
        if (auto* st = dynamic_cast<StructDecl*>(declPtr.get())) {
            analyzeStructDecl(*st);
        }
    }

    // Pass 1c: imports, extern vars, global lets, and function signatures —
    // everything a function body might reference, before any body is checked.
    for (auto& declPtr : program.declarations) {
        if (auto* imp = dynamic_cast<ImportDecl*>(declPtr.get())) {
            analyzeImport(*imp);
        } else if (auto* ext = dynamic_cast<ExternVarDecl*>(declPtr.get())) {
            analyzeExternVar(*ext);
        } else if (auto* fn = dynamic_cast<FunctionDecl*>(declPtr.get())) {
            if (functions_.count(fn->name)) {
                error("function '" + fn->name + "' is already defined", fn->line);
            }
            FunctionSig sig;
            sig.returnType = fn->name == "main" ? "int" : cTypeCheckName(fn->returnType);
            if (isArrayType(sig.returnType)) {
                error("arrays are not supported as function return types yet", fn->line);
            }
            if (fn->name != "main") validateType(sig.returnType, fn->line);
            for (auto& p : fn->params) {
                if (isArrayType(p.type)) {
                    error("arrays are not supported as function parameters yet", fn->line);
                }
                validateType(p.type, fn->line);
                sig.paramTypes.push_back(p.type);
            }
            functions_[fn->name] = sig;
        } else if (auto* let = dynamic_cast<LetStmt*>(declPtr.get())) {
            // Only global lets reach the top level (parser guarantees this).
            analyzeGlobalLet(*let);
        }
    }

    if (!functions_.count("main")) {
        error("cX program has no 'main' function", 0);
    }

    // Pass 2: check each non-extern function body.
    for (auto& declPtr : program.declarations) {
        if (auto* fn = dynamic_cast<FunctionDecl*>(declPtr.get())) {
            if (!fn->isExtern) analyzeFunction(*fn);
        }
    }
}

void SemanticAnalyzer::analyzeStructDecl(StructDecl& decl) {
    std::unordered_map<std::string, bool> seen;
    for (auto& f : decl.fields) {
        if (seen.count(f.name)) {
            error("duplicate field '" + f.name + "' in struct '" + decl.name + "'", decl.line);
        }
        seen[f.name] = true;
        if (isArrayType(f.type)) {
            error("arrays are not supported as struct fields yet (field '" + f.name + "')", decl.line);
        }
        validateType(f.type, decl.line);
    }
    structs_[decl.name] = decl.fields;
}

void SemanticAnalyzer::analyzeExternVar(ExternVarDecl& decl) {
    if (globals_.count(decl.name) || lookupVar(decl.name) != "") {
        error("'" + decl.name + "' is already declared", decl.line);
    }
    validateType(decl.type, decl.line);
    globals_[decl.name] = decl.type;
    globalConstFlags_[decl.name] = false;
}

void SemanticAnalyzer::analyzeGlobalLet(LetStmt& decl) {
    if (globals_.count(decl.name)) {
        error("'" + decl.name + "' is already declared", decl.line);
    }
    if (decl.type.empty()) {
        error("global '" + decl.name + "' needs an explicit type "
                  "(top-level declarations can't infer from an initializer)",
              decl.line);
    }
    validateType(decl.type, decl.line);
    if (isArrayType(decl.type) && arraySizeStr(decl.type).empty()) {
        error("global array '" + decl.name + "' needs an explicit size", decl.line);
    }
    if (decl.init) {
        if (!isLiteralExpr(*decl.init)) {
            error("global '" + decl.name + "' can only be initialized with a constant literal "
                      "(not a function call or an expression referencing other variables)",
                  decl.line);
        }
        analyzeExpr(*decl.init);
        const std::string& it = decl.init->exprType;
        bool ok = compatible(it, decl.type) ||
                  (isArrayType(decl.type) && isArrayType(it) && arrayElemType(it) == arrayElemType(decl.type));
        if (!ok) {
            error("cannot initialize global '" + decl.name + "' of type '" + decl.type +
                      "' with a value of type '" + it + "'",
                  decl.line);
        }
    }
    decl.resolvedType = decl.type;
    globals_[decl.name] = decl.type;
    globalConstFlags_[decl.name] = decl.isConst;
}

void SemanticAnalyzer::analyzeImport(ImportDecl& decl) {
    if (decl.isFileImport) return; // already inlined by the module loader before sema runs
    if (decl.path.size() == 2 && decl.path[0] == "mx" && decl.path[1] == "console") {
        consoleImported_ = true;
        return;
    }
    std::string joined;
    for (size_t i = 0; i < decl.path.size(); ++i) {
        if (i) joined += ".";
        joined += decl.path[i];
    }
    error("unknown module '" + joined + "' (only 'mx.console' or a file import like "
              "'import \"path/to/file.cx\";' is available right now)",
          decl.line);
}

void SemanticAnalyzer::analyzeFunction(FunctionDecl& decl) {
    pushScope();
    for (auto& p : decl.params) {
        declareVar(p.name, p.type, decl.line);
    }
    currentIsMain_ = (decl.name == "main");
    currentReturnType_ = currentIsMain_ ? "int" : cTypeCheckName(decl.returnType);

    analyzeBlock(*decl.body, /*newScope=*/false);
    popScope();
}

void SemanticAnalyzer::analyzeBlock(BlockStmt& block, bool newScope) {
    if (newScope) pushScope();
    for (auto& s : block.statements) analyzeStmt(*s);
    if (newScope) popScope();
}

void SemanticAnalyzer::analyzeStmt(Stmt& stmt) {
    if (auto* let = dynamic_cast<LetStmt*>(&stmt)) {
        if (let->init) analyzeExpr(*let->init);

        if (!let->type.empty()) {
            validateType(let->type, let->line);
            if (isArrayType(let->type)) {
                std::string elem = arrayElemType(let->type);
                std::string sizeStr = arraySizeStr(let->type);
                auto* arrLit = let->init ? dynamic_cast<ArrayLiteralExpr*>(let->init.get()) : nullptr;
                if (arrLit) {
                    size_t litLen = arrLit->elements.size();
                    std::string litElem = arrayElemType(arrLit->exprType);
                    bool elemOk = (litElem == elem) || (isNumeric(litElem) && isNumeric(elem));
                    if (!elemOk) {
                        error("array element type mismatch for '" + let->name + "': declared '" +
                                  elem + "', got '" + litElem + "'",
                              let->line);
                    }
                    if (!sizeStr.empty()) {
                        size_t declaredSize = static_cast<size_t>(std::atoi(sizeStr.c_str()));
                        if (declaredSize != litLen) {
                            error("array size mismatch for '" + let->name + "': declared " +
                                      sizeStr + ", got " + std::to_string(litLen) + " element(s)",
                                  let->line);
                        }
                    }
                    let->resolvedType = elem + "[" + std::to_string(litLen) + "]";
                } else if (let->init) {
                    if (!isArrayType(let->init->exprType) ||
                        arrayElemType(let->init->exprType) != elem) {
                        error("cannot initialize array '" + let->name + "' of type '" + let->type +
                                  "' with a value of type '" + let->init->exprType + "'",
                              let->line);
                    }
                    let->resolvedType = sizeStr.empty() ? let->init->exprType : let->type;
                } else if (!sizeStr.empty()) {
                    let->resolvedType = let->type;
                } else {
                    error("array '" + let->name + "' needs an explicit size or an initializer "
                              "to infer its size",
                          let->line);
                }
            } else {
                let->resolvedType = let->type;
                if (let->init) {
                    const std::string& it = let->init->exprType;
                    bool ok = compatible(it, let->type);
                    if (!ok) {
                        error("cannot initialize '" + let->name + "' of type '" + let->type +
                                  "' with a value of type '" + it + "'",
                              let->line);
                    }
                }
            }
        } else if (let->init) {
            if (let->init->exprType.empty() || let->init->exprType == "void") {
                error("cannot infer a type for '" + let->name + "'", let->line);
            }
            let->resolvedType = let->init->exprType;
        } else {
            error("'let " + let->name + "' needs either a type annotation or an initializer", let->line);
        }
        declareVar(let->name, let->resolvedType, let->line, let->isConst);
        return;
    }
    if (auto* ret = dynamic_cast<ReturnStmt*>(&stmt)) {
        if (ret->value) analyzeExpr(*ret->value);
        if (currentReturnType_ == "void" && ret->value && !currentIsMain_) {
            error("function returns 'void' but a value was returned", ret->line);
        }
        if (currentReturnType_ != "void" && !ret->value && !currentIsMain_) {
            error("function must return a value of type '" + currentReturnType_ + "'", ret->line);
        }
        return;
    }
    if (auto* exprStmt = dynamic_cast<ExprStmt*>(&stmt)) {
        analyzeExpr(*exprStmt->expr);
        return;
    }
    if (auto* block = dynamic_cast<BlockStmt*>(&stmt)) {
        analyzeBlock(*block, /*newScope=*/true);
        return;
    }
    if (auto* ifs = dynamic_cast<IfStmt*>(&stmt)) {
        analyzeExpr(*ifs->condition);
        analyzeStmt(*ifs->thenBranch);
        if (ifs->elseBranch) analyzeStmt(*ifs->elseBranch);
        return;
    }
    if (auto* whiles = dynamic_cast<WhileStmt*>(&stmt)) {
        analyzeExpr(*whiles->condition);
        loopDepth_++;
        analyzeStmt(*whiles->body);
        loopDepth_--;
        return;
    }
    if (auto* fors = dynamic_cast<ForStmt*>(&stmt)) {
        pushScope();
        if (fors->init) analyzeStmt(*fors->init);
        if (fors->cond) analyzeExpr(*fors->cond);
        if (fors->post) analyzeExpr(*fors->post);
        loopDepth_++;
        analyzeStmt(*fors->body);
        loopDepth_--;
        popScope();
        return;
    }
    if (dynamic_cast<BreakStmt*>(&stmt)) {
        if (loopDepth_ == 0) error("'break' used outside of a loop", stmt.line);
        return;
    }
    if (dynamic_cast<ContinueStmt*>(&stmt)) {
        if (loopDepth_ == 0) error("'continue' used outside of a loop", stmt.line);
        return;
    }
    // ImportDecl / FunctionDecl / StructDecl / ExternVarDecl should never
    // appear nested; ignore defensively.
}

void SemanticAnalyzer::analyzeAssignTarget(Expr& target) {
    bool validKind = dynamic_cast<IdentifierExpr*>(&target) || dynamic_cast<IndexExpr*>(&target) ||
                     dynamic_cast<MemberExpr*>(&target);
    if (auto* un = dynamic_cast<UnaryExpr*>(&target)) {
        if (un->op == "*") validKind = true; // *p = ... (write through a pointer)
    }
    if (!validKind) {
        error("left-hand side of assignment must be a variable, array element, struct field, "
                  "or a dereferenced pointer",
              target.line);
    }
    if (auto* id = dynamic_cast<IdentifierExpr*>(&target)) {
        if (lookupIsConst(id->name)) {
            error("cannot assign to '" + id->name + "' — it was declared 'const'", target.line);
        }
    }
    analyzeExpr(target); // reuses read-path logic to resolve/validate + set exprType
}

void SemanticAnalyzer::analyzeExpr(Expr& expr) {
    if (auto* e = dynamic_cast<IntLiteralExpr*>(&expr)) { e->exprType = "int"; return; }
    if (auto* e = dynamic_cast<FloatLiteralExpr*>(&expr)) { e->exprType = "float"; return; }
    if (auto* e = dynamic_cast<StringLiteralExpr*>(&expr)) { e->exprType = "string"; return; }
    if (auto* e = dynamic_cast<CharLiteralExpr*>(&expr)) { e->exprType = "char"; return; }
    if (auto* e = dynamic_cast<BoolLiteralExpr*>(&expr)) { e->exprType = "bool"; return; }
    if (auto* e = dynamic_cast<NullptrExpr*>(&expr)) { e->exprType = "nullptr"; return; }

    if (auto* id = dynamic_cast<IdentifierExpr*>(&expr)) {
        std::string t = lookupVar(id->name);
        if (!t.empty()) { id->exprType = t; return; }
        if (functions_.count(id->name)) { id->exprType = "function"; return; }
        if (id->name == "console" && consoleImported_) { id->exprType = "namespace:console"; return; }
        if (id->name == "console" && !consoleImported_) {
            error("'console' is not available (add 'import mx.console;')", id->line);
        }
        error("use of undeclared identifier '" + id->name + "'", id->line);
    }

    if (auto* arrLit = dynamic_cast<ArrayLiteralExpr*>(&expr)) {
        if (arrLit->elements.empty()) {
            error("empty array literals aren't supported (need at least one element)", arrLit->line);
        }
        analyzeExpr(*arrLit->elements[0]);
        std::string elemType = arrLit->elements[0]->exprType;
        for (size_t i = 1; i < arrLit->elements.size(); ++i) {
            analyzeExpr(*arrLit->elements[i]);
            const std::string& t = arrLit->elements[i]->exprType;
            if (t == elemType) continue;
            if (isNumeric(t) && isNumeric(elemType)) {
                if (t == "float") elemType = "float";
                continue;
            }
            error("array elements must all be the same type (got '" + elemType + "' and '" + t + "')",
                  arrLit->line);
        }
        arrLit->exprType = elemType + "[" + std::to_string(arrLit->elements.size()) + "]";
        return;
    }

    if (auto* idx = dynamic_cast<IndexExpr*>(&expr)) {
        analyzeExpr(*idx->array);
        std::string elemType;
        if (isArrayType(idx->array->exprType)) {
            elemType = arrayElemType(idx->array->exprType);
        } else if (isPointerType(idx->array->exprType)) {
            elemType = pointeeType(idx->array->exprType);
        } else {
            error("cannot index a value of type '" + idx->array->exprType + "' (not an array or pointer)",
                  idx->line);
        }
        analyzeExpr(*idx->index);
        if (idx->index->exprType != "int") {
            error("array index must be of type 'int', got '" + idx->index->exprType + "'", idx->line);
        }
        idx->exprType = elemType;
        return;
    }

    if (auto* lit = dynamic_cast<StructLiteralExpr*>(&expr)) {
        auto structIt = structs_.find(lit->structName);
        if (structIt == structs_.end()) {
            error("unknown struct '" + lit->structName + "'", lit->line);
        }
        const std::vector<Param>& fieldDefs = structIt->second;
        std::unordered_map<std::string, std::string> fieldTypes;
        for (auto& f : fieldDefs) fieldTypes[f.name] = f.type;

        std::unordered_map<std::string, bool> seen;
        for (auto& given : lit->fields) {
            const std::string& fname = given.first;
            auto ft = fieldTypes.find(fname);
            if (ft == fieldTypes.end()) {
                error("struct '" + lit->structName + "' has no field '" + fname + "'", lit->line);
            }
            if (seen.count(fname)) {
                error("field '" + fname + "' specified more than once", lit->line);
            }
            seen[fname] = true;
            analyzeExpr(*given.second);
            const std::string& gotType = given.second->exprType;
            bool ok = compatible(gotType, ft->second);
            if (!ok) {
                error("field '" + fname + "' of '" + lit->structName + "' expects type '" +
                          ft->second + "', got '" + gotType + "'",
                      lit->line);
            }
        }
        for (auto& f : fieldDefs) {
            if (!seen.count(f.name)) {
                error("missing field '" + f.name + "' in struct literal for '" + lit->structName + "'",
                      lit->line);
            }
        }
        lit->exprType = lit->structName;
        return;
    }

    if (auto* cast = dynamic_cast<CastExpr*>(&expr)) {
        analyzeExpr(*cast->operand);
        validateType(cast->targetType, cast->line);
        const std::string& from = cast->operand->exprType;
        const std::string& to = cast->targetType;
        bool ok = false;
        if (isScalar(from) && isScalar(to)) ok = true;
        if (isPointerType(to) && (from == "long" || from == "int")) ok = true;
        if (isPointerType(from) && (to == "long" || to == "int")) ok = true;
        if (isPointerType(from) && isPointerType(to)) ok = true;
        // cX's `string` already *is* a const char* under the hood; casting
        // to/from char* is how code walks a string's characters (cX has no
        // built-in string indexing of its own).
        if ((from == "string" && to == "char*") || (from == "char*" && to == "string")) ok = true;
        if (!ok) {
            error("cannot cast from '" + from + "' to '" + to + "'", cast->line);
        }
        cast->exprType = to;
        return;
    }

    if (auto* bin = dynamic_cast<BinaryExpr*>(&expr)) {
        analyzeExpr(*bin->left);
        analyzeExpr(*bin->right);
        const std::string& lt = bin->left->exprType;
        const std::string& rt = bin->right->exprType;
        const std::string& op = bin->op;
        bool isCompare = (op == "==" || op == "!=" || op == "<" || op == ">" || op == "<=" || op == ">=");
        bool isLogic = (op == "&&" || op == "||");
        bool isBitwise = (op == "&" || op == "|" || op == "^" || op == "<<" || op == ">>");
        if (isLogic) {
            bin->exprType = "bool";
        } else if (isCompare) {
            if ((lt == "string" || rt == "string") && (op == "==" || op == "!=")) {
                error("string comparison with '" + op + "' isn't supported yet (no strcmp helper wired up)",
                      bin->line);
            }
            bin->exprType = "bool";
        } else if (isBitwise) {
            bool bothInt = (lt == "int" && rt == "int");
            bool involvesLong = (lt == "long" || rt == "long");
            bool longCompatible = (lt == "long" || lt == "int") && (rt == "long" || rt == "int");
            if (bothInt) {
                bin->exprType = "int";
            } else if (involvesLong && longCompatible) {
                // A 64-bit address shifted/masked by a plain int shift-amount
                // or mask (e.g. `addr >> 32`, `x & 0xFFFFFFFF`) is exactly the
                // bit-twiddling this exists for; the result stays long.
                bin->exprType = "long";
            } else {
                error("operator '" + op + "' requires int or long operands (got '" + lt +
                          "' and '" + rt + "')",
                      bin->line);
            }
        } else if (op == "+" || op == "-") {
            // Pointer arithmetic: pointer +/- int, or pointer - pointer (of the same type).
            if (isPointerType(lt) && rt == "int") { bin->exprType = lt; return; }
            if (op == "+" && lt == "int" && isPointerType(rt)) { bin->exprType = rt; return; }
            if (op == "-" && isPointerType(lt) && isPointerType(rt) && lt == rt) {
                bin->exprType = "int";
                return;
            }
            if (isPointerType(lt) || isPointerType(rt)) {
                error("operator '" + op + "' on pointers only supports pointer +/- int, "
                          "or pointer - pointer of the same type",
                      bin->line);
            }
            if (lt == "string" || rt == "string") {
                error("operator '" + op + "' is not supported on strings", bin->line);
            }
            if (lt == "bool" || rt == "bool") {
                error("operator '" + op + "' is not supported on bool", bin->line);
            }
            if (isArrayType(lt) || isArrayType(rt) || structs_.count(lt) || structs_.count(rt)) {
                error("operator '" + op + "' is not supported on arrays or structs", bin->line);
            }
            bin->exprType = (lt == "float" || rt == "float") ? "float" : "int";
        } else {
            if (lt == "string" || rt == "string") {
                error("operator '" + op + "' is not supported on strings", bin->line);
            }
            if (lt == "bool" || rt == "bool") {
                error("operator '" + op + "' is not supported on bool", bin->line);
            }
            if (isArrayType(lt) || isArrayType(rt) || structs_.count(lt) || structs_.count(rt) ||
                isPointerType(lt) || isPointerType(rt)) {
                error("operator '" + op + "' is not supported on arrays, structs, or pointers", bin->line);
            }
            bin->exprType = (lt == "float" || rt == "float") ? "float" : "int";
        }
        return;
    }

    if (auto* un = dynamic_cast<UnaryExpr*>(&expr)) {
        if (un->op == "&") {
            bool isLvalue = dynamic_cast<IdentifierExpr*>(un->operand.get()) ||
                             dynamic_cast<IndexExpr*>(un->operand.get()) ||
                             dynamic_cast<MemberExpr*>(un->operand.get());
            if (!isLvalue) {
                error("'&' requires a variable, array element, or struct field", un->line);
            }
            analyzeExpr(*un->operand);
            un->exprType = un->operand->exprType + "*";
            return;
        }
        analyzeExpr(*un->operand);
        if (un->op == "*") {
            if (!isPointerType(un->operand->exprType)) {
                error("cannot dereference a value of type '" + un->operand->exprType +
                          "' (not a pointer)",
                      un->line);
            }
            un->exprType = pointeeType(un->operand->exprType);
            return;
        }
        if (un->op == "!") {
            un->exprType = "bool";
        } else if (un->op == "~") {
            if (un->operand->exprType != "int" && un->operand->exprType != "long") {
                error("unary '~' requires an int or long operand (got '" +
                          un->operand->exprType + "')",
                      un->line);
            }
            un->exprType = un->operand->exprType;
        } else { // '-'
            if (!isNumeric(un->operand->exprType)) {
                error("unary '-' requires a numeric operand", un->line);
            }
            un->exprType = un->operand->exprType;
        }
        return;
    }

    if (auto* asn = dynamic_cast<AssignExpr*>(&expr)) {
        analyzeAssignTarget(*asn->target);
        std::string declaredType = asn->target->exprType;
        analyzeExpr(*asn->value);
        bool ok = compatible(asn->value->exprType, declaredType);
        if (!ok && isPointerType(declaredType) && asn->value->exprType == "int" &&
            (asn->op == "+=" || asn->op == "-=")) {
            ok = true; // pointer += / -= int (also covers desugared p++ / p--)
        }
        if (!ok) {
            error("cannot assign a value of type '" + asn->value->exprType +
                      "' to a target of type '" + declaredType + "'",
                  asn->line);
        }
        asn->exprType = declaredType;
        return;
    }

    if (auto* call = dynamic_cast<CallExpr*>(&expr)) {
        // Special case: console.<method>(...)
        if (auto* member = dynamic_cast<MemberExpr*>(call->callee.get())) {
            auto* objId = dynamic_cast<IdentifierExpr*>(member->object.get());
            if (objId && objId->name == "console") {
                if (!consoleImported_) {
                    error("'console' is not available (add 'import mx.console;')", call->line);
                }
                int expectedArgs;
                std::string returnType;
                if (member->member == "print" || member->member == "write") {
                    expectedArgs = 1;
                    returnType = "void";
                } else if (member->member == "read_int") {
                    expectedArgs = 0;
                    returnType = "int";
                } else if (member->member == "read_line") {
                    expectedArgs = 0;
                    returnType = "string";
                } else {
                    error("console has no member '" + member->member +
                              "' (available: print, write, read_int, read_line)",
                          member->line);
                }
                if (static_cast<int>(call->args.size()) != expectedArgs) {
                    error("console." + member->member + " expects " + std::to_string(expectedArgs) +
                              " argument(s), got " + std::to_string(call->args.size()),
                          call->line);
                }
                for (auto& a : call->args) analyzeExpr(*a);
                member->exprType = "function";
                objId->exprType = "namespace:console";
                call->exprType = returnType;
                return;
            }
            error("member access is only supported for 'console' calls in this version of cX", member->line);
        }

        auto* calleeId = dynamic_cast<IdentifierExpr*>(call->callee.get());
        if (!calleeId) {
            error("expression is not callable", call->line);
        }
        auto it = functions_.find(calleeId->name);
        if (it == functions_.end()) {
            error("call to undeclared function '" + calleeId->name + "'", call->line);
        }
        const FunctionSig& sig = it->second;
        if (call->args.size() != sig.paramTypes.size()) {
            error("'" + calleeId->name + "' expects " + std::to_string(sig.paramTypes.size()) +
                      " argument(s), got " + std::to_string(call->args.size()),
                  call->line);
        }
        for (size_t i = 0; i < call->args.size(); ++i) {
            analyzeExpr(*call->args[i]);
            const std::string& at = call->args[i]->exprType;
            const std::string& pt = sig.paramTypes[i];
            bool ok = compatible(at, pt);
            if (!ok) {
                error("argument " + std::to_string(i + 1) + " to '" + calleeId->name +
                          "' should be '" + pt + "', got '" + at + "'",
                      call->line);
            }
        }
        calleeId->exprType = "function";
        call->exprType = sig.returnType;
        return;
    }

    if (auto* member = dynamic_cast<MemberExpr*>(&expr)) {
        analyzeExpr(*member->object);
        if (member->object->exprType == "namespace:console") {
            error("'console." + member->member + "' can only be used as part of a function call",
                  member->line);
        }
        // A pointer to a struct auto-dereferences for '.' access, same as
        // writing ptr->field would in C — cX doesn't need a separate arrow
        // operator for this.
        std::string objType = member->object->exprType;
        if (isPointerType(objType)) objType = pointeeType(objType);

        auto structIt = structs_.find(objType);
        if (structIt == structs_.end()) {
            error("member access is not supported on type '" + member->object->exprType + "'",
                  member->line);
        }
        for (auto& f : structIt->second) {
            if (f.name == member->member) {
                member->exprType = f.type;
                return;
            }
        }
        error("struct '" + objType + "' has no field '" + member->member + "'",
              member->line);
    }

    error("internal error: unrecognized expression node", expr.line);
}

} // namespace cx
