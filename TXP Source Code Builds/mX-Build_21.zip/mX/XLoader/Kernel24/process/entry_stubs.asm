; entry_stubs.asm — addresses of cX task-entry functions.
;
; cX has no function-pointer type (confirmed directly against the
; compiler, not assumed): an identifier naming a function has type
; "function", and there's no cast or implicit conversion from that to
; `long` or any pointer type. process/task.cx's task_create needs an
; actual address to fabricate a task's initial instruction pointer from,
; so each entry function that needs to be handed to task_create gets a
; one-line trampoline here — same trick arch/x86_64/lowlevel.asm's
; kernel_image_end already uses for "the address of something cX can't
; directly name".

BITS 64
section .text

extern idle_task_entry
global idle_task_entry_addr
idle_task_entry_addr:
    lea rax, [rel idle_task_entry]
    ret

extern hello_task_entry
global hello_task_entry_addr
hello_task_entry_addr:
    lea rax, [rel hello_task_entry]
    ret

extern counter_task_entry
global counter_task_entry_addr
counter_task_entry_addr:
    lea rax, [rel counter_task_entry]
    ret

extern mx_init
global mx_init_addr
mx_init_addr:
    lea rax, [rel mx_init]
    ret

section .note.GNU-stack noalloc noexec nowrite progbits
