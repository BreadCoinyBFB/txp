This Kernel is only in Termux.

Kernel24/
├── boot/
│   └── entry.asm       # _start — first code that actually runs
├── arch/x86_64/
│   ├── lowlevel.asm       # port I/O, control-register access, cpuid/rdmsr,
│   │                       # idt_load, kernel_image_end — every single-
│   │                       # instruction primitive cX has no syntax for
│   ├── idt/
│   │   └── idt.cx          # Interrupt Descriptor Table
│   └── interrupts/
│       ├── isr_stubs.asm    # ISR trampolines
│       └── isr.cx           # dispatch / exception reporting
├── kernel/
│   ├── main.cx           # kernel_main() — orchestrates everything below
│   ├── panic.cx
│   ├── bootinfo.cx
│   └── version.cx
├── memory/
│   ├── physical.cx       # bitmap physical memory manager
│   ├── align.cx          # alignment & bitmap math
│   ├── virtual.cx        # empty — not needed yet, see docs/cx-integration.md
│   └── heap.cx           # empty — same reason
├── drivers/
│   └── screen/
│       └── screen.cx      # VGA text output
├── cX/                     # the cX compiler; every file above is built
│                           # through it (see the Makefile's cx-gen rules)
├── tools/
│   └── patch_checksum.py   # same tool XLoader uses, same contract
├── docs/
│   ├── design.md            # memory map, hand-off contract, what's deferred
│   ├── cx-integration.md     # how cX grew pointers/extern/long for this
│   └── roadmap.md
├── linker.ld
├── Makefile
├── README.md
└── LICENSE

There is no hand-written C anywhere in this tree — every kernel-logic
file is `.cx`; only single-instruction primitives and the two stack-
frame-sensitive entry points stay in NASM. See `docs/cx-integration.md`.

## Build

Needs `nasm`, `x86_64-elf-gcc` (a freestanding cross-compiler — plain
`gcc` won't produce a bare-metal x86_64 binary), `ld`, `objcopy`, `g++`
(to build `cxc` itself), and `python3`. From this directory:

```
make          # -> build/kernel24.bin
make clean
```

`cX/build/cxc` is built automatically the first time (`make -C cX`) if it
isn't already present — that step uses your regular host `g++`, not the
cross-compiler, since `cxc` is a normal program that runs on your machine
to *generate* the C that the cross-compiler then builds for the kernel.

Building from XLoader's own `Makefile` (one directory up) picks this up
automatically — `make` there detects `Kernel24/Makefile`, builds this
project, and uses its output in place of the placeholder stub. See
XLoader's `docs/memory-map.md` for the image contract both sides honor.

## Status

Early stage: done — see `docs/roadmap.md`. Screen output, a physical
memory manager, and interrupt handling are all in place, transpiled
from cX and boot-tested (built + disassembled-and-verified against
XLoader's real hand-off, the same way XLoader itself was).
