# Kernel24 roadmap

## Early stage ✅

- [x] Receive control from XLoader — `boot/entry.asm` (`_start`, entered
      via computed jump at exactly `0x100008`)
- [x] Read BootInfo from XLoader — `kernel/bootinfo.cx`
- [x] Initialize the kernel environment — `boot/entry.asm` zeroes `.bss`
      and switches to a real kernel stack before anything else runs
- [x] Print "Kernel24 v0.1" — `kernel/main.cx`, version numbers from
      `kernel/version.cx`
- [x] Verify CPU is in 64-bit Long Mode — `arch/x86_64/lowlevel.asm`'s
      `cpu_verify_long_mode` (one `cpuid` check, one `EFER.LMA` read —
      see the file for why it's kept to exactly that and no more)
- [x] Initialize a basic screen output — `drivers/screen/screen.cx` (VGA
      text mode: clear, print, scroll, color, hex/decimal number printing)
- [x] Initialize a basic physical memory manager — `memory/physical.cx`,
      bitmap allocator seeded from the E820 map, math from `memory/align.cx`
- [x] Initialize interrupt handling — `arch/x86_64/idt/idt.cx` +
      `arch/x86_64/interrupts/` (all 256 vectors wired up; "empty" in the
      sense of no recovery logic, but each one reports clearly and halts
      rather than silently falling through)
- [x] Enter the kernel main loop — `kernel/main.cx` (`while (true) { cx_hlt(); }`)

Verified the same way as XLoader: actually built (cxc → x86_64-elf-gcc →
nasm → ld → objcopy → patch_checksum.py) and disassembled, not just
reviewed. That process caught one real bug worth naming —
`linker.ld`'s original `.header`/`.text` split let `.text`'s inherited
16-byte alignment push `_start` to load-address+0x10 instead of the
required +8, which would have made XLoader's computed jump land 8 bytes
into the middle of `_start`'s own instructions. Fixed by merging the
header into `.text` directly (see `linker.ld`'s comment).

There is no hand-written C anywhere in this tree anymore — every kernel
logic file above is `.cx`; only the truly asm-only pieces (the entry
stub, the ISR trampoline table, and the handful of single-instruction
primitives in `lowlevel.asm`) are NASM. See `docs/cx-integration.md`
for how cX grew the pointer support that made this possible.

## Memory management 🟡

- [x] Virtual memory — `memory/virtual.cx`: Kernel24's own 4-level page
      tables (PML4/PDPT/PD/PT, 4 KiB pages), a general `vmm_map`/
      `vmm_unmap`/`vmm_translate`, and a CR3 switch off of XLoader's
      tables entirely. Still only identity-maps the same 0-8 MiB
      `memory/physical.cx` already tracks — see that file's comment for
      the (safe, understood, deliberately deferred) next step.
- [x] Kernel heap — `memory/heap.cx`: `kmalloc`/`kfree` on a real
      address-ordered free list (first-fit, splits on alloc, forward-
      coalesces on free), built on `vmm_map` + `pmm_alloc_page`. See the
      file's own comment for what it deliberately doesn't do yet
      (backward coalescing, returning pages to the PMM, double-free
      detection).
- [ ] Everything past that: no per-allocation tracking/stats beyond a
      total-free-bytes counter, no `vfree`-style unmapping when the heap
      shrinks (it never does yet), no NX/W^X page protection.

**Verification note, different from the rest of this file:** the
"Early stage" section above was checked by actually building and
disassembling a real binary. This section wasn't — the environment this
was written in has no `nasm`, so the real pipeline (cX → asm → nasm →
ld → objcopy) can't run end to end here. What *was* checked: every new
and modified `.cx` file compiles clean through the real
`x86_64-elf-cxc` (built from source in that same environment) all the
way through lexing, parsing, semantic analysis, and IR/assembly
generation via its `--emit-asm` flag — which catches type errors, wrong
signatures, unknown identifiers, and the like, but not link-time or
runtime bugs. Build and boot-test this before trusting it the way the
rest of this checklist has earned.

## Stage 3 🟡

- [x] Process management — `process/task.cx`: PIDs, a fixed 16-task
      table, creation, and termination. `process/scheduler.cx`: a
      round-robin scheduler plus a real preemptive context switch —
      see `arch/x86_64/interrupts/isr_stubs.asm`'s comment for the
      "hand back a stack pointer" mechanism that makes the switch
      itself a couple of lines of asm rather than a hand-rolled one.
      Every task runs at ring 0 (shares the kernel's own address
      space) except the ones `task_create_user` makes — see the
      security-model entry below.
- [x] Memory management improvements — `memory/virtual.cx` grew
      `PTE_USER`, address-space-parameterized `vmm_map_in`/
      `vmm_unmap_in`/`vmm_translate_in`, and `vmm_new_address_space`
      (shares the kernel's low mapping, keeps everything else
      process-private). `memory/physical.cx` and `memory/heap.cx` are
      unchanged — still the same deliberately-deferred gaps their own
      Stage 2 entries above already named.
- [x] System-call interface — `arch/x86_64/interrupts/syscall.cx`:
      `int 0x80`, dispatched by vector like every other interrupt (see
      `arch/x86_64/interrupts/isr.cx`). Seven numbers: output, input,
      memory allocation (x2: alloc/free), process information,
      process termination, and yield. `process/syslib.cx` is the
      cX-side wrapper any task calls instead of the raw trap.
      Non-blocking by design — see that file's own comment on why a
      real blocking read is different, later scope.
- [x] Filesystem foundation — `fs/vfs.cx`: a fixed 32-inode pool
      (files and directories both), file handles, path resolution
      (absolute and cwd-relative), and mkdir/create/open/read/write/
      close/unlink. `drivers/storage/ramdisk.cx` is the storage-driver
      side of that — a real four-function interface
      (`storage_read_block`/`write_block`/`alloc_block`/`free_block`)
      that happens to be RAM-backed today. Single block (512 bytes)
      per file — see `fs/vfs.cx`'s own comment for why that's a
      foundation-level limit, not an oversight.
- [x] Hardware/device layer — `drivers/pic/pic.cx` (8259 remap,
      IRQ0/IRQ1 unmasked, everything else stays masked),
      `drivers/timer/timer.cx` (PIT channel 0, 100 Hz, drives the
      scheduler), `drivers/keyboard/keyboard.cx` (moved out of
      `mX/shell` — now IRQ-driven with a ring buffer instead of
      polling the hardware port directly, see its own comment),
      `drivers/serial/serial.cx` (COM1, polled, for debug output that
      doesn't depend on the VGA text buffer).
- [x] Basic system security model — `arch/x86_64/gdt/gdt.cx`:
      Kernel24's own GDT (replacing reliance on XLoader's), with DPL=3
      user code/data segments and a loaded TSS. `arch/x86_64/idt/
      idt.cx`'s syscall gate is the one vector a ring-3 caller can
      reach; every other vector stays DPL=0. `arch/x86_64/interrupts/
      isr.cx` now tells a user task's own bug apart from a kernel one:
      an unhandled CPU exception in a `is_user` task kills that task
      and keeps going (real process isolation, backed by
      `vmm_new_address_space`'s separate PML4s) instead of halting the
      whole kernel — see that file's `kill_faulting_task` vs.
      `kernel_panic_from_interrupt`.
- [x] Userspace foundation — the kernel/user distinction is real at
      the GDT/paging level (`PTE_USER`, the user selectors above,
      `task_create_user`'s ring-3 initial-frame construction). Not
      done: anything actually *launching* at ring 3 by default — there's
      still no on-disk loader to point it at (`fs/vfs.cx` is a
      foundation, not that), so this is deliberately "begin preparing
      for native cX applications" (the Stage 3 brief's own words) and
      not further than that yet.
- [x] Developer tooling — `Makefile`'s new `cx-check` target (compiles
      every `.cx` file through the real compiler, no `nasm`/`ld`
      needed — the same check used by hand throughout this stage's own
      development, now reusable). `arch/x86_64/interrupts/isr.cx`'s
      `dump_registers` is a real kernel-debugging facility: every GPR,
      printed from the exact saved frame `isr_stubs.asm` builds, on any
      unhandled exception.

**Verification note, same shape as Stage 2's:** every `.cx` file in
this stage — new and modified both — compiles clean through the real
`x86_64-elf-cxc`, lexing through IR/assembly generation, via
`make cx-check` (72 files: everything in `CX_SOURCES` and
`MX_SOURCES`). The new/modified `.asm` (`arch/x86_64/lowlevel.asm`'s
additions, `arch/x86_64/interrupts/isr_stubs.asm`'s context-switch
diff, `process/entry_stubs.asm`) was written and re-read carefully but
**not** assembled — this environment still has no `nasm` (a from-
source build was attempted against the bundled archive in
`XLoader/tools/archives/` and abandoned: it needs `autoconf`/
`autoheader` to generate `configure`/`config.h` from `configure.ac`,
neither of which is available here, and hand-substituting an
autotools build for a project this size was judged not worth the risk
of introducing a *different*, harder-to-spot mistake). Two pieces
carry the most real risk if something's wrong: the GDT/TSS byte
layout in `arch/x86_64/gdt/gdt.cx` (checked by hand, multiple times,
against the descriptor formats — but "checked by hand" is exactly the
category of mistake a real assemble+boot catches and a read-through
doesn't), and the `isr_stubs.asm`/`process/task.cx` saved-frame layout
the context switch depends on being byte-for-byte consistent across
three separate files. Build and boot-test before trusting any of this
the way the "Early stage" section above has earned.

## Not started

A real disk driver (`drivers/storage/ramdisk.cx` is RAM-backed, not
disk-backed — the storage-driver *interface* is real, a second
implementation behind it isn't), multi-block files, an on-disk
executable loader (and therefore a real `exec` of an arbitrary
program, rather than Stage 3's fixed small set — see
`shell/builtin/run.cx`), an actually-launched ring-3 task by default,
blocking I/O, and IST-backed stacks for double faults. See
`docs/design.md` for what's deliberately deferred and why, and
`docs/cx-integration.md` for the handful of things cX still can't
express and how the kernel code works around them.
