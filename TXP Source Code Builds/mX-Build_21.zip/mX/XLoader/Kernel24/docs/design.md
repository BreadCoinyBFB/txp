# Kernel24 design

## The hand-off contract (XLoader → Kernel24)

Kernel24 is entered directly by a computed jump — there's no ELF loader,
no Multiboot parsing, nothing. That means the contract has to be exact:

- **Load address**: `0x100000` (1 MiB), physical = virtual (identity-mapped
  by XLoader's page tables).
- **Image header**: the first 8 bytes are `KERNEL24_MAGIC` (4 bytes) then
  a checksum (4 bytes) — see `linker.ld` and `tools/patch_checksum.py`.
  XLoader's `kernel24_verify` checks both before jumping in.
- **Entry point**: `0x100008` (load address + 8, past the header) — this
  is `_start` in `boot/entry.asm`, and `linker.ld` is written specifically
  to guarantee it lands exactly there (see the comment in `linker.ld`
  about why the header and `.text` share one output section).
- **CPU state at entry**: 64-bit long mode, XLoader's flat GDT already
  loaded, paging enabled with the first 8 MiB identity-mapped, interrupts
  off, `RSP = 0x90000` (a throwaway stack — `_start`'s first job is
  switching off of it), `RDI` = pointer to XLoader's `BootInfo` struct.

## Memory map

| Address              | Contents |
|-----------------------|----------|
| `0x00000000`–`0x1FFFFF` | Unconditionally reserved by the PMM (see below) — covers the IVT/BDA, XLoader itself, its page tables, the E820 map, BootInfo, and Kernel24's own image |
| `0x00100000` (1 MiB)  | Kernel24's load address (8-byte header, then `_start`) |
| `__bss_start`–`__bss_end` | Kernel24's `.bss` — IDT (4 KiB), PMM bitmap (256 B), 16 KiB kernel stack |
| `0x00200000`–`0x007FFFFF` | Tracked by the PMM per the E820 map (usable vs. reserved) |
| `0x00800000` (8 MiB)  | End of XLoader's identity mapping — the PMM doesn't track anything past here yet |

The physical memory manager deliberately doesn't track anything past
8 MiB: XLoader's page tables only identity-map that much (see XLoader's
own `docs/memory-map.md`), so a "free" page beyond it would fault the
instant anything tried to use it. Tracking more becomes possible once
Kernel24 builds its own page tables — see `memory/virtual.cx` below.

## What's here vs. not

**Implemented** (see `docs/roadmap.md` for the checklist mapping):
screen output (VGA text), a bitmap physical memory manager seeded from
the E820 map, Kernel24's own 4-level page tables with a general
`vmm_map`/`vmm_unmap` (`memory/virtual.cx`), a free-list kernel heap
built on top of that (`memory/heap.cx`), a full 256-vector IDT with
reporting (not recovering) handlers, the boot hand-off itself, and —
as of Stage 3 — process management, a preemptive scheduler, a syscall
interface, a filesystem foundation, IRQ-driven keyboard/timer/serial
drivers, Kernel24's own GDT/TSS, and per-process address spaces. See
`docs/roadmap.md`'s Stage 3 section for the file-by-file breakdown.

**Deliberately not here yet**:
- **A dedicated IST stack for double-fault safety** — every IDT entry
  still uses `IST=0` (run handlers on whatever stack was active). This
  one held even through Stage 3 adding ring-3 support: a corrupted
  stack during a fault is a *more* real risk now than when this was
  first written (more tasks, more stacks, one of them possibly
  untrusted), which is exactly why it's worth calling out again rather
  than assuming it quietly stopped mattering.
- **Tracking more than 8 MiB of physical memory** — `memory/virtual.cx`
  makes this safe to attempt (Kernel24 no longer depends on XLoader's
  own page tables at all), but bumping `PMM_MANAGED_LIMIT` needs the
  change checked against real E820/RAM data, which isn't possible in the
  environment this was written in. See that file's own comment for the
  exact next step.
- **Freeing physical pages back from the heap**, and **backward
  coalescing** of freed heap blocks — see `memory/heap.cx`'s own comment
  for both; neither has come up as a real problem yet.
- **A real disk-backed storage driver, and multi-block files** —
  `drivers/storage/ramdisk.cx` implements the same four-function
  interface a real one would, but is RAM-backed, and `fs/vfs.cx` gives
  each file exactly one block (512 bytes). See `docs/roadmap.md`'s
  Stage 3 "Not started" section.
- **Anything actually launching at ring 3 by default** — the GDT/TSS,
  `PTE_USER`, and `task_create_user`'s ring-3 frame construction are
  all real and active, but there's still no on-disk executable loader
  to point them at. "Begin preparing for native cX applications" (the
  Stage 3 brief's own phrase) is exactly the state this is in.

