# cX in Kernel24

## Where cX is used now: everywhere

There is no hand-written C left in this tree. Every kernel-logic file is
`.cx`:

- `memory/align.cx` — page alignment and bitmap index/mask arithmetic
- `kernel/version.cx` — the kernel's version number
- `kernel/bootinfo.cx` — the `BootInfo`/`E820Entry` struct layouts XLoader
  hands off, and validating the handoff
- `drivers/screen/screen.cx` — VGA text-mode output
- `memory/physical.cx` — the bitmap physical page allocator
- `arch/x86_64/idt/idt.cx` — building the IDT
- `arch/x86_64/interrupts/isr.cx` — the C side of interrupt handling
- `kernel/panic.cx` — the unrecoverable-error path
- `kernel/main.cx` — `kernel_main`, tying all of the above together

All of it compiles straight to a real ELF64 object file via
`compiler/x86_64-elf-cxc` — no C, no transpilation, no hosted or cross C
compiler anywhere in this build. See that compiler's own `README.md` for
how it works and why it's built the way it is (short version: it emits
x86-64 assembly and hands that to nasm, and links via GNU ld — both
adopted rather than reimplemented from scratch, same as everything else
in this project leans on nasm/ld rather than hand-rolling either).

## What changed: cX grew a pointer

The previous version of this document explained why pointer-shaped work
(reading `BootInfo`, touching `0xB8000`, building the IDT) had to stay
in hand-written C. That's no longer true. cX now has:

- **`T*` pointer types** — one level of indirection, with `&` (address-of),
  `*` (dereference), pointer arithmetic (`p + n`), and pointer indexing
  (`p[i]`, identical to array indexing)
- **`.` that auto-dereferences** — `p.field` works whether `p` is a
  struct value or a pointer to one (no separate `->` needed, though it's
  accepted too, as an alias, for anyone whose fingers expect it from C)
- **`as` casts** — `expr as Type`, covering int/long/float/char
  conversions and pointer↔integer/pointer↔pointer reinterpretation
  (`0xB8000 as char*`, `handler as long`)
- **`extern fn` / `extern let`** — declaring a function or global
  variable that's *defined* elsewhere (in another `.cx` file's own
  translation unit, or in assembly) without pulling in its
  implementation. This is how cross-file calls work now — see below.
- **`long`** — a real 64-bit integer type, alongside `int` (32-bit).
  `int → long` widens implicitly; `long → int` always needs an explicit
  `as int`, since that direction can silently truncate a 64-bit address
  and that's exactly the kind of mistake worth forcing into the open.
- **Hex literals** (`0xB8000`)

## Why `extern`, not `import`, between kernel files

cX already had a file-import mechanism (`import "other.cx";`) that
inlines the imported file's declarations directly into the importer's
AST before codegen. That works well for a single `cxc` invocation over
a self-contained program — but Kernel24's Makefile compiles every `.cx`
file **separately** into its own object file, exactly like the old
per-file C compilation did. Inlining `align.cx` into `physical.cx` would
duplicate `align_up`'s definition into two separately-linked object
files — a duplicate-symbol error at link time.

So the convention here is: cross-file cX-to-cX calls are declared with
`extern fn`, and cross-file globals with `extern let`, exactly the way
the old C headers declared them. Each `.cx` file that calls
`align_up`, `screen_print`, `panic`, etc. declares it as `extern`
at the top, matching the real definition's signature exactly. The
linker resolves it the same way it always resolved same-named C
functions across translation units — nothing about that part changed.

## What's still assembly, and why

Two categories of thing remain in `.asm`, both for the same underlying
reason: cX has no inline-assembly escape hatch, and isn't trying to grow
one.

- **`arch/x86_64/lowlevel.asm`** — `outb`/`inb`/`io_wait`, `cx_cli`/
  `cx_sti`/`cx_hlt`, `read_cr2`, `cpu_verify_long_mode` (CPUID + RDMSR),
  and `idt_load` (the `lidt` instruction itself). Every one of these is
  a single CPU instruction or a tiny fixed sequence of them — there's no
  "logic" to move into cX, just an instruction cX has no syntax for.
  Called from cX via ordinary `extern fn` declarations, using the
  regular System V calling convention.
- **`boot/entry.asm` and `arch/x86_64/interrupts/isr_stubs.asm`** —
  unchanged from before. Both need precise control over the stack frame
  at exactly the moment execution arrives from somewhere else (the
  bootloader; a CPU interrupt), which is awkward from either C or cX,
  and neither actually contains any decision-making logic worth
  expressing in a higher-level language.

One specific case worth calling out: the CPU's `IDTR` register wants an
exact, padding-free `{limit: u16, base: u64}` 10-byte layout. cX has no
`packed struct` attribute to force that — its structs use plain,
natural alignment (which happens to already match the 16-byte IDT
*entry* format and the 48-byte `BootInfo` format with zero padding, by
design, but wouldn't help here). Rather than add a packed-struct feature
for this one 10-byte case, `idt_load` builds the IDTR directly on the
stack in assembly, where exact byte layout is the natural thing to
express anyway.

Similarly, cX has no notion of "a large static buffer" beyond ordinary
global variables — and the IDT table (4 KiB) needs storage that
outlives `idt_init()`'s own stack frame, since the CPU keeps reading it
forever after `lidt`. That buffer (`idt_table`) is reserved in
`lowlevel.asm`'s `.bss` section and referenced from `idt.cx` via
`extern let`, the same way `isr_stub_table` already was.

## What's still not expressible

- **8/16-bit integer widths.** cX only has `int` (32-bit), `long`
  (64-bit), and `char` (8-bit, used as a byte, not really "a small
  integer type" in spirit). The IDT entry format needs 16-bit and 8-bit
  fields; `idt.cx` builds them by writing individual bytes into a raw
  `char*` buffer rather than declaring a struct with the "real" field
  widths. Same idea for the VGA buffer: each cell is two explicit
  1-byte stores instead of one 16-bit store.
- **Arrays as struct fields**, and arrays with unclear ownership beyond
  a single translation unit's lifetime, are still unsupported — not
  needed anywhere in the current kernel, so left alone rather than
  designed under time pressure.
- **Generic monomorphization, enums, unions, struct methods** — none of
  these came up as blockers for Kernel24, so none of them exist. cX grows
  in the direction the kernel actually needs, not speculatively.
