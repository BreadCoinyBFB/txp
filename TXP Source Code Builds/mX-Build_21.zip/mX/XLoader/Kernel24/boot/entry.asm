; ============================================================================
; entry.asm — Kernel24's real entry point
; ============================================================================
; XLoader jumps here directly (KERNEL24_ENTRY_ADDR = load address + 8) in
; 64-bit long mode, with RDI already holding a pointer to its BootInfo
; structure — that's exactly the System V AMD64 first-argument register, so
; there's no argument-marshalling to do. The only job here is to get off
; XLoader's throwaway stack (0x90000) and onto a real one before calling
; into C, since kernel_main is going to want a stack that's actually ours.

BITS 64

section .text.entry

global _start
extern kernel_main
extern __bss_start
extern __bss_end

_start:
    mov rsp, kernel_stack_top
    xor rbp, rbp             ; zero frame pointer: conventional "bottom of stack" marker

    mov r15, rdi              ; stash XLoader's BootInfo pointer — the .bss
                               ; zeroing below needs RDI for itself

    ; Zero .bss explicitly. There's no C runtime here to do this for us —
    ; it would *happen* to already be zero today, since the disk image is
    ; zero-padded out to its full reserved slot and .bss is the last
    ; section (see linker.ld), but relying on that is fragile: it silently
    ; breaks the moment section order changes or a byte of real data ends
    ; up placed after .bss. Doing it explicitly costs nothing and can't be
    ; wrong.
    mov rdi, __bss_start
    mov rcx, __bss_end
    sub rcx, rdi
    xor rax, rax
    cld
    rep stosb

    mov rdi, r15               ; restore the BootInfo pointer as the argument
    call kernel_main             ; System V AMD64: first arg in RDI

    ; kernel_main's own main loop should never return, but if it somehow
    ; does, stop cleanly rather than running off into whatever comes next.
    cli
.hang:
    hlt
    jmp .hang

section .note.GNU-stack noalloc noexec nowrite progbits

section .bss
align 16
kernel_stack_bottom:
    resb 16384               ; 16 KiB kernel stack
kernel_stack_top:
