#!/usr/bin/env python3
"""Patches a 32-bit additive checksum into a Kernel24 image's header.

Layout (see docs/memory-map.md): offset 0 = magic (untouched by this
script), offset 4 = checksum (patched here), offset 8+ = payload.

The checksum is simply the sum of every payload byte (offset 8 to the end
of the file), truncated to 32 bits. This has to run *after* the image has
already been padded to its full reserved disk size, since the checksum
must cover exactly the bytes XLoader will read back from disk — padding
included. kernel24_verify (kernel/loader.asm) recomputes this identically
at boot time and refuses to jump into the kernel if it doesn't match.
"""
import os
import sys


def patch(path: str) -> None:
    with open(path, "rb") as f:
        data = bytearray(f.read())

    if len(data) < 8:
        sys.exit(f"error: {path} is only {len(data)} bytes, smaller than the 8-byte header")

    checksum = sum(data[8:]) & 0xFFFFFFFF
    checksum_bytes = checksum.to_bytes(4, "little")
    data[4:8] = checksum_bytes

    # flush()+fsync() force the write out to actual storage before this
    # process exits, rather than trusting it's landed just because
    # write() returned — the very next Makefile step (`cp` into
    # XLoader's own build/) opens this same path fresh, in a separate
    # process, and has no reason to see anything Python hasn't actually
    # pushed to the filesystem yet. Some Android/Termux storage setups
    # have looser write-visibility timing than a plain desktop Linux
    # filesystem; this makes the ordering correct regardless of which
    # kind of storage `path` lives on.
    with open(path, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())

    # Re-open and re-read rather than trusting the in-memory buffer, so
    # a write that silently didn't persist fails the build right here —
    # loudly, at the moment it happens — instead of quietly producing a
    # kernel24.bin whose header doesn't match what this script just
    # computed, which only surfaces later as a confusing boot-time
    # checksum mismatch with no indication of *why*.
    with open(path, "rb") as f:
        f.seek(4)
        verify = f.read(4)
    if verify != checksum_bytes:
        sys.exit(
            f"error: wrote checksum 0x{checksum:08X} to {path}, but reading it back "
            f"immediately afterward gives 0x{int.from_bytes(verify, 'little'):08X} — "
            f"the write to bytes 4-7 did not persist"
        )

    print(f"patch_checksum: wrote 0x{checksum:08X} into {path} (verified)")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(f"usage: {sys.argv[0]} <kernel-image>")
    patch(sys.argv[1])
