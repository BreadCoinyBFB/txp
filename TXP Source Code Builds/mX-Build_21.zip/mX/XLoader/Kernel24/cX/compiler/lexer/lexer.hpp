// lexer.hpp — turns cX source text into a token stream
#pragma once
#include <string>
#include <vector>
#include "token.hpp"

namespace cx {

class Lexer {
public:
    explicit Lexer(std::string source);

    // Tokenizes the whole source and returns the token stream,
    // terminated with an END_OF_FILE token.
    std::vector<Token> tokenize();

private:
    std::string src_;
    size_t pos_ = 0;
    int line_ = 1;
    int col_ = 1;

    bool atEnd() const;
    char peek(int offset = 0) const;
    char advance();
    bool match(char expected);

    void skipWhitespaceAndComments();

    Token makeToken(TokenType type, const std::string& lexeme, int line, int col);
    Token lexIdentifierOrKeyword();
    Token lexNumber();
    Token lexString();
    Token lexChar();
};

} // namespace cx
