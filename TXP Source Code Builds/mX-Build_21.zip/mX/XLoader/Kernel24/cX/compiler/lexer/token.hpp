// token.hpp — Token definitions for the cX language
#pragma once
#include <string>
#include <unordered_map>

namespace cx {

enum class TokenType {
    // literals
    IDENTIFIER, INT_LITERAL, FLOAT_LITERAL, STRING_LITERAL, CHAR_LITERAL,

    // keywords
    KW_FN, KW_LET, KW_CONST, KW_IF, KW_ELSE, KW_WHILE, KW_FOR,
    KW_RETURN, KW_BREAK, KW_CONTINUE, KW_STRUCT, KW_IMPORT,
    KW_TRUE, KW_FALSE, KW_NULLPTR, KW_VOID,
    KW_INT, KW_FLOAT, KW_CHAR, KW_BOOL, KW_STRING, KW_LONG,
    KW_AS, KW_EXTERN,

    // punctuation
    LPAREN, RPAREN, LBRACE, RBRACE, LBRACKET, RBRACKET,
    COMMA, SEMICOLON, COLON, ARROW, DOT,

    // operators
    PLUS, MINUS, STAR, SLASH, PERCENT,
    ASSIGN, EQ, NEQ, LT, GT, LE, GE,
    AND, OR, NOT,
    PLUS_ASSIGN, MINUS_ASSIGN, STAR_ASSIGN, SLASH_ASSIGN,
    AMP, PIPE, CARET, TILDE, SHL, SHR,   // bitwise: & | ^ ~ << >>
    PLUS_PLUS, MINUS_MINUS,               // ++ --

    END_OF_FILE, INVALID
};

struct Token {
    TokenType type;
    std::string lexeme;
    int line;
    int col;
};

// keyword lookup table, shared by the lexer
inline const std::unordered_map<std::string, TokenType>& keywords() {
    static const std::unordered_map<std::string, TokenType> kw = {
        {"fn", TokenType::KW_FN},
        {"let", TokenType::KW_LET},
        {"const", TokenType::KW_CONST},
        {"if", TokenType::KW_IF},
        {"else", TokenType::KW_ELSE},
        {"while", TokenType::KW_WHILE},
        {"for", TokenType::KW_FOR},
        {"return", TokenType::KW_RETURN},
        {"break", TokenType::KW_BREAK},
        {"continue", TokenType::KW_CONTINUE},
        {"struct", TokenType::KW_STRUCT},
        {"import", TokenType::KW_IMPORT},
        {"true", TokenType::KW_TRUE},
        {"false", TokenType::KW_FALSE},
        {"nullptr", TokenType::KW_NULLPTR},
        {"void", TokenType::KW_VOID},
        {"int", TokenType::KW_INT},
        {"float", TokenType::KW_FLOAT},
        {"char", TokenType::KW_CHAR},
        {"bool", TokenType::KW_BOOL},
        {"string", TokenType::KW_STRING},
        {"long", TokenType::KW_LONG},
        {"as", TokenType::KW_AS},
        {"extern", TokenType::KW_EXTERN},
    };
    return kw;
}

inline std::string tokenTypeName(TokenType t) {
    switch (t) {
        case TokenType::IDENTIFIER: return "IDENTIFIER";
        case TokenType::INT_LITERAL: return "INT_LITERAL";
        case TokenType::FLOAT_LITERAL: return "FLOAT_LITERAL";
        case TokenType::STRING_LITERAL: return "STRING_LITERAL";
        case TokenType::CHAR_LITERAL: return "CHAR_LITERAL";
        case TokenType::KW_FN: return "KW_FN";
        case TokenType::KW_LET: return "KW_LET";
        case TokenType::KW_CONST: return "KW_CONST";
        case TokenType::KW_IF: return "KW_IF";
        case TokenType::KW_ELSE: return "KW_ELSE";
        case TokenType::KW_WHILE: return "KW_WHILE";
        case TokenType::KW_FOR: return "KW_FOR";
        case TokenType::KW_RETURN: return "KW_RETURN";
        case TokenType::KW_BREAK: return "KW_BREAK";
        case TokenType::KW_CONTINUE: return "KW_CONTINUE";
        case TokenType::KW_STRUCT: return "KW_STRUCT";
        case TokenType::KW_IMPORT: return "KW_IMPORT";
        case TokenType::KW_TRUE: return "KW_TRUE";
        case TokenType::KW_FALSE: return "KW_FALSE";
        case TokenType::KW_NULLPTR: return "KW_NULLPTR";
        case TokenType::KW_VOID: return "KW_VOID";
        case TokenType::KW_INT: return "KW_INT";
        case TokenType::KW_FLOAT: return "KW_FLOAT";
        case TokenType::KW_CHAR: return "KW_CHAR";
        case TokenType::KW_BOOL: return "KW_BOOL";
        case TokenType::KW_STRING: return "KW_STRING";
        case TokenType::KW_LONG: return "KW_LONG";
        case TokenType::KW_AS: return "KW_AS";
        case TokenType::KW_EXTERN: return "KW_EXTERN";
        case TokenType::LPAREN: return "LPAREN";
        case TokenType::RPAREN: return "RPAREN";
        case TokenType::LBRACE: return "LBRACE";
        case TokenType::RBRACE: return "RBRACE";
        case TokenType::LBRACKET: return "LBRACKET";
        case TokenType::RBRACKET: return "RBRACKET";
        case TokenType::COMMA: return "COMMA";
        case TokenType::SEMICOLON: return "SEMICOLON";
        case TokenType::COLON: return "COLON";
        case TokenType::ARROW: return "ARROW";
        case TokenType::DOT: return "DOT";
        case TokenType::PLUS: return "PLUS";
        case TokenType::MINUS: return "MINUS";
        case TokenType::STAR: return "STAR";
        case TokenType::SLASH: return "SLASH";
        case TokenType::PERCENT: return "PERCENT";
        case TokenType::ASSIGN: return "ASSIGN";
        case TokenType::EQ: return "EQ";
        case TokenType::NEQ: return "NEQ";
        case TokenType::LT: return "LT";
        case TokenType::GT: return "GT";
        case TokenType::LE: return "LE";
        case TokenType::GE: return "GE";
        case TokenType::AND: return "AND";
        case TokenType::OR: return "OR";
        case TokenType::NOT: return "NOT";
        case TokenType::PLUS_ASSIGN: return "PLUS_ASSIGN";
        case TokenType::MINUS_ASSIGN: return "MINUS_ASSIGN";
        case TokenType::STAR_ASSIGN: return "STAR_ASSIGN";
        case TokenType::SLASH_ASSIGN: return "SLASH_ASSIGN";
        case TokenType::AMP: return "AMP";
        case TokenType::PIPE: return "PIPE";
        case TokenType::CARET: return "CARET";
        case TokenType::TILDE: return "TILDE";
        case TokenType::SHL: return "SHL";
        case TokenType::SHR: return "SHR";
        case TokenType::PLUS_PLUS: return "PLUS_PLUS";
        case TokenType::MINUS_MINUS: return "MINUS_MINUS";
        case TokenType::END_OF_FILE: return "EOF";
        default: return "INVALID";
    }
}

} // namespace cx
