// lexer.cpp — implementation of the cX lexer
#include "lexer.hpp"
#include <cctype>
#include <stdexcept>

namespace cx {

Lexer::Lexer(std::string source) : src_(std::move(source)) {}

bool Lexer::atEnd() const { return pos_ >= src_.size(); }

char Lexer::peek(int offset) const {
    size_t idx = pos_ + offset;
    if (idx >= src_.size()) return '\0';
    return src_[idx];
}

char Lexer::advance() {
    char c = src_[pos_++];
    if (c == '\n') { line_++; col_ = 1; }
    else { col_++; }
    return c;
}

bool Lexer::match(char expected) {
    if (atEnd() || peek() != expected) return false;
    advance();
    return true;
}

Token Lexer::makeToken(TokenType type, const std::string& lexeme, int line, int col) {
    return Token{type, lexeme, line, col};
}

void Lexer::skipWhitespaceAndComments() {
    for (;;) {
        char c = peek();
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
            advance();
        } else if (c == '/' && peek(1) == '/') {
            while (!atEnd() && peek() != '\n') advance();
        } else if (c == '/' && peek(1) == '*') {
            advance(); advance();
            while (!atEnd() && !(peek() == '*' && peek(1) == '/')) advance();
            if (!atEnd()) { advance(); advance(); } // consume */
        } else {
            break;
        }
    }
}

Token Lexer::lexIdentifierOrKeyword() {
    int startLine = line_, startCol = col_;
    size_t start = pos_;
    while (!atEnd() && (std::isalnum((unsigned char)peek()) || peek() == '_')) advance();
    std::string text = src_.substr(start, pos_ - start);

    auto& kw = keywords();
    auto it = kw.find(text);
    TokenType type = (it != kw.end()) ? it->second : TokenType::IDENTIFIER;
    return makeToken(type, text, startLine, startCol);
}

Token Lexer::lexNumber() {
    int startLine = line_, startCol = col_;
    size_t start = pos_;
    bool isFloat = false;

    // Hex literal: 0x... / 0X... — always an int, never float.
    if (peek() == '0' && (peek(1) == 'x' || peek(1) == 'X')) {
        advance(); advance(); // consume "0x"
        while (!atEnd() && std::isxdigit((unsigned char)peek())) advance();
        std::string text = src_.substr(start, pos_ - start);
        return makeToken(TokenType::INT_LITERAL, text, startLine, startCol);
    }

    while (!atEnd() && std::isdigit((unsigned char)peek())) advance();
    if (peek() == '.' && std::isdigit((unsigned char)peek(1))) {
        isFloat = true;
        advance(); // consume '.'
        while (!atEnd() && std::isdigit((unsigned char)peek())) advance();
    }
    std::string text = src_.substr(start, pos_ - start);
    return makeToken(isFloat ? TokenType::FLOAT_LITERAL : TokenType::INT_LITERAL,
                      text, startLine, startCol);
}

Token Lexer::lexString() {
    int startLine = line_, startCol = col_;
    advance(); // consume opening quote
    std::string value;
    while (!atEnd() && peek() != '"') {
        char c = advance();
        if (c == '\\' && !atEnd()) {
            char esc = advance();
            switch (esc) {
                case 'n': value += '\n'; break;
                case 't': value += '\t'; break;
                case 'r': value += '\r'; break;
                case '"': value += '"'; break;
                case '\\': value += '\\'; break;
                default: value += esc; break;
            }
        } else {
            value += c;
        }
    }
    if (!atEnd()) advance(); // consume closing quote
    return makeToken(TokenType::STRING_LITERAL, value, startLine, startCol);
}

Token Lexer::lexChar() {
    int startLine = line_, startCol = col_;
    advance(); // consume opening quote
    std::string value;
    if (!atEnd() && peek() == '\\') {
        advance();
        char esc = advance();
        switch (esc) {
            case 'n': value = "\n"; break;
            case 't': value = "\t"; break;
            case 'r': value = "\r"; break;
            case '\'': value = "'"; break;
            case '\\': value = "\\"; break;
            default: value = std::string(1, esc); break;
        }
    } else if (!atEnd()) {
        value = std::string(1, advance());
    }
    if (!atEnd() && peek() == '\'') advance(); // consume closing quote
    return makeToken(TokenType::CHAR_LITERAL, value, startLine, startCol);
}

std::vector<Token> Lexer::tokenize() {
    std::vector<Token> tokens;

    for (;;) {
        skipWhitespaceAndComments();
        if (atEnd()) break;

        int startLine = line_, startCol = col_;
        char c = peek();

        if (std::isalpha((unsigned char)c) || c == '_') {
            tokens.push_back(lexIdentifierOrKeyword());
            continue;
        }
        if (std::isdigit((unsigned char)c)) {
            tokens.push_back(lexNumber());
            continue;
        }
        if (c == '"') {
            tokens.push_back(lexString());
            continue;
        }
        if (c == '\'') {
            tokens.push_back(lexChar());
            continue;
        }

        advance(); // consume the character; decide what it is
        switch (c) {
            case '(': tokens.push_back(makeToken(TokenType::LPAREN, "(", startLine, startCol)); break;
            case ')': tokens.push_back(makeToken(TokenType::RPAREN, ")", startLine, startCol)); break;
            case '{': tokens.push_back(makeToken(TokenType::LBRACE, "{", startLine, startCol)); break;
            case '}': tokens.push_back(makeToken(TokenType::RBRACE, "}", startLine, startCol)); break;
            case '[': tokens.push_back(makeToken(TokenType::LBRACKET, "[", startLine, startCol)); break;
            case ']': tokens.push_back(makeToken(TokenType::RBRACKET, "]", startLine, startCol)); break;
            case ',': tokens.push_back(makeToken(TokenType::COMMA, ",", startLine, startCol)); break;
            case ';': tokens.push_back(makeToken(TokenType::SEMICOLON, ";", startLine, startCol)); break;
            case '.': tokens.push_back(makeToken(TokenType::DOT, ".", startLine, startCol)); break;
            case ':': tokens.push_back(makeToken(TokenType::COLON, ":", startLine, startCol)); break;
            case '+':
                if (match('+')) tokens.push_back(makeToken(TokenType::PLUS_PLUS, "++", startLine, startCol));
                else if (match('=')) tokens.push_back(makeToken(TokenType::PLUS_ASSIGN, "+=", startLine, startCol));
                else tokens.push_back(makeToken(TokenType::PLUS, "+", startLine, startCol));
                break;
            case '-':
                if (match('-')) tokens.push_back(makeToken(TokenType::MINUS_MINUS, "--", startLine, startCol));
                else if (match('>')) tokens.push_back(makeToken(TokenType::ARROW, "->", startLine, startCol));
                else if (match('=')) tokens.push_back(makeToken(TokenType::MINUS_ASSIGN, "-=", startLine, startCol));
                else tokens.push_back(makeToken(TokenType::MINUS, "-", startLine, startCol));
                break;
            case '*':
                tokens.push_back(match('=')
                    ? makeToken(TokenType::STAR_ASSIGN, "*=", startLine, startCol)
                    : makeToken(TokenType::STAR, "*", startLine, startCol));
                break;
            case '/':
                tokens.push_back(match('=')
                    ? makeToken(TokenType::SLASH_ASSIGN, "/=", startLine, startCol)
                    : makeToken(TokenType::SLASH, "/", startLine, startCol));
                break;
            case '%': tokens.push_back(makeToken(TokenType::PERCENT, "%", startLine, startCol)); break;
            case '=':
                tokens.push_back(match('=')
                    ? makeToken(TokenType::EQ, "==", startLine, startCol)
                    : makeToken(TokenType::ASSIGN, "=", startLine, startCol));
                break;
            case '!':
                tokens.push_back(match('=')
                    ? makeToken(TokenType::NEQ, "!=", startLine, startCol)
                    : makeToken(TokenType::NOT, "!", startLine, startCol));
                break;
            case '<':
                if (match('<')) tokens.push_back(makeToken(TokenType::SHL, "<<", startLine, startCol));
                else if (match('=')) tokens.push_back(makeToken(TokenType::LE, "<=", startLine, startCol));
                else tokens.push_back(makeToken(TokenType::LT, "<", startLine, startCol));
                break;
            case '>':
                if (match('>')) tokens.push_back(makeToken(TokenType::SHR, ">>", startLine, startCol));
                else if (match('=')) tokens.push_back(makeToken(TokenType::GE, ">=", startLine, startCol));
                else tokens.push_back(makeToken(TokenType::GT, ">", startLine, startCol));
                break;
            case '&':
                if (match('&')) tokens.push_back(makeToken(TokenType::AND, "&&", startLine, startCol));
                else tokens.push_back(makeToken(TokenType::AMP, "&", startLine, startCol));
                break;
            case '|':
                if (match('|')) tokens.push_back(makeToken(TokenType::OR, "||", startLine, startCol));
                else tokens.push_back(makeToken(TokenType::PIPE, "|", startLine, startCol));
                break;
            case '^': tokens.push_back(makeToken(TokenType::CARET, "^", startLine, startCol)); break;
            case '~': tokens.push_back(makeToken(TokenType::TILDE, "~", startLine, startCol)); break;
            default:
                tokens.push_back(makeToken(TokenType::INVALID, std::string(1, c), startLine, startCol));
                break;
        }
    }

    tokens.push_back(makeToken(TokenType::END_OF_FILE, "", line_, col_));
    return tokens;
}

} // namespace cx
