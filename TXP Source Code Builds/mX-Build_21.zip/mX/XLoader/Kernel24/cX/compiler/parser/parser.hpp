// parser.hpp — recursive-descent parser: tokens -> AST
#pragma once
#include <vector>
#include <memory>
#include <stdexcept>
#include "../lexer/token.hpp"
#include "ast.hpp"

namespace cx {

struct ParseError : std::runtime_error {
    int line;
    ParseError(const std::string& msg, int line_)
        : std::runtime_error(msg), line(line_) {}
};

class Parser {
public:
    explicit Parser(std::vector<Token> tokens);

    // Parses the full token stream into a Program.
    // Throws ParseError on the first syntax error.
    std::unique_ptr<Program> parseProgram();

private:
    std::vector<Token> tokens_;
    size_t pos_ = 0;

    const Token& peek(int offset = 0) const;
    const Token& previous() const;
    bool atEnd() const;
    bool check(TokenType type) const;
    const Token& advance();
    bool match(TokenType type);
    const Token& expect(TokenType type, const std::string& message);
    [[noreturn]] void error(const std::string& message);
    [[noreturn]] void error(const std::string& message, const Token& at);

    // declarations
    StmtPtr parseImportDecl();
    StmtPtr parseFunctionDecl();
    StmtPtr parseStructDecl();
    StmtPtr parseExternDecl();
    std::string parseType();

    // statements
    StmtPtr parseStatement();
    std::unique_ptr<BlockStmt> parseBlock();
    StmtPtr parseLetStmt();
    StmtPtr parseReturnStmt();
    StmtPtr parseIfStmt();
    StmtPtr parseWhileStmt();
    StmtPtr parseForStmt();
    StmtPtr parseExprStmt();

    // expressions (precedence climbing)
    ExprPtr parseExpression();
    ExprPtr parseAssignment();
    ExprPtr parseLogicOr();
    ExprPtr parseLogicAnd();
    ExprPtr parseBitOr();
    ExprPtr parseBitXor();
    ExprPtr parseBitAnd();
    ExprPtr parseEquality();
    ExprPtr parseComparison();
    ExprPtr parseShift();
    ExprPtr parseTerm();
    ExprPtr parseFactor();
    ExprPtr parseUnary();
    ExprPtr parseCall();
    ExprPtr parsePrimary();
};

} // namespace cx
