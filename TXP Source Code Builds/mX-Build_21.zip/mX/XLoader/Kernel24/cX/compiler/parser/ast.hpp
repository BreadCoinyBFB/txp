// ast.hpp — AST node definitions for cX
#pragma once
#include <string>
#include <vector>
#include <memory>
#include <ostream>

namespace cx {

struct Node {
    int line = 0;
    virtual ~Node() = default;
    virtual void dump(std::ostream& os, int indent) const = 0;
};

struct Expr : Node {
    // Filled in by semantic analysis: the cX type of this expression
    // ("int", "float", "string", "char", "bool", "void", "nullptr",
    // "function", or "namespace:console"). Empty until analyzed.
    std::string exprType;
};
struct Stmt : Node {};

using ExprPtr = std::unique_ptr<Expr>;
using StmtPtr = std::unique_ptr<Stmt>;

inline void pad(std::ostream& os, int indent) {
    for (int i = 0; i < indent; ++i) os << "  ";
}

// ---------- Expressions ----------

struct IntLiteralExpr : Expr {
    std::string value;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "IntLiteral(" << value << ")\n";
    }
};

struct FloatLiteralExpr : Expr {
    std::string value;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "FloatLiteral(" << value << ")\n";
    }
};

struct StringLiteralExpr : Expr {
    std::string value;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "StringLiteral(\"" << value << "\")\n";
    }
};

struct CharLiteralExpr : Expr {
    std::string value;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "CharLiteral('" << value << "')\n";
    }
};

struct BoolLiteralExpr : Expr {
    bool value = false;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "BoolLiteral(" << (value ? "true" : "false") << ")\n";
    }
};

struct NullptrExpr : Expr {
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Nullptr\n";
    }
};

struct IdentifierExpr : Expr {
    std::string name;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Identifier(" << name << ")\n";
    }
};

struct BinaryExpr : Expr {
    std::string op;
    ExprPtr left, right;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Binary(" << op << ")\n";
        left->dump(os, indent + 1);
        right->dump(os, indent + 1);
    }
};

struct UnaryExpr : Expr {
    std::string op;
    ExprPtr operand;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Unary(" << op << ")\n";
        operand->dump(os, indent + 1);
    }
};

struct AssignExpr : Expr {
    std::string op; // '=', '+=', '-=', '*=', '/='
    ExprPtr target;
    ExprPtr value;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Assign(" << op << ")\n";
        target->dump(os, indent + 1);
        value->dump(os, indent + 1);
    }
};

struct CallExpr : Expr {
    ExprPtr callee;
    std::vector<ExprPtr> args;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Call\n";
        callee->dump(os, indent + 1);
        for (auto& a : args) a->dump(os, indent + 1);
    }
};

struct MemberExpr : Expr {
    ExprPtr object;
    std::string member;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Member(." << member << ")\n";
        object->dump(os, indent + 1);
    }
};

struct ArrayLiteralExpr : Expr {
    std::vector<ExprPtr> elements;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "ArrayLiteral\n";
        for (auto& e : elements) e->dump(os, indent + 1);
    }
};

struct IndexExpr : Expr {
    ExprPtr array;
    ExprPtr index;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Index\n";
        array->dump(os, indent + 1);
        index->dump(os, indent + 1);
    }
};

struct StructLiteralExpr : Expr {
    std::string structName;
    std::vector<std::pair<std::string, ExprPtr>> fields;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "StructLiteral(" << structName << ")\n";
        for (auto& f : fields) {
            pad(os, indent + 1); os << f.first << ":\n";
            f.second->dump(os, indent + 2);
        }
    }
};

struct CastExpr : Expr {
    ExprPtr operand;
    std::string targetType;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Cast(-> " << targetType << ")\n";
        operand->dump(os, indent + 1);
    }
};

// ---------- Statements ----------

struct LetStmt : Stmt {
    std::string name;
    std::string type; // may be empty if inferred (as written by the user)
    std::string resolvedType; // filled by semantic analysis: type or its inferred type
    bool isConst = false; // true if declared with 'const' instead of 'let'
    bool isGlobal = false; // true if this is a top-level (file-scope) declaration
    ExprPtr init;      // may be null
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << (isConst ? "Const(" : "Let(") << name;
        if (!type.empty()) os << ": " << type;
        os << ")\n";
        if (init) init->dump(os, indent + 1);
    }
};

struct ReturnStmt : Stmt {
    ExprPtr value; // may be null
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Return\n";
        if (value) value->dump(os, indent + 1);
    }
};

struct ExprStmt : Stmt {
    ExprPtr expr;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "ExprStmt\n";
        expr->dump(os, indent + 1);
    }
};

struct BlockStmt : Stmt {
    std::vector<StmtPtr> statements;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Block\n";
        for (auto& s : statements) s->dump(os, indent + 1);
    }
};

struct IfStmt : Stmt {
    ExprPtr condition;
    StmtPtr thenBranch;
    StmtPtr elseBranch; // may be null
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "If\n";
        condition->dump(os, indent + 1);
        thenBranch->dump(os, indent + 1);
        if (elseBranch) elseBranch->dump(os, indent + 1);
    }
};

struct WhileStmt : Stmt {
    ExprPtr condition;
    StmtPtr body;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "While\n";
        condition->dump(os, indent + 1);
        body->dump(os, indent + 1);
    }
};

struct ForStmt : Stmt {
    StmtPtr init;   // may be null (LetStmt or ExprStmt)
    ExprPtr cond;   // may be null
    ExprPtr post;   // may be null
    StmtPtr body;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "For\n";
        if (init) init->dump(os, indent + 1);
        if (cond) cond->dump(os, indent + 1);
        if (post) post->dump(os, indent + 1);
        body->dump(os, indent + 1);
    }
};

struct BreakStmt : Stmt {
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Break\n";
    }
};

struct ContinueStmt : Stmt {
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Continue\n";
    }
};

// ---------- Top level ----------

struct Param {
    std::string name;
    std::string type;
};

struct ImportDecl : Stmt {
    std::vector<std::string> path; // e.g. ["mx", "console"] for builtin modules
    bool isFileImport = false;      // true for import "some/file.cx";
    std::string filePath;           // set when isFileImport is true
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent);
        if (isFileImport) {
            os << "Import(\"" << filePath << "\")\n";
            return;
        }
        os << "Import(";
        for (size_t i = 0; i < path.size(); ++i) {
            if (i) os << ".";
            os << path[i];
        }
        os << ")\n";
    }
};

struct StructDecl : Stmt {
    std::string name;
    std::vector<Param> fields; // reuse Param{name, type}
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Struct(" << name << ")\n";
        for (auto& f : fields) {
            pad(os, indent + 1); os << "Field(" << f.name << ": " << f.type << ")\n";
        }
    }
};

struct ExternVarDecl : Stmt {
    std::string name;
    std::string type;
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "ExternVar(" << name << ": " << type << ")\n";
    }
};

struct FunctionDecl : Stmt {
    std::string name;
    std::vector<Param> params;
    std::string returnType; // empty => void
    bool isExtern = false; // true for "extern fn name(...) -> T;" (no body — implemented in .asm)
    std::unique_ptr<BlockStmt> body; // null when isExtern
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << (isExtern ? "ExternFunction(" : "Function(") << name << ") -> "
                            << (returnType.empty() ? "void" : returnType) << "\n";
        for (auto& p : params) {
            pad(os, indent + 1); os << "Param(" << p.name << ": " << p.type << ")\n";
        }
        if (body) body->dump(os, indent + 1);
    }
};

struct Program : Node {
    std::vector<StmtPtr> declarations; // ImportDecl / FunctionDecl
    void dump(std::ostream& os, int indent) const override {
        pad(os, indent); os << "Program\n";
        for (auto& d : declarations) d->dump(os, indent + 1);
    }
};

} // namespace cx
