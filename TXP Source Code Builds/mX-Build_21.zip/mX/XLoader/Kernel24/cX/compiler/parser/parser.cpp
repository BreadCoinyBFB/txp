// parser.cpp — implementation of the cX recursive-descent parser
#include "parser.hpp"

namespace cx {

Parser::Parser(std::vector<Token> tokens) : tokens_(std::move(tokens)) {}

const Token& Parser::peek(int offset) const {
    size_t idx = pos_ + offset;
    if (idx >= tokens_.size()) return tokens_.back(); // EOF
    return tokens_[idx];
}

const Token& Parser::previous() const { return tokens_[pos_ - 1]; }

bool Parser::atEnd() const { return peek().type == TokenType::END_OF_FILE; }

bool Parser::check(TokenType type) const {
    if (atEnd() && type != TokenType::END_OF_FILE) return false;
    return peek().type == type;
}

const Token& Parser::advance() {
    if (!atEnd()) pos_++;
    return previous();
}

bool Parser::match(TokenType type) {
    if (!check(type)) return false;
    advance();
    return true;
}

const Token& Parser::expect(TokenType type, const std::string& message) {
    if (check(type)) return advance();
    error(message, peek());
}

void Parser::error(const std::string& message) { error(message, peek()); }

void Parser::error(const std::string& message, const Token& at) {
    throw ParseError(
        "cX parse error at line " + std::to_string(at.line) + ": " + message +
        " (got '" + at.lexeme + "')",
        at.line);
}

// ---------- top level ----------

std::unique_ptr<Program> Parser::parseProgram() {
    auto program = std::make_unique<Program>();
    while (!atEnd()) {
        if (check(TokenType::KW_IMPORT)) {
            program->declarations.push_back(parseImportDecl());
        } else if (check(TokenType::KW_FN)) {
            program->declarations.push_back(parseFunctionDecl());
        } else if (check(TokenType::KW_STRUCT)) {
            program->declarations.push_back(parseStructDecl());
        } else if (check(TokenType::KW_EXTERN)) {
            program->declarations.push_back(parseExternDecl());
        } else if (check(TokenType::KW_LET) || check(TokenType::KW_CONST)) {
            // Top-level let/const: a file-scope (C `static`) global variable.
            // Reuses parseLetStmt's token-level logic exactly; only the
            // isGlobal flag distinguishes it from a local variable.
            StmtPtr letStmt = parseLetStmt();
            if (auto* let = dynamic_cast<LetStmt*>(letStmt.get())) let->isGlobal = true;
            program->declarations.push_back(std::move(letStmt));
        } else {
            error("expected 'import', 'struct', 'extern', 'let', 'const', or 'fn' at top level");
        }
    }
    return program;
}

StmtPtr Parser::parseExternDecl() {
    int line = peek().line;
    expect(TokenType::KW_EXTERN, "expected 'extern'");

    if (check(TokenType::KW_LET)) {
        advance();
        auto decl = std::make_unique<ExternVarDecl>();
        decl->line = line;
        decl->name = expect(TokenType::IDENTIFIER, "expected variable name").lexeme;
        expect(TokenType::COLON, "expected ':' after extern variable name");
        decl->type = parseType();
        expect(TokenType::SEMICOLON, "expected ';' after extern declaration");
        return decl;
    }

    expect(TokenType::KW_FN, "expected 'fn' or 'let' after 'extern'");
    auto decl = std::make_unique<FunctionDecl>();
    decl->line = line;
    decl->isExtern = true;
    decl->name = expect(TokenType::IDENTIFIER, "expected function name").lexeme;

    expect(TokenType::LPAREN, "expected '(' after function name");
    if (!check(TokenType::RPAREN)) {
        do {
            Param p;
            p.name = expect(TokenType::IDENTIFIER, "expected parameter name").lexeme;
            expect(TokenType::COLON, "expected ':' after parameter name");
            p.type = parseType();
            decl->params.push_back(std::move(p));
        } while (match(TokenType::COMMA));
    }
    expect(TokenType::RPAREN, "expected ')' after parameters");

    if (match(TokenType::ARROW)) {
        decl->returnType = parseType();
    }
    expect(TokenType::SEMICOLON, "expected ';' after extern function declaration (no body)");
    return decl;
}

StmtPtr Parser::parseStructDecl() {
    int line = peek().line;
    expect(TokenType::KW_STRUCT, "expected 'struct'");
    auto decl = std::make_unique<StructDecl>();
    decl->line = line;
    decl->name = expect(TokenType::IDENTIFIER, "expected struct name").lexeme;
    expect(TokenType::LBRACE, "expected '{' after struct name");
    if (!check(TokenType::RBRACE)) {
        do {
            Param field;
            field.name = expect(TokenType::IDENTIFIER, "expected field name").lexeme;
            expect(TokenType::COLON, "expected ':' after field name");
            field.type = parseType();
            decl->fields.push_back(std::move(field));
        } while (match(TokenType::COMMA));
    }
    expect(TokenType::RBRACE, "expected '}' to close struct");
    return decl;
}

StmtPtr Parser::parseImportDecl() {
    int line = peek().line;
    expect(TokenType::KW_IMPORT, "expected 'import'");
    auto decl = std::make_unique<ImportDecl>();
    decl->line = line;

    if (check(TokenType::STRING_LITERAL)) {
        decl->isFileImport = true;
        decl->filePath = advance().lexeme;
        expect(TokenType::SEMICOLON, "expected ';' after import");
        return decl;
    }

    Token first = expect(TokenType::IDENTIFIER, "expected module path after 'import'");
    decl->path.push_back(first.lexeme);
    // accept both mx/console and mx.console as path separators
    while (check(TokenType::SLASH) || check(TokenType::DOT)) {
        advance();
        Token part = expect(TokenType::IDENTIFIER, "expected identifier in import path");
        decl->path.push_back(part.lexeme);
    }
    expect(TokenType::SEMICOLON, "expected ';' after import");
    return decl;
}

std::string Parser::parseType() {
    // accepts built-in type keywords or a user identifier (struct name)
    std::string base;
    if (check(TokenType::KW_INT) || check(TokenType::KW_FLOAT) ||
        check(TokenType::KW_CHAR) || check(TokenType::KW_BOOL) ||
        check(TokenType::KW_STRING) || check(TokenType::KW_VOID) ||
        check(TokenType::KW_LONG) || check(TokenType::IDENTIFIER)) {
        base = advance().lexeme;
    } else {
        error("expected a type");
    }
    // One level of pointer indirection: T* (e.g. char*, void*, Point*).
    if (match(TokenType::STAR)) {
        base += "*";
    }
    if (match(TokenType::LBRACKET)) {
        std::string size;
        if (check(TokenType::INT_LITERAL)) size = advance().lexeme;
        expect(TokenType::RBRACKET, "expected ']' in array type");
        base += "[" + size + "]";
    }
    return base;
}

StmtPtr Parser::parseFunctionDecl() {
    int line = peek().line;
    expect(TokenType::KW_FN, "expected 'fn'");
    auto decl = std::make_unique<FunctionDecl>();
    decl->line = line;
    decl->name = expect(TokenType::IDENTIFIER, "expected function name").lexeme;

    expect(TokenType::LPAREN, "expected '(' after function name");
    if (!check(TokenType::RPAREN)) {
        do {
            Param p;
            p.name = expect(TokenType::IDENTIFIER, "expected parameter name").lexeme;
            expect(TokenType::COLON, "expected ':' after parameter name");
            p.type = parseType();
            decl->params.push_back(std::move(p));
        } while (match(TokenType::COMMA));
    }
    expect(TokenType::RPAREN, "expected ')' after parameters");

    if (match(TokenType::ARROW)) {
        decl->returnType = parseType();
    }

    decl->body = parseBlock();
    return decl;
}

// ---------- statements ----------

std::unique_ptr<BlockStmt> Parser::parseBlock() {
    int line = peek().line;
    expect(TokenType::LBRACE, "expected '{'");
    auto block = std::make_unique<BlockStmt>();
    block->line = line;
    while (!check(TokenType::RBRACE) && !atEnd()) {
        block->statements.push_back(parseStatement());
    }
    expect(TokenType::RBRACE, "expected '}' to close block");
    return block;
}

StmtPtr Parser::parseStatement() {
    if (check(TokenType::KW_LET) || check(TokenType::KW_CONST)) return parseLetStmt();
    if (check(TokenType::KW_RETURN)) return parseReturnStmt();
    if (check(TokenType::KW_IF)) return parseIfStmt();
    if (check(TokenType::KW_WHILE)) return parseWhileStmt();
    if (check(TokenType::KW_FOR)) return parseForStmt();
    if (check(TokenType::LBRACE)) return parseBlock();
    if (check(TokenType::KW_BREAK)) {
        int line = peek().line;
        advance();
        expect(TokenType::SEMICOLON, "expected ';' after 'break'");
        auto s = std::make_unique<BreakStmt>(); s->line = line; return s;
    }
    if (check(TokenType::KW_CONTINUE)) {
        int line = peek().line;
        advance();
        expect(TokenType::SEMICOLON, "expected ';' after 'continue'");
        auto s = std::make_unique<ContinueStmt>(); s->line = line; return s;
    }
    return parseExprStmt();
}

StmtPtr Parser::parseLetStmt() {
    int line = peek().line;
    bool isConst = check(TokenType::KW_CONST);
    if (isConst) advance();
    else expect(TokenType::KW_LET, "expected 'let' or 'const'");
    auto stmt = std::make_unique<LetStmt>();
    stmt->line = line;
    stmt->isConst = isConst;
    stmt->name = expect(TokenType::IDENTIFIER, "expected variable name").lexeme;
    if (match(TokenType::COLON)) {
        stmt->type = parseType();
    }
    if (match(TokenType::ASSIGN)) {
        stmt->init = parseExpression();
    } else if (isConst) {
        error("'const " + stmt->name + "' needs an initializer");
    }
    expect(TokenType::SEMICOLON, "expected ';' after let statement");
    return stmt;
}

StmtPtr Parser::parseReturnStmt() {
    int line = peek().line;
    expect(TokenType::KW_RETURN, "expected 'return'");
    auto stmt = std::make_unique<ReturnStmt>();
    stmt->line = line;
    if (!check(TokenType::SEMICOLON)) {
        stmt->value = parseExpression();
    }
    expect(TokenType::SEMICOLON, "expected ';' after return statement");
    return stmt;
}

StmtPtr Parser::parseIfStmt() {
    int line = peek().line;
    expect(TokenType::KW_IF, "expected 'if'");
    expect(TokenType::LPAREN, "expected '(' after 'if'");
    auto stmt = std::make_unique<IfStmt>();
    stmt->line = line;
    stmt->condition = parseExpression();
    expect(TokenType::RPAREN, "expected ')' after if condition");
    stmt->thenBranch = parseBlock();
    if (match(TokenType::KW_ELSE)) {
        if (check(TokenType::KW_IF)) {
            stmt->elseBranch = parseIfStmt();
        } else {
            stmt->elseBranch = parseBlock();
        }
    }
    return stmt;
}

StmtPtr Parser::parseWhileStmt() {
    int line = peek().line;
    expect(TokenType::KW_WHILE, "expected 'while'");
    expect(TokenType::LPAREN, "expected '(' after 'while'");
    auto stmt = std::make_unique<WhileStmt>();
    stmt->line = line;
    stmt->condition = parseExpression();
    expect(TokenType::RPAREN, "expected ')' after while condition");
    stmt->body = parseBlock();
    return stmt;
}

StmtPtr Parser::parseForStmt() {
    int line = peek().line;
    expect(TokenType::KW_FOR, "expected 'for'");
    expect(TokenType::LPAREN, "expected '(' after 'for'");
    auto stmt = std::make_unique<ForStmt>();
    stmt->line = line;

    if (check(TokenType::SEMICOLON)) {
        advance();
    } else if (check(TokenType::KW_LET)) {
        stmt->init = parseLetStmt(); // consumes trailing ';'
    } else {
        stmt->init = parseExprStmt(); // consumes trailing ';'
    }

    if (!check(TokenType::SEMICOLON)) {
        stmt->cond = parseExpression();
    }
    expect(TokenType::SEMICOLON, "expected ';' after for-loop condition");

    if (!check(TokenType::RPAREN)) {
        stmt->post = parseExpression();
    }
    expect(TokenType::RPAREN, "expected ')' after for-loop clauses");

    stmt->body = parseBlock();
    return stmt;
}

StmtPtr Parser::parseExprStmt() {
    int line = peek().line;
    auto stmt = std::make_unique<ExprStmt>();
    stmt->line = line;
    stmt->expr = parseExpression();
    expect(TokenType::SEMICOLON, "expected ';' after expression");
    return stmt;
}

// ---------- expressions ----------

ExprPtr Parser::parseExpression() { return parseAssignment(); }

ExprPtr Parser::parseAssignment() {
    ExprPtr expr = parseLogicOr();

    if (check(TokenType::ASSIGN) || check(TokenType::PLUS_ASSIGN) ||
        check(TokenType::MINUS_ASSIGN) || check(TokenType::STAR_ASSIGN) ||
        check(TokenType::SLASH_ASSIGN)) {
        Token opTok = advance();
        ExprPtr value = parseAssignment(); // right-associative
        auto assign = std::make_unique<AssignExpr>();
        assign->line = opTok.line;
        assign->op = opTok.lexeme;
        assign->target = std::move(expr);
        assign->value = std::move(value);
        return assign;
    }
    return expr;
}

ExprPtr Parser::parseLogicOr() {
    ExprPtr expr = parseLogicAnd();
    while (check(TokenType::OR)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseLogicAnd();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseLogicAnd() {
    ExprPtr expr = parseBitOr();
    while (check(TokenType::AND)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseBitOr();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseBitOr() {
    ExprPtr expr = parseBitXor();
    while (check(TokenType::PIPE)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseBitXor();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseBitXor() {
    ExprPtr expr = parseBitAnd();
    while (check(TokenType::CARET)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseBitAnd();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseBitAnd() {
    ExprPtr expr = parseEquality();
    while (check(TokenType::AMP)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseEquality();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseEquality() {
    ExprPtr expr = parseComparison();
    while (check(TokenType::EQ) || check(TokenType::NEQ)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseComparison();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseComparison() {
    ExprPtr expr = parseShift();
    while (check(TokenType::LT) || check(TokenType::GT) ||
           check(TokenType::LE) || check(TokenType::GE)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseShift();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseShift() {
    ExprPtr expr = parseTerm();
    while (check(TokenType::SHL) || check(TokenType::SHR)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseTerm();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseTerm() {
    ExprPtr expr = parseFactor();
    while (check(TokenType::PLUS) || check(TokenType::MINUS)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseFactor();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseFactor() {
    ExprPtr expr = parseUnary();
    while (check(TokenType::STAR) || check(TokenType::SLASH) || check(TokenType::PERCENT)) {
        Token opTok = advance();
        auto bin = std::make_unique<BinaryExpr>();
        bin->line = opTok.line; bin->op = opTok.lexeme;
        bin->left = std::move(expr);
        bin->right = parseUnary();
        expr = std::move(bin);
    }
    return expr;
}

ExprPtr Parser::parseUnary() {
    if (check(TokenType::NOT) || check(TokenType::MINUS) || check(TokenType::TILDE) ||
        check(TokenType::AMP) || check(TokenType::STAR)) {
        Token opTok = advance();
        auto un = std::make_unique<UnaryExpr>();
        un->line = opTok.line; un->op = opTok.lexeme;
        un->operand = parseUnary();
        return un;
    }
    return parseCall();
}

ExprPtr Parser::parseCall() {
    ExprPtr expr = parsePrimary();
    for (;;) {
        if (check(TokenType::LPAREN)) {
            Token paren = advance();
            auto call = std::make_unique<CallExpr>();
            call->line = paren.line;
            call->callee = std::move(expr);
            if (!check(TokenType::RPAREN)) {
                do {
                    call->args.push_back(parseExpression());
                } while (match(TokenType::COMMA));
            }
            expect(TokenType::RPAREN, "expected ')' after call arguments");
            expr = std::move(call);
        } else if (check(TokenType::DOT) || check(TokenType::ARROW)) {
            // '->' is accepted as an alias for '.' — cX's '.' already
            // auto-dereferences a pointer-to-struct, so both spellings
            // produce the identical MemberExpr; '->' is just here for
            // anyone whose fingers expect it from C.
            Token dot = advance();
            auto member = std::make_unique<MemberExpr>();
            member->line = dot.line;
            member->object = std::move(expr);
            member->member = expect(TokenType::IDENTIFIER, "expected member name").lexeme;
            expr = std::move(member);
        } else if (check(TokenType::LBRACKET)) {
            Token br = advance();
            auto idx = std::make_unique<IndexExpr>();
            idx->line = br.line;
            idx->array = std::move(expr);
            idx->index = parseExpression();
            expect(TokenType::RBRACKET, "expected ']' after array index");
            expr = std::move(idx);
        } else if (check(TokenType::PLUS_PLUS) || check(TokenType::MINUS_MINUS)) {
            // Postfix ++/-- desugars to a compound assignment right here in
            // the parser, so sema/codegen need no changes: `x++` becomes
            // `x += 1`, `x--` becomes `x -= 1`. Terminal — no `x++++`.
            Token opTok = advance();
            auto one = std::make_unique<IntLiteralExpr>();
            one->line = opTok.line;
            one->value = "1";
            auto assign = std::make_unique<AssignExpr>();
            assign->line = opTok.line;
            assign->op = (opTok.type == TokenType::PLUS_PLUS) ? "+=" : "-=";
            assign->target = std::move(expr);
            assign->value = std::move(one);
            expr = std::move(assign);
            break;
        } else if (check(TokenType::KW_AS)) {
            Token asTok = advance();
            auto cast = std::make_unique<CastExpr>();
            cast->line = asTok.line;
            cast->operand = std::move(expr);
            cast->targetType = parseType();
            expr = std::move(cast);
        } else {
            break;
        }
    }
    return expr;
}

ExprPtr Parser::parsePrimary() {
    Token tok = peek();

    if (match(TokenType::INT_LITERAL)) {
        auto e = std::make_unique<IntLiteralExpr>(); e->line = tok.line; e->value = tok.lexeme; return e;
    }
    if (match(TokenType::FLOAT_LITERAL)) {
        auto e = std::make_unique<FloatLiteralExpr>(); e->line = tok.line; e->value = tok.lexeme; return e;
    }
    if (match(TokenType::STRING_LITERAL)) {
        auto e = std::make_unique<StringLiteralExpr>(); e->line = tok.line; e->value = tok.lexeme; return e;
    }
    if (match(TokenType::CHAR_LITERAL)) {
        auto e = std::make_unique<CharLiteralExpr>(); e->line = tok.line; e->value = tok.lexeme; return e;
    }
    if (match(TokenType::KW_TRUE)) {
        auto e = std::make_unique<BoolLiteralExpr>(); e->line = tok.line; e->value = true; return e;
    }
    if (match(TokenType::KW_FALSE)) {
        auto e = std::make_unique<BoolLiteralExpr>(); e->line = tok.line; e->value = false; return e;
    }
    if (match(TokenType::KW_NULLPTR)) {
        auto e = std::make_unique<NullptrExpr>(); e->line = tok.line; return e;
    }
    if (check(TokenType::IDENTIFIER)) {
        Token idTok = advance();
        if (check(TokenType::LBRACE)) {
            // Struct literal: Name { field: expr, ... }
            advance(); // consume '{'
            auto lit = std::make_unique<StructLiteralExpr>();
            lit->line = idTok.line;
            lit->structName = idTok.lexeme;
            if (!check(TokenType::RBRACE)) {
                do {
                    std::string fname = expect(TokenType::IDENTIFIER, "expected field name").lexeme;
                    expect(TokenType::COLON, "expected ':' after field name");
                    ExprPtr fval = parseExpression();
                    lit->fields.emplace_back(fname, std::move(fval));
                } while (match(TokenType::COMMA));
            }
            expect(TokenType::RBRACE, "expected '}' to close struct literal");
            return lit;
        }
        auto e = std::make_unique<IdentifierExpr>(); e->line = idTok.line; e->name = idTok.lexeme; return e;
    }
    if (check(TokenType::LBRACKET)) {
        Token br = advance();
        auto lit = std::make_unique<ArrayLiteralExpr>();
        lit->line = br.line;
        if (!check(TokenType::RBRACKET)) {
            do {
                lit->elements.push_back(parseExpression());
            } while (match(TokenType::COMMA));
        }
        expect(TokenType::RBRACKET, "expected ']' to close array literal");
        return lit;
    }
    if (match(TokenType::LPAREN)) {
        ExprPtr inner = parseExpression();
        expect(TokenType::RPAREN, "expected ')' after expression");
        return inner;
    }

    error("expected an expression", tok);
}

} // namespace cx
