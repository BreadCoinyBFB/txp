// main.cpp — cX compiler entry point
// Pipeline: lex -> parse -> (resolve file imports) -> semantic analysis
//           -> codegen (C) -> cc -> binary
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <set>
#include <filesystem>
#include "lexer/lexer.hpp"
#include "parser/parser.hpp"
#include "semantic/sema.hpp"
#include "codegen/codegen.hpp"

namespace fs = std::filesystem;

static std::string readFile(const std::string& path) {
    std::ifstream file(path);
    if (!file) {
        throw std::runtime_error("cX: could not open file '" + path + "'");
    }
    std::stringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

static void printUsage() {
    std::cerr <<
        "usage: cxc <file.cx> [options]\n"
        "  --tokens        print the raw token stream of the entry file and exit\n"
        "  --ast           print the parsed AST of the entry file and exit\n"
        "  --emit-c        print the generated C source and exit (no compile)\n"
        "  -o <path>       output binary path (default: input name without .cx)\n"
        "  --run           build then immediately execute the binary\n"
        "  (no flags)      lex, parse, check, generate C, compile to a binary\n";
}

static std::string stripExtension(const std::string& path) {
    auto slash = path.find_last_of('/');
    auto dot = path.find_last_of('.');
    if (dot != std::string::npos && (slash == std::string::npos || dot > slash)) {
        return path.substr(0, dot);
    }
    return path;
}

// Tries each C compiler in turn; returns the one that exists, or "" if none do.
static std::string findCompiler() {
    for (const char* candidate : {"clang", "cc", "gcc"}) {
        std::string checkCmd = std::string("command -v ") + candidate + " > /dev/null 2>&1";
        if (std::system(checkCmd.c_str()) == 0) return candidate;
    }
    return "";
}

// Recursively loads a .cx file and inlines any `import "file.cx";` declarations
// (resolved relative to the importing file's own directory), producing one flat
// list of declarations. Builtin imports like `import mx.console;` are left as-is
// for the semantic analyzer to process. Already-visited files are skipped so a
// diamond or circular import doesn't duplicate or infinite-loop.
static std::vector<cx::StmtPtr> loadDeclarations(const std::string& path,
                                                  std::set<std::string>& visited) {
    fs::path canon;
    try {
        canon = fs::canonical(path);
    } catch (const std::exception&) {
        throw std::runtime_error("cX: could not find imported file '" + path + "'");
    }
    std::string key = canon.string();
    if (visited.count(key)) return {}; // already included elsewhere in the import graph
    visited.insert(key);

    std::string source = readFile(canon.string());
    cx::Lexer lexer(source);
    std::vector<cx::Token> tokens = lexer.tokenize();
    cx::Parser parser(tokens);
    auto program = parser.parseProgram(); // may throw cx::ParseError

    fs::path baseDir = canon.parent_path();
    std::vector<cx::StmtPtr> result;
    for (auto& decl : program->declarations) {
        if (auto* imp = dynamic_cast<cx::ImportDecl*>(decl.get())) {
            if (imp->isFileImport) {
                fs::path resolved = baseDir / imp->filePath;
                auto nested = loadDeclarations(resolved.string(), visited);
                for (auto& d : nested) result.push_back(std::move(d));
                continue;
            }
        }
        result.push_back(std::move(decl));
    }
    return result;
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printUsage();
        return 1;
    }

    std::string path, outPath, mode;
    bool runAfter = false;
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--tokens" || arg == "--ast" || arg == "--emit-c") {
            mode = arg;
        } else if (arg == "--run") {
            runAfter = true;
        } else if (arg == "-o") {
            if (i + 1 >= argc) { std::cerr << "cX: -o requires a path\n"; return 1; }
            outPath = argv[++i];
        } else if (arg.rfind("--", 0) == 0) {
            std::cerr << "cX: unknown flag '" << arg << "'\n";
            printUsage();
            return 1;
        } else {
            path = arg;
        }
    }
    if (path.empty()) {
        printUsage();
        return 1;
    }
    if (outPath.empty()) outPath = stripExtension(path);

    if (mode == "--tokens" || mode == "--ast") {
        // These modes look at the entry file only, pre-module-resolution.
        std::string source;
        try {
            source = readFile(path);
        } catch (const std::exception& e) {
            std::cerr << e.what() << "\n";
            return 1;
        }
        cx::Lexer lexer(source);
        std::vector<cx::Token> tokens = lexer.tokenize();

        if (mode == "--tokens") {
            for (const auto& tok : tokens) {
                std::cout << "[" << tok.line << ":" << tok.col << "] " << cx::tokenTypeName(tok.type);
                if (tok.type != cx::TokenType::END_OF_FILE) std::cout << " '" << tok.lexeme << "'";
                std::cout << "\n";
            }
            return 0;
        }
        try {
            cx::Parser parser(tokens);
            auto program = parser.parseProgram();
            program->dump(std::cout, 0);
        } catch (const cx::ParseError& e) {
            std::cerr << e.what() << "\n";
            return 1;
        }
        return 0;
    }

    // Full pipeline: resolve imports into one flat program, then sema/codegen/compile.
    auto program = std::make_unique<cx::Program>();
    try {
        std::set<std::string> visited;
        program->declarations = loadDeclarations(path, visited);
    } catch (const cx::ParseError& e) {
        std::cerr << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << e.what() << "\n";
        return 1;
    }

    try {
        cx::SemanticAnalyzer sema;
        sema.analyze(*program);
    } catch (const cx::SemaError& e) {
        std::cerr << e.what() << "\n";
        return 1;
    }

    std::string cSource;
    try {
        cx::CodeGenerator codegen;
        cSource = codegen.generate(*program);
    } catch (const std::exception& e) {
        std::cerr << "cX codegen error: " << e.what() << "\n";
        return 1;
    }

    if (mode == "--emit-c") {
        std::cout << cSource;
        return 0;
    }

    std::string cPath = stripExtension(path) + ".gen.c";
    {
        std::ofstream cFile(cPath);
        if (!cFile) {
            std::cerr << "cX: could not write generated C to '" << cPath << "'\n";
            return 1;
        }
        cFile << cSource;
    }

    std::string compiler = findCompiler();
    if (compiler.empty()) {
        std::cerr << "cX: no C compiler found (looked for clang, cc, gcc).\n"
                      "     Install one, e.g. in Termux: pkg install clang\n";
        return 1;
    }

    std::string compileCmd = compiler + " -std=c11 -O2 -Wno-format -o " + outPath + " " + cPath;
    int result = std::system(compileCmd.c_str());
    if (result != 0) {
        std::cerr << "cX: " << compiler << " failed to compile the generated C (see above).\n"
                      "     Generated source kept at: " << cPath << "\n";
        return 1;
    }

    std::cout << "cX: built '" << outPath << "'\n";

    if (runAfter) {
        std::string runCmd = outPath.rfind('/', 0) == 0 || outPath.rfind("./", 0) == 0
                                  ? outPath
                                  : "./" + outPath;
        return std::system(runCmd.c_str());
    }

    return 0;
}
