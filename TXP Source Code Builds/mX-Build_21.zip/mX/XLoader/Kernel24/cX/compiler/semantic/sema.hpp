// sema.hpp — semantic analysis: scope/type checking over the AST.
// Walks the AST produced by the parser, checks that every identifier is
// declared before use, every call is to a known function (or builtin
// console method) with the right arity, break/continue only occur inside
// loops, struct literals/field access are well-formed, array indexing is
// type-correct, and annotates every expression with a resolved cX type
// (Expr::exprType) plus every `let` with its resolved variable type
// (LetStmt::resolvedType). Codegen relies on these annotations, so codegen
// should only ever run after this passes.
#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <stdexcept>
#include "../parser/ast.hpp"

namespace cx {

struct SemaError : std::runtime_error {
    int line;
    SemaError(const std::string& msg, int line_)
        : std::runtime_error(msg), line(line_) {}
};

struct FunctionSig {
    std::string returnType; // "void" if none
    std::vector<std::string> paramTypes;
};

class SemanticAnalyzer {
public:
    // Throws SemaError on the first problem found.
    void analyze(Program& program);

private:
    std::vector<std::unordered_map<std::string, std::string>> scopes_;
    std::vector<std::unordered_map<std::string, bool>> constFlags_; // parallel to scopes_, by name
    std::unordered_map<std::string, FunctionSig> functions_;
    std::unordered_map<std::string, std::vector<Param>> structs_;
    std::unordered_map<std::string, std::string> globals_;      // extern/global-let name -> type
    std::unordered_map<std::string, bool> globalConstFlags_;    // name -> is-const (global-let only)
    bool consoleImported_ = false;
    int loopDepth_ = 0;
    std::string currentReturnType_;
    bool currentIsMain_ = false;

    void pushScope();
    void popScope();
    void declareVar(const std::string& name, const std::string& type, int line, bool isConst = false);
    // Returns the declared type, or empty string if not found.
    std::string lookupVar(const std::string& name) const;
    // Returns true if `name` resolves to a const-declared variable.
    bool lookupIsConst(const std::string& name) const;

    [[noreturn]] void error(const std::string& msg, int line);

    void analyzeImport(ImportDecl& decl);
    void analyzeStructDecl(StructDecl& decl);
    void analyzeExternVar(ExternVarDecl& decl);
    void analyzeGlobalLet(LetStmt& decl);
    void analyzeFunction(FunctionDecl& decl);
    void analyzeStmt(Stmt& stmt);
    void analyzeBlock(BlockStmt& block, bool newScope);
    void analyzeExpr(Expr& expr);
    void analyzeAssignTarget(Expr& target);
    bool isLiteralExpr(Expr& e) const;

    void validateType(const std::string& type, int line);
    bool isKnownType(const std::string& type) const;

    static bool isNumeric(const std::string& t) { return t == "int" || t == "float"; }
    static bool isScalar(const std::string& t) { return t == "int" || t == "float" || t == "long" || t == "char"; }
    // int -> long is a safe widening conversion, allowed implicitly (e.g. in a
    // `let x: long = 0;` initializer). long -> int is not: that can silently
    // truncate a 64-bit address, so it always requires an explicit 'as' cast.
    static bool isWidening(const std::string& from, const std::string& to) {
        return from == "int" && to == "long";
    }
    static bool compatible(const std::string& from, const std::string& to) {
        return from == to || (isNumeric(from) && isNumeric(to)) || isWidening(from, to);
    }
    static std::string cTypeCheckName(const std::string& t) { return t.empty() ? "void" : t; }
    static bool isArrayType(const std::string& t);
    static std::string arrayElemType(const std::string& t);
    static std::string arraySizeStr(const std::string& t);
    static bool isPointerType(const std::string& t);
    static std::string pointeeType(const std::string& t);
};

} // namespace cx
