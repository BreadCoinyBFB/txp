// codegen.hpp — walks a semantically-analyzed AST and emits C source.
#pragma once
#include <string>
#include <sstream>
#include "../parser/ast.hpp"

namespace cx {

class CodeGenerator {
public:
    // Program must have already passed SemanticAnalyzer::analyze().
    std::string generate(Program& program);

private:
    std::ostringstream out_;
    bool usesPrint_ = false;
    bool usesWrite_ = false;
    bool usesReadInt_ = false;
    bool usesReadLine_ = false;
    bool inMain_ = false; // true while generating main(); only main gets an implicit 'return 0'

    static std::string cType(const std::string& cxType);
    static std::string escapeCString(const std::string& raw);
    static std::string escapeCChar(const std::string& raw);
    static void indent(std::ostringstream& os, int level);
    static bool isArrayType(const std::string& t);
    static std::string arrayElemType(const std::string& t);
    static std::string arraySizeStr(const std::string& t);
    static bool isPointerType(const std::string& t);
    static std::string pointeeType(const std::string& t);

    void emitStructs(Program& program);
    void emitGlobals(Program& program); // extern vars + global lets, file scope
    void emitPrototype(FunctionDecl& fn);
    void emitFunction(FunctionDecl& fn);
    void emitStmt(Stmt& stmt, int level);
    void emitBlockBody(BlockStmt& block, int level);
    std::string emitForClause(Stmt& stmt); // for LetStmt/ExprStmt used in a for(...) header
    std::string emitExpr(Expr& expr);

    bool lastStmtIsReturn(BlockStmt& block) const;
};

} // namespace cx
