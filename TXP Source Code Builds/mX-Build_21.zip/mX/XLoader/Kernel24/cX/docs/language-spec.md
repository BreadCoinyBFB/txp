# cX language spec (v0.1, matches the current compiler)

This is a reference for what the compiler in `compiler/` actually accepts
today, one level more detailed than the README. If this file and the
compiler ever disagree, the compiler is right — update this doc.

## Lexical elements

- Comments: `// line comment` and `/* block comment */` (block comments
  don't nest).
- Identifiers: `[A-Za-z_][A-Za-z0-9_]*`.
- Literals: integers (`42`), floats (`3.14`), strings (`"like this"`),
  chars (`'a'`), booleans (`true` / `false`), `nullptr`.
- Keywords: `fn let const if else while for return break continue
  struct import true false nullptr void int float char bool string`.

## Types

`int`, `float`, `char`, `bool`, `string`, `void`, a named `struct`, or an
array of any of these written `T[N]` (fixed size) or `T[]` (size inferred
from an initializer). Arrays of arrays are not supported.

## Declarations

```
fn add(a: int, b: int) -> int {
    return a + b;
}

fn greet() {          // no `-> type` means void
    ...
}

struct Point {
    x: int,
    y: int
}

let x: int = 10;      // type + initializer
let y = 10;            // type omitted — inferred as int from the initializer
const limit: int = 100;   // const, not let: reassigning it is a sema error
const pi = 3;              // const also supports inferred type
let nums: int[3] = [1, 2, 3];
let nums2: int[] = [1, 2, 3];   // size inferred as 3
```

`const` requires an initializer (there's nothing to infer or freeze
otherwise) and, once declared, the name can't appear on the left of an
`=`, `+=`, `-=`, `*=`, `/=`, `++`, or `--` — sema catches it with a line
number, same as any other type error.

`main` may be declared `fn main()` or `fn main() -> int`; the compiler
always treats it as returning `int` and emits a plain C `int main(void)`.

## Expression precedence (loosest to tightest binding)

| level | operators                                | associativity |
|-------|--------------------------------------------|---------------|
| 1     | `= += -= *= /=`                            | right          |
| 2     | `||`                                       | left           |
| 3     | `&&`                                       | left           |
| 4     | `\|` (bitwise or)                           | left           |
| 5     | `^` (bitwise xor)                          | left           |
| 6     | `&` (bitwise and)                          | left           |
| 7     | `== !=`                                    | left           |
| 8     | `< > <= >=`                                | left           |
| 9     | `<< >>` (shifts)                           | left           |
| 10    | `+ -`                                      | left           |
| 11    | `* / %`                                    | left           |
| 12    | unary `! - ~`                              | right          |
| 13    | call `f(...)`, member `.`, index `[...]`, postfix `++ --` | left |

The bitwise operators (`& | ^ ~ << >>`) require `int` operands on both
sides — no implicit conversion from `float` or `bool`. Postfix `++`/`--`
is sugar the parser expands on the spot: `x++` is exactly `x += 1`, so
it follows the same const/type rules as any other compound assignment.
There's no prefix `++x`/`--x` — postfix only.

Assignment targets must be an identifier, a field access, or an index
expression — `a = b = 1` works, `1 = a` does not.

## Statements

`let`, `if`/`else`, `while (cond) { }`, C-style
`for (init; cond; post) { }` (each clause optional), `break`, `continue`
(only inside a loop), `return` (bare or with a value), and expression
statements. Blocks are `{ }`; there's no bare single-statement `if`
without braces.

## Structs

```
struct Point { x: int, y: int }

let p: Point = Point { x: 1, y: 2 };   // fields can be given in any order
p.x = p.x + 1;
```

Struct fields must currently be non-array primitive or struct types —
no array fields yet.

## Arrays

```
let a: int[5] = [1, 2, 3, 4, 5];
let b: int[] = [1, 2, 3];   // size inferred
a[0] = 99;
console.print(a[0]);
```

Arrays aren't yet usable as function parameters, function return types,
or struct fields — only as local variables.

## Modules

Two independent mechanisms:

- **Builtin namespace import**: `import mx.console;` unlocks the
  `console.*` builtins (see below). This is the only builtin module
  right now; anything else (`import mx.math;`, `import foo.bar;`, ...)
  is a semantic error.
- **File import**: `import "relative/path.cx";` (path resolved relative
  to the *importing* file, not the working directory) inlines that
  file's `fn` and `struct` declarations directly. This is how
  `std/mx/math.cx` gets pulled into a program — it's ordinary cX code,
  not a compiler builtin. The same file imported twice (directly or via
  a diamond) is only included once.

## Pointers, casts, and extern (added for Kernel24)

cX has one level of pointer indirection: `T*` for any type `T`
(including `void*`). `&x` takes the address of a variable, array
element, or struct field; `*p` dereferences; `p[i]` indexes a pointer
exactly like an array; `p + n` / `p - n` do pointer arithmetic (`n`
must be `int`). `.` auto-dereferences a pointer-to-struct, so
`p.field` works whether `p` is a struct value or a pointer to one —
`->` is accepted too, as an alias, for anyone used to writing it.

`expr as Type` casts between int/long/float/char, between a pointer and
`int`/`long`, or between two pointer types. `long` is a real 64-bit
integer alongside `int` (32-bit); `int` widens to `long` implicitly,
but `long → int` always needs an explicit cast (that direction can
silently truncate an address, which is exactly the kind of mistake
worth forcing into the open). Hex literals (`0xB8000`) are supported.

`extern fn name(...) -> T;` declares a function implemented elsewhere
(another separately-compiled `.cx` file, or hand-written assembly) —
no body, just a signature, exactly like a C prototype. `extern let
name: T;` does the same for a variable or array whose storage lives
elsewhere. Both are how cX code calls into assembly primitives (port
I/O, control registers, anything needing a real CPU instruction) and
how separately-compiled `.cx` files call each other without cX's
`import "file.cx";` inlining mechanism duplicating symbols across
translation units. See Kernel24's `docs/cx-integration.md` for the
real-world story of why and how these got added.

Top-level (file-scope) `let`/`const` are also supported now — a global
variable with `static` storage duration in the generated C, usable from
every function in that file. The initializer, if given, must be a
constant literal (no function calls or other-variable references).

## Standard library (builtin, via `import mx.console;`)

| call                     | behavior                                         |
|--------------------------|---------------------------------------------------|
| `console.print(x)`       | prints `x` followed by a newline                  |
| `console.write(x)`       | prints `x`, no trailing newline                    |
| `console.read_int()`     | reads one integer from stdin, returns `int`        |
| `console.read_line()`    | reads a line from stdin, returns `string`          |

`print`/`write` accept any of `int`, `float`, `char`, `bool`, `string`
and pick the right format at compile time (C11 `_Generic` under the
hood) — no format strings to get wrong.

## Semantic checks you can rely on

Undeclared variables/functions, redeclaration in the same scope, wrong
argument count or type in a call, wrong or missing struct fields in a
struct literal, array size/element-type mismatches, `break`/`continue`
outside a loop, a missing or wrong-typed `return`, a missing `main`,
and assignment to a `const` — all reported with a source line number,
before codegen ever runs.

## Known gaps (also tracked in the README roadmap)

Arrays as function parameters/return types/struct fields, struct
methods, string concatenation/comparison, generics, prefix `++x`/`--x`
(postfix only, see the precedence table above), and no memory model
beyond whatever the generated C gives you for free (no GC, no
ownership checking, no exposed `malloc`/`free`). `else if` is just
`else { if ... }` — works fine, no special form needed.
