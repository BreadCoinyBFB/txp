#!/usr/bin/env bash
# tests/run_tests.sh — build cxc, then run every case in tests/cases/
# against its expected output.
#
# Each normal case is a pair of files sharing a basename:
#   tests/cases/<name>.cx        the program
#   tests/cases/<name>.expected  the exact stdout it should print
#
# A case whose name ends in "_fail" is expected to be rejected by the
# compiler instead of run. Its .expected file holds a substring that
# must appear in the compiler's stderr; success means "compile failed
# AND stderr contains that substring".
#
# Usage: ./tests/run_tests.sh

set -uo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CASES_DIR="$ROOT_DIR/tests/cases"
CXC="$ROOT_DIR/build/cxc"

echo "Building cxc..."
if ! make -C "$ROOT_DIR" > /tmp/cx_test_build.log 2>&1; then
    echo "cX: build failed, see /tmp/cx_test_build.log"
    cat /tmp/cx_test_build.log
    exit 1
fi

pass=0
fail=0

for cx_file in "$CASES_DIR"/*.cx; do
    name="$(basename "$cx_file" .cx)"
    expected_file="$CASES_DIR/$name.expected"
    bin="$CASES_DIR/$name.bin"
    gen_c="$CASES_DIR/$name.gen.c" # cxc names this after the source file, not -o

    if [[ ! -f "$expected_file" ]]; then
        echo "SKIP  $name (no .expected file)"
        continue
    fi
    expected="$(cat "$expected_file")"

    if [[ "$name" == *_fail ]]; then
        # Expected to be rejected during lex/parse/sema, before a binary exists.
        build_output="$("$CXC" "$cx_file" -o "$bin" 2>&1)"
        build_status=$?
        if [[ $build_status -ne 0 && "$build_output" == *"$expected"* ]]; then
            echo "PASS  $name (rejected as expected)"
            pass=$((pass + 1))
        else
            echo "FAIL  $name"
            echo "  expected stderr to contain: $expected"
            echo "  got (exit $build_status):"
            echo "$build_output" | sed 's/^/    /'
            fail=$((fail + 1))
        fi
        rm -f "$bin" "$gen_c"
        continue
    fi

    build_output="$("$CXC" "$cx_file" -o "$bin" 2>&1)"
    build_status=$?
    if [[ $build_status -ne 0 ]]; then
        echo "FAIL  $name (compile failed)"
        echo "$build_output" | sed 's/^/    /'
        fail=$((fail + 1))
        rm -f "$bin" "$gen_c"
        continue
    fi

    actual="$("$bin")"
    run_status=$?
    if [[ $run_status -eq 0 && "$actual" == "$expected" ]]; then
        echo "PASS  $name"
        pass=$((pass + 1))
    else
        echo "FAIL  $name"
        diff <(echo "$expected") <(echo "$actual") | sed 's/^/    /'
        fail=$((fail + 1))
    fi
    rm -f "$bin" "$gen_c"
done

echo
echo "$pass passed, $fail failed"
[[ $fail -eq 0 ]]
