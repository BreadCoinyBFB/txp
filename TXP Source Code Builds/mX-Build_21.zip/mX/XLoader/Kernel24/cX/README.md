# cX

C, but it mX. A small language that transpiles to C, built for (and in) Termux.

Eventually pairs with **mX**, an OS written in cX.

> "OHHH, NAHHH, what is this, templeos?" — no, but respect to Terry.

## Status

**cX programs actually run now.** The full pipeline works:
lex → parse → semantic analysis → generate C → compile with a system
C compiler (clang/cc/gcc) → binary.

```bash
./build/cxc examples/hello.cx --run
# Hello from cX!
# 42
```

Pipeline (per `compiler/`):

```
lexer → parser → semantic → codegen → (emits .c) → gcc/clang → binary
```

## Build (Termux)

```bash
pkg install clang make    # or g++
cd cX
make
```

Run the parser against the example program (prints the AST):

```bash
make run
# or directly:
./build/cxc examples/hello.cx --run     # build + execute
./build/cxc examples/hello.cx           # build only (writes a binary next to the .cx file)
./build/cxc examples/hello.cx --emit-c  # print the generated C, don't compile
./build/cxc examples/hello.cx --ast     # print the AST, don't compile
./build/cxc examples/hello.cx --tokens  # print raw tokens, don't compile
```

`cxc` looks for `clang`, then `cc`, then `gcc` on your PATH to do the actual
C compile. In Termux: `pkg install clang`.

## Language sketch (v0.1 draft, subject to change)

```
import mx.console;

fn add(a: int, b: int) -> int {
    return a + b;
}

fn main() -> int {
    let x: int = 10;
    let y: int = 32;
    console.print("Hello from cX!");
    console.print(add(x, y));
    return 0;
}
```

Differences from C so far:

| cX                          | transpiles to (planned) |
|------------------------------|--------------------------|
| `fn name(a: int) -> int {}`  | `int name(int a) {}`     |
| `let x: int = 5;`            | `int x = 5;`              |
| `import mx.console;`         | `#include "mx/console.h"`|

Everything else (control flow, operators, structs) is meant to stay
close to C — the point isn't to reinvent syntax, it's to sand off the
rough edges (manifest types-after-name, no `let`, verbose includes)
while still compiling down to plain, portable C.

### What actually works right now

- `fn`, `let`, `const`, `if`/`else`, `while`, `for`, `break`, `continue`, `return`
- Types: `int`, `float`, `char`, `bool`, `string`, `void`
- **Immutability**: `const x: int = 5;` — reassigning a `const` is a
  semantic error with a line number, same as any other type mistake
- **Operators**: the usual arithmetic/comparison/logical set, plus
  bitwise `& | ^ ~ << >>` (int operands only) and postfix `x++`/`x--`
  (sugar for `x += 1`/`x -= 1` — no prefix `++x` yet)
- **Structs**: `struct Point { x: int, y: int }`, literals `Point { x: 1, y: 2 }`,
  field access `p.x`, field assignment `p.x = 5;` (fields must all be
  non-array primitive/struct types for now)
- **Arrays**: `let nums: int[5] = [1, 2, 3, 4, 5];`, indexing `nums[0]`,
  index assignment `nums[0] = 99;`. Size can be omitted (`int[]`) when an
  array literal initializer is given — the size is inferred. Arrays aren't
  yet supported as function parameters/return types or struct fields.
- **Real modules**: `import "path/to/file.cx";` (relative to the importing
  file) pulls in another file's `fn`/`struct` declarations directly —
  ordinary user-written cX code, not a compiler builtin. Diamond/circular
  imports are deduplicated automatically.
- `console.print(x)` / `console.write(x)` (no newline) — work for any of
  the types above, via C11 `_Generic` to pick the right `printf` format
  at compile time
- `console.read_int()` / `console.read_line()` — read from stdin
- Type checking: undeclared variables/functions, wrong argument counts,
  wrong struct fields, array type/size mismatches, `break`/`continue`
  outside a loop, bad `return` types, assignment to a `const` — all
  caught before codegen runs, with a line number
- Not yet: arrays as function params/struct fields, struct methods,
  string concatenation/comparison, generics, prefix `++x`/`--x`, a real
  memory model beyond what C gives you for free

See [`docs/language-spec.md`](docs/language-spec.md) for the full
grammar, precedence table, and semantic-check reference. Run
`./tests/run_tests.sh` to build the compiler and check it against the
cases in `tests/cases/` (lexer→binary, plus one expected-error case).

## Repo layout

```
cX/
├── compiler/
│   ├── lexer/       tokenizer (done: token.hpp, lexer.hpp/.cpp)
│   ├── parser/       tokens → AST (done: ast.hpp, parser.hpp/.cpp)
│   ├── semantic/      type/scope checking (done: sema.hpp/.cpp)
│   ├── codegen/       AST → C source (done: codegen.hpp/.cpp)
│   └── main.cpp      driver / CLI
├── std/mx/           cX standard library (console builtin, math.cx module)
├── examples/         sample .cx programs (hello, structs+arrays, modules, operators)
├── docs/             language spec, notes
├── tests/            run_tests.sh + cases/ (compile-and-run + one error case)
└── Makefile
```

## Roadmap

- [x] Lexer
- [x] Parser → AST (recursive descent)
- [x] Semantic analysis (types, scopes)
- [x] C codegen (`.cx` → `.c`)
- [x] Invoke gcc/clang on generated C, produce a binary
- [x] Structs
- [x] Arrays
- [x] Real modules (`import "file.cx";`)
- [x] Standard library beyond `console.print` (`write`, `read_int`, `read_line`)
- [x] `const` (immutable bindings, enforced by sema)
- [x] Bitwise operators (`& | ^ ~ << >>`)
- [x] Postfix `++`/`--`
- [ ] Arrays as function params / struct fields
- [ ] Struct methods
- [ ] mX (the OS)
