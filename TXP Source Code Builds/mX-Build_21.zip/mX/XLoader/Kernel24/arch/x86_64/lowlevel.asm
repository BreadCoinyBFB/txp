; lowlevel.asm — CPU/port-I/O primitives cX can't express (no inline asm,
; no way to force an exact packed byte layout). Replaces the old
; arch/x86_64/cpu/cpu.c and arch/x86_64/io.h: every function here is
; called from cX via a matching `extern fn` declaration, using the
; ordinary System V AMD64 calling convention (integer args in RDI, RSI,
; RDX, ...; return value in RAX). Nothing here does anything cleverer
; than what the original C/inline-asm did — this is a direct translation,
; not a redesign.

BITS 64
section .text

; void outb(int port, int val) — writes the low byte of val to the low
; 16 bits of port.
global outb
outb:
    mov dx, di
    mov al, sil
    out dx, al
    ret

; int inb(int port) -> 0-255 in EAX
global inb
inb:
    mov dx, di
    xor eax, eax
    in al, dx
    ret

; void io_wait(void) — the traditional "write to an unused port" delay
global io_wait
io_wait:
    mov al, 0
    out 0x80, al
    ret

global cx_cli
cx_cli:
    cli
    ret

global cx_sti
cx_sti:
    sti
    ret

global cx_hlt
cx_hlt:
    hlt
    ret

; long read_cr2(void) — the faulting address after a page fault
global read_cr2
read_cr2:
    mov rax, cr2
    ret

; bool cpu_verify_long_mode(void) -> 0 or 1 in AL.
global cpu_verify_long_mode
cpu_verify_long_mode:
    push rbx
    mov eax, 0x80000001
    cpuid
    test edx, (1 << 29)
    jz .no
    mov ecx, 0xC0000080     ; IA32_EFER
    rdmsr
    test eax, (1 << 10)     ; LMA
    jz .no
    mov al, 1
    pop rbx
    ret
.no:
    mov al, 0
    pop rbx
    ret

; void idt_load(long base, int limit)
global idt_load
idt_load:
    sub rsp, 16
    mov [rsp], si
    mov [rsp + 2], rdi
    lidt [rsp]
    add rsp, 16
    ret

; long kernel_image_end(void) — the linker-provided __bss_end symbol
extern __bss_end
global kernel_image_end
kernel_image_end:
    lea rax, [rel __bss_end]
    ret

; void write_cr3(long addr)
global write_cr3
write_cr3:
    mov cr3, rdi
    ret

; long read_cr3(void)
global read_cr3
read_cr3:
    mov rax, cr3
    ret

; void invlpg(long addr)
global invlpg
invlpg:
    invlpg [rdi]
    ret

; void cpuid_query(int leaf, long* out_eax, long* out_ebx, long* out_ecx, long* out_edx)
global cpuid_query
cpuid_query:
    push rbx
    mov r9, rdx
    mov r10, rcx

    mov eax, edi
    xor ecx, ecx
    cpuid

    mov r11d, eax
    mov [rsi], r11
    mov r11d, ebx
    mov [r9], r11
    mov r11d, ecx
    mov [r10], r11
    mov r11d, edx
    mov [r8], r11

    pop rbx
    ret

; void gdt_load(long base, int limit) — same {limit:u16, base:u64} GDTR
; shape and reasoning as idt_load above, for arch/x86_64/gdt/gdt.cx.
global gdt_load
gdt_load:
    sub rsp, 16
    mov [rsp], si
    mov [rsp + 2], rdi
    lgdt [rsp]
    add rsp, 16
    ret

; void tss_load(int selector) — LTR.
global tss_load
tss_load:
    mov ax, di
    ltr ax
    ret

; long syscall_invoke(long num, long a1, long a2, long a3) -> long
; The only place any cX code executes `int 0x80` — cX has no inline
; asm. Shuffles System V incoming args (RDI/RSI/RDX/RCX) into mX's own
; syscall convention (RAX=number, RBX=arg1, RCX=arg2, RDX=arg3 — chosen
; to avoid colliding with RDI/RSI/RDX, which
; arch/x86_64/interrupts/isr.cx's interrupt_handler already uses for
; vector/error_code/saved_rsp). By the time `int 0x80` "returns" here,
; RAX already holds arch/x86_64/interrupts/syscall.cx's result — see
; isr_stubs.asm's isr_common_stub, which restores RAX from the saved
; frame that syscall.cx wrote into.
global syscall_invoke
syscall_invoke:
    push rbx
    mov rax, rdi
    mov rbx, rsi
    mov r10, rdx
    mov rdx, rcx
    mov rcx, r10
    int 0x80
    pop rbx
    ret

; 4 KiB scratch buffer for idt.cx to build the IDT in.
section .bss
align 16
global idt_table
idt_table:
    resb 4096

; GDT scratch buffer for arch/x86_64/gdt/gdt.cx. 9 descriptors at 8
; bytes each (null, code32, data32, code64, data64, user_code64,
; user_data64, tss-low, tss-high) = 72 bytes; rounded up for headroom.
align 16
global gdt_table
gdt_table:
    resb 128

; TSS scratch buffer. A minimal 64-bit TSS is 104 bytes (see gdt.cx);
; rounded up for headroom.
align 16
global tss_table
tss_table:
    resb 128

section .note.GNU-stack noalloc noexec nowrite progbits
