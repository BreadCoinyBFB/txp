#!/usr/bin/env bash
# Builds build/disk.img. Just a thin wrapper — `make` is the source of truth.
set -e
cd "$(dirname "$0")/.."
make all
