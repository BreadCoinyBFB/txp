#!/usr/bin/env bash
# Removes everything under build/.
set -e
cd "$(dirname "$0")/.."
make clean
