#!/usr/bin/env bash
# Builds (if needed) and boots build/disk.img in QEMU.
set -e
cd "$(dirname "$0")/.."
make run
