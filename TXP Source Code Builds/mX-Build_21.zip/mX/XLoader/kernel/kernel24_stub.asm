; ============================================================================
; kernel24_stub.asm — TEMPORARY placeholder for Kernel24
; ============================================================================
; Kernel24 doesn't exist yet ("it soon"). This is a small stand-in so
; XLoader's boot chain can be built and tested end-to-end right now: it
; writes a message to the VGA text buffer, reads back a couple of fields
; from the BootInfo structure XLoader hands it (proving that hand-off
; actually works), and halts.
;
; Delete this file (and repoint the Makefile at the real Kernel24 binary)
; once Kernel24 exists — nothing in XLoader itself needs to change, as long
; as the new image starts with the same 8-byte header (see below) and reads
; its BootInfo pointer from RDI the same way.

%include "boot.inc"

BITS 64
ORG KERNEL24_LOAD_ADDR

dd KERNEL24_MAGIC
dd 0                    ; checksum placeholder — tools/patch_checksum.py
                         ; overwrites this after assembly with the real value

start:
    ; RDI = pointer to XLoader's BootInfo structure (boot/bootinfo.asm).
    ; Stash it in a callee-saved-style register before it gets clobbered by
    ; the print calls below.
    mov r15, rdi

    mov rdi, 0xB8000                  ; row 0
    mov rsi, msg_ok
    call print_string_vga

    mov rdi, 0xB8000 + 160             ; row 1
    mov rsi, msg_drive
    call print_string_vga
    mov eax, [r15 + 4]                  ; BootInfo.boot_drive
    call print_hex32

    mov rdi, 0xB8000 + 320                ; row 2
    mov rsi, msg_memmap
    call print_string_vga
    mov eax, [r15 + 8]                     ; BootInfo.memory_map_count
    call print_hex32

.halt:
    cli
    hlt
    jmp .halt

; print_string_vga — writes a null-terminated string to the VGA text buffer.
; In: RSI = string, RDI = VGA buffer position. Out: RDI advanced past it.
print_string_vga:
.next:
    mov al, [rsi]
    cmp al, 0
    je .done
    mov [rdi], al
    mov byte [rdi + 1], 0x0A     ; green on black
    add rdi, 2
    add rsi, 1
    jmp .next
.done:
    ret

; print_hex32 — writes EAX as 8 hex digits (most significant first) to the
; VGA text buffer. In: EAX = value, RDI = position. Out: RDI advanced past it.
print_hex32:
    mov ecx, 8
.next_digit:
    rol eax, 4              ; after N rotations, the low nibble holds the
    mov edx, eax             ; (N mod 8)-th nibble counting from the top
    and edx, 0x0F
    cmp edx, 10
    jb .digit
    add edx, 'A' - 10 - '0'  ; land on 'A'-'F' once the '0' add below runs
.digit:
    add edx, '0'
    mov [rdi], dl
    mov byte [rdi + 1], 0x0A
    add rdi, 2
    loop .next_digit
    ret

msg_ok:     db "KERNEL24 OK", 0
msg_drive:  db "BOOT DRIVE=0x", 0
msg_memmap: db "MEMORY MAP ENTRIES=0x", 0
