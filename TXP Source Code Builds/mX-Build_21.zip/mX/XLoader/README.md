# XLoader

A bootloader for **mX**. BIOS/MBR, x86, real mode → protected mode → 64-bit
long mode → jump to Kernel24.

```
XLoader/
├── boot/
│   ├── stage1.asm      # boot sector: banner, loads stage2
│   ├── stage2.asm      # loads Kernel24, A20, memory map, GDT, protected mode
│   ├── gdt.asm         # the Global Descriptor Table
│   ├── a20.asm         # A20 line enable (4-method fallback chain)
│   ├── memory.asm      # BIOS E820 memory detection
│   ├── bootinfo.asm    # builds the BootInfo struct handed to Kernel24
│   └── longmode.asm    # page tables, PAE/EFER/paging, jump to 64-bit
├── include/
│   ├── boot.inc        # memory map & disk layout constants
│   ├── gdt.inc         # segment selector constants
│   ├── disk.inc        # INT 13h LBA sector reads
│   └── screen.inc      # BIOS teletype text output
├── kernel/
│   ├── loader.asm         # Kernel24-specific load + relocate + verify logic
│   └── kernel24_stub.asm  # placeholder Kernel24 for end-to-end testing
├── tools/
│   ├── build.sh / run.sh / clean.sh   # thin wrappers around `make`
│   ├── patch_checksum.py              # bakes a checksum into the kernel image
│   └── archives/nasm-nasm-3.02.zip
├── docs/
│   ├── boot-process.md
│   ├── memory-map.md
│   └── roadmap.md
├── Makefile
└── README.md
```

## Build & run

Needs `nasm`, `qemu-system-x86_64`, and `python3` on your `PATH`.

```
make          # -> build/disk.img
make run      # build (if needed) and boot it in QEMU
make clean
```

`tools/build.sh`, `tools/run.sh`, `tools/clean.sh` do the same thing, if you
prefer running a script over `make` directly.

## Status

| Component  | Status |
|------------|--------|
| cX         | done |
| XLoader    | phases 1-3 + Stage 2 checklist (incl. BootInfo hand-off) implemented (see `docs/roadmap.md`) |
| Kernel24   | early stage implemented (see `Kernel24/docs/roadmap.md`) |
| mX         | not started |

XLoader boots into the real Kernel24 (see `Kernel24/`) automatically when
that project is present — `make` detects it and builds it as part of
XLoader's own build. Without it, XLoader falls back to a placeholder
stub (`kernel/kernel24_stub.asm`) that just proves the boot chain works.
