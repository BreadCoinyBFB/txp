; ============================================================================
; longmode.asm — enable PAE, build page tables, jump into 64-bit long mode
; ============================================================================
; Entry condition: 32-bit protected mode, flat data segments already loaded,
; interrupts off. Called once, never returns (falls through into Kernel24).
;
; We identity-map the first 8 MiB using four 2 MiB pages, which is more than
; enough to cover our own code/tables and Kernel24's load address at 1 MiB.
; One PML4 entry -> one PDPT entry -> four PD entries. No 4 KiB-granularity
; page tables needed at all, which keeps this short.

enter_long_mode:
    DEBUG_MARK 3, "LM1"    ; entering enter_long_mode (kernel24_verify passed)

    cld
    ; Zero the three page-table pages (PML4, PDPT, PD are laid out
    ; contiguously — see boot.inc). 3 pages * 4096 bytes = 3072 dwords.
    mov edi, PML4_ADDR
    mov ecx, 3072
    xor eax, eax
    rep stosd

    ; PML4[0] -> PDPT (present, writable)
    mov edi, PML4_ADDR
    mov dword [edi], PDPT_ADDR | 0x03

    ; PDPT[0] -> PD (present, writable)
    mov edi, PDPT_ADDR
    mov dword [edi], PD_ADDR | 0x03

    ; PD[0..3] -> four 2 MiB identity-mapped pages covering 0-8 MiB
    ; (present, writable, PS=1 means "this is a 2MiB page, not a pointer
    ; to a 4KiB page table")
    mov edi, PD_ADDR
    mov eax, 0x00000083        ; page 0: base=0x000000 | present|write|PS
    mov ecx, 4
.fill_pd:
    mov [edi], eax
    add eax, 0x00200000        ; next 2 MiB page
    add edi, 8                 ; next 8-byte PD entry
    loop .fill_pd

    ; Enable PAE (CR4 bit 5) — required before long mode can be entered
    mov eax, cr4
    or eax, 1 << 5
    mov cr4, eax

    ; Point CR3 at PML4
    mov eax, PML4_ADDR
    mov cr3, eax

    ; Set EFER.LME (bit 8 of MSR 0xC0000080) — "yes, we intend to run in long mode"
    mov ecx, 0xC0000080
    rdmsr
    or eax, 1 << 8
    wrmsr

    ; Enable paging (CR0 bit 31). With LME already set, this atomically
    ; drops us into IA-32e "compatibility mode" — still executing 32-bit
    ; code until we reload CS with a 64-bit code descriptor below.
    mov eax, cr0
    or eax, 1 << 31
    mov cr0, eax

    ; Reload CS via a far jump — this is what actually switches the CPU
    ; into full 64-bit instruction decoding.
    jmp CODE64_SEG:long_mode_entry

BITS 64
long_mode_entry:
    DEBUG_MARK 4, "LM2"    ; CPU is genuinely in 64-bit mode now

    ; Data segments are mostly vestigial in long mode, but must still hold
    ; a valid selector.
    mov ax, DATA64_SEG
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    ; A throwaway stack — we never call back into the BIOS again after this
    ; point, so borrowing this low-memory region for a few instructions is
    ; safe even though it overlaps the EBDA on some machines.
    mov rsp, 0x90000

    ; Hand off to Kernel24. RDI = pointer to the BootInfo structure
    ; (boot/bootinfo.asm) — the System V AMD64 calling convention passes the
    ; first argument in RDI, so a Kernel24 written in C can simply declare
    ; `void kmain(struct boot_info *info)` and this just works.
    ; KERNEL24_LOAD_ADDR itself holds Kernel24's 8-byte header (magic +
    ; checksum — see kernel24_verify), so the real entry point is
    ; KERNEL24_ENTRY_ADDR, 8 bytes further in.
    mov rdi, BOOT_INFO_ADDR
    mov rax, KERNEL24_ENTRY_ADDR
    jmp rax
BITS 32