%ifdef DEBUG

debug_print:
    ; print SI string
    call print_string
    ret

; DEBUG_MARK slot, msg — writes a short marker to a fixed spot on the
; last screen row (row 24 of an 80x25 display), independent of
; wherever the cursor is or whatever real-mode text is already on
; screen above it. Added specifically to localize the "freezes after
; Entering Protected Mode" report: each checkpoint below only overwrites
; its own slot, so whichever markers actually show up on the next test
; boot say exactly how far execution got before it stopped — without
; needing a debugger or serial port. White-on-green, to stay visually
; distinct from kernel24_verify's white-on-red failure messages.
;
; `slot` is 0,1,2,... — each slot is 4 screen columns wide (room for a
; short tag like "PM1 "), so slot N sits at column N*4. Works
; unmodified from BITS 32 or BITS 64 — it only touches 32-bit-register
; forms (edi/esi/eax), which are valid register operand sizes in
; either mode.
%macro DEBUG_MARK 2
    mov edi, 0xB8000 + (24 * 160) + (%1 * 4 * 2)
    mov esi, %%msg
    jmp %%after
%%msg: db %2, 0
%%after:
%%loop:
    mov al, [esi]
    cmp al, 0
    je %%done
    mov [edi], al
    mov byte [edi + 1], 0x2F
    inc esi
    add edi, 2
    jmp %%loop
%%done:
%endmacro

%else

debug_print:
    ret

%macro DEBUG_MARK 2
%endmacro

%endif
