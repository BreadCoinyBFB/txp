; ============================================================================
; bootinfo.asm — builds the structure XLoader hands off to Kernel24
; ============================================================================
; Real mode. Call this only after detect_memory and kernel24_load_from_disk
; have already filled in the values it copies (boot drive, memory map).
;
; Layout (48 bytes total; see docs/memory-map.md for the prose version).
; Pointer-sized fields are 64-bit even though every address in here fits in
; 32 bits today, since Kernel24 itself runs in 64-bit long mode and this
; struct is what it'll actually dereference:
;
;   offset  0  (4 bytes)  magic              = BOOTINFO_MAGIC
;   offset  4  (4 bytes)  boot_drive         = BIOS drive number
;   offset  8  (4 bytes)  memory_map_count   = number of E820 entries
;   offset 12  (4 bytes)  reserved           = 0 (padding, keeps the next
;                                                  field 8-byte aligned)
;   offset 16  (8 bytes)  memory_map_addr    = pointer to the E820 entries
;   offset 24  (8 bytes)  framebuffer_addr   = 0 (not available yet)
;   offset 32  (4 bytes)  framebuffer_width  = 0
;   offset 36  (4 bytes)  framebuffer_height = 0
;   offset 40  (4 bytes)  framebuffer_pitch  = 0
;   offset 44  (4 bytes)  framebuffer_bpp    = 0
;
; The framebuffer fields are reserved, zeroed placeholders — XLoader doesn't
; set up a linear framebuffer yet (still BIOS VGA text mode), but the field
; layout is here now so Kernel24's struct definition doesn't need to change
; shape later, only start getting non-zero values.

; build_boot_info
; Clobbers: nothing (all registers saved/restored)
build_boot_info:
    pusha

    mov dword [BOOT_INFO_ADDR + 0], BOOTINFO_MAGIC

    xor eax, eax
    mov al, [BOOT_DRIVE_ADDR]
    mov dword [BOOT_INFO_ADDR + 4], eax

    mov eax, [MEMORY_MAP_COUNT_ADDR]
    mov dword [BOOT_INFO_ADDR + 8], eax

    mov dword [BOOT_INFO_ADDR + 12], 0             ; reserved/padding

    mov dword [BOOT_INFO_ADDR + 16], MEMORY_MAP_ADDR
    mov dword [BOOT_INFO_ADDR + 20], 0              ; high dword: always 0, our addresses fit in 32 bits

    mov dword [BOOT_INFO_ADDR + 24], 0              ; framebuffer_addr (low)
    mov dword [BOOT_INFO_ADDR + 28], 0              ; framebuffer_addr (high)
    mov dword [BOOT_INFO_ADDR + 32], 0              ; framebuffer_width
    mov dword [BOOT_INFO_ADDR + 36], 0              ; framebuffer_height
    mov dword [BOOT_INFO_ADDR + 40], 0              ; framebuffer_pitch
    mov dword [BOOT_INFO_ADDR + 44], 0              ; framebuffer_bpp

    popa
    ret
