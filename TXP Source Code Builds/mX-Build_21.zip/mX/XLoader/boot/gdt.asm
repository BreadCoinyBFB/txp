; ============================================================================
; gdt.asm — the Global Descriptor Table
; ============================================================================
; A flat-model GDT: every segment's base is 0 and (for the 32-bit entries)
; its limit spans the full address space. Once we're in long mode, base and
; limit are ignored for code entirely and mostly ignored for data — but we
; still define real 64-bit descriptors rather than relying on that, since
; it's clearer and it's what LGDT actually needs at hand-off time.
;
; Selector values (see include/gdt.inc) are just this table's byte offsets:
; null=0x00, code32=0x08, data32=0x10, code64=0x18, data64=0x20.

align 8
gdt_start:

gdt_null:
    dq 0x0000000000000000

gdt_code32:
    dw 0xFFFF           ; limit[15:0]
    dw 0x0000           ; base[15:0]
    db 0x00             ; base[23:16]
    db 10011010b        ; access: present, ring0, code, executable, readable
    db 11001111b        ; flags: G=1 (4KiB granularity), D=1 (32-bit) | limit[19:16]=F
    db 0x00             ; base[31:24]

gdt_data32:
    dw 0xFFFF
    dw 0x0000
    db 0x00
    db 10010010b        ; access: present, ring0, data, writable
    db 11001111b
    db 0x00

gdt_code64:
    dw 0x0000           ; limit ignored in 64-bit mode
    dw 0x0000
    db 0x00
    db 10011010b        ; access: present, ring0, code, executable, readable
    db 00100000b        ; flags: L=1 (long mode), D=0 (must be 0 when L=1)
    db 0x00

gdt_data64:
    dw 0x0000
    dw 0x0000
    db 0x00
    db 10010010b        ; access: present, ring0, data, writable
    db 00000000b
    db 0x00

gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1  ; size of table, minus 1, per LGDT's convention
    dd gdt_start                ; linear base address (flat, low memory: fits in 32 bits)
