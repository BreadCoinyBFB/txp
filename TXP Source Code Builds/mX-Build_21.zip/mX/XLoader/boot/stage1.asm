; ============================================================================
; stage1.asm — the boot sector (512 bytes, loaded by the BIOS at 0x7C00)
; ============================================================================
; Phase 1: prove we're alive (print the banner).
; Phase 2 (part 1): confirm LBA disk reads are available, then load stage2.
; Everything past this file's 512 bytes (GDT, long mode, Kernel24 loading)
; lives in stage2, which has far more room to work with.

BITS 16
ORG 0x7C00

jmp start   ; the includes below land library code right after this file's
            ; first byte — without this jump the CPU would start executing
            ; print_string's bytes instead of our actual entry point

%include "boot.inc"
%include "screen.inc"
%include "disk.inc"
%include "debug.asm"

start:
    jmp 0x0000:.init   ; normalize CS:IP in case the BIOS entered us at 07C0:0000

.init:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, STACK_TOP
    sti

    mov [BOOT_DRIVE_ADDR], dl   ; the BIOS passes the boot drive in DL — save it
                                ; now, before anything else has a chance to clobber it

    mov si, msg_banner
    call print_string

    mov dl, [BOOT_DRIVE_ADDR]
    call check_extensions_present
    jc .disk_error

    ; Load stage2: STAGE2_SECTORS sectors starting at STAGE2_LBA, into
    ; 0x0000:STAGE2_ADDR.
    xor ax, ax
    mov es, ax
    mov bx, STAGE2_ADDR
    mov eax, STAGE2_LBA
    mov cx, STAGE2_SECTORS
    mov dl, [BOOT_DRIVE_ADDR]
    call read_sectors
    jc .disk_error

    ; Verify stage2 loaded correctly before trusting it enough to jump in —
    ; its last 4 bytes should be STAGE2_MAGIC (see stage2.asm's `times` pad).
    mov eax, [STAGE2_ADDR + (STAGE2_SECTORS * 512) - 4]
    cmp eax, STAGE2_MAGIC
    jne .stage2_bad

    jmp 0x0000:STAGE2_ADDR

.stage2_bad:
    mov si, msg_stage2_bad
    call print_string
    jmp .hang

.disk_error:
    mov si, msg_disk_error
    call print_string
.hang:
    cli
    hlt
    jmp .hang

msg_banner:     db "XLoader v1.0", 13, 10, 0
msg_disk_error: db "Disk error!", 13, 10, 0
msg_stage2_bad: db "Stage 2 corrupt!", 13, 10, 0

times 510-($-$$) db 0
dw 0xAA55
