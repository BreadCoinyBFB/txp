; ============================================================================
; memory.asm — BIOS memory detection (INT 15h, E820)
; ============================================================================
; Real mode only — must run in stage2 before the switch to protected mode.
;
; Fills an array of up to MEMORY_MAP_MAX_ENTRIES entries (24 bytes each:
; base:8, length:8, type:4, ACPI extended attributes:4) at MEMORY_MAP_ADDR,
; and stores how many were actually found at MEMORY_MAP_COUNT_ADDR.
;
; This is XLoader's hand-off to Kernel24: once Kernel24 exists, it reads this
; table to learn how much RAM exists and where, instead of re-detecting it.
; If a BIOS doesn't support E820 at all, this degrades gracefully — the
; count is left at 0, which Kernel24 can treat as "no memory map available".

; detect_memory
; Out:  [MEMORY_MAP_COUNT_ADDR] = number of entries found (may be 0)
;       [MEMORY_MAP_ADDR..]     = that many 24-byte SMAP entries
; Clobbers: nothing (all registers saved/restored)
detect_memory:
    pusha
    push es

    xor ax, ax
    mov es, ax
    mov di, MEMORY_MAP_ADDR
    xor ebx, ebx                       ; 0 = start enumeration from the beginning
    mov dword [MEMORY_MAP_COUNT_ADDR], 0

.loop:
    mov dword [es:di + 20], 0          ; in case this BIOS only writes a 20-byte
                                        ; entry (no extended attributes), make
                                        ; sure that field isn't stale garbage
    mov eax, 0xE820
    mov ecx, 24
    mov edx, 0x534D4150                ; 'SMAP' — required magic for this call
    int 0x15
    jc .done                           ; CF set: unsupported, or "no more entries"

    cmp eax, 0x534D4150                ; some BIOSes don't echo this back reliably,
    jne .done                          ; but when they do, it confirms a real entry

    inc dword [MEMORY_MAP_COUNT_ADDR]
    add di, 24

    cmp dword [MEMORY_MAP_COUNT_ADDR], MEMORY_MAP_MAX_ENTRIES
    jae .done                          ; safety cap against a misbehaving BIOS

    test ebx, ebx                      ; EBX = 0 means that was the last entry
    jnz .loop

.done:
    pop es
    popa
    ret
