; ============================================================================
; stage2.asm — loaded by stage1 at 0x8000; runs the rest of the boot process
; ============================================================================
; Real mode:      load Kernel24 off disk, enable A20, build/load the GDT
; -> Protected mode: relocate Kernel24 up to 1 MiB, then build page tables
; -> Long mode:      (see longmode.asm) jump straight into Kernel24
;
; This file is the orchestrator; the actual work lives in the %include'd
; modules so each piece can be read (and eventually replaced) on its own.

BITS 16
ORG 0x8000

jmp stage2_start   ; skip over the included library code (see stage1.asm for why)

%include "boot.inc"
%include "gdt.inc"
%include "screen.inc"
%include "disk.inc"
%include "loader.asm"
%include "a20.asm"
%include "memory.asm"
%include "bootinfo.asm"
%include "gdt.asm"
%include "debug.asm"

stage2_start:
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, STACK_TOP

    mov si, msg_stage2
    call print_string

    call enable_a20
    %ifdef DEBUG
        mov si, msg_a20_ok
        call print_string
    %endif
    jc .a20_error

    call kernel24_load_from_disk
    jc .disk_error

    call detect_memory     ; real mode only — must happen before protected mode
    call build_boot_info    ; needs the boot drive + memory map gathered above

    mov si, msg_pmode
    call print_string

    cli
    lgdt [gdt_descriptor]

    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp dword CODE32_SEG:protected_mode_entry

.a20_error:
    mov si, msg_a20_error
    call print_string
    jmp .hang

.disk_error:
    mov si, msg_disk_error
    call print_string
.hang:
    cli
    hlt
    jmp .hang

msg_stage2:     db "Stage 2", 13, 10, 0
msg_pmode:      db "Entering Protected Mode...", 13, 10, 0

%ifdef DEBUG
msg_a20_ok db "[DEBUG] A20 enabled",13,10,0
%endif
msg_disk_error: db "Disk error!", 13, 10, 0
msg_a20_error:  db "A20 line enable failed!", 13, 10, 0

BITS 32
protected_mode_entry:
    mov ax, DATA32_SEG
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x90000

    DEBUG_MARK 0, "PM1"    ; reached 32-bit code; segments/stack set

    call kernel24_relocate_high
    DEBUG_MARK 1, "PM2"    ; relocate returned

    call kernel24_verify        ; halts on its own if the magic/checksum don't match
    DEBUG_MARK 2, "PM3"    ; verify passed (didn't halt above)

    call enter_long_mode        ; never returns — ends by jumping into Kernel24

%include "longmode.asm"

; Stage2's own magic, checked by stage1 right after loading this file and
; before jumping in — see include/boot.inc for STAGE2_MAGIC. Placed as the
; last 4 bytes of stage2's reserved disk slot, mirroring how stage1 ends
; with its own 0xAA55 boot signature. If stage2 ever grows past its
; reserved slot, this `times` computation goes negative and NASM refuses to
; assemble — a loud build-time failure instead of a silently truncated image.
times (STAGE2_SECTORS * 512) - 4 - ($ - $$) db 0
dd STAGE2_MAGIC
