; ============================================================================
; a20.asm — enable the A20 line (real mode only)
; ============================================================================
; Without A20, address 0x100000 (1 MiB) aliases back to 0x000000, because
; the 21st address line is forced low for compatibility with the original
; 8086. We need addresses above 1 MiB (that's where Kernel24 lives), so this
; has to be fixed before anything up there can be trusted.
;
; Tries, in order, stopping as soon as a check confirms A20 is on:
;   1. Nothing — some BIOSes/emulators just leave it enabled already.
;   2. BIOS INT 15h, AX=2401h.
;   3. Fast A20 (port 0x92) — what most modern chipsets expect.
;   4. The legacy PS/2 keyboard controller dance.
; If all four leave it disabled, that's a fatal error: continuing would mean
; "loading Kernel24 at 1 MiB" silently corrupts address 0 (the IVT) instead.

; check_a20 — the classic wraparound test.
; Out: AX = 1 if enabled, 0 if disabled
; Clobbers: nothing (all registers saved/restored)
check_a20:
    pushf
    push ds
    push es
    push si
    push di
    cli

    xor ax, ax
    mov es, ax
    mov di, 0x0500          ; es:di = 0000:0500 = linear 0x000500

    mov ax, 0xFFFF
    mov ds, ax
    mov si, 0x0510          ; ds:si = FFFF:0510 = linear 0x100500 (wraps to
                            ; 0x000500 if A20 is off)

    mov al, [es:di]
    push ax                 ; save the real byte at 0x000500
    mov al, [ds:si]
    push ax                 ; save the real byte at 0x100500

    mov byte [es:di], 0x00
    mov byte [ds:si], 0xFF

    cmp byte [es:di], 0xFF  ; if 0x000500 picked up the write to 0x100500,
                            ; they're the same physical byte — A20 is off

    pop ax
    mov [ds:si], al         ; restore both original bytes before returning
    pop ax
    mov [es:di], al

    mov ax, 0
    je .done                ; equal => aliased => A20 disabled => return 0
    mov ax, 1
.done:
    pop di
    pop si
    pop es
    pop ds
    popf
    ret

; enable_a20 — tries each method in turn until check_a20 confirms success.
; Out: CF clear if A20 ends up enabled, CF set if every method failed
; Clobbers: AX (methods below also touch BX/CX briefly, but restore them)
enable_a20:
    call check_a20
    test ax, ax
    jnz .success

    ; Method 1: ask the BIOS.
    mov ax, 0x2401
    int 0x15
    call check_a20
    test ax, ax
    jnz .success

    ; Method 2: fast A20 via the system control port.
    in al, 0x92
    or al, 2
    out 0x92, al
    call check_a20
    test ax, ax
    jnz .success

    ; Method 3: the old PS/2 keyboard controller trick.
    push ax
    push bx
    call .kbc_wait_input_clear
    mov al, 0xAD                ; disable keyboard
    out 0x64, al

    call .kbc_wait_input_clear
    mov al, 0xD0                ; "read output port" command
    out 0x64, al
    call .kbc_wait_output_full
    in al, 0x60
    mov bl, al                  ; save the current output-port byte

    call .kbc_wait_input_clear
    mov al, 0xD1                ; "write output port" command
    out 0x64, al
    call .kbc_wait_input_clear
    mov al, bl
    or al, 2                    ; set the A20 gate bit
    out 0x60, al

    call .kbc_wait_input_clear
    mov al, 0xAE                ; re-enable keyboard
    out 0x64, al
    pop bx
    pop ax

    call check_a20
    test ax, ax
    jnz .success

    stc
    ret

.success:
    clc
    ret

.kbc_wait_input_clear:
    in al, 0x64
    test al, 2
    jnz .kbc_wait_input_clear
    ret
.kbc_wait_output_full:
    in al, 0x64
    test al, 1
    jz .kbc_wait_output_full
    ret
