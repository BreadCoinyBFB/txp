# resources/

Reserved for shell/UI assets — font/glyph data, color palettes for
`theme` (`shell/builtin/theme.cx` — not implemented yet, see that
file's own comment), that kind of thing. Nothing here yet because
nothing currently reads from disk at runtime at all (no filesystem —
see mX/README.md).
