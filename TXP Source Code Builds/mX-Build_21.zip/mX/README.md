Termux is needed to run mX and TXP

EARLY STAGE PLAN:

☑ Shell entry point
☑ Shell initialization
☑ Boot banner
☑ Version information
☑ Prompt system
☑ Input system
☑ Line buffer
☑ Parser framework
☑ Command registry
☑ Command dispatcher
☑ Basic error handling
☑ Shell loop
☑ Exit/restart framework
☑ Screen interface
☑ Keyboard interface

Kernel24
      │
      ▼
Keyboard Driver
      │
      ▼
Input System
      │
      ▼
Line Buffer
      │
      ▼
Parser
      │
      ▼
Dispatcher
      │
      ▼
(Commands come later)

---

STAGE 1 — Interactive Shell:

☑ Built-in command execution
☑ help command
☑ version command
☑ clear command
☑ echo command
☑ Basic command arguments
☑ Unknown command handling
☑ Command history
☑ Simple autocomplete (Tab)
☑ Basic shell settings
☑ Reboot command
☑ Shutdown command
☑ Stable shell loop

mX Shell
Powered by Kernel24

mX> help
Available commands:
help
version
clear
echo
reboot
shutdown

mX> version
mX 2026.9
Kernel24 1.0

mX> echo Hello TXP
Hello TXP

mX> unknown
Unknown command: unknown

mX>

help       - List available commands
version    - Show mX and Kernel24 version
clear      - Clear the screen
echo       - Print text
reboot     - Restart the system
shutdown   - Power off the system

---

STATUS: all 6 commands above are real (shell/builtin/*.cx), dispatched
by name from shell/command.cx — see that file's own comment for why
it's a plain if-chain rather than a lookup table (cX has no
function-pointer type, checked directly against the compiler, not
assumed). `help <command>` also works, giving the one-line description
shown above. Tab-completes command names when unambiguous; Up/Down
recall previous commands (shell/history.cx, 8 entries, oldest dropped
first — doesn't preserve whatever you were mid-typing before the first
Up press, see that file's comment). Both can be turned off in code via
shell/settings.cx, though nothing exposes that as a command yet.

reboot performs a real hardware reset (8042 keyboard-controller pulse).
shutdown halts the CPU forever rather than a real ACPI power-off — see
shell/builtin/shutdown.cx for why that's a deliberate, honest
simplification rather than an oversight.

Build: `make` from here (mX/), or `make run` for QEMU. Delegates to
XLoader/Makefile, which builds Kernel24 (mX's shell/init sources are
compiled into that same image — see XLoader/Kernel24/Makefile's header
comment for why) and assembles the bootable disk.

Verification note: everything here compiled clean through the real
compiler at XLoader/compiler/x86_64-elf-cxc (built from source and run
with --emit-asm — lexer through codegen, all real checks — for every
file in the tree, not just the ones touched this pass) in the
environment this was written in, which has no nasm and so can't run
the actual boot-test the rest of TXP has earned. Build and boot this
for real before trusting it that far.

NEXT: see the STAGE 2 section below.

---

STAGE 2:

☑ Better command parser (double-quoted strings — "like this" — as a
  single token; still no escaped quotes or single quotes)
☑ Multi-argument support (already true since Stage 1 — echo/set/prompt
  all exercise argv[1..])
☑ Quoted string parsing (see parser.cx — this is what makes `prompt
  "Kernel24>"` below actually work)
☐ Better error messages — colored + an unterminated-quote error are
  new; still just "usage: ..." text, no "did you mean" suggestions
☐ Command aliases — cls/clear and dir/ls/tree share a name-per-command
  registration, not a real user-definable alias system (no `alias`
  command exists)

New commands, all real except where noted "stub":
about, cls, exit, whoami, hostname, uname, date, time — real
pwd, dir, ls, tree, cd, mkdir — stub (no filesystem yet)
set, get — real, but only for the two settings that exist
  (autocomplete, history — shell/settings.cx)
theme — stub (needs a real color-scheme system)
history, history clear — real (shell/history.cx already had the data;
  this is the command surface for it)
sysinfo, meminfo, cpuinfo — real (E820 total memory, PMM stats, CPUID
  vendor string respectively — see each file's own comment)
run, exec — stub, exactly "Stage 3 feature." as requested, to
  establish the Shell API surface now
prompt "text" — real, backed by a genuine mutable buffer
  (shell/prompt.cx), not just re-printing the argument once

☐ Up/Down history, Tab autocomplete — already existed since Stage 1,
  not re-done
☐ Left/Right cursor movement — NOT done. The line editor
  (shell/input.cx) only supports appending/backspacing at the end of
  the line; inserting mid-line needs shifting buffer contents and
  redrawing part of the line, which is real complexity to get right
  with no way to test it by actually running it. Deferred rather than
  guessed at.
☐ Backspace improvements — unclear what beyond current behavior was
  wanted; deferred alongside cursor movement since they're related
☑ Colored errors ("Unknown command", unterminated quote — both light
  red now)
☐ Colored success messages — not done; no clear signal yet for what
  counts as "success" worth coloring beyond a command just not erroring
☐ theme / colored prompt — see theme.cx stub above

bin/, system/, apps/, resources/ each got a short README explaining
what they're reserved for and why they're still otherwise empty —
see each folder.

IMPORTANT: this was all written and compile-verified without a
confirmed-working Stage 1 boot to build on — see the top of this
round's conversation. If Stage 1 turns out not to have been fully
working, some of Stage 2's assumptions about existing behavior (the
prompt loop, argc/argv, history storage) may need re-checking against
whatever the real cause turns out to be.


---

STAGE 3:

☑ Process management -- process/task.cx (PIDs, a 16-task table,
  creation, termination) + process/scheduler.cx (round-robin,
  preemptive, driven by the PIT timer)
☑ Context switching -- arch/x86_64/interrupts/isr_stubs.asm's shared
  ISR stub hands back a stack pointer instead of always resuming the
  same one; see that file's comment for the mechanism (no inline asm
  needed in any cX file to make it work)
☑ Memory management improvements -- PTE_USER, per-process address
  spaces (memory/virtual.cx's vmm_new_address_space), sharing the
  kernel's own mapping while keeping user pages private
☑ System-call interface -- int 0x80, dispatched by vector like any
  other interrupt (arch/x86_64/interrupts/syscall.cx). Seven numbers:
  output, input, alloc, free, getpid, exit, yield
☑ Filesystem foundation -- fs/vfs.cx: 32 inodes, file handles, path
  resolution, open/read/write/close/mkdir/unlink, sitting on
  drivers/storage/ramdisk.cx's real (if RAM-backed) four-function
  storage-driver interface
☑ Hardware/device layer -- PIC remap + PIT timer (new), keyboard
  driver moved out of shell/ into Kernel24's own drivers/ and made
  IRQ-driven instead of polling, serial (COM1) output (new)
☑ Basic system security model -- Kernel24's own GDT/TSS
  (arch/x86_64/gdt/gdt.cx), a DPL=3 syscall gate, and real process
  isolation: a CPU exception inside a user task now kills that task
  instead of halting the kernel (arch/x86_64/interrupts/isr.cx)
☑ Userspace foundation -- the kernel/user split is real at the GDT
  and paging level; nothing launches at ring 3 by default yet, since
  there's still no on-disk loader to point it at (see
  XLoader/Kernel24/docs/design.md)
☑ Developer tooling -- `make cx-check` (XLoader/Kernel24/Makefile),
  a real kernel-debugging register dump on any unhandled exception
  (arch/x86_64/interrupts/isr.cx's dump_registers)

New commands, all real:
run, exec -- no longer stubs: launch one of a small fixed set of
  kernel-known programs (process/demo_tasks.cx) as a real task; run
  returns immediately, exec waits for it to finish
pwd, dir, ls, tree, cd, mkdir -- no longer stubs: real against
  fs/vfs.cx's in-memory filesystem
uptime -- no longer a stub: real seconds since drivers/timer/timer.cx
  initialized, now that there's a tick source
ps -- lists every live task
kill <pid> -- terminates a task
cat, touch, write, rm -- basic file operations against fs/vfs.cx
sysdemo -- exercises SYS_GETPID/SYS_WRITE/SYS_ALLOC/SYS_FREE directly
  from the shell's own context, proving the syscall gate round-trips
  correctly with no background task needed

help was quietly out of date since Stage 1 -- it only ever listed the
original 6 commands even after Stage 2 added ~25 more. Every
registered command has an entry now (shell/builtin/help.cx).

Verification note, same shape as Stage 1 and 2's: every .cx file --
new and modified both -- compiles clean through the real
x86_64-elf-cxc, lexing through IR/assembly generation, via the new
`make cx-check` target (72 files). The modified/new .asm
(lowlevel.asm's additions, isr_stubs.asm's context-switch diff,
process/entry_stubs.asm) was written and re-read carefully but not
assembled -- this environment still has no nasm (a from-source build
against the archive in XLoader/tools/archives/ was attempted and
abandoned; it needs autoconf/autoheader to generate configure/
config.h, neither available here). The GDT/TSS byte layout
(arch/x86_64/gdt/gdt.cx) and the saved-frame layout the context switch
depends on staying consistent across isr_stubs.asm/process/task.cx are
the two places most worth double-checking before trusting this the way
Stage 1's actual boot-test earned. See
XLoader/Kernel24/docs/roadmap.md's Stage 3 section for the full,
file-by-file breakdown, including what's explicitly still not done.
