# apps/

Reserved for user applications, loaded from disk once there's a real
executable loader to put here.

Stage 3 made `run`/`exec` (`shell/builtin/run.cx`, `exec.cx`) real —
they create and schedule a genuine task (`XLoader/Kernel24/process/
task.cx`) — but only for a small, fixed set of programs the kernel
already knows about (`XLoader/Kernel24/process/demo_tasks.cx`), not
anything loaded from here. That needs `fs/vfs.cx` (a filesystem
*foundation*, not a complete one yet) plus an actual loader neither of
which exists. This is still where that would attach.
