; ============================================================================
; kernel/loader.asm — loads Kernel24 into memory
; ============================================================================
; Split into two routines because of *when* each part can run:
;
;   kernel24_load_from_disk  — real mode only (BIOS INT 13h calls only work
;                               in real mode), reads Kernel24's sectors off
;                               disk into a low staging buffer.
;
;   kernel24_relocate_high   — 32-bit protected mode only (needs unrestricted
;                               32-bit addressing to reach 1 MiB+), copies the
;                               staged bytes up to their final home.
;
; Reads and relocates whatever KERNEL24_SECTORS worth of bytes sit at
; KERNEL24_LBA on disk — a real Kernel24 image today (see ../Kernel24/),
; built and checksummed by its own Makefile, copied into place by
; XLoader's top-level Makefile. kernel24_verify (below) is what actually
; confirms it's real and intact before jumping in.

; kernel24_load_from_disk — real mode.
; Reads KERNEL24_SECTORS sectors starting at KERNEL24_LBA into
; KERNEL24_STAGE_SEG:KERNEL24_STAGE_OFF, chunked to at most
; MAX_SECTORS_PER_READ sectors per BIOS call rather than one single
; 128-sector (64 KiB) request — see include/disk.inc's own comment on
; read_sectors for why that size isn't trusted as a single transfer.
; Each chunk lands at offset 0 of its own advancing segment (rather than
; a fixed segment with a growing offset), which sidesteps needing a
; 32-bit offset in real mode entirely.
; Out: CF set on error
; Clobbers: AX, BX, CX, DX, EAX, ES (SI is saved/restored)
kernel24_load_from_disk:
    push si
    mov si, msg_loading_kernel
    call print_string

    push es
    mov word [.remaining], KERNEL24_SECTORS
    mov dword [.next_lba], KERNEL24_LBA
    mov word [.dest_seg], KERNEL24_STAGE_SEG

.chunk_loop:
    mov cx, [.remaining]
    cmp cx, 0
    je .success
    cmp cx, MAX_SECTORS_PER_READ
    jbe .count_ready
    mov cx, MAX_SECTORS_PER_READ
.count_ready:

    mov ax, [.dest_seg]
    mov es, ax
    mov bx, KERNEL24_STAGE_OFF
    mov eax, [.next_lba]
    mov dl, [BOOT_DRIVE_ADDR]
    call read_sectors
    jc .fail

    sub word [.remaining], cx
    movzx eax, cx
    add [.next_lba], eax

    mov ax, cx
    shl ax, 5                   ; sectors just read * 32 = paragraphs (512B = 32 paragraphs)
    add [.dest_seg], ax

    jmp .chunk_loop

.success:
    pop es
    pop si
    clc
    ret
.fail:
    pop es
    pop si
    stc
    ret

.remaining: dw 0
.next_lba:  dd 0
.dest_seg:  dw 0

; kernel24_relocate_high — 32-bit protected mode.
; Copies KERNEL24_SECTORS*512 bytes from the real-mode staging buffer
; (linear KERNEL24_STAGE_SEG*16 + KERNEL24_STAGE_OFF) up to
; KERNEL24_LOAD_ADDR, where the eventual jump into Kernel24 expects to find it.
; Clobbers: ESI, EDI, ECX
;
; NOTE: this file is %include'd from stage2.asm while NASM is still under
; that file's `BITS 16` (the switch to `BITS 32` happens later, textually,
; in stage2.asm itself). Without bracketing this routine explicitly, NASM
; would encode its 32-bit register operations with 16-bit operand-size
; prefixes — valid bytes, but exactly backwards once the CPU is actually
; running in 32-bit protected mode at call time.
BITS 32
kernel24_relocate_high:
    mov esi, (KERNEL24_STAGE_SEG << 4) + KERNEL24_STAGE_OFF
    mov edi, KERNEL24_LOAD_ADDR
    mov ecx, (KERNEL24_SECTORS * 512) / 4   ; copy as dwords
    cld
    rep movsd
    ret
BITS 16

; kernel24_verify — 32-bit protected mode.
; Checks that Kernel24's magic and checksum both made it across the
; load+relocate intact. On success, returns normally. On failure, there's no
; BIOS left to print through (no IDT is set up yet for a real-mode-style
; interrupt, and INT 10h isn't callable from protected mode anyway) — so
; this writes straight to the VGA text buffer itself, then halts for good.
; Clobbers: none on success; does not return on failure
BITS 32
kernel24_verify:
    cmp dword [KERNEL24_LOAD_ADDR], KERNEL24_MAGIC
    jne .bad_magic

    ; Recompute the checksum over the payload (everything past the 8-byte
    ; header) and compare against the value tools/patch_checksum.py baked
    ; into the image at build time. This catches truncation or bit-flips
    ; that a magic-number check alone would miss.
    xor eax, eax                              ; running sum
    mov esi, KERNEL24_LOAD_ADDR + 8
    mov ecx, (KERNEL24_SECTORS * 512) - 8
.sum_loop:
    movzx edx, byte [esi]
    add eax, edx
    inc esi
    loop .sum_loop

    cmp eax, [KERNEL24_LOAD_ADDR + 4]
    jne .bad_checksum
    ret

.bad_magic:
    mov esi, .msg_bad_magic
    jmp .report
.bad_checksum:
    mov esi, .msg_bad_checksum
.report:
    mov edi, 0xB8000
.print:
    mov al, [esi]
    cmp al, 0
    je .halt
    mov [edi], al
    mov byte [edi + 1], 0x4F      ; white on red — unmistakably an error
    add esi, 1
    add edi, 2
    jmp .print
.halt:
    cli
    hlt
    jmp .halt
.msg_bad_magic:    db "KERNEL24 BAD MAGIC", 0
.msg_bad_checksum: db "KERNEL24 BAD CHECKSUM", 0
BITS 16

msg_loading_kernel: db "Loading Kernel24...", 13, 10, 0
