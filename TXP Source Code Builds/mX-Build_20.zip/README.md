Termux is needed to run mX and TXP

EARLY STAGE PLAN:

☑ Shell entry point
☑ Shell initialization
☑ Boot banner
☑ Version information
☑ Prompt system
☑ Input system
☑ Line buffer
☑ Parser framework
☑ Command registry
☑ Command dispatcher
☑ Basic error handling
☑ Shell loop
☑ Exit/restart framework
☑ Screen interface
☑ Keyboard interface

Kernel24
      │
      ▼
Keyboard Driver
      │
      ▼
Input System
      │
      ▼
Line Buffer
      │
      ▼
Parser
      │
      ▼
Dispatcher
      │
      ▼
(Commands come later)

---

STAGE 1 — Interactive Shell:

☑ Built-in command execution
☑ help command
☑ version command
☑ clear command
☑ echo command
☑ Basic command arguments
☑ Unknown command handling
☑ Command history
☑ Simple autocomplete (Tab)
☑ Basic shell settings
☑ Reboot command
☑ Shutdown command
☑ Stable shell loop

mX Shell
Powered by Kernel24

mX> help
Available commands:
help
version
clear
echo
reboot
shutdown

mX> version
mX 2026.9
Kernel24 1.0

mX> echo Hello TXP
Hello TXP

mX> unknown
Unknown command: unknown

mX>

help       - List available commands
version    - Show mX and Kernel24 version
clear      - Clear the screen
echo       - Print text
reboot     - Restart the system
shutdown   - Power off the system

---

STATUS: all 6 commands above are real (shell/builtin/*.cx), dispatched
by name from shell/command.cx — see that file's own comment for why
it's a plain if-chain rather than a lookup table (cX has no
function-pointer type, checked directly against the compiler, not
assumed). `help <command>` also works, giving the one-line description
shown above. Tab-completes command names when unambiguous; Up/Down
recall previous commands (shell/history.cx, 8 entries, oldest dropped
first — doesn't preserve whatever you were mid-typing before the first
Up press, see that file's comment). Both can be turned off in code via
shell/settings.cx, though nothing exposes that as a command yet.

reboot performs a real hardware reset (8042 keyboard-controller pulse).
shutdown halts the CPU forever rather than a real ACPI power-off — see
shell/builtin/shutdown.cx for why that's a deliberate, honest
simplification rather than an oversight.

Build: `make` from here (mX/), or `make run` for QEMU. Delegates to
XLoader/Makefile, which builds Kernel24 (mX's shell/init sources are
compiled into that same image — see XLoader/Kernel24/Makefile's header
comment for why) and assembles the bootable disk.

Verification note: everything here compiled clean through the real
compiler at XLoader/compiler/x86_64-elf-cxc (built from source and run
with --emit-asm — lexer through codegen, all real checks — for every
file in the tree, not just the ones touched this pass) in the
environment this was written in, which has no nasm and so can't run
the actual boot-test the rest of TXP has earned. Build and boot this
for real before trusting it that far.

NEXT: see the STAGE 2 section below.

---

STAGE 2:

☑ Better command parser (double-quoted strings — "like this" — as a
  single token; still no escaped quotes or single quotes)
☑ Multi-argument support (already true since Stage 1 — echo/set/prompt
  all exercise argv[1..])
☑ Quoted string parsing (see parser.cx — this is what makes `prompt
  "Kernel24>"` below actually work)
☐ Better error messages — colored + an unterminated-quote error are
  new; still just "usage: ..." text, no "did you mean" suggestions
☐ Command aliases — cls/clear and dir/ls/tree share a name-per-command
  registration, not a real user-definable alias system (no `alias`
  command exists)

New commands, all real except where noted "stub":
about, cls, exit, whoami, hostname, uname, date, time — real
pwd, dir, ls, tree, cd, mkdir — backed by the Stage 3 RAM VFS
set, get — real, but only for the two settings that exist
  (autocomplete, history — shell/settings.cx)
theme — stub (needs a real color-scheme system)
history, history clear — real (shell/history.cx already had the data;
  this is the command surface for it)
sysinfo, meminfo, cpuinfo — real (E820 total memory, PMM stats, CPUID
  vendor string respectively — see each file's own comment)
run, exec — create Stage 3 kernel/userspace task records, with external program loading deferred to
  establish the Shell API surface now
prompt "text" — real, backed by a genuine mutable buffer
  (shell/prompt.cx), not just re-printing the argument once

☐ Up/Down history, Tab autocomplete — already existed since Stage 1,
  not re-done
☐ Left/Right cursor movement — NOT done. The line editor
  (shell/input.cx) only supports appending/backspacing at the end of
  the line; inserting mid-line needs shifting buffer contents and
  redrawing part of the line, which is real complexity to get right
  with no way to test it by actually running it. Deferred rather than
  guessed at.
☐ Backspace improvements — unclear what beyond current behavior was
  wanted; deferred alongside cursor movement since they're related
☑ Colored errors ("Unknown command", unterminated quote — both light
  red now)
☐ Colored success messages — not done; no clear signal yet for what
  counts as "success" worth coloring beyond a command just not erroring
☐ theme / colored prompt — see theme.cx stub above

bin/, system/, apps/, resources/ each got a short README explaining
what they're reserved for and why they're still otherwise empty —
see each folder.

IMPORTANT: this was all written and compile-verified without a
confirmed-working Stage 1 boot to build on — see the top of this
round's conversation. If Stage 1 turns out not to have been fully
working, some of Stage 3's assumptions about existing behavior (the
prompt loop, argc/argv, history storage) may need re-checking against
whatever the real cause turns out to be.
