# mX Stage 3 — System Foundation

Stage 3 is implemented in this tree while preserving the traditional five-step workflow.

## Implemented
- Process/task table, PIDs, states, creation/termination, cooperative scheduler and context-switch assembly groundwork.
- Hardened kernel heap plus per-task address-space roots.
- `int 0x80` system-call ABI with output/input/allocation/process interfaces.
- RAM-backed VFS with nodes, handles, paths, open/read/write/close APIs and directory representation.
- Device registry, PIT timer/IRQ0 and serial/storage driver interfaces.
- Kernel/user privilege bookkeeping, user-range validation and protected syscall entry (DPL3 gate).
- Userspace process-record boundary for future native cX/ELF loading.
- Kernel diagnostics and linker dead-code collection for smaller freestanding images.
- New shell commands: `ps`, `kill`; existing filesystem commands now use the VFS; `run` and `exec` create task records.

## Intentionally deferred
The external ELF/cX program loader, fully populated ring-3 process launch, disk filesystem driver, and fully preemptive context switching remain later work. Stage 3 establishes their interfaces without pretending those later layers already exist.

## Canonical five-step workflow
1. `cd ~/mX`
2. `rm -rf XLoader/build XLoader/Kernel24/build`
3. `make`
4. Run the existing 131072-byte checksum verification command against `XLoader/build/disk.img`
5. `make run`

These steps are intentionally unchanged.
