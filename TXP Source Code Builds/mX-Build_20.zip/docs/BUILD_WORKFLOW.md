# mX traditional build/run workflow

1. `cd ~/mX`
2. `rm -rf XLoader/build XLoader/Kernel24/build`
3. `make`
4. checksum verification of `XLoader/build/disk.img`
5. `make run`

Stage 3 changes integrate with this workflow rather than replacing it.
