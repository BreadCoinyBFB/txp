# apps/

Reserved for user applications, once `run`/`exec`
(`shell/builtin/run.cx`, `exec.cx`) do more than print "Stage 3
feature." — those two commands exist now specifically to establish
where an app-loading API will attach later, without needing a new
command name invented once there's something real to load.
