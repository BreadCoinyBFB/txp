; context.asm — Stage 3 context-switch groundwork.
; Saves/restores the System V callee-saved register set and switches RSP.
; A new task must provide a stack frame compatible with this routine before
; scheduler_yield is allowed to enter it.
BITS 64
section .text

global context_switch
context_switch:
    push rbp
    push rbx
    push r12
    push r13
    push r14
    push r15
    mov [rdi], rsp
    mov rsp, rsi
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbx
    pop rbp
    ret

; Exposed as a symbol so a later task bootstrap can use one stable entry
; address without teaching cX about function-pointer values yet.
global task_context_entry
task_context_entry:
    ret

section .note.GNU-stack noalloc noexec nowrite progbits
