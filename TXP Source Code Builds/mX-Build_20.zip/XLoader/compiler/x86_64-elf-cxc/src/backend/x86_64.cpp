// x86_64.cpp — lowers ir::Module to x86-64 assembly text (NASM syntax,
// ELF64-target). See README.md for why this backend emits assembly
// rather than hand-encoded machine code bytes directly: nasm (already
// used throughout this project and independently verified) becomes the
// actual instruction encoder, which is a substantially safer bet than a
// hand-rolled encoder for a first native backend.
//
// Every value lives in its own 8-byte stack slot (see ir.hpp's opening
// comment) — this file's whole job, for almost every IR instruction, is
// "load operand(s) from their slot(s) into a scratch register, compute,
// store the result back to the destination's slot." Two scratch
// registers (RAX, RCX — see registers.hpp) are enough because no value
// is ever live across more than one IR instruction in registers; RDX is
// used only transiently for division/shift, never across instruction
// boundaries either.
#include "../ir/ir.hpp"
#include "registers.hpp"
#include "x86_64.hpp"
#include <sstream>
#include <unordered_map>

namespace cx::backend {

using namespace cx::ir;

namespace {

// Every local gets a uniform 8-byte slot regardless of its declared
// type's actual size — simple, and correct: Load/Store instructions
// always specify their own memory width explicitly (see ir.cpp), so nothing
// depends on a slot being exactly as wide as the value it represents.
int slotOffset(int index) { return -8 * (index + 1); }

int frameSize(size_t localCount) {
    int raw = 8 * (int)localCount;
    return (raw + 15) / 16 * 16;  // round up to 16 — see the alignment note below
}

const char* sizeKeyword(int size) {
    switch (size) {
        case 1: return "byte";
        case 2: return "word";
        case 4: return "dword";
        default: return "qword";
    }
}

class FuncEmitter {
public:
    FuncEmitter(std::ostream& out, const Function& fn) : out_(out), fn_(fn) {}

    void emit() {
        out_ << "global " << fn_.name << "\n";
        out_ << fn_.name << ":\n";
        out_ << "    push rbp\n    mov rbp, rsp\n";
        int fsize = frameSize(fn_.locals.size());
        if (fsize > 0) out_ << "    sub rsp, " << fsize << "\n";

        // Spill incoming register arguments into their slots.
        for (int i = 0; i < fn_.paramCount && i < 6; i++) {
            out_ << "    mov [rbp" << slotOffset(i) << "], " << kArgRegs64[i] << "\n";
        }

        for (auto& instr : fn_.code) emitInstr(instr);
    }

private:
    std::ostream& out_;
    const Function& fn_;

    std::string slot(VReg v) {
        int off = slotOffset(v);
        return "[rbp" + (off >= 0 ? "+" + std::to_string(off) : std::to_string(off)) + "]";
    }

    void loadA(VReg v) { out_ << "    mov rax, " << slot(v) << "\n"; }
    void loadB(VReg v) { out_ << "    mov rcx, " << slot(v) << "\n"; }
    void storeA(VReg dst) { out_ << "    mov " << slot(dst) << ", rax\n"; }

    void epilogue() { out_ << "    mov rsp, rbp\n    pop rbp\n    ret\n"; }

    void emitInstr(const Instr& i) {
        switch (i.op) {
        case Op::ConstI:
            out_ << "    mov rax, " << i.imm << "\n";
            storeA(i.dst);
            return;
        case Op::AddrLocal: {
            int off = slotOffset((int)i.imm);
            out_ << "    lea rax, [rbp" << (off >= 0 ? "+" : "") << off << "]\n";
            storeA(i.dst);
            return;
        }
        case Op::AddrGlobal:
            out_ << "    lea rax, [rel " << i.symbol << "]\n";
            storeA(i.dst);
            return;
        case Op::AddrString:
            out_ << "    lea rax, [rel __cx_str" << i.imm << "]\n";
            storeA(i.dst);
            return;
        case Op::Load: {
            loadA(i.lhs); // address
            const char* sk = sizeKeyword(i.size);
            if (i.size == 8) {
                out_ << "    mov rax, [rax]\n";
            } else if (i.isUnsigned) {
                if (i.size == 4) out_ << "    mov eax, [rax]\n"; // auto zero-extends to rax
                else out_ << "    movzx rax, " << sk << " [rax]\n";
            } else {
                out_ << "    movsx rax, " << sk << " [rax]\n";
            }
            storeA(i.dst);
            return;
        }
        case Op::Store: {
            loadA(i.lhs);  // address -> rax
            loadB(i.rhs);  // value -> rcx
            const char* sk = sizeKeyword(i.size);
            const char* r = i.size == 1 ? kScratchB8 : i.size == 8 ? kScratchB64 : "ecx";
            out_ << "    mov " << sk << " [rax], " << r << "\n";
            return;
        }
        case Op::Move:
            loadA(i.lhs); storeA(i.dst); return;

        case Op::Add: binop(i, "add"); return;
        case Op::Sub: binop(i, "sub"); return;
        case Op::Mul:
            loadA(i.lhs); loadB(i.rhs);
            out_ << "    imul rax, rcx\n"; storeA(i.dst); return;
        case Op::SDiv:
            loadA(i.lhs); loadB(i.rhs);
            out_ << "    cqo\n    idiv rcx\n"; storeA(i.dst); return;
        case Op::SMod:
            loadA(i.lhs); loadB(i.rhs);
            out_ << "    cqo\n    idiv rcx\n    mov rax, rdx\n"; storeA(i.dst); return;
        case Op::BAnd: binop(i, "and"); return;
        case Op::BOr: binop(i, "or"); return;
        case Op::BXor: binop(i, "xor"); return;
        case Op::Shl:
            loadA(i.lhs); out_ << "    mov rcx, " << slot(i.rhs) << "\n    shl rax, cl\n";
            storeA(i.dst); return;
        case Op::Shr:
            loadA(i.lhs); out_ << "    mov rcx, " << slot(i.rhs) << "\n    sar rax, cl\n";
            storeA(i.dst); return;

        case Op::CmpEq: cmp(i, "sete"); return;
        case Op::CmpNe: cmp(i, "setne"); return;
        case Op::CmpLt: cmp(i, "setl"); return;
        case Op::CmpLe: cmp(i, "setle"); return;
        case Op::CmpGt: cmp(i, "setg"); return;
        case Op::CmpGe: cmp(i, "setge"); return;

        case Op::Neg: loadA(i.lhs); out_ << "    neg rax\n"; storeA(i.dst); return;
        case Op::LNot:
            loadA(i.lhs);
            out_ << "    test rax, rax\n    sete al\n    movzx rax, al\n";
            storeA(i.dst); return;
        case Op::BNot: loadA(i.lhs); out_ << "    not rax\n"; storeA(i.dst); return;

        case Op::SextTo64:
            loadA(i.lhs);
            // Defensively re-derive the extension from just the low
            // `size` bytes already in RAX, regardless of what (if
            // anything) was already in the higher bytes — see ir.cpp's
            // emitCast comment for why this is belt-and-suspenders
            // rather than strictly required.
            if (i.size == 1) out_ << "    movsx rax, al\n";
            else if (i.size == 2) out_ << "    movsx rax, ax\n";
            else if (i.size == 4) out_ << "    movsxd rax, eax\n";
            storeA(i.dst); return;
        case Op::ZextTo64:
            loadA(i.lhs);
            if (i.size == 1) out_ << "    movzx rax, al\n";
            else if (i.size == 2) out_ << "    movzx rax, ax\n";
            else if (i.size == 4) out_ << "    mov eax, eax\n"; // zero-extends into rax
            storeA(i.dst); return;

        case Op::Label: out_ << i.symbol << ":\n"; return;
        case Op::Jump: out_ << "    jmp near " << i.symbol << "\n"; return;
        case Op::JumpIfZero:
            loadA(i.lhs); out_ << "    test rax, rax\n    jz near " << i.symbol << "\n"; return;
        case Op::JumpIfNotZero:
            loadA(i.lhs); out_ << "    test rax, rax\n    jnz near " << i.symbol << "\n"; return;

        case Op::Call: {
            for (size_t a = 0; a < i.args.size(); a++) {
                out_ << "    mov " << kArgRegs64[a] << ", " << slot(i.args[a]) << "\n";
            }
            out_ << "    call " << i.symbol << "\n";
            if (i.hasDst) storeA(i.dst);
            return;
        }
        case Op::Ret:
            if (i.hasDst) loadA(i.lhs);
            epilogue();
            return;
        }
    }

    void binop(const Instr& i, const char* mnemonic) {
        loadA(i.lhs); loadB(i.rhs);
        out_ << "    " << mnemonic << " rax, rcx\n";
        storeA(i.dst);
    }
    void cmp(const Instr& i, const char* setcc) {
        loadA(i.lhs); loadB(i.rhs);
        out_ << "    cmp rax, rcx\n    " << setcc << " al\n    movzx rax, al\n";
        storeA(i.dst);
    }
};

} // namespace

// Emits a complete NASM-syntax translation unit for `mod` to `out`.
void emitAssembly(const Module& mod, std::ostream& out) {
    out << "; Generated by x86_64-elf-cxc — do not edit by hand.\n";
    out << "BITS 64\n\n";

    for (auto& fn : mod.functions) {
        if (fn.isExtern) { out << "extern " << fn.name << "\n"; }
    }
    out << "\n";
    for (auto& fn : mod.functions) {
        if (fn.isExtern) continue;
        // One section per function lets the freestanding linker garbage-
        // collect unused helper APIs. This is especially important for the
        // growing Kernel24/cX surface: every translation unit exposes a
        // localized main plus many APIs, but only reachable functions need
        // to occupy the boot image.
        out << "section .text." << fn.name << "\n";
        FuncEmitter(out, fn).emit();
        out << "\n";
    }

    if (!mod.strings.empty()) {
        out << "section .rodata\n";
        for (size_t idx = 0; idx < mod.strings.size(); idx++) {
            out << "__cx_str" << idx << ": db ";
            const std::string& s = mod.strings[idx];
            if (s.empty()) {
                out << "0\n";
            } else {
                for (unsigned char c : s) out << (int)c << ",";
                out << "0\n";
            }
        }
        out << "\n";
    }

    bool anyData = false, anyBss = false;
    for (auto& g : mod.globals) {
        if (g.isExtern) continue;
        if (g.hasInit) anyData = true; else anyBss = true;
    }
    for (auto& g : mod.globals) if (g.isExtern) out << "extern " << g.name << "\n";

    if (anyData) {
        out << "\nsection .data\n";
        for (auto& g : mod.globals) {
            if (g.isExtern || !g.hasInit) continue;
            out << "global " << g.name << "\n" << g.name << ": ";
            if (g.size == 1) out << "db " << g.initValue << "\n";
            else if (g.size == 2) out << "dw " << g.initValue << "\n";
            else if (g.size == 4) out << "dd " << g.initValue << "\n";
            else out << "dq " << g.initValue << "\n";
        }
    }
    if (anyBss) {
        out << "\nsection .bss\n";
        for (auto& g : mod.globals) {
            if (g.isExtern || g.hasInit) continue;
            out << "global " << g.name << "\n" << g.name << ": resb " << g.size << "\n";
        }
    }

    out << "\nsection .note.GNU-stack noalloc noexec nowrite progbits\n";
}

} // namespace cx::backend
