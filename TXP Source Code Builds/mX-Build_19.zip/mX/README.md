Termux is needed to run mX and TXP

EARLY STAGE PLAN:

☑ Shell entry point
☑ Shell initialization
☑ Boot banner
☑ Version information
☑ Prompt system
☑ Input system
☑ Line buffer
☑ Parser framework
☑ Command registry
☑ Command dispatcher
☑ Basic error handling
☑ Shell loop
☑ Exit/restart framework
☑ Screen interface
☑ Keyboard interface

Kernel24
      │
      ▼
Keyboard Driver
      │
      ▼
Input System
      │
      ▼
Line Buffer
      │
      ▼
Parser
      │
      ▼
Dispatcher
      │
      ▼
(Commands come later)

---

STAGE 1 — Interactive Shell:

☑ Built-in command execution
☑ help command
☑ version command
☑ clear command
☑ echo command
☑ Basic command arguments
☑ Unknown command handling
☑ Command history
☑ Simple autocomplete (Tab)
☑ Basic shell settings
☑ Reboot command
☑ Shutdown command
☑ Stable shell loop

mX Shell
Powered by Kernel24

mX> help
Available commands:
help
version
clear
echo
reboot
shutdown

mX> version
mX 2026.9
Kernel24 1.0

mX> echo Hello TXP
Hello TXP

mX> unknown
Unknown command: unknown

mX>

help       - List available commands
version    - Show mX and Kernel24 version
clear      - Clear the screen
echo       - Print text
reboot     - Restart the system
shutdown   - Power off the system

---

STATUS: all 6 commands above are real (shell/builtin/*.cx), dispatched
by name from shell/command.cx — see that file's own comment for why
it's a plain if-chain rather than a lookup table (cX has no
function-pointer type, checked directly against the compiler, not
assumed). `help <command>` also works, giving the one-line description
shown above. Tab-completes command names when unambiguous; Up/Down
recall previous commands (shell/history.cx, 8 entries, oldest dropped
first — doesn't preserve whatever you were mid-typing before the first
Up press, see that file's comment). Both can be turned off in code via
shell/settings.cx, though nothing exposes that as a command yet.

reboot performs a real hardware reset (8042 keyboard-controller pulse).
shutdown halts the CPU forever rather than a real ACPI power-off — see
shell/builtin/shutdown.cx for why that's a deliberate, honest
simplification rather than an oversight.

Build: `make` from here (mX/), or `make run` for QEMU. Delegates to
XLoader/Makefile, which builds Kernel24 (mX's shell/init sources are
compiled into that same image — see XLoader/Kernel24/Makefile's header
comment for why) and assembles the bootable disk.

Verification note: everything here compiled clean through the real
compiler at XLoader/compiler/x86_64-elf-cxc (built from source and run
with --emit-asm — lexer through codegen, all real checks — for every
file in the tree, not just the ones touched this pass) in the
environment this was written in, which has no nasm and so can't run
the actual boot-test the rest of TXP has earned. Build and boot this
for real before trusting it that far.

NEXT: shell/builtin/meminfo.cx and cpuinfo.cx (still empty — not part
of Stage 1's six commands), then whatever Stage 2 turns out to be.
