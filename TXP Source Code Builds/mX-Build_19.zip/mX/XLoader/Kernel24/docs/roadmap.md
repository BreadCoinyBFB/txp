# Kernel24 roadmap

## Early stage ✅

- [x] Receive control from XLoader — `boot/entry.asm` (`_start`, entered
      via computed jump at exactly `0x100008`)
- [x] Read BootInfo from XLoader — `kernel/bootinfo.cx`
- [x] Initialize the kernel environment — `boot/entry.asm` zeroes `.bss`
      and switches to a real kernel stack before anything else runs
- [x] Print "Kernel24 v0.1" — `kernel/main.cx`, version numbers from
      `kernel/version.cx`
- [x] Verify CPU is in 64-bit Long Mode — `arch/x86_64/lowlevel.asm`'s
      `cpu_verify_long_mode` (one `cpuid` check, one `EFER.LMA` read —
      see the file for why it's kept to exactly that and no more)
- [x] Initialize a basic screen output — `drivers/screen/screen.cx` (VGA
      text mode: clear, print, scroll, color, hex/decimal number printing)
- [x] Initialize a basic physical memory manager — `memory/physical.cx`,
      bitmap allocator seeded from the E820 map, math from `memory/align.cx`
- [x] Initialize interrupt handling — `arch/x86_64/idt/idt.cx` +
      `arch/x86_64/interrupts/` (all 256 vectors wired up; "empty" in the
      sense of no recovery logic, but each one reports clearly and halts
      rather than silently falling through)
- [x] Enter the kernel main loop — `kernel/main.cx` (`while (true) { cx_hlt(); }`)

Verified the same way as XLoader: actually built (cxc → x86_64-elf-gcc →
nasm → ld → objcopy → patch_checksum.py) and disassembled, not just
reviewed. That process caught one real bug worth naming —
`linker.ld`'s original `.header`/`.text` split let `.text`'s inherited
16-byte alignment push `_start` to load-address+0x10 instead of the
required +8, which would have made XLoader's computed jump land 8 bytes
into the middle of `_start`'s own instructions. Fixed by merging the
header into `.text` directly (see `linker.ld`'s comment).

There is no hand-written C anywhere in this tree anymore — every kernel
logic file above is `.cx`; only the truly asm-only pieces (the entry
stub, the ISR trampoline table, and the handful of single-instruction
primitives in `lowlevel.asm`) are NASM. See `docs/cx-integration.md`
for how cX grew the pointer support that made this possible.

## Memory management 🟡

- [x] Virtual memory — `memory/virtual.cx`: Kernel24's own 4-level page
      tables (PML4/PDPT/PD/PT, 4 KiB pages), a general `vmm_map`/
      `vmm_unmap`/`vmm_translate`, and a CR3 switch off of XLoader's
      tables entirely. Still only identity-maps the same 0-8 MiB
      `memory/physical.cx` already tracks — see that file's comment for
      the (safe, understood, deliberately deferred) next step.
- [x] Kernel heap — `memory/heap.cx`: `kmalloc`/`kfree` on a real
      address-ordered free list (first-fit, splits on alloc, forward-
      coalesces on free), built on `vmm_map` + `pmm_alloc_page`. See the
      file's own comment for what it deliberately doesn't do yet
      (backward coalescing, returning pages to the PMM, double-free
      detection).
- [ ] Everything past that: no per-allocation tracking/stats beyond a
      total-free-bytes counter, no `vfree`-style unmapping when the heap
      shrinks (it never does yet), no NX/W^X page protection.

**Verification note, different from the rest of this file:** the
"Early stage" section above was checked by actually building and
disassembling a real binary. This section wasn't — the environment this
was written in has no `nasm`, so the real pipeline (cX → asm → nasm →
ld → objcopy) can't run end to end here. What *was* checked: every new
and modified `.cx` file compiles clean through the real
`x86_64-elf-cxc` (built from source in that same environment) all the
way through lexing, parsing, semantic analysis, and IR/assembly
generation via its `--emit-asm` flag — which catches type errors, wrong
signatures, unknown identifiers, and the like, but not link-time or
runtime bugs. Build and boot-test this before trusting it the way the
rest of this checklist has earned.

## Not started

Interrupt handling beyond CPU exceptions (no PIC remap, so IRQs stay
masked), scheduling, drivers beyond the screen, a filesystem, system
calls, a shell. See `docs/design.md` for what's deliberately deferred
and why, and `docs/cx-integration.md` for the handful of things cX
still can't express (8/16-bit integer widths, mainly) and how the
kernel code works around them today.
