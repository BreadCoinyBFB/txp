# Kernel24 design

## The hand-off contract (XLoader → Kernel24)

Kernel24 is entered directly by a computed jump — there's no ELF loader,
no Multiboot parsing, nothing. That means the contract has to be exact:

- **Load address**: `0x100000` (1 MiB), physical = virtual (identity-mapped
  by XLoader's page tables).
- **Image header**: the first 8 bytes are `KERNEL24_MAGIC` (4 bytes) then
  a checksum (4 bytes) — see `linker.ld` and `tools/patch_checksum.py`.
  XLoader's `kernel24_verify` checks both before jumping in.
- **Entry point**: `0x100008` (load address + 8, past the header) — this
  is `_start` in `boot/entry.asm`, and `linker.ld` is written specifically
  to guarantee it lands exactly there (see the comment in `linker.ld`
  about why the header and `.text` share one output section).
- **CPU state at entry**: 64-bit long mode, XLoader's flat GDT already
  loaded, paging enabled with the first 8 MiB identity-mapped, interrupts
  off, `RSP = 0x90000` (a throwaway stack — `_start`'s first job is
  switching off of it), `RDI` = pointer to XLoader's `BootInfo` struct.

## Memory map

| Address              | Contents |
|-----------------------|----------|
| `0x00000000`–`0x1FFFFF` | Unconditionally reserved by the PMM (see below) — covers the IVT/BDA, XLoader itself, its page tables, the E820 map, BootInfo, and Kernel24's own image |
| `0x00100000` (1 MiB)  | Kernel24's load address (8-byte header, then `_start`) |
| `__bss_start`–`__bss_end` | Kernel24's `.bss` — IDT (4 KiB), PMM bitmap (256 B), 16 KiB kernel stack |
| `0x00200000`–`0x007FFFFF` | Tracked by the PMM per the E820 map (usable vs. reserved) |
| `0x00800000` (8 MiB)  | End of XLoader's identity mapping — the PMM doesn't track anything past here yet |

The physical memory manager deliberately doesn't track anything past
8 MiB: XLoader's page tables only identity-map that much (see XLoader's
own `docs/memory-map.md`), so a "free" page beyond it would fault the
instant anything tried to use it. Tracking more becomes possible once
Kernel24 builds its own page tables — see `memory/virtual.cx` below.

## What's here vs. not

**Implemented** (see `docs/roadmap.md` for the checklist mapping):
screen output (VGA text), a bitmap physical memory manager seeded from
the E820 map, Kernel24's own 4-level page tables with a general
`vmm_map`/`vmm_unmap` (`memory/virtual.cx`), a free-list kernel heap
built on top of that (`memory/heap.cx`), a full 256-vector IDT with
reporting (not recovering) handlers, and the boot hand-off itself.

**Deliberately not here yet**:
- **Kernel24's own GDT** — XLoader's flat 64-bit GDT (`CODE64_SEG`,
  `DATA64_SEG`) already covers everything a single-ring kernel with no
  user processes needs. A real GDT (with user-mode segments and a TSS)
  becomes necessary once there's a reason to leave ring 0.
- **A dedicated IST stack for double-fault safety** — every IDT entry
  uses `IST=0` (run handlers on whatever stack was active). Fine with one
  kernel stack and no ring transitions; revisit once a corrupted stack
  during a fault becomes a real risk.
- **Tracking more than 8 MiB of physical memory** — `memory/virtual.cx`
  makes this safe to attempt (Kernel24 no longer depends on XLoader's
  own page tables at all), but bumping `PMM_MANAGED_LIMIT` needs the
  change checked against real E820/RAM data, which isn't possible in the
  environment this was written in. See that file's own comment for the
  exact next step.
- **Freeing physical pages back from the heap**, and **backward
  coalescing** of freed heap blocks — see `memory/heap.cx`'s own comment
  for both; neither has come up as a real problem yet.
- **IRQs** — the IDT is fully built and loaded, but interrupts stay
  masked (see `kernel/main.cx`) since there's no PIC remap yet. CPU exceptions
  (vectors 0-31) still reach their handler regardless — those aren't
  gated by the `IF` flag. Next up per `docs/roadmap.md`.
