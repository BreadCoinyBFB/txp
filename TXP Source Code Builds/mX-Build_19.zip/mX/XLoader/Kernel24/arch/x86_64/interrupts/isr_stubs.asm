; ============================================================================
; isr_stubs.asm — 256 tiny trampolines, one per interrupt vector
; ============================================================================
; The CPU only pushes a hardware error code for a handful of exception
; vectors (8, 10-14, 17 are the classic set that still applies today);
; everything else gets a dummy zero pushed here instead, so the shared
; handler below can always assume the same stack shape regardless of which
; vector fired: [error_code][vector_number].
;
; "Empty handlers are fine" per the early-stage brief — these don't attempt
; any real recovery. They exist so an unexpected interrupt produces a clear
; on-screen message and a controlled halt instead of a silent triple fault.

BITS 64

extern interrupt_handler

section .text

%macro ISR_NOERR 1
global isr%1
isr%1:
    push qword 0         ; dummy error code, keeps the stack shape uniform
    push qword %1
    jmp isr_common_stub
%endmacro

%macro ISR_ERR 1
global isr%1
isr%1:
    push qword %1         ; CPU already pushed the real error code below this
    jmp isr_common_stub
%endmacro

; Vectors 0-31: CPU exceptions. Only these ever carry a real error code.
%assign i 0
%rep 32
    %if i = 8 || i = 10 || i = 11 || i = 12 || i = 13 || i = 14 || i = 17
        ISR_ERR i
    %else
        ISR_NOERR i
    %endif
    %assign i i+1
%endrep

; Vectors 32-255: everything else (IRQs and unused vectors). None of these
; push a hardware error code.
%assign i 32
%rep 224
    ISR_NOERR i
    %assign i i+1
%endrep

; Stack layout on entry (top to bottom): vector_number, error_code, then
; the CPU-pushed frame (RIP/CS/RFLAGS/RSP/SS). After the 15 pushes below,
; vector_number sits at [rsp+15*8] and error_code at [rsp+15*8+8] — call
; interrupt_handler(vector, error_code) per the System V AMD64 convention
; (first arg in RDI, second in RSI).
isr_common_stub:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov rdi, [rsp + 15*8]
    mov rsi, [rsp + 15*8 + 8]
    call interrupt_handler

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    add rsp, 16           ; discard vector_number and error_code
    iretq

; isr_stub_table: 256 pointers, so idt.c can wire up all 256 IDT entries
; with a plain loop instead of 256 hand-written lines.
section .rodata
global isr_stub_table
isr_stub_table:
%assign i 0
%rep 256
    dq isr %+ i
    %assign i i+1
%endrep

section .note.GNU-stack noalloc noexec nowrite progbits
