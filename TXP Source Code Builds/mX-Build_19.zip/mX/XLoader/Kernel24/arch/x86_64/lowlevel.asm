; lowlevel.asm — CPU/port-I/O primitives cX can't express (no inline asm,
; no way to force an exact packed byte layout). Replaces the old
; arch/x86_64/cpu/cpu.c and arch/x86_64/io.h: every function here is
; called from cX via a matching `extern fn` declaration, using the
; ordinary System V AMD64 calling convention (integer args in RDI, RSI,
; RDX, ...; return value in RAX). Nothing here does anything cleverer
; than what the original C/inline-asm did — this is a direct translation,
; not a redesign.

BITS 64
section .text

; void outb(int port, int val) — writes the low byte of val to the low
; 16 bits of port. Unused today (no driver needs it yet), kept on hand
; for the same reason the original io.h did.
global outb
outb:
    mov dx, di
    mov al, sil
    out dx, al
    ret

; int inb(int port) -> 0-255 in EAX
global inb
inb:
    mov dx, di
    xor eax, eax
    in al, dx
    ret

; void io_wait(void) — the traditional "write to an unused port" delay
global io_wait
io_wait:
    mov al, 0
    out 0x80, al
    ret

global cx_cli
cx_cli:
    cli
    ret

global cx_sti
cx_sti:
    sti
    ret

global cx_hlt
cx_hlt:
    hlt
    ret

; long read_cr2(void) — the faulting address after a page fault
global read_cr2
read_cr2:
    mov rax, cr2
    ret

; bool cpu_verify_long_mode(void) -> 0 or 1 in AL.
; Same two checks the original cpu.c made: CPUID reports long-mode
; *capability* (extended function 0x80000001, EDX bit 29), and EFER.LMA
; (bit 10) shows we're *actually* in it right now, not just capable of
; getting there.
global cpu_verify_long_mode
cpu_verify_long_mode:
    push rbx
    mov eax, 0x80000001
    cpuid
    test edx, (1 << 29)
    jz .no
    mov ecx, 0xC0000080     ; IA32_EFER
    rdmsr
    test eax, (1 << 10)     ; LMA
    jz .no
    mov al, 1
    pop rbx
    ret
.no:
    mov al, 0
    pop rbx
    ret

; void idt_load(long base, int limit)
; Builds the CPU's required {limit:u16, base:u64} 10-byte IDTR on the
; stack — the one place in the old idt.c that genuinely needed an exact,
; padding-free byte layout cX has no way to express (no packed-struct
; attribute) — and executes lidt. System V: base in RDI, limit in ESI.
global idt_load
idt_load:
    sub rsp, 16
    mov [rsp], si
    mov [rsp + 2], rdi
    lidt [rsp]
    add rsp, 16
    ret

; long kernel_image_end(void) — the linker-provided __bss_end symbol
; (see linker.ld), as an address value. physical.cx needs this to know
; where Kernel24's own image ends so it can reserve those pages; cX has
; no syntax for "the address of a symbol with no cX-visible storage of
; its own", so this one function stands in for the `extern char
; __bss_end[]` trick the original C used.
extern __bss_end
global kernel_image_end
kernel_image_end:
    lea rax, [rel __bss_end]
    ret

; void write_cr3(long addr) — loads a new PML4 physical address, i.e.
; switches page tables. memory/virtual.cx's vmm_init calls this exactly
; once, after its own tables are fully built and known-safe.
global write_cr3
write_cr3:
    mov cr3, rdi
    ret

; long read_cr3(void) — the current PML4 physical address. Not on the
; critical path for anything yet; kept on hand for debugging, same
; reasoning as outb/inb before any driver used them.
global read_cr3
read_cr3:
    mov rax, cr3
    ret

; void invlpg(long addr) — flushes one stale TLB entry after
; memory/virtual.cx changes what a virtual address maps to.
global invlpg
invlpg:
    invlpg [rdi]
    ret

; 4 KiB scratch buffer for idt.cx to build the IDT in — needs static
; storage that outlives idt_init()'s own stack frame (the CPU keeps
; reading it via the lidt'd pointer forever after), which is exactly what
; cX's own variables can't provide (locals are stack-transient; cX has
; no global-buffer-of-this-size convention beyond simple scalars/small
; arrays). 256 entries * 16 bytes each.
section .bss
align 16
global idt_table
idt_table:
    resb 4096

section .note.GNU-stack noalloc noexec nowrite progbits
